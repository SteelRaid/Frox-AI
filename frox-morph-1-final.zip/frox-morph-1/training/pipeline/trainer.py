"""
Frox AI Morph 1 — Training Pipeline
Supports:
  - Pretraining from scratch (text only first)
  - Multimodal fine-tuning (text + image + video)
  - QLoRA for Colab Free T4 (15GB)
  - Auto-resume from Google Drive checkpoint
  - Scales to full training when you upgrade hardware
"""
from __future__ import annotations

import gc
import json
import math
import os
import time
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Tuple

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset, IterableDataset

from config.model_config import MorphConfig, MorphTextConfig
from model.architecture.morph_model import MorphForCausalLM


# ── Dataset ───────────────────────────────────────────────────────

class MorphTextDataset(IterableDataset):
    """
    Streaming text dataset — works without loading everything into RAM.
    Sources:
      - FineWeb (high quality web text)
      - OpenHermes (instruction following)
      - Custom data (your own examples)
    """

    def __init__(
        self,
        tokenizer,
        seq_len: int = 2048,
        dataset_name: str = "HuggingFaceFW/fineweb-edu",
        dataset_split: str = "train",
        shuffle_buffer: int = 1000,
    ):
        self.tokenizer = tokenizer
        self.seq_len = seq_len
        self.dataset_name = dataset_name
        self.dataset_split = dataset_split
        self.shuffle_buffer = shuffle_buffer

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        from datasets import load_dataset

        dataset = load_dataset(
            self.dataset_name,
            split=self.dataset_split,
            streaming=True,
            trust_remote_code=True,
        ).shuffle(buffer_size=self.shuffle_buffer)

        token_buffer = []

        for example in dataset:
            text = example.get("text", example.get("content", ""))
            if not text or len(text) < 100:
                continue

            tokens = self.tokenizer.encode(text, add_special_tokens=True)
            token_buffer.extend(tokens)
            token_buffer.append(self.tokenizer.eos_token_id)

            # Yield complete sequences
            while len(token_buffer) >= self.seq_len + 1:
                chunk = token_buffer[:self.seq_len + 1]
                token_buffer = token_buffer[self.seq_len:]

                input_ids = torch.tensor(chunk[:-1], dtype=torch.long)
                labels    = torch.tensor(chunk[1:],  dtype=torch.long)

                yield {"input_ids": input_ids, "labels": labels}


class MorphInstructionDataset(Dataset):
    """
    Instruction-following dataset for SFT.
    Format: system + user turn + assistant turn
    """

    SYSTEM_PROMPT = (
        "You are Frox AI Morph 1, a highly capable multimodal AI assistant. "
        "You can understand text, images, and video. "
        "You can generate images, videos, and 3D models on request. "
        "Always be helpful, accurate, and honest."
    )

    def __init__(
        self,
        tokenizer,
        data_path: Optional[str] = None,
        dataset_name: str = "teknium/OpenHermes-2.5",
        max_samples: int = 50000,
        seq_len: int = 4096,
    ):
        self.tokenizer = tokenizer
        self.seq_len = seq_len
        self.examples = []

        if data_path and os.path.exists(data_path):
            self._load_local(data_path)
        else:
            self._load_hub(dataset_name, max_samples)

    def _load_hub(self, dataset_name: str, max_samples: int):
        from datasets import load_dataset
        dataset = load_dataset(dataset_name, split=f"train[:{max_samples}]")
        for ex in dataset:
            self.examples.append({
                "system": ex.get("system_prompt", self.SYSTEM_PROMPT),
                "user":   ex.get("human", ex.get("instruction", "")),
                "assistant": ex.get("gpt", ex.get("output", "")),
            })

    def _load_local(self, path: str):
        with open(path) as f:
            data = json.load(f)
        for ex in data:
            self.examples.append({
                "system": ex.get("system", self.SYSTEM_PROMPT),
                "user":   ex.get("user", ex.get("instruction", "")),
                "assistant": ex.get("assistant", ex.get("output", "")),
            })

    def _format(self, ex: Dict) -> str:
        """Format using Llama 3 chat template."""
        return (
            f"<|begin_of_text|>"
            f"<|start_header_id|>system<|end_header_id|>\n{ex['system']}<|eot_id|>"
            f"<|start_header_id|>user<|end_header_id|>\n{ex['user']}<|eot_id|>"
            f"<|start_header_id|>assistant<|end_header_id|>\n{ex['assistant']}<|eot_id|>"
        )

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        text = self._format(self.examples[idx])
        tokens = self.tokenizer.encode(text, max_length=self.seq_len, truncation=True)

        input_ids = torch.tensor(tokens[:-1], dtype=torch.long)
        labels    = torch.tensor(tokens[1:],  dtype=torch.long)

        # Mask system and user tokens from loss (only train on assistant)
        # Find assistant start position
        asst_start = self._find_assistant_start(tokens)
        if asst_start > 0:
            labels[:asst_start - 1] = -100  # ignore_index

        return {"input_ids": input_ids, "labels": labels}

    def _find_assistant_start(self, tokens: List[int]) -> int:
        """Find where assistant response starts."""
        # Decode tokens to find the assistant marker
        text = self.tokenizer.decode(tokens)
        marker = "<|start_header_id|>assistant<|end_header_id|>"
        pos = text.rfind(marker)
        if pos == -1:
            return 0
        # Convert character position to token position (approximate)
        prefix_tokens = self.tokenizer.encode(text[:pos + len(marker)])
        return len(prefix_tokens)


def collate_fn(batch: List[Dict]) -> Dict[str, torch.Tensor]:
    """Pad batch to same length."""
    max_len = max(x["input_ids"].shape[0] for x in batch)

    input_ids_padded = []
    labels_padded    = []
    attention_masks  = []

    for x in batch:
        pad_len = max_len - x["input_ids"].shape[0]
        input_ids_padded.append(
            torch.cat([x["input_ids"], torch.zeros(pad_len, dtype=torch.long)])
        )
        labels_padded.append(
            torch.cat([x["labels"], torch.full((pad_len,), -100, dtype=torch.long)])
        )
        attention_masks.append(
            torch.cat([torch.ones(x["input_ids"].shape[0]), torch.zeros(pad_len)])
        )

    return {
        "input_ids":      torch.stack(input_ids_padded),
        "labels":         torch.stack(labels_padded),
        "attention_mask": torch.stack(attention_masks),
    }


# ── Optimizer & Scheduler ─────────────────────────────────────────

def build_optimizer(model: nn.Module, lr: float, weight_decay: float) -> torch.optim.Optimizer:
    """
    AdamW with weight decay on non-bias/norm parameters.
    paged_adamw_32bit when bitsandbytes available (Colab).
    """
    decay_params = []
    no_decay_params = []

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if "bias" in name or "norm" in name or "embedding" in name:
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    groups = [
        {"params": decay_params,    "weight_decay": weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ]

    try:
        import bitsandbytes as bnb
        return bnb.optim.PagedAdamW32bit(groups, lr=lr)
    except ImportError:
        return torch.optim.AdamW(groups, lr=lr)


def build_cosine_scheduler(
    optimizer,
    warmup_steps: int,
    total_steps: int,
    min_lr_ratio: float = 0.1,
):
    """Cosine decay with linear warmup."""
    from torch.optim.lr_scheduler import LambdaLR

    def lr_lambda(step: int) -> float:
        if step < warmup_steps:
            return step / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return max(min_lr_ratio, 0.5 * (1.0 + math.cos(math.pi * progress)))

    return LambdaLR(optimizer, lr_lambda)


# ── LoRA for Colab ────────────────────────────────────────────────

def apply_lora(
    model: MorphForCausalLM,
    rank: int = 16,
    alpha: int = 32,
    dropout: float = 0.05,
    target_modules: Optional[List[str]] = None,
) -> nn.Module:
    """
    Apply LoRA adapters for parameter-efficient fine-tuning.
    Required for Colab Free T4 (15GB VRAM).
    """
    from peft import LoraConfig, get_peft_model, TaskType

    if target_modules is None:
        target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                          "gate_proj", "up_proj", "down_proj"]

    config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=rank,
        lora_alpha=alpha,
        lora_dropout=dropout,
        target_modules=target_modules,
        bias="none",
    )

    model = get_peft_model(model, config)
    model.print_trainable_parameters()
    return model


def apply_4bit_quantization(model_id: str) -> Tuple:
    """Load model with 4-bit QLoRA quantization for Colab."""
    from transformers import BitsAndBytesConfig, AutoTokenizer
    from transformers import AutoModelForCausalLM

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
    )
    return bnb_config


# ── Main Trainer ──────────────────────────────────────────────────

class MorphTrainer:
    """
    Training orchestrator for Frox Morph 1.
    - Handles pretraining and SFT
    - Auto-saves to Google Drive
    - Auto-resumes from checkpoint
    - Gradient accumulation for Colab's small batch size
    - Mixed precision (bfloat16)
    """

    def __init__(
        self,
        model: nn.Module,
        tokenizer,
        config: MorphConfig,
        train_dataset: Dataset,
        device: torch.device,
        save_path: str = "/content/drive/MyDrive/frox-morph-1",
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.dataset = train_dataset
        self.device = device
        self.save_path = Path(save_path)
        self.save_path.mkdir(parents=True, exist_ok=True)

        tc = config.training

        # DataLoader
        self.dataloader = DataLoader(
            train_dataset,
            batch_size=tc.sft_batch_size,
            collate_fn=collate_fn,
            num_workers=0,
            pin_memory=True,
        )

        # Optimizer
        self.optimizer = build_optimizer(model, tc.sft_lr, tc.weight_decay)

        # Scaler for mixed precision
        self.scaler = torch.cuda.amp.GradScaler(enabled=True)

        # Step tracking
        self.global_step = 0
        self.best_loss = float("inf")

        # Load checkpoint if exists
        self._try_resume()

    def _try_resume(self):
        """Resume from last checkpoint if available."""
        ckpt_path = self.save_path / "latest_checkpoint.pt"
        if ckpt_path.exists():
            print(f"📂 Resuming from {ckpt_path}")
            ckpt = torch.load(ckpt_path, map_location="cpu")
            self.model.load_state_dict(ckpt["model_state"], strict=False)
            self.optimizer.load_state_dict(ckpt["optimizer_state"])
            self.global_step = ckpt["step"]
            self.best_loss = ckpt.get("best_loss", float("inf"))
            print(f"✓ Resumed from step {self.global_step}")

    def save_checkpoint(self, loss: float):
        """Save checkpoint to Google Drive."""
        ckpt = {
            "model_state":    self.model.state_dict(),
            "optimizer_state": self.optimizer.state_dict(),
            "step":           self.global_step,
            "best_loss":      min(self.best_loss, loss),
            "config":         self.config,
        }
        # Save latest
        torch.save(ckpt, self.save_path / "latest_checkpoint.pt")

        # Save numbered checkpoint every 500 steps
        if self.global_step % 500 == 0:
            torch.save(ckpt, self.save_path / f"checkpoint_step_{self.global_step}.pt")

        print(f"💾 Saved checkpoint at step {self.global_step} | loss={loss:.4f}")

    def train(self, max_steps: Optional[int] = None):
        """Main training loop."""
        tc = self.config.training
        max_steps = max_steps or tc.sft_max_steps
        grad_accum = tc.sft_grad_accum

        # Build scheduler now that we know total steps
        scheduler = build_cosine_scheduler(
            self.optimizer,
            warmup_steps=min(100, max_steps // 10),
            total_steps=max_steps,
        )
        # Advance scheduler to current step
        for _ in range(self.global_step):
            scheduler.step()

        self.model.train()
        self.model.to(self.device)

        print(f"\n🚀 Starting Frox Morph 1 Training")
        print(f"   Steps: {self.global_step} → {max_steps}")
        print(f"   Device: {self.device}")
        print(f"   Batch: {tc.sft_batch_size} × {grad_accum} accum = {tc.sft_batch_size * grad_accum} effective")
        print(f"   Save path: {self.save_path}\n")

        self.optimizer.zero_grad()
        running_loss = 0.0
        t0 = time.time()

        for batch in self.dataloader:
            if self.global_step >= max_steps:
                break

            # Move to device
            input_ids      = batch["input_ids"].to(self.device)
            labels         = batch["labels"].to(self.device)
            attention_mask = batch["attention_mask"].to(self.device)

            # Forward with mixed precision
            with torch.cuda.amp.autocast(dtype=torch.bfloat16):
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels,
                )
                loss = outputs.loss / grad_accum

            # Backward
            self.scaler.scale(loss).backward()
            running_loss += loss.item() * grad_accum

            # Gradient accumulation step
            if (self.global_step + 1) % grad_accum == 0:
                # Clip gradients
                self.scaler.unscale_(self.optimizer)
                nn.utils.clip_grad_norm_(
                    self.model.parameters(),
                    tc.max_grad_norm,
                )
                self.scaler.step(self.optimizer)
                self.scaler.update()
                scheduler.step()
                self.optimizer.zero_grad()

                avg_loss = running_loss / grad_accum
                running_loss = 0.0

                # Logging
                if self.global_step % tc.logging_steps == 0:
                    lr = scheduler.get_last_lr()[0]
                    elapsed = time.time() - t0
                    tokens_per_sec = (
                        tc.sft_batch_size * tc.sft_seq_len *
                        tc.logging_steps / elapsed
                    )
                    print(
                        f"Step {self.global_step:>6} | "
                        f"loss={avg_loss:.4f} | "
                        f"lr={lr:.2e} | "
                        f"{tokens_per_sec:.0f} tok/s"
                    )
                    t0 = time.time()

                # Save checkpoint
                if self.global_step % tc.save_steps == 0:
                    self.save_checkpoint(avg_loss)
                    # Free memory after save
                    gc.collect()
                    torch.cuda.empty_cache()

            self.global_step += 1

        # Final save
        self.save_checkpoint(running_loss)
        print("\n✅ Training complete!")

        return self
