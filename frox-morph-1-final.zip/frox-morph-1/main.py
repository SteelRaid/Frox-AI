"""
Frox AI Morph 1 — Main Entry Point
No gated repos. No HuggingFace auth. Runs on Colab Free T4 (15GB).

Usage:
  python main.py --mode demo       # test architecture (no training needed)
  python main.py --mode train      # full training run
  python main.py --mode colab      # Colab-optimized (mounts Drive, auto-corpus)
  python main.py --mode inference  # interactive chat after training
  python main.py --mode info       # print model sizes
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import torch


def get_device() -> torch.device:
    if torch.cuda.is_available():
        name = torch.cuda.get_device_name(0)
        vram = torch.cuda.get_device_properties(0).total_memory / 1e9
        print(f"✓ GPU: {name} ({vram:.1f} GB VRAM)")
        return torch.device("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        print("✓ Apple MPS")
        return torch.device("mps")
    else:
        print("⚠ CPU only — training will be slow")
        return torch.device("cpu")


def get_vram_gb() -> float:
    if torch.cuda.is_available():
        return torch.cuda.get_device_properties(0).total_memory / 1e9
    return 0.0


def pick_config_for_vram():
    """Auto-select model scale based on available VRAM."""
    from config.model_config import MorphConfig
    vram = get_vram_gb()
    if vram < 10:
        print(f"📱 VRAM={vram:.1f}GB → using 1.5B config (Colab Free T4)")
        return MorphConfig.scale_1_5b()
    elif vram < 25:
        print(f"💻 VRAM={vram:.1f}GB → using 3B config")
        return MorphConfig.scale_3b()
    else:
        print(f"🚀 VRAM={vram:.1f}GB → using 8B config")
        return MorphConfig.scale_8b()


# ── mode: info ────────────────────────────────────────────────────

def mode_info():
    from config.model_config import MorphConfig
    from model.architecture.morph_model import MorphForCausalLM

    print("\n" + "=" * 60)
    print("  FROX AI MORPH 1 — Model Information")
    print("=" * 60)

    for name, cfg in [
        ("1.5B (Colab Free T4)", MorphConfig.scale_1_5b()),
        ("3B   (Colab Pro A100)", MorphConfig.scale_3b()),
        ("8B   (Upgrade GPU)",    MorphConfig.scale_8b()),
    ]:
        m = MorphForCausalLM(cfg.text)
        p = m.param_count()
        print(f"\n  [{name}]")
        print(f"    Params:         {p['total_billions']}B")
        print(f"    Hidden size:    {cfg.text.hidden_size}")
        print(f"    Layers:         {cfg.text.num_hidden_layers}")
        print(f"    Heads (Q/KV):   {cfg.text.num_attention_heads}/{cfg.text.num_key_value_heads}")
        print(f"    Context:        {cfg.text.max_position_embeddings:,} tokens")
        print(f"    Vocab:          {cfg.text.vocab_size:,}")
        del m

    print("\n  Multimodal modules:")
    print("    Vision:    ViT-L/14 encoder → MLP projector")
    print("    Video:     3D patch encoder + Wan2.2 temporal RoPE")
    print("    Image gen: SDXL (diffusers) or Fooocus API")
    print("    Video gen: Wan2.2 T2V")
    print("    3D recon:  TripoSR")
    print("    Workflow:  ComfyUI API")
    print("=" * 60 + "\n")


# ── mode: demo ────────────────────────────────────────────────────

def mode_demo():
    """
    Tests the full pipeline with real tokenizer + real forward pass.
    No training needed. No gated repos.
    """
    from config.model_config import MorphConfig
    from model.architecture.morph_model import MorphForCausalLM
    from tokenizer.morph_tokenizer import build_morph_tokenizer, apply_chat_template

    print("\n🎯 Frox AI Morph 1 — Architecture Demo")
    print("   Real tokenizer + real model + real forward pass\n")

    device = get_device()
    config = MorphConfig.scale_1_5b()

    # ── Step 1: Real tokenizer (no FakeTokenizer) ─────────────────
    print("1. Building tokenizer (auto-corpus)...")
    tokenizer = build_morph_tokenizer(
        vocab_size=config.text.vocab_size,
    )
    print(f"   Vocab size: {len(tokenizer):,} tokens ✓")

    # ── Step 2: Real model ────────────────────────────────────────
    print("\n2. Building 1.5B model...")
    # Resize vocab to match tokenizer
    config.text.vocab_size = len(tokenizer)
    model = MorphForCausalLM(config.text)
    model.eval()
    p = model.param_count()
    print(f"   Parameters: {p['total_billions']}B ✓")

    # ── Step 3: Real tokenization ─────────────────────────────────
    print("\n3. Tokenizing test prompt...")
    messages = [{"role": "user", "content": "What is Frox AI Morph 1?"}]
    prompt = apply_chat_template(messages, tokenizer, add_generation_prompt=True)
    input_ids = tokenizer.encode(prompt, return_tensors="pt").to(device)
    model = model.to(device)
    print(f"   Input tokens: {input_ids.shape[1]} ✓")

    # ── Step 4: Real forward pass ─────────────────────────────────
    print("\n4. Running forward pass...")
    with torch.no_grad():
        outputs = model(input_ids=input_ids, labels=input_ids)
    print(f"   Loss:         {outputs.loss.item():.4f} ✓")
    print(f"   Logits shape: {outputs.logits.shape} ✓")

    # ── Step 5: Real greedy generation (untrained = random, expected) ─
    print("\n5. Running greedy generation (5 tokens, untrained weights)...")
    with torch.no_grad():
        gen_ids = model.generate(
            input_ids=input_ids,
            max_new_tokens=5,
            do_sample=False,
            temperature=1.0,
        )
    new_tokens = gen_ids[0][input_ids.shape[1]:]
    decoded = tokenizer.decode(new_tokens, skip_special_tokens=True)
    print(f"   Generated: '{decoded}' (random — needs training) ✓")

    print("\n✅ All systems operational!")
    print("   Architecture: working")
    print("   Tokenizer:    working")
    print("   Forward pass: working")
    print("   Generation:   working")
    print("\n   Next: python main.py --mode colab   (starts training)\n")


# ── mode: train ───────────────────────────────────────────────────

def mode_train(args):
    from config.model_config import MorphConfig
    from model.architecture.morph_model import MorphForCausalLM
    from training.pipeline.trainer import (
        MorphTrainer, MorphInstructionDataset, apply_lora,
    )
    from tokenizer.morph_tokenizer import build_morph_tokenizer

    device = get_device()
    config = pick_config_for_vram()

    if args.save_path:
        config.training.save_path = args.save_path

    # 1. Tokenizer
    print("\n1. Building tokenizer...")
    tokenizer = build_morph_tokenizer(
        tokenizer_path=args.tokenizer_path,
        corpus_files=args.corpus_file,
        save_path=os.path.join(config.training.save_path, "tokenizer"),
        vocab_size=config.text.vocab_size,
    )
    # Sync vocab size with actual tokenizer
    config.text.vocab_size = len(tokenizer)
    print(f"   Vocab size: {len(tokenizer):,}")

    # 2. Model
    print("\n2. Building model...")
    model = MorphForCausalLM(config.text)
    p = model.param_count()
    print(f"   Parameters: {p['total_billions']}B")

    # 3. LoRA
    if config.training.use_lora:
        print("\n3. Applying LoRA adapters...")
        model = apply_lora(
            model,
            rank=config.training.lora_rank,
            alpha=config.training.lora_alpha,
            target_modules=config.training.lora_target_modules,
        )

    # 4. Dataset
    print("\n4. Building dataset...")
    dataset = MorphInstructionDataset(
        tokenizer=tokenizer,
        data_path=args.data_path,
        seq_len=config.training.sft_seq_len,
    )
    print(f"   Examples: {len(dataset):,}")

    # 5. Train
    print("\n5. Starting training...")
    trainer = MorphTrainer(
        model=model,
        tokenizer=tokenizer,
        config=config,
        train_dataset=dataset,
        device=device,
        save_path=config.training.save_path,
    )
    trainer.train(max_steps=args.max_steps)


# ── mode: colab ───────────────────────────────────────────────────

def mode_colab(args):
    """
    One-click Colab training:
    - Mounts Google Drive
    - Installs dependencies
    - Auto-downloads corpus if none given
    - Starts training with safe defaults
    """
    print("🔧 Colab Mode — Setting up environment...")

    # Mount Google Drive
    try:
        from google.colab import drive
        drive.mount("/content/drive")
        save_path = "/content/drive/MyDrive/frox-morph-1"
        print("✓ Google Drive mounted")
    except ImportError:
        save_path = "./frox-morph-1-output"
        print("  Not in Colab — saving locally")

    # Install dependencies
    print("Installing dependencies...")
    os.system(
        "pip install -q transformers peft trl bitsandbytes accelerate "
        "datasets tokenizers sentencepiece einops torchvision tqdm"
    )
    print("✓ Dependencies installed")

    args.save_path = save_path
    args.max_steps = args.max_steps or 300

    # corpus_file intentionally left as None → auto-downloads WikiText-2
    mode_train(args)


# ── mode: inference ───────────────────────────────────────────────

def mode_inference(args):
    from inference.engine.morph_engine import MorphInferenceEngine

    engine = MorphInferenceEngine(
        model_path=args.model_path,
        use_4bit=(get_vram_gb() < 16),
    )

    print("\n🤖 Frox AI Morph 1 — Interactive Mode")
    print("   Commands: 'quit' | 'clear' | 'image: <prompt>' | 'video: <prompt>'\n")

    messages = []
    system = (
        "You are Frox AI Morph 1, a unified multimodal AI. "
        "You understand text, images, and video. "
        "You can generate images, videos, and 3D models. "
        "Be helpful, accurate, and creative."
    )

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() == "quit":
            break
        if user_input.lower() == "clear":
            messages = []
            print("Context cleared.\n")
            continue

        messages.append({"role": "user", "content": user_input})
        response = engine.generate(
            messages=messages,
            system_prompt=system,
            max_new_tokens=args.max_tokens,
            temperature=args.temperature,
        )
        messages.append({"role": "assistant", "content": response})
        print(f"\nMorph 1: {response}\n")


# ── CLI ───────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Frox AI Morph 1")
    parser.add_argument(
        "--mode",
        choices=["info", "demo", "train", "colab", "inference"],
        default="demo",
        help="What to do (default: demo)",
    )
    parser.add_argument("--model-path",     default="./frox-morph-1-output")
    parser.add_argument("--save-path",      default=None)
    parser.add_argument("--tokenizer-path", default=None,
                        help="Path to saved tokenizer (skip BPE training)")
    parser.add_argument("--corpus-file",    action="append", default=None,
                        help="Text file to train tokenizer from. Repeat for multiple files.")
    parser.add_argument("--data-path",      default=None,
                        help="JSON file with instruction data for SFT")
    parser.add_argument("--max-steps",  type=int,   default=None)
    parser.add_argument("--max-tokens", type=int,   default=512)
    parser.add_argument("--temperature",type=float, default=0.7)

    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("  FROX AI MORPH 1 — Unified Multimodal Intelligence")
    print("=" * 60 + "\n")

    modes = {
        "info":      mode_info,
        "demo":      mode_demo,
        "train":     lambda: mode_train(args),
        "colab":     lambda: mode_colab(args),
        "inference": lambda: mode_inference(args),
    }
    modes[args.mode]()


if __name__ == "__main__":
    main()
