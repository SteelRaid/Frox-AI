"""
Frox AI Morph 1 — Master Configuration
Architecture: Llama 3.2-class decoder-only transformer
Scales: 1.5B (Colab Free) → 3B (default) → 8B (upgrade)
Multimodal: Text + Image + Video + 3D

Merged from original + ChatGPT improvements:
  - scale_1_5b() / scale_8b() naming (ChatGPT)
  - num_extra_tokens field (ChatGPT)
  - vocab_size 32000 default to match local BPE tokenizer
  - backward-compat aliases scale_1b / scale_7b
"""
from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class MorphTextConfig:
    """Core LLM — decoder-only transformer"""
    model_type: str = "morph"
    version:    str = "1.0.0"

    # Vocabulary — matches local BPE tokenizer (no gated repos)
    vocab_size:       int = 32000
    num_extra_tokens: int = 32        # reserved for future special tokens
    pad_token_id:     int = 0
    bos_token_id:     int = 1
    eos_token_id:     int = 2

    # Architecture (3B default — Llama 3.2 3B class)
    hidden_size:            int   = 3072
    intermediate_size:      int   = 8192
    num_hidden_layers:      int   = 28
    num_attention_heads:    int   = 24
    num_key_value_heads:    int   = 8       # GQA: 3 queries per KV pair
    head_dim:               int   = 128
    max_position_embeddings:int   = 131072  # 128K context
    rope_theta:             float = 500000.0
    rope_scaling_factor:    float = 32.0

    # Normalization
    rms_norm_eps: float = 1e-5

    # Activation (SwiGLU)
    hidden_act: str = "silu"

    # Dropout (off during pretraining — standard practice)
    attention_dropout: float = 0.0
    hidden_dropout:    float = 0.0

    # Precision
    torch_dtype: str = "bfloat16"

    # Tie input/output embeddings (saves ~200M params on 3B)
    tie_word_embeddings: bool = True

    @property
    def total_vocab_size(self) -> int:
        """Actual embedding table size = vocab + reserved."""
        return self.vocab_size + self.num_extra_tokens


@dataclass
class MorphVisionConfig:
    """Vision encoder — ViT-L/14 class"""
    image_size:         int = 336
    patch_size:         int = 14
    hidden_size:        int = 1024
    num_hidden_layers:  int = 24
    num_attention_heads:int = 16
    intermediate_size:  int = 4096
    num_channels:       int = 3
    projection_dim:     int = 3072   # must match MorphTextConfig.hidden_size
    image_token_id:     int = 32000  # first token after vocab
    num_image_tokens:   int = 576    # 24×24 patches for 336px


@dataclass
class MorphVideoConfig:
    """Video understanding — 3D spatiotemporal encoder"""
    num_frames:          int   = 16
    frame_size:          int   = 224
    patch_size:          int   = 14
    temporal_patch_size: int   = 2
    hidden_size:         int   = 1024
    num_hidden_layers:   int   = 12
    num_attention_heads: int   = 16
    use_3d_rope:         bool  = True
    rope_theta:          float = 10000.0
    projection_dim:      int   = 3072
    video_token_id:      int   = 32001
    num_video_tokens:    int   = 1024


@dataclass
class MorphGenerationConfig:
    """Generation pipeline settings"""
    # Image (SDXL / Fooocus API)
    image_model:       str   = "sdxl"
    image_steps:       int   = 25
    image_cfg:         float = 7.5
    default_image_size:str   = "1024x1024"

    # Video (Wan2.2)
    video_model:         str = "wan2.2-t2v"
    video_steps:         int = 50
    video_fps:           int = 16
    default_video_frames:int = 81
    default_video_size:  str = "480x832"

    # 3D (TripoSR)
    threed_model:            str   = "triposr"
    threed_resolution:       int   = 256
    threed_foreground_ratio: float = 0.85

    # ComfyUI
    use_comfy_pipeline: bool = True
    comfy_vram_mode:    str  = "auto"

    # Fooocus API URL (set if running Fooocus separately)
    fooocus_api_url: str = "http://localhost:7860"
    comfyui_api_url: str = "http://localhost:8188"


@dataclass
class MorphTrainingConfig:
    """Training hyperparameters"""
    # Pretraining
    pretrain_batch_size:   int   = 2
    pretrain_grad_accum:   int   = 16
    pretrain_lr:           float = 3e-4
    pretrain_warmup_steps: int   = 1000
    pretrain_max_steps:    int   = 100000
    pretrain_seq_len:      int   = 2048

    # SFT
    sft_batch_size: int   = 2
    sft_grad_accum: int   = 8
    sft_lr:         float = 2e-5
    sft_max_steps:  int   = 10000
    sft_seq_len:    int   = 4096

    # LoRA (required for Colab T4)
    use_lora:            bool      = True
    lora_rank:           int       = 16
    lora_alpha:          int       = 32
    lora_dropout:        float     = 0.05
    lora_target_modules: List[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ])

    # 4-bit QLoRA quantization
    use_4bit:              bool  = True
    bnb_4bit_quant_type:   str   = "nf4"
    bnb_4bit_compute_dtype:str   = "bfloat16"

    # Optimizer (paged = memory-efficient for Colab)
    optimizer:      str   = "paged_adamw_32bit"
    weight_decay:   float = 0.1
    max_grad_norm:  float = 1.0
    lr_scheduler:   str   = "cosine"

    # Checkpointing
    save_steps:      int = 50
    save_total_limit:int = 3
    save_path:       str = "/content/drive/MyDrive/frox-morph-1"

    # Logging
    logging_steps: int = 10
    report_to:     str = "tensorboard"


@dataclass
class MorphInferenceConfig:
    """Inference settings"""
    max_new_tokens:      int   = 2048
    temperature:         float = 0.7
    top_p:               float = 0.9
    top_k:               int   = 50
    repetition_penalty:  float = 1.1
    use_flash_attention: bool  = True
    use_kv_cache:        bool  = True
    dtype:               str   = "bfloat16"
    vram_state:          str   = "auto"
    offload_to_cpu:      bool  = False
    use_8bit:            bool  = False
    use_4bit:            bool  = False


@dataclass
class MorphConfig:
    """Master config — single source of truth for everything."""
    text:       MorphTextConfig       = field(default_factory=MorphTextConfig)
    vision:     MorphVisionConfig     = field(default_factory=MorphVisionConfig)
    video:      MorphVideoConfig      = field(default_factory=MorphVideoConfig)
    generation: MorphGenerationConfig = field(default_factory=MorphGenerationConfig)
    training:   MorphTrainingConfig   = field(default_factory=MorphTrainingConfig)
    inference:  MorphInferenceConfig  = field(default_factory=MorphInferenceConfig)

    @classmethod
    def scale_1_5b(cls) -> "MorphConfig":
        """1.5B — fits Colab Free T4 (15GB) with QLoRA."""
        cfg = cls()
        cfg.text.hidden_size         = 2048
        cfg.text.intermediate_size   = 5504
        cfg.text.num_hidden_layers   = 24
        cfg.text.num_attention_heads = 16
        cfg.text.num_key_value_heads = 8
        cfg.text.head_dim            = 128
        # Adjust vision projection to match hidden size
        cfg.vision.projection_dim = 2048
        cfg.video.projection_dim  = 2048
        return cfg

    @classmethod
    def scale_3b(cls) -> "MorphConfig":
        """3B — default. Needs Colab Pro A100 for QLoRA."""
        return cls()

    @classmethod
    def scale_8b(cls) -> "MorphConfig":
        """8B — serious training. 2×A100 or better."""
        cfg = cls()
        cfg.text.hidden_size         = 4096
        cfg.text.intermediate_size   = 14336
        cfg.text.num_hidden_layers   = 48
        cfg.text.num_attention_heads = 32
        cfg.text.num_key_value_heads = 8
        cfg.text.head_dim            = 128
        cfg.vision.projection_dim    = 4096
        cfg.video.projection_dim     = 4096
        return cfg

    # Backward-compat aliases
    @classmethod
    def scale_1b(cls) -> "MorphConfig":
        return cls.scale_1_5b()

    @classmethod
    def scale_7b(cls) -> "MorphConfig":
        return cls.scale_8b()
