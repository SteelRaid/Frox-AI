"""
Frox AI Morph 1 — Tokenizer
Fully local. No gated HuggingFace repos. No 401 errors.

Priority order:
  1. Load from saved tokenizer_path (fastest, use after first run)
  2. Train BPE from your own corpus_files
  3. Auto-download a small free corpus and train (Colab zero-config mode)

Vocab size: 32000 (small = fast training) up to 100000 (production)
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Union

# ── Special tokens ────────────────────────────────────────────────

CHAT_SPECIAL_TOKENS = [
    "<|pad|>",
    "<|begin_of_text|>",
    "<|end_of_text|>",
    "<|unk|>",
    "<|eot_id|>",
    "<|start_header_id|>",
    "<|end_header_id|>",
    "<|finetune_right_pad_id|>",
    "<|step_id|>",
    "<|python_tag|>",
]

MORPH_SPECIAL_TOKENS = [
    # Multimodal
    "<|image|>",
    "<|video|>",
    "<|audio|>",
    # Generation
    "<|gen_image|>",
    "<|gen_video|>",
    "<|gen_3d|>",
    "<|/gen|>",
    # Tool use
    "<|tool_call|>",
    "<|/tool_call|>",
    "<|tool_result|>",
    "<|/tool_result|>",
    # Thinking (chain of thought)
    "<|think|>",
    "<|/think|>",
]

ALL_SPECIAL_TOKENS = CHAT_SPECIAL_TOKENS + MORPH_SPECIAL_TOKENS

# Token IDs (match MorphTextConfig)
PAD_TOKEN_ID   = 0
BOS_TOKEN_ID   = 1
EOS_TOKEN_ID   = 2
UNK_TOKEN_ID   = 3
IMAGE_TOKEN_ID = len(CHAT_SPECIAL_TOKENS)      # first Morph token
VIDEO_TOKEN_ID = len(CHAT_SPECIAL_TOKENS) + 1


def build_morph_tokenizer(
    tokenizer_path: Optional[str] = None,
    corpus_files: Optional[Sequence[str]] = None,
    save_path: Optional[str] = None,
    vocab_size: int = 32000,
):
    """
    Build Frox Morph 1 tokenizer — fully local, no gated repos.

    Args:
        tokenizer_path: Path to a previously saved tokenizer (fastest option).
        corpus_files:   List of .txt files to train BPE from scratch.
        save_path:      Where to save the tokenizer after building.
        vocab_size:     BPE vocabulary size (32000 for fast training).

    Colab zero-config: if neither tokenizer_path nor corpus_files
    are provided, a small free corpus is downloaded automatically.
    """
    from transformers import PreTrainedTokenizerFast

    print("Building Morph 1 tokenizer...")

    # ── 1. Load saved tokenizer ───────────────────────────────────
    if tokenizer_path and Path(tokenizer_path).exists():
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained(tokenizer_path, use_fast=True)
        _ensure_special_tokens(tok)
        print(f"  Loaded from: {tokenizer_path}")
        print(f"  Vocab size:  {len(tok):,}")
        if save_path:
            _save(tok, save_path)
        return tok

    # ── 2. Train from corpus files ────────────────────────────────
    if corpus_files:
        valid = [p for p in corpus_files if Path(p).exists()]
        if not valid:
            raise FileNotFoundError(
                f"None of the corpus_files exist: {corpus_files}"
            )
        print(f"  Training BPE from {len(valid)} file(s)...")
        tok_model = _train_bpe(valid, vocab_size)
        tok = _wrap_tokenizer(tok_model)
        print(f"  Vocab size:  {len(tok):,}")
        if save_path:
            _save(tok, save_path)
        return tok

    # ── 3. Auto-download small corpus (Colab zero-config) ─────────
    print("  No corpus provided — downloading WikiText-2 (free, ~4MB)...")
    corpus_path = _download_wikitext2()
    print(f"  Training BPE from downloaded corpus...")
    tok_model = _train_bpe([corpus_path], vocab_size)
    tok = _wrap_tokenizer(tok_model)
    print(f"  Vocab size:  {len(tok):,}")
    if save_path:
        _save(tok, save_path)
    return tok


def _download_wikitext2() -> str:
    """
    Download WikiText-2 (MIT license, ~4MB) without HuggingFace auth.
    Falls back to a synthetic corpus if download fails.
    """
    import urllib.request

    save_dir = Path(tempfile.gettempdir()) / "morph1_corpus"
    save_dir.mkdir(exist_ok=True)
    corpus_path = save_dir / "wikitext2.txt"

    if corpus_path.exists() and corpus_path.stat().st_size > 1_000_000:
        print(f"  Using cached corpus: {corpus_path}")
        return str(corpus_path)

    # WikiText-2 raw train split (public, no auth)
    url = (
        "https://raw.githubusercontent.com/pytorch/examples/main/"
        "word_language_model/data/wikitext-2/train.txt"
    )
    try:
        urllib.request.urlretrieve(url, str(corpus_path))
        size_mb = corpus_path.stat().st_size / 1e6
        print(f"  Downloaded {size_mb:.1f} MB")
        return str(corpus_path)
    except Exception as e:
        print(f"  Download failed ({e}) — using synthetic corpus")
        return _make_synthetic_corpus(save_dir)


def _make_synthetic_corpus(save_dir: Path) -> str:
    """
    Generate a small synthetic corpus so training never crashes.
    This gives a working tokenizer (not a great one — use real data for production).
    """
    path = save_dir / "synthetic.txt"
    sentences = [
        "The quick brown fox jumps over the lazy dog.",
        "Artificial intelligence is transforming the world.",
        "Language models learn from large amounts of text data.",
        "Neural networks have many layers of computation.",
        "Frox AI Morph 1 is a unified multimodal intelligence system.",
        "You can generate images videos and 3D models with this model.",
        "Training a model requires data computation and time.",
        "The transformer architecture uses attention mechanisms.",
        "Tokenization splits text into subword units called tokens.",
        "Byte pair encoding BPE is a common tokenization algorithm.",
    ] * 5000  # repeat to give BPE trainer enough data

    path.write_text("\n".join(sentences))
    print(f"  Synthetic corpus: {len(sentences)} sentences")
    return str(path)


def _train_bpe(corpus_paths: List[str], vocab_size: int):
    """Train a real byte-level BPE tokenizer from corpus files."""
    from tokenizers import Tokenizer
    from tokenizers.models import BPE
    from tokenizers.pre_tokenizers import ByteLevel
    from tokenizers.decoders import ByteLevel as ByteLevelDecoder
    from tokenizers.trainers import BpeTrainer

    tok = Tokenizer(BPE(unk_token="<|unk|>"))
    tok.pre_tokenizer = ByteLevel(add_prefix_space=False)
    tok.decoder = ByteLevelDecoder()

    trainer = BpeTrainer(
        vocab_size=vocab_size,
        special_tokens=ALL_SPECIAL_TOKENS,
        initial_alphabet=ByteLevel.alphabet(),
        show_progress=True,
        min_frequency=2,
    )
    tok.train(corpus_paths, trainer)
    return tok


def _wrap_tokenizer(tok_model) -> "PreTrainedTokenizerFast":
    """Wrap tokenizers.Tokenizer into a HuggingFace PreTrainedTokenizerFast."""
    from transformers import PreTrainedTokenizerFast

    tok = PreTrainedTokenizerFast(
        tokenizer_object=tok_model,
        bos_token="<|begin_of_text|>",
        eos_token="<|end_of_text|>",
        unk_token="<|unk|>",
        pad_token="<|pad|>",
        additional_special_tokens=ALL_SPECIAL_TOKENS,
    )

    # Set chat template
    tok.chat_template = MORPH_CHAT_TEMPLATE
    return tok


def _ensure_special_tokens(tok):
    """Make sure a loaded tokenizer has all Morph special tokens."""
    missing = [t for t in ALL_SPECIAL_TOKENS if t not in tok.get_vocab()]
    if missing:
        tok.add_special_tokens({"additional_special_tokens": missing})
        print(f"  Added {len(missing)} missing special tokens")

    if tok.pad_token is None:
        tok.add_special_tokens({"pad_token": "<|pad|>"})
    if tok.bos_token is None:
        tok.add_special_tokens({"bos_token": "<|begin_of_text|>"})
    if tok.eos_token is None:
        tok.add_special_tokens({"eos_token": "<|end_of_text|>"})


def _save(tok, save_path: str):
    Path(save_path).mkdir(parents=True, exist_ok=True)
    tok.save_pretrained(save_path)
    print(f"  Saved to: {save_path}")


# ── Chat template ─────────────────────────────────────────────────

MORPH_CHAT_TEMPLATE = (
    "{%- set system_message = '' -%}"
    "{%- if messages[0]['role'] == 'system' -%}"
    "{%- set system_message = messages[0]['content'] -%}"
    "{%- set messages = messages[1:] -%}"
    "{%- endif -%}"
    "<|begin_of_text|>"
    "{%- if system_message -%}"
    "<|start_header_id|>system<|end_header_id|>\n"
    "{{ system_message }}<|eot_id|>"
    "{%- endif -%}"
    "{%- for message in messages -%}"
    "<|start_header_id|>{{ message['role'] }}<|end_header_id|>\n"
    "{{ message['content'] }}<|eot_id|>"
    "{%- endfor -%}"
    "{%- if add_generation_prompt -%}"
    "<|start_header_id|>assistant<|end_header_id|>\n"
    "{%- endif -%}"
)


def apply_chat_template(
    messages: List[Dict[str, str]],
    tokenizer,
    add_generation_prompt: bool = True,
    system_prompt: Optional[str] = None,
) -> str:
    if system_prompt and (not messages or messages[0]["role"] != "system"):
        messages = [{"role": "system", "content": system_prompt}] + messages

    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )
    except Exception:
        # Manual fallback
        parts = ["<|begin_of_text|>"]
        for msg in messages:
            parts.append(
                f"<|start_header_id|>{msg['role']}<|end_header_id|>\n"
                f"{msg['content']}<|eot_id|>"
            )
        if add_generation_prompt:
            parts.append("<|start_header_id|>assistant<|end_header_id|>\n")
        return "".join(parts)
