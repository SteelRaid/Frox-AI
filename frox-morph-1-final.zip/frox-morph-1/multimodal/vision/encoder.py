"""
Frox AI Morph 1 — Vision Encoder
Encodes images into token embeddings the LLM can read.
Architecture: ViT + MLP projector → text embedding space
Based on: Wan2.2 vision + CodinIT multimodal pattern
"""
from __future__ import annotations

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

from model.attention.gqa import MorphRMSNorm


class VisionPatchEmbedding(nn.Module):
    """
    Split image into patches and project to hidden dim.
    336px image / 14px patches = 24×24 = 576 patches (tokens).
    """

    def __init__(
        self,
        image_size: int = 336,
        patch_size: int = 14,
        num_channels: int = 3,
        hidden_size: int = 1024,
    ):
        super().__init__()
        self.image_size = image_size
        self.patch_size = patch_size
        self.num_patches = (image_size // patch_size) ** 2
        self.num_patches_side = image_size // patch_size

        # Conv2d = efficient patch extraction
        self.projection = nn.Conv2d(
            num_channels, hidden_size,
            kernel_size=patch_size, stride=patch_size, bias=False,
        )

        # CLS token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, hidden_size))

        # Positional embedding
        self.position_embedding = nn.Embedding(self.num_patches + 1, hidden_size)

        nn.init.trunc_normal_(self.cls_token, std=0.02)
        nn.init.trunc_normal_(self.position_embedding.weight, std=0.02)

    def forward(self, pixel_values: torch.Tensor) -> torch.Tensor:
        """
        pixel_values: [B, 3, H, W]
        returns: [B, num_patches+1, hidden_size]
        """
        B = pixel_values.shape[0]

        # Patch projection
        x = self.projection(pixel_values)           # [B, hidden, H/p, W/p]
        x = rearrange(x, 'b c h w -> b (h w) c')   # [B, num_patches, hidden]

        # Prepend CLS token
        cls = self.cls_token.expand(B, -1, -1)
        x = torch.cat([cls, x], dim=1)              # [B, num_patches+1, hidden]

        # Add positional embeddings
        positions = torch.arange(x.shape[1], device=x.device)
        x = x + self.position_embedding(positions)

        return x


class VisionAttention(nn.Module):
    """Standard multi-head attention for vision encoder."""

    def __init__(self, hidden_size: int, num_heads: int):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(hidden_size, 3 * hidden_size, bias=False)
        self.proj = nn.Linear(hidden_size, hidden_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, S, C = x.shape
        qkv = self.qkv(x).reshape(B, S, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)

        # Use PyTorch SDPA (uses Flash Attention when available)
        x = F.scaled_dot_product_attention(q, k, v, is_causal=False)
        x = x.transpose(1, 2).contiguous().reshape(B, S, C)
        return self.proj(x)


class VisionLayer(nn.Module):
    """Single ViT encoder layer."""

    def __init__(self, hidden_size: int, num_heads: int, intermediate_size: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_size, eps=1e-6)
        self.attn  = VisionAttention(hidden_size, num_heads)
        self.norm2 = nn.LayerNorm(hidden_size, eps=1e-6)
        self.mlp   = nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.GELU(),
            nn.Linear(intermediate_size, hidden_size),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class MorphVisionEncoder(nn.Module):
    """
    Vision Transformer encoder.
    Input:  RGB image [B, 3, 336, 336]
    Output: visual tokens [B, 576, 1024]
    """

    def __init__(
        self,
        image_size: int = 336,
        patch_size: int = 14,
        num_channels: int = 3,
        hidden_size: int = 1024,
        num_layers: int = 24,
        num_heads: int = 16,
        intermediate_size: int = 4096,
    ):
        super().__init__()

        self.patch_embed = VisionPatchEmbedding(
            image_size, patch_size, num_channels, hidden_size
        )
        self.layers = nn.ModuleList([
            VisionLayer(hidden_size, num_heads, intermediate_size)
            for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(hidden_size, eps=1e-6)

    def forward(self, pixel_values: torch.Tensor) -> torch.Tensor:
        x = self.patch_embed(pixel_values)
        for layer in self.layers:
            x = layer(x)
        x = self.norm(x)
        # Remove CLS token, return patch tokens only
        return x[:, 1:, :]   # [B, 576, 1024]


class MorphVisionProjector(nn.Module):
    """
    Projects vision features into LLM embedding space.
    1024 → 3072 (matches Morph 1 hidden size)
    Uses MLP with GELU activation (better than linear for alignment).
    """

    def __init__(
        self,
        vision_hidden_size: int = 1024,
        text_hidden_size: int = 3072,
    ):
        super().__init__()
        self.projector = nn.Sequential(
            nn.Linear(vision_hidden_size, text_hidden_size, bias=False),
            nn.GELU(),
            nn.Linear(text_hidden_size, text_hidden_size, bias=False),
        )
        self.norm = MorphRMSNorm(text_hidden_size)

    def forward(self, vision_features: torch.Tensor) -> torch.Tensor:
        """
        vision_features: [B, 576, 1024]
        returns:         [B, 576, 3072]  ← ready to concat with text embeddings
        """
        return self.norm(self.projector(vision_features))


class MorphVisionModule(nn.Module):
    """
    Complete vision pipeline:
    image pixels → ViT encoder → projector → text-space tokens

    These tokens replace <image> placeholder tokens in the LLM input.
    """

    def __init__(
        self,
        image_size: int = 336,
        patch_size: int = 14,
        vision_hidden: int = 1024,
        vision_layers: int = 24,
        vision_heads: int = 16,
        vision_intermediate: int = 4096,
        text_hidden: int = 3072,
    ):
        super().__init__()

        self.encoder = MorphVisionEncoder(
            image_size=image_size,
            patch_size=patch_size,
            hidden_size=vision_hidden,
            num_layers=vision_layers,
            num_heads=vision_heads,
            intermediate_size=vision_intermediate,
        )
        self.projector = MorphVisionProjector(vision_hidden, text_hidden)

        # Number of visual tokens per image
        self.num_image_tokens = (image_size // patch_size) ** 2   # 576

    def forward(self, pixel_values: torch.Tensor) -> torch.Tensor:
        """
        pixel_values: [B, 3, H, W] — normalized RGB
        returns: [B, 576, 3072] — visual tokens in LLM space
        """
        features = self.encoder(pixel_values)
        return self.projector(features)

    def preprocess_image(
        self,
        image,
        device: torch.device,
    ) -> torch.Tensor:
        """
        Preprocess PIL image or numpy array to tensor.
        Applies ImageNet normalization.
        """
        import torchvision.transforms as T

        transform = T.Compose([
            T.Resize((self.encoder.patch_embed.image_size,) * 2),
            T.ToTensor(),
            T.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])

        if not isinstance(image, list):
            image = [image]

        tensors = [transform(img) for img in image]
        return torch.stack(tensors).to(device)
