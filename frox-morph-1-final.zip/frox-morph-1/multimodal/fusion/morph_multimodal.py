"""
Frox AI Morph 1 — Multimodal Fusion
The complete unified model:
  Text LLM + Vision Encoder + Video Encoder
  + Generation Router (Image/Video/3D via ComfyUI pipeline)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn

from config.model_config import MorphConfig
from model.architecture.morph_model import MorphForCausalLM, MorphCausalLMOutput
from multimodal.vision.encoder import MorphVisionModule
from multimodal.video.encoder import MorphVideoEncoder


# ── Special token IDs ─────────────────────────────────────────────
IMAGE_TOKEN_ID = 128256
VIDEO_TOKEN_ID = 128257

# Generation request tokens (tool calls)
GEN_IMAGE_TOKEN  = "<|gen_image|>"
GEN_VIDEO_TOKEN  = "<|gen_video|>"
GEN_3D_TOKEN     = "<|gen_3d|>"
TOOL_CALL_START  = "<|tool_call|>"
TOOL_CALL_END    = "<|/tool_call|>"


@dataclass
class MorphMultimodalOutput:
    loss: Optional[torch.Tensor] = None
    logits: Optional[torch.Tensor] = None
    past_key_values: Optional[Tuple] = None
    # Generation requests detected in output
    generation_requests: Optional[List[Dict]] = None


class MorphMultimodalModel(nn.Module):
    """
    Frox AI Morph 1 — Complete multimodal model.

    Capabilities:
    1. TEXT:  Read and generate text (LLM backbone)
    2. VISION: Understand images (ViT encoder → LLM)
    3. VIDEO:  Understand video (3D encoder → LLM)
    4. GENERATE IMAGE: Route to Fooocus/SDXL pipeline
    5. GENERATE VIDEO: Route to Wan2.2 pipeline
    6. GENERATE 3D:    Route to TripoSR pipeline
    7. CODE:  Write and execute code (CodinIT patterns)
    """

    def __init__(self, config: MorphConfig):
        super().__init__()
        self.config = config

        # ── Core LLM ──────────────────────────────────────────────
        self.language_model = MorphForCausalLM(config.text)

        # ── Vision encoder (image understanding) ──────────────────
        self.vision = MorphVisionModule(
            image_size=config.vision.image_size,
            patch_size=config.vision.patch_size,
            vision_hidden=config.vision.hidden_size,
            vision_layers=config.vision.num_hidden_layers,
            vision_heads=config.vision.num_attention_heads,
            vision_intermediate=config.vision.intermediate_size,
            text_hidden=config.text.hidden_size,
        )

        # ── Video encoder (video understanding) ───────────────────
        self.video_encoder = MorphVideoEncoder(
            num_frames=config.video.num_frames,
            frame_size=config.video.frame_size,
            patch_size=config.video.patch_size,
            temporal_patch_size=config.video.temporal_patch_size,
            hidden_size=config.video.hidden_size,
            num_layers=config.video.num_hidden_layers,
            num_heads=config.video.num_attention_heads,
            text_hidden_size=config.text.hidden_size,
        )

        # ── Generation router (calls external pipelines) ──────────
        self.generation_router = MorphGenerationRouter(config)

        # ── VRAM manager (from ComfyUI model_management.py) ───────
        self.vram_manager = MorphVRAMManager()

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        pixel_values: Optional[torch.Tensor] = None,     # images
        video_values: Optional[torch.Tensor] = None,     # video frames
        labels: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple] = None,
        use_cache: bool = True,
    ) -> MorphMultimodalOutput:

        # Build unified input embeddings
        inputs_embeds, attention_mask = self._build_inputs_embeds(
            input_ids, pixel_values, video_values, attention_mask,
        )

        # Forward through LLM
        outputs = self.language_model(
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            labels=labels,
            past_key_values=past_key_values,
            use_cache=use_cache,
        )

        return MorphMultimodalOutput(
            loss=outputs.loss,
            logits=outputs.logits,
            past_key_values=outputs.past_key_values,
        )

    def _build_inputs_embeds(
        self,
        input_ids: torch.LongTensor,
        pixel_values: Optional[torch.Tensor],
        video_values: Optional[torch.Tensor],
        attention_mask: Optional[torch.Tensor],
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        Replace IMAGE_TOKEN_ID and VIDEO_TOKEN_ID placeholders
        with actual visual embeddings.
        """
        # Get text embeddings
        text_embeds = self.language_model.get_input_embeddings()(input_ids)

        # Replace image tokens
        if pixel_values is not None:
            image_features = self.vision(pixel_values)  # [B, 576, 3072]
            text_embeds = self._replace_tokens(
                text_embeds, input_ids, IMAGE_TOKEN_ID, image_features
            )

        # Replace video tokens
        if video_values is not None:
            video_features = self.video_encoder(video_values)
            text_embeds = self._replace_tokens(
                text_embeds, input_ids, VIDEO_TOKEN_ID, video_features
            )

        return text_embeds, attention_mask

    def _replace_tokens(
        self,
        embeds: torch.Tensor,
        input_ids: torch.Tensor,
        token_id: int,
        visual_features: torch.Tensor,
    ) -> torch.Tensor:
        """Replace placeholder tokens with visual embeddings."""
        B = embeds.shape[0]
        result = embeds.clone()

        for b in range(B):
            token_positions = (input_ids[b] == token_id).nonzero(as_tuple=True)[0]
            if len(token_positions) == 0:
                continue

            # For each placeholder, insert corresponding visual tokens
            # This assumes visual tokens are pre-flattened into the sequence
            for i, pos in enumerate(token_positions):
                if i < visual_features.shape[0]:
                    # Single token position → take mean of visual features
                    result[b, pos] = visual_features[i].mean(dim=0)

        return result

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.LongTensor,
        pixel_values: Optional[torch.Tensor] = None,
        video_values: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        max_new_tokens: int = 1024,
        temperature: float = 0.7,
        top_p: float = 0.9,
        do_sample: bool = True,
    ) -> Dict:
        """
        Unified generation:
        - Generates text response
        - Detects generation requests in output
        - Routes to image/video/3D pipeline if needed
        """
        # Build multimodal embeddings
        inputs_embeds, attention_mask = self._build_inputs_embeds(
            input_ids, pixel_values, video_values, attention_mask,
        )

        # Generate text
        # For multimodal, we need to pass inputs_embeds to generate
        output_ids = self.language_model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            do_sample=do_sample,
        )

        return {"output_ids": output_ids}

    def param_count(self) -> Dict:
        llm = self.language_model.param_count()
        vision_params = sum(p.numel() for p in self.vision.parameters())
        video_params = sum(p.numel() for p in self.video_encoder.parameters())
        total = sum(p.numel() for p in self.parameters())
        return {
            "llm_backbone": llm,
            "vision_encoder_m": round(vision_params / 1e6, 1),
            "video_encoder_m": round(video_params / 1e6, 1),
            "total_billions": round(total / 1e9, 3),
        }

    def save(self, path: str):
        import os
        os.makedirs(path, exist_ok=True)
        torch.save({
            "language_model": self.language_model.state_dict(),
            "vision": self.vision.state_dict(),
            "video_encoder": self.video_encoder.state_dict(),
        }, f"{path}/morph1_multimodal.pt")
        print(f"✓ Frox Morph 1 saved to {path}")


# ── VRAM Manager (from ComfyUI model_management.py) ──────────────

class MorphVRAMManager:
    """
    VRAM state machine — adapted from ComfyUI's VRAMState enum.
    Handles model offloading for different GPU sizes.
    """

    DISABLED  = 0   # No VRAM
    NO_VRAM   = 1   # < 2GB
    LOW_VRAM  = 2   # 2-4GB
    NORMAL    = 3   # 4-8GB
    HIGH      = 4   # 8GB+
    SHARED    = 5   # CPU/GPU shared (Apple M-series)

    def __init__(self):
        self.state = self._detect_state()

    def _detect_state(self) -> int:
        if not torch.cuda.is_available():
            return self.DISABLED

        total_vram = torch.cuda.get_device_properties(0).total_memory / (1024**3)

        if total_vram < 2:   return self.NO_VRAM
        if total_vram < 5:   return self.LOW_VRAM
        if total_vram < 10:  return self.NORMAL
        return self.HIGH

    def should_offload(self) -> bool:
        return self.state in (self.NO_VRAM, self.LOW_VRAM)

    def free_memory(self):
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        import gc
        gc.collect()


# ── Generation Router ─────────────────────────────────────────────

class MorphGenerationRouter:
    """
    Routes generation requests from LLM output to:
    - Fooocus/SDXL for images
    - Wan2.2 for video
    - TripoSR for 3D models
    - ComfyUI pipeline for complex workflows
    """

    def __init__(self, config: MorphConfig):
        self.config = config
        self._image_pipeline = None
        self._video_pipeline = None
        self._threed_pipeline = None

    def route(self, request_type: str, prompt: str, **kwargs) -> Dict:
        """Route a generation request to the appropriate pipeline."""
        if request_type == "image":
            return self._generate_image(prompt, **kwargs)
        elif request_type == "video":
            return self._generate_video(prompt, **kwargs)
        elif request_type == "3d":
            return self._generate_3d(prompt, **kwargs)
        else:
            raise ValueError(f"Unknown generation type: {request_type}")

    def _generate_image(self, prompt: str, **kwargs) -> Dict:
        """Route to Fooocus image generation pipeline."""
        return {
            "type": "image",
            "prompt": prompt,
            "pipeline": "fooocus_sdxl",
            "params": {
                "guidance_scale": kwargs.get("guidance_scale", 4.0),
                "steps": kwargs.get("steps", 20),
                "size": kwargs.get("size", "1024x1024"),
                "styles": kwargs.get("styles", ["Fooocus V2"]),
            }
        }

    def _generate_video(self, prompt: str, **kwargs) -> Dict:
        """Route to Wan2.2 video generation pipeline."""
        return {
            "type": "video",
            "prompt": prompt,
            "pipeline": "wan2.2_t2v",
            "params": {
                "num_frames": kwargs.get("frames", 81),
                "fps": kwargs.get("fps", 16),
                "size": kwargs.get("size", "480x832"),
                "steps": kwargs.get("steps", 50),
            }
        }

    def _generate_3d(self, image_path: str, **kwargs) -> Dict:
        """Route to TripoSR 3D reconstruction pipeline."""
        return {
            "type": "3d",
            "image_path": image_path,
            "pipeline": "triposr",
            "params": {
                "mc_resolution": kwargs.get("resolution", 256),
                "foreground_ratio": kwargs.get("foreground_ratio", 0.85),
            }
        }
