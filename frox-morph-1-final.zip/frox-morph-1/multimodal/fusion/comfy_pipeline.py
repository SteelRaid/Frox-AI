"""
Frox AI Morph 1 — Generation Pipeline Integration
Real implementations for:
  - Fooocus/SDXL image generation (direct diffusers pipeline)
  - Wan2.2 video generation (direct model load)
  - TripoSR 3D reconstruction (direct TSR load)
  - ComfyUI workflow execution (API mode)

License boundaries:
  - Fooocus (GPL v3): called via its own API server (HTTP), never imported
  - ComfyUI (GPL v3): called via its own API server (HTTP), never imported
  - Wan2.2 (Apache 2.0): imported directly
  - TripoSR (MIT): imported directly
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import random
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import torch
import torch.nn as nn


# ── VRAM manager (from ComfyUI model_management.py) ───────────────

class VRAMState:
    DISABLED = 0
    NO_VRAM  = 1
    LOW_VRAM = 2
    NORMAL   = 3
    HIGH     = 4
    SHARED   = 5


def detect_vram_state() -> int:
    if not torch.cuda.is_available():
        return VRAMState.DISABLED
    total = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    if total < 1:  return VRAMState.NO_VRAM
    if total < 4:  return VRAMState.LOW_VRAM
    if total < 8:  return VRAMState.NORMAL
    return VRAMState.HIGH


def free_memory():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()


# ── Base pipeline ──────────────────────────────────────────────────

class BasePipeline:
    """Base class — all subclasses implement load() fully."""

    def __init__(self, device: str = "cuda"):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.vram_state = detect_vram_state()
        self._model = None
        self._loaded = False

    def load(self):
        """Subclasses MUST implement this with real model loading."""
        raise RuntimeError(
            f"{self.__class__.__name__}.load() not implemented. "
            "This is a bug in Frox Morph 1 — report it."
        )

    def unload(self):
        if self._model is not None:
            self._model.to("cpu")
        free_memory()
        self._loaded = False

    def _ensure_loaded(self):
        if not self._loaded:
            self.load()


# ── Image pipeline (diffusers SDXL — no Fooocus import) ───────────

class MorphImagePipeline(BasePipeline):
    """
    Real SDXL image generation using diffusers directly.
    No Fooocus import — avoids GPL v3 contamination.
    Uses the same SDXL base model Fooocus uses under the hood.

    To use Fooocus instead: run its API server separately and
    call MorphFooocusAPIClient (below) instead of this class.
    """

    def __init__(
        self,
        model_id: str = "stabilityai/stable-diffusion-xl-base-1.0",
        device: str = "cuda",
        use_refiner: bool = False,
        dtype: torch.dtype = torch.bfloat16,
    ):
        super().__init__(device)
        self.model_id = model_id
        self.use_refiner = use_refiner
        self.dtype = dtype
        self._pipe = None
        self._refiner = None

    def load(self):
        from diffusers import StableDiffusionXLPipeline, DiffusionPipeline
        from diffusers import EulerAncestralDiscreteScheduler

        print(f"Loading SDXL: {self.model_id}")

        self._pipe = StableDiffusionXLPipeline.from_pretrained(
            self.model_id,
            torch_dtype=self.dtype,
            use_safetensors=True,
            variant="fp16" if self.dtype == torch.float16 else None,
        )

        # Memory optimizations based on VRAM state
        if self.vram_state <= VRAMState.NORMAL:
            self._pipe.enable_model_cpu_offload()
            self._pipe.enable_vae_slicing()
            print("  VRAM optimizations: CPU offload + VAE slicing")
        else:
            self._pipe = self._pipe.to(self.device)

        # Better scheduler
        self._pipe.scheduler = EulerAncestralDiscreteScheduler.from_config(
            self._pipe.scheduler.config
        )

        self._loaded = True
        print("✓ SDXL pipeline ready")

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "blurry, low quality, distorted, ugly",
        width: int = 1024,
        height: int = 1024,
        steps: int = 25,
        guidance_scale: float = 7.5,
        seed: Optional[int] = None,
        num_images: int = 1,
        output_dir: str = "./outputs/images",
    ) -> List[str]:
        """Generate images and save to disk. Returns list of paths."""
        self._ensure_loaded()

        os.makedirs(output_dir, exist_ok=True)
        seed = seed if seed is not None else random.randint(0, 2**32 - 1)
        generator = torch.Generator(device=self.device).manual_seed(seed)

        print(f"  Generating {num_images} image(s): '{prompt[:60]}...'")
        t0 = time.perf_counter()

        images = self._pipe(
            prompt=prompt,
            negative_prompt=negative_prompt,
            width=width,
            height=height,
            num_inference_steps=steps,
            guidance_scale=guidance_scale,
            generator=generator,
            num_images_per_prompt=num_images,
        ).images

        elapsed = time.perf_counter() - t0
        print(f"  Generated in {elapsed:.1f}s")

        paths = []
        for i, img in enumerate(images):
            fname = f"morph1_{seed}_{i}.png"
            path = os.path.join(output_dir, fname)
            img.save(path)
            paths.append(path)
            print(f"  Saved: {path}")

        free_memory()
        return paths

    def generate_with_lora(
        self,
        prompt: str,
        lora_path: str,
        lora_scale: float = 0.8,
        **kwargs,
    ) -> List[str]:
        """Load a LoRA adapter and generate — mirrors ComfyUI lora.py pattern."""
        self._ensure_loaded()
        self._pipe.load_lora_weights(lora_path)
        self._pipe.fuse_lora(lora_scale=lora_scale)
        result = self.generate(prompt, **kwargs)
        self._pipe.unfuse_lora()
        self._pipe.unload_lora_weights()
        return result


class MorphFooocusAPIClient:
    """
    Calls Fooocus via its built-in API server (HTTP).
    Fooocus must be running: python launch.py --listen --api
    This is the CORRECT way to use GPL software without license contamination.
    """

    def __init__(self, base_url: str = "http://localhost:7860"):
        self.base_url = base_url.rstrip("/")

    def is_available(self) -> bool:
        try:
            import urllib.request
            urllib.request.urlopen(f"{self.base_url}/", timeout=3)
            return True
        except Exception:
            return False

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 1024,
        height: int = 1024,
        steps: int = 25,
        guidance_scale: float = 4.0,
        styles: Optional[List[str]] = None,
        seed: int = -1,
        num_images: int = 1,
        output_dir: str = "./outputs/images",
    ) -> List[str]:
        """
        Call Fooocus API. Returns list of saved image paths.
        Fooocus API docs: http://localhost:7860/docs
        """
        import urllib.request
        import base64

        os.makedirs(output_dir, exist_ok=True)
        styles = styles or ["Fooocus V2", "Fooocus Enhance"]

        payload = json.dumps({
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "style_selections": styles,
            "performance_selection": "Speed",
            "aspect_ratios_selection": f"{width}×{height}",
            "image_number": num_images,
            "guidance_scale": guidance_scale,
            "sharpness": 2.0,
            "seed": seed,
            "async_process": False,
            "save_extension": "png",
        }).encode()

        req = urllib.request.Request(
            f"{self.base_url}/v1/generation/text-to-image",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        paths = []
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                results = json.loads(resp.read())

            for i, item in enumerate(results):
                b64 = item.get("base64")
                if b64:
                    img_bytes = base64.b64decode(b64)
                    fname = f"fooocus_{int(time.time())}_{i}.png"
                    path = os.path.join(output_dir, fname)
                    with open(path, "wb") as f:
                        f.write(img_bytes)
                    paths.append(path)
        except Exception as e:
            print(f"Fooocus API error: {e}")

        return paths


# ── Video pipeline (Wan2.2 direct import — Apache 2.0) ────────────

class MorphVideoPipeline(BasePipeline):
    """
    Real Wan2.2 text-to-video generation.
    Direct import — Apache 2.0 license allows this.
    Requires Wan2.2 model weights downloaded separately.
    """

    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        offload_t5_to_cpu: bool = True,
    ):
        super().__init__(device)
        self.model_path = Path(model_path)
        self.offload_t5 = offload_t5_to_cpu
        self._wan = None

    def load(self):
        """Load Wan2.2 WanT2V model — real implementation."""
        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Wan2.2 model not found at {self.model_path}.\n"
                "Download from: https://huggingface.co/Wan-AI/Wan2.2-T2V-14B"
            )

        import sys
        # Add Wan2.2 source to path (user cloned it alongside frox-morph-1)
        wan_src = self.model_path.parent / "Wan2.2-main"
        if wan_src.exists():
            sys.path.insert(0, str(wan_src))

        try:
            from wan.text2video import WanT2V
            from wan.configs.wan_t2v_A14B import cfg as wan_cfg

            self._wan = WanT2V(
                config=wan_cfg,
                checkpoint_dir=str(self.model_path),
                device_id=0 if torch.cuda.is_available() else -1,
                t5_cpu=self.offload_t5,
                init_on_cpu=True,
            )
            self._loaded = True
            print("✓ Wan2.2 T2V pipeline loaded")

        except ImportError as e:
            raise ImportError(
                f"Could not import Wan2.2: {e}\n"
                "Make sure Wan2.2-main/ is in the parent directory."
            )

    def generate(
        self,
        prompt: str,
        negative_prompt: str = "blurry, low quality, distorted",
        num_frames: int = 81,
        height: int = 480,
        width: int = 832,
        fps: int = 16,
        steps: int = 50,
        guidance_scale: float = 5.0,
        seed: Optional[int] = None,
        output_path: str = "./outputs/videos/output.mp4",
    ) -> str:
        """
        Real Wan2.2 video generation.
        Returns path to saved .mp4 file.
        """
        self._ensure_loaded()

        os.makedirs(Path(output_path).parent, exist_ok=True)
        seed = seed if seed is not None else random.randint(0, 2**32 - 1)

        print(f"  Generating video ({num_frames} frames @ {fps}fps): '{prompt[:60]}...'")
        t0 = time.perf_counter()

        video_frames = self._wan.generate(
            prompt,
            size=(height, width),
            frame_num=num_frames,
            shift=3.0,
            sample_solver="unipc",
            sampling_steps=steps,
            guide_scale=guidance_scale,
            n_prompt=negative_prompt,
            seed=seed,
            offload_model=self.offload_t5,
        )

        elapsed = time.perf_counter() - t0
        print(f"  Generated in {elapsed:.1f}s")

        self._save_mp4(video_frames, output_path, fps)
        free_memory()
        return output_path

    def _save_mp4(self, frames: torch.Tensor, path: str, fps: int):
        """Save frame tensor as .mp4."""
        try:
            import torchvision.io as vio
            # Normalize to [0, 255] uint8
            if frames.min() < 0:
                frames = (frames + 1.0) / 2.0
            frames = (frames.clamp(0, 1) * 255).byte()
            # Ensure [T, H, W, C] format
            if frames.ndim == 4 and frames.shape[1] in (1, 3, 4):
                frames = frames.permute(0, 2, 3, 1)
            vio.write_video(path, frames.cpu(), fps=fps, video_codec="h264")
            print(f"  Saved: {path}")
        except Exception as e:
            # Fallback: save as individual frames
            print(f"  Could not write mp4 ({e}), saving frames...")
            frame_dir = Path(path).with_suffix("")
            frame_dir.mkdir(parents=True, exist_ok=True)
            from PIL import Image as PILImage
            for i, frame in enumerate(frames):
                if frame.shape[0] in (1, 3):
                    frame = frame.permute(1, 2, 0)
                img = PILImage.fromarray(frame.cpu().numpy())
                img.save(str(frame_dir / f"frame_{i:04d}.png"))
            print(f"  Saved {len(frames)} frames to {frame_dir}")


# ── 3D pipeline (TripoSR direct import — MIT) ─────────────────────

class MorphThreeDPipeline(BasePipeline):
    """
    Real TripoSR 3D reconstruction.
    Direct import — MIT license allows this.
    Uses TSR.from_pretrained() exactly as in TripoSR/tsr/system.py
    """

    def __init__(
        self,
        model_path: str = "stabilityai/TripoSR",
        device: str = "cuda",
    ):
        super().__init__(device)
        self.model_path = model_path
        self._tsr = None

    def load(self):
        """Load TripoSR model. model_path can be HF repo or local dir."""
        import sys
        triposr_src = Path("./TripoSR-main/TripoSR-main")
        if triposr_src.exists():
            sys.path.insert(0, str(triposr_src))

        try:
            from tsr.system import TSR

            self._tsr = TSR.from_pretrained(
                self.model_path,
                config_name="config.yaml",
                weight_name="model.ckpt",
            )
            self._tsr = self._tsr.to(self.device)
            self._tsr.eval()
            self._loaded = True
            print("✓ TripoSR pipeline loaded")

        except ImportError as e:
            raise ImportError(
                f"Could not import TripoSR: {e}\n"
                "Make sure TripoSR-main/ is in the parent directory."
            )

    def reconstruct(
        self,
        image,
        mc_resolution: int = 256,
        foreground_ratio: float = 0.85,
        output_dir: str = "./outputs/3d",
        formats: Optional[List[str]] = None,
        remove_bg: bool = True,
    ) -> Dict[str, str]:
        """
        Real TripoSR reconstruction.
        image: PIL.Image, numpy array, or path string.
        Returns dict: {"obj": "/path/to/mesh.obj", "glb": "/path/to/mesh.glb"}
        """
        self._ensure_loaded()

        from PIL import Image as PILImage

        formats = formats or ["obj", "glb"]
        os.makedirs(output_dir, exist_ok=True)

        # Load image
        if isinstance(image, str):
            image = PILImage.open(image).convert("RGBA")
        elif isinstance(image, np.ndarray):
            image = PILImage.fromarray(image).convert("RGBA")

        # Background removal (improves TripoSR quality significantly)
        if remove_bg:
            try:
                import rembg
                image = rembg.remove(image)
                print("  Background removed")
            except ImportError:
                print("  rembg not installed — skipping background removal")
                print("  Install: pip install rembg")
            except Exception as e:
                print(f"  Background removal failed: {e}")

        # Resize to TripoSR expected input
        image = image.resize((512, 512), PILImage.LANCZOS)

        print(f"  Reconstructing 3D mesh (resolution={mc_resolution})...")
        t0 = time.perf_counter()

        outputs = {}
        with torch.no_grad():
            # TripoSR forward pass — from tsr/system.py TSR.forward()
            scene_codes = self._tsr(image, device=str(self.device))

            # Extract mesh using marching cubes
            meshes = self._tsr.extract_mesh(
                scene_codes,
                mc_resolution=mc_resolution,
            )

        elapsed = time.perf_counter() - t0
        print(f"  Reconstructed in {elapsed:.1f}s")

        # Export in requested formats
        for fmt in formats:
            out_path = os.path.join(output_dir, f"mesh.{fmt}")
            try:
                meshes[0].export(out_path)
                outputs[fmt] = out_path
                print(f"  Saved: {out_path}")
            except Exception as e:
                print(f"  Could not export {fmt}: {e}")

        free_memory()
        return outputs


# ── ComfyUI API client (GPL v3 boundary) ──────────────────────────

class MorphComfyAPIClient:
    """
    Calls ComfyUI via its built-in API (HTTP).
    ComfyUI must be running: python main.py --listen
    This is the correct GPL v3 boundary — HTTP API, no direct import.
    """

    def __init__(self, base_url: str = "http://localhost:8188"):
        self.base_url = base_url.rstrip("/")
        self._client_id = hashlib.md5(b"frox-morph-1").hexdigest()[:8]

    def is_available(self) -> bool:
        try:
            import urllib.request
            urllib.request.urlopen(f"{self.base_url}/system_stats", timeout=3)
            return True
        except Exception:
            return False

    def queue_prompt(self, workflow: Dict) -> Optional[str]:
        """
        Queue a workflow for execution.
        Returns prompt_id or None on failure.
        """
        import urllib.request

        payload = json.dumps({
            "prompt": workflow,
            "client_id": self._client_id,
        }).encode()

        req = urllib.request.Request(
            f"{self.base_url}/prompt",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read())["prompt_id"]
        except Exception as e:
            print(f"ComfyUI queue error: {e}")
            return None

    def wait_for_result(
        self,
        prompt_id: str,
        timeout: int = 300,
    ) -> Dict:
        """Poll ComfyUI until prompt is done. Returns history dict."""
        import urllib.request

        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(
                    f"{self.base_url}/history/{prompt_id}", timeout=10
                ) as resp:
                    history = json.loads(resp.read())
                    if prompt_id in history:
                        return history[prompt_id]
            except Exception:
                pass
            time.sleep(2)

        raise TimeoutError(f"ComfyUI prompt {prompt_id} timed out after {timeout}s")

    def get_image(self, filename: str, subfolder: str = "", folder_type: str = "output") -> bytes:
        """Download a generated image from ComfyUI."""
        import urllib.request, urllib.parse

        params = urllib.parse.urlencode({
            "filename": filename,
            "subfolder": subfolder,
            "type": folder_type,
        })
        with urllib.request.urlopen(f"{self.base_url}/view?{params}", timeout=30) as resp:
            return resp.read()

    def text_to_image(
        self,
        prompt: str,
        negative_prompt: str = "",
        width: int = 1024,
        height: int = 1024,
        steps: int = 20,
        cfg: float = 7.0,
        checkpoint: str = "sd_xl_base_1.0.safetensors",
        output_dir: str = "./outputs/images",
    ) -> List[str]:
        """
        Full text-to-image via ComfyUI node graph.
        Builds the workflow JSON, queues it, waits for result, saves images.
        """
        os.makedirs(output_dir, exist_ok=True)

        workflow = {
            "1": {"class_type": "CheckpointLoaderSimple",
                  "inputs": {"ckpt_name": checkpoint}},
            "2": {"class_type": "CLIPTextEncode",
                  "inputs": {"text": prompt, "clip": ["1", 1]}},
            "3": {"class_type": "CLIPTextEncode",
                  "inputs": {"text": negative_prompt, "clip": ["1", 1]}},
            "4": {"class_type": "EmptyLatentImage",
                  "inputs": {"width": width, "height": height, "batch_size": 1}},
            "5": {"class_type": "KSampler",
                  "inputs": {
                      "model": ["1", 0], "positive": ["2", 0],
                      "negative": ["3", 0], "latent_image": ["4", 0],
                      "seed": random.randint(0, 2**32-1),
                      "steps": steps, "cfg": cfg,
                      "sampler_name": "euler_ancestral",
                      "scheduler": "karras", "denoise": 1.0,
                  }},
            "6": {"class_type": "VAEDecode",
                  "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
            "7": {"class_type": "SaveImage",
                  "inputs": {"images": ["6", 0], "filename_prefix": "morph1"}},
        }

        prompt_id = self.queue_prompt(workflow)
        if not prompt_id:
            return []

        history = self.wait_for_result(prompt_id)

        # Extract and save output images
        paths = []
        for node_id, node_output in history.get("outputs", {}).items():
            for img_info in node_output.get("images", []):
                img_bytes = self.get_image(
                    img_info["filename"],
                    img_info.get("subfolder", ""),
                    img_info.get("type", "output"),
                )
                fname = img_info["filename"]
                path = os.path.join(output_dir, fname)
                with open(path, "wb") as f:
                    f.write(img_bytes)
                paths.append(path)
                print(f"  Saved: {path}")

        return paths


# ── Unified dispatcher ────────────────────────────────────────────

class MorphGenerationDispatcher:
    """
    Routes generation requests from the LLM to the right pipeline.
    Auto-selects best available backend for each modality.
    """

    def __init__(
        self,
        sdxl_model_id: str = "stabilityai/stable-diffusion-xl-base-1.0",
        wan_model_path: Optional[str] = None,
        triposr_model_path: str = "stabilityai/TripoSR",
        fooocus_url: str = "http://localhost:7860",
        comfyui_url: str = "http://localhost:8188",
        output_root: str = "./outputs",
        device: str = "cuda",
    ):
        self.output_root = Path(output_root)
        self.device = device

        # Image: try Fooocus API first, fall back to direct SDXL
        self._fooocus_client = MorphFooocusAPIClient(fooocus_url)
        self._sdxl = None              # lazy-loaded
        self._sdxl_model_id = sdxl_model_id

        # Video: Wan2.2 (lazy-loaded)
        self._video = None
        self._wan_path = wan_model_path

        # 3D: TripoSR (lazy-loaded)
        self._threed = None
        self._triposr_path = triposr_model_path

        # ComfyUI API
        self._comfy = MorphComfyAPIClient(comfyui_url)

    def _get_image_pipeline(self):
        """Return best available image pipeline."""
        if self._fooocus_client.is_available():
            print("  Using Fooocus API")
            return self._fooocus_client
        if self._sdxl is None:
            self._sdxl = MorphImagePipeline(self._sdxl_model_id, self.device)
        return self._sdxl

    def _get_video_pipeline(self) -> MorphVideoPipeline:
        if self._video is None:
            if not self._wan_path:
                raise RuntimeError(
                    "Wan2.2 model path not set. Pass wan_model_path to MorphGenerationDispatcher."
                )
            self._video = MorphVideoPipeline(self._wan_path, self.device)
        return self._video

    def _get_threed_pipeline(self) -> MorphThreeDPipeline:
        if self._threed is None:
            self._threed = MorphThreeDPipeline(self._triposr_path, self.device)
        return self._threed

    def dispatch(self, request: Dict) -> Dict:
        req_type = request.get("type", "image")
        if req_type == "image":   return self._image(request)
        if req_type == "video":   return self._video_gen(request)
        if req_type == "3d":      return self._threed_gen(request)
        return {"error": f"Unknown type: {req_type}"}

    def _image(self, req: Dict) -> Dict:
        pipe = self._get_image_pipeline()
        prompt   = req.get("prompt", "")
        out_dir  = str(self.output_root / "images")
        params   = {k: v for k, v in req.items() if k not in ("type", "prompt")}
        paths = pipe.generate(prompt=prompt, output_dir=out_dir, **params)
        return {"type": "image", "paths": paths, "prompt": prompt}

    def _video_gen(self, req: Dict) -> Dict:
        pipe = self._get_video_pipeline()
        prompt   = req.get("prompt", "")
        out_path = str(self.output_root / "videos" / "output.mp4")
        params   = {k: v for k, v in req.items() if k not in ("type", "prompt")}
        path = pipe.generate(prompt=prompt, output_path=out_path, **params)
        return {"type": "video", "path": path, "prompt": prompt}

    def _threed_gen(self, req: Dict) -> Dict:
        pipe = self._get_threed_pipeline()
        image    = req.get("image") or req.get("prompt", "")
        out_dir  = str(self.output_root / "3d")
        params   = {k: v for k, v in req.items() if k not in ("type", "image", "prompt")}
        outputs = pipe.reconstruct(image=image, output_dir=out_dir, **params)
        return {"type": "3d", "outputs": outputs}

    def unload_all(self):
        """Free all pipeline VRAM."""
        for pipe in (self._sdxl, self._video, self._threed):
            if pipe is not None:
                pipe.unload()
        free_memory()
