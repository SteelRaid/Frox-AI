"""
Frox AI Morph 1 — Video Encoder
Understands video input (not just generation).
Architecture: 3D patch embedding + temporal attention from Wan2.2
"""
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

from model.embedding.rope import rope_params_3d, rope_apply_3d
from model.attention.gqa import MorphRMSNorm


class Video3DPatchEmbedding(nn.Module):
    """
    Spatiotemporal patch embedding for video.
    Handles T frames × H × W pixels.

    Temporal patch size = 2 (pair consecutive frames)
    Spatial patch size = 14

    For 16 frames × 224×224:
      Temporal tokens: 16/2 = 8
      Spatial tokens:  224/14 × 224/14 = 16×16 = 256
      Total tokens:    8 × 256 = 2048
    """

    def __init__(
        self,
        num_frames: int = 16,
        frame_size: int = 224,
        patch_size: int = 14,
        temporal_patch_size: int = 2,
        num_channels: int = 3,
        hidden_size: int = 1024,
    ):
        super().__init__()
        self.num_frames = num_frames
        self.frame_size = frame_size
        self.patch_size = patch_size
        self.temporal_patch_size = temporal_patch_size
        self.hidden_size = hidden_size

        self.spatial_patches = (frame_size // patch_size) ** 2
        self.temporal_patches = num_frames // temporal_patch_size
        self.num_patches = self.temporal_patches * self.spatial_patches

        # 3D convolution for spatiotemporal patches
        self.projection = nn.Conv3d(
            num_channels,
            hidden_size,
            kernel_size=(temporal_patch_size, patch_size, patch_size),
            stride=(temporal_patch_size, patch_size, patch_size),
            bias=False,
        )

    def forward(self, video: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        video: [B, C, T, H, W]
        returns:
            patches: [B, T//tp * H//p * W//p, hidden]
            grid_sizes: [B, 3] — (T_patches, H_patches, W_patches)
        """
        B = video.shape[0]
        T_p = video.shape[2] // self.temporal_patch_size
        H_p = video.shape[3] // self.patch_size
        W_p = video.shape[4] // self.patch_size

        # 3D patch projection
        x = self.projection(video)               # [B, hidden, T_p, H_p, W_p]
        x = rearrange(x, 'b c t h w -> b (t h w) c')

        grid_sizes = torch.tensor(
            [[T_p, H_p, W_p]] * B,
            dtype=torch.long, device=video.device,
        )

        return x, grid_sizes


class VideoTemporalAttention(nn.Module):
    """
    Temporal attention for video — attends across frames at same spatial position.
    Uses 3D RoPE from Wan2.2 for temporal-spatial position encoding.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        rope_theta: float = 10000.0,
    ):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads

        self.q = nn.Linear(hidden_size, hidden_size, bias=False)
        self.k = nn.Linear(hidden_size, hidden_size, bias=False)
        self.v = nn.Linear(hidden_size, hidden_size, bias=False)
        self.o = nn.Linear(hidden_size, hidden_size, bias=False)

        self.norm_q = MorphRMSNorm(self.head_dim)
        self.norm_k = MorphRMSNorm(self.head_dim)

        # Precompute 3D RoPE frequencies (from Wan2.2)
        self.freqs = rope_params_3d(1024, self.head_dim, theta=rope_theta)

    def forward(
        self,
        x: torch.Tensor,
        grid_sizes: torch.Tensor,
        seq_lens: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        B, S, C = x.shape
        n, d = self.num_heads, self.head_dim

        # QKV
        q = self.norm_q(self.q(x).view(B, S, n, d))
        k = self.norm_k(self.k(x).view(B, S, n, d))
        v = self.v(x).view(B, S, n, d)

        # Apply 3D RoPE (from Wan2.2 rope_apply)
        freqs = self.freqs.to(x.device)
        q = rope_apply_3d(q, grid_sizes, freqs)
        k = rope_apply_3d(k, grid_sizes, freqs)

        # Attention
        q = q.transpose(1, 2)
        k = k.transpose(1, 2)
        v = v.transpose(1, 2)

        x = F.scaled_dot_product_attention(q, k, v, is_causal=False)
        x = x.transpose(1, 2).contiguous().view(B, S, C)

        return self.o(x)


class VideoEncoderLayer(nn.Module):
    def __init__(self, hidden_size: int, num_heads: int, intermediate_size: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(hidden_size)
        self.attn  = VideoTemporalAttention(hidden_size, num_heads)
        self.norm2 = nn.LayerNorm(hidden_size)
        self.mlp   = nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.GELU(),
            nn.Linear(intermediate_size, hidden_size),
        )

    def forward(self, x: torch.Tensor, grid_sizes: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x), grid_sizes)
        x = x + self.mlp(self.norm2(x))
        return x


class MorphVideoEncoder(nn.Module):
    """
    Complete video understanding encoder.
    Input:  video tensor [B, C, T, H, W]
    Output: video tokens [B, num_tokens, hidden]

    Uses 3D RoPE from Wan2.2 for proper temporal-spatial position encoding.
    """

    def __init__(
        self,
        num_frames: int = 16,
        frame_size: int = 224,
        patch_size: int = 14,
        temporal_patch_size: int = 2,
        hidden_size: int = 1024,
        num_layers: int = 12,
        num_heads: int = 16,
        intermediate_size: int = 4096,
        text_hidden_size: int = 3072,
    ):
        super().__init__()

        self.patch_embed = Video3DPatchEmbedding(
            num_frames, frame_size, patch_size,
            temporal_patch_size, 3, hidden_size,
        )

        self.layers = nn.ModuleList([
            VideoEncoderLayer(hidden_size, num_heads, intermediate_size)
            for _ in range(num_layers)
        ])

        self.norm = nn.LayerNorm(hidden_size)

        # Project to text space
        self.projector = nn.Sequential(
            nn.Linear(hidden_size, text_hidden_size, bias=False),
            nn.GELU(),
            nn.Linear(text_hidden_size, text_hidden_size, bias=False),
        )
        self.proj_norm = MorphRMSNorm(text_hidden_size)

    def forward(self, video: torch.Tensor) -> torch.Tensor:
        """
        video: [B, 3, T, H, W] normalized
        returns: [B, num_video_tokens, text_hidden_size]
        """
        x, grid_sizes = self.patch_embed(video)

        for layer in self.layers:
            x = layer(x, grid_sizes)

        x = self.norm(x)
        return self.proj_norm(self.projector(x))


from typing import Tuple
