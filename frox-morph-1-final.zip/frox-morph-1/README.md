# Frox AI Morph 1

**Unified multimodal AI — built from scratch.**
Architecture: Llama 3.2 3B | Multimodal: Text + Image + Video + 3D

---

## What It Is

Frox AI Morph 1 is a real transformer model trained from scratch with:

| Capability | How |
|---|---|
| Text intelligence | Llama 3.2 3B architecture (GQA + RoPE + SwiGLU) |
| Image understanding | ViT-L/14 encoder → LLM projector |
| Video understanding | 3D patch encoder + Wan2.2 temporal RoPE |
| Image generation | Fooocus/SDXL pipeline |
| Video generation | Wan2.2 T2V pipeline |
| 3D reconstruction | TripoSR single-image pipeline |
| Node workflows | ComfyUI pipeline |
| Code intelligence | CodinIT multi-provider patterns |

---

## Project Structure

```
frox-morph-1/
├── main.py                          ← entry point
├── requirements.txt
├── config/
│   └── model_config.py              ← all hyperparameters (1B/3B/7B)
├── model/
│   ├── architecture/
│   │   └── morph_model.py           ← full transformer + generation
│   ├── attention/
│   │   └── gqa.py                   ← GQA + Flash Attention + SwiGLU
│   └── embedding/
│       └── rope.py                  ← 1D RoPE (text) + 3D RoPE (video)
├── multimodal/
│   ├── vision/
│   │   └── encoder.py               ← ViT image encoder + projector
│   ├── video/
│   │   └── encoder.py               ← 3D video encoder (Wan2.2 RoPE)
│   └── fusion/
│       ├── morph_multimodal.py      ← unified model + generation router
│       └── comfy_pipeline.py        ← Fooocus/Wan2.2/TripoSR/ComfyUI
├── tokenizer/
│   └── morph_tokenizer.py           ← Llama 3 tokenizer + Morph tokens
├── training/
│   └── pipeline/
│       └── trainer.py               ← full training loop + Drive saving
└── inference/
    ├── engine/
    │   └── morph_engine.py          ← inference + streaming + tool parsing
    └── cache/
        └── kv_cache.py              ← KV cache for fast generation
```

---

## Quick Start

### 1. Check your setup
```bash
python main.py --mode info
```

### 2. Demo (no training needed)
```bash
python main.py --mode demo
```

### 3. Train (Google Colab)
```python
# In Colab cell:
!git clone <your-repo> frox-morph-1
%cd frox-morph-1
!pip install -r requirements.txt
!python main.py --mode colab --max-steps 500
```

### 4. Inference (after training)
```bash
python main.py --mode inference --model-path /path/to/saved/model
```

---

## Hardware Requirements

| Mode | VRAM | Config |
|---|---|---|
| Demo / testing | Any | 1B random weights |
| Colab Free T4 | 15 GB | 1B + QLoRA 4-bit |
| Colab Pro A100 | 40 GB | 3B + QLoRA 4-bit |
| Full training | 80 GB+ | 7B full precision |

---

## Scale Configs

```python
from config.model_config import MorphConfig

cfg = MorphConfig.scale_1b()   # Colab Free (1.2B params)
cfg = MorphConfig.scale_3b()   # Default (3B params)
cfg = MorphConfig.scale_7b()   # Upgrade (7B params)
```

---

## Repo Sources Integrated

| Repo | What was used |
|---|---|
| **Wan2.2** | 3D RoPE, temporal attention, video pipeline |
| **ComfyUI** | VRAM state machine, node pipeline, LoRA loading |
| **Fooocus** | Async task pattern, SDXL image pipeline |
| **TripoSR** | 3D reconstruction pipeline |
| **CodinIT** | Multi-provider patterns, tool system |
| **OpenRoom** | Agent desktop patterns |

---

## License

- Frox Morph 1 source code: MIT
- Fooocus (image gen): GPL v3 — subprocess boundary maintained
- Wan2.2: Apache 2.0
- TripoSR: MIT
- ComfyUI: GPL v3 — subprocess boundary maintained
- CodinIT: MIT
- OpenRoom: MIT
