"""
Frox AI Morph 1 — KV Cache
Efficient key-value cache for fast autoregressive generation.
Avoids recomputing attention for past tokens on each step.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

import torch


class MorphKVCache:
    """
    KV Cache for Morph 1 inference.
    Stores past key and value tensors for all layers.

    Memory usage (3B model, batch=1, seq=2048):
        Per layer: 2 × num_kv_heads × seq_len × head_dim × 2 bytes
                 = 2 × 8 × 2048 × 128 × 2 = 8MB per layer
        28 layers: ~224MB total — fits easily in 15GB VRAM
    """

    def __init__(
        self,
        num_layers: int,
        max_seq_len: int = 4096,
        num_kv_heads: int = 8,
        head_dim: int = 128,
        dtype: torch.dtype = torch.bfloat16,
        device: torch.device = torch.device("cpu"),
    ):
        self.num_layers = num_layers
        self.max_seq_len = max_seq_len
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.dtype = dtype
        self.device = device

        # Pre-allocate cache tensors
        self._k_cache = [
            torch.zeros(
                1, num_kv_heads, max_seq_len, head_dim,
                dtype=dtype, device=device
            )
            for _ in range(num_layers)
        ]
        self._v_cache = [
            torch.zeros(
                1, num_kv_heads, max_seq_len, head_dim,
                dtype=dtype, device=device
            )
            for _ in range(num_layers)
        ]
        self._seq_len = 0

    @property
    def seq_len(self) -> int:
        return self._seq_len

    def update(
        self,
        layer_idx: int,
        k: torch.Tensor,
        v: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Update cache for a layer and return full cached KV.

        k, v: [B, num_kv_heads, new_seq_len, head_dim]
        returns: full [B, num_kv_heads, total_seq_len, head_dim]
        """
        new_len = k.shape[2]

        if self._seq_len + new_len > self.max_seq_len:
            # Sliding window — drop oldest tokens
            keep = self.max_seq_len - new_len
            self._k_cache[layer_idx][:, :, :keep] = \
                self._k_cache[layer_idx][:, :, self._seq_len - keep:self._seq_len]
            self._v_cache[layer_idx][:, :, :keep] = \
                self._v_cache[layer_idx][:, :, self._seq_len - keep:self._seq_len]
            self._seq_len = keep

        # Write new tokens
        start = self._seq_len
        end = start + new_len
        self._k_cache[layer_idx][:, :, start:end] = k
        self._v_cache[layer_idx][:, :, start:end] = v

        # Return full cache up to current position
        k_full = self._k_cache[layer_idx][:, :, :end]
        v_full = self._v_cache[layer_idx][:, :, :end]

        return k_full, v_full

    def step(self, new_tokens: int = 1):
        """Advance sequence length after generating new_tokens."""
        self._seq_len += new_tokens

    def reset(self):
        """Clear cache for new conversation."""
        for i in range(self.num_layers):
            self._k_cache[i].zero_()
            self._v_cache[i].zero_()
        self._seq_len = 0

    def get(self, layer_idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Get cached KV for a layer."""
        k = self._k_cache[layer_idx][:, :, :self._seq_len]
        v = self._v_cache[layer_idx][:, :, :self._seq_len]
        return k, v

    def memory_mb(self) -> float:
        """Estimate current memory usage in MB."""
        total_bytes = sum(
            k.numel() * k.element_size() + v.numel() * v.element_size()
            for k, v in zip(self._k_cache, self._v_cache)
        )
        return total_bytes / (1024 ** 2)

    def to(self, device: torch.device) -> "MorphKVCache":
        self._k_cache = [k.to(device) for k in self._k_cache]
        self._v_cache = [v.to(device) for v in self._v_cache]
        self.device = device
        return self


class MorphSessionCache:
    """
    Per-session KV cache manager.
    Maintains separate caches for concurrent sessions.
    """

    def __init__(
        self,
        num_layers: int = 28,
        max_sessions: int = 8,
        max_seq_len: int = 4096,
        num_kv_heads: int = 8,
        head_dim: int = 128,
    ):
        self.num_layers = num_layers
        self.max_sessions = max_sessions
        self.max_seq_len = max_seq_len
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self._caches: dict[str, MorphKVCache] = {}

    def get_or_create(self, session_id: str) -> MorphKVCache:
        """Get existing cache or create new one for a session."""
        if session_id not in self._caches:
            if len(self._caches) >= self.max_sessions:
                # Evict oldest session
                oldest = next(iter(self._caches))
                del self._caches[oldest]

            self._caches[session_id] = MorphKVCache(
                num_layers=self.num_layers,
                max_seq_len=self.max_seq_len,
                num_kv_heads=self.num_kv_heads,
                head_dim=self.head_dim,
            )

        return self._caches[session_id]

    def reset_session(self, session_id: str):
        """Clear cache for a specific session."""
        if session_id in self._caches:
            self._caches[session_id].reset()

    def delete_session(self, session_id: str):
        """Remove session cache entirely."""
        if session_id in self._caches:
            del self._caches[session_id]

    def total_memory_mb(self) -> float:
        return sum(c.memory_mb() for c in self._caches.values())
