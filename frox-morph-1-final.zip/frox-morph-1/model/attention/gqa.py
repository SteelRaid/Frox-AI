"""
Frox AI Morph 1 — Grouped Query Attention (GQA)
Llama 3.2 3B uses GQA: 24 query heads, 8 KV heads (3:1 ratio)
Flash Attention 2/3 support from Wan2.2 attention.py
"""
import math
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from model.embedding.rope import apply_rotary_pos_emb, MorphRotaryEmbedding

# Flash Attention availability (from Wan2.2 attention.py pattern)
try:
    from flash_attn import flash_attn_func, flash_attn_varlen_func
    FLASH_ATTN_AVAILABLE = True
except ImportError:
    FLASH_ATTN_AVAILABLE = False

try:
    import flash_attn_interface
    FLASH_ATTN_3_AVAILABLE = True
except ImportError:
    FLASH_ATTN_3_AVAILABLE = False


class MorphRMSNorm(nn.Module):
    """
    RMSNorm — used throughout Morph 1.
    From Wan2.2 WanRMSNorm + Llama RMSNorm.
    Faster than LayerNorm, no mean subtraction needed.
    """
    def __init__(self, hidden_size: int, eps: float = 1e-5):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Cast to float32 for numerical stability, then back
        input_dtype = x.dtype
        x = x.to(torch.float32)
        variance = x.pow(2).mean(dim=-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return (self.weight * x).to(input_dtype)


class MorphAttention(nn.Module):
    """
    Grouped Query Attention for Frox Morph 1.

    Config (3B):
        num_heads (Q):    24
        num_kv_heads:     8
        head_dim:         128
        hidden_size:      3072

    Speed features:
        - GQA reduces KV cache memory by 3×
        - Flash Attention 2/3 when available
        - QK normalization (from Wan2.2)
        - Sliding window attention for long context
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        max_position_embeddings: int = 131072,
        rope_theta: float = 500000.0,
        rope_scaling_factor: float = 32.0,
        attention_dropout: float = 0.0,
        qk_norm: bool = False,
        layer_idx: Optional[int] = None,
    ):
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.num_kv_groups = num_heads // num_kv_heads  # = 3
        self.attention_dropout = attention_dropout
        self.layer_idx = layer_idx
        self.scaling = head_dim ** -0.5

        # Projections
        self.q_proj = nn.Linear(hidden_size, num_heads * head_dim, bias=False)
        self.k_proj = nn.Linear(hidden_size, num_kv_heads * head_dim, bias=False)
        self.v_proj = nn.Linear(hidden_size, num_kv_heads * head_dim, bias=False)
        self.o_proj = nn.Linear(num_heads * head_dim, hidden_size, bias=False)

        # Optional QK norm (from Wan2.2 — improves stability)
        self.q_norm = MorphRMSNorm(head_dim) if qk_norm else nn.Identity()
        self.k_norm = MorphRMSNorm(head_dim) if qk_norm else nn.Identity()

        # RoPE
        self.rotary_emb = MorphRotaryEmbedding(
            dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            base=rope_theta,
            scaling_factor=rope_scaling_factor,
        )

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        use_cache: bool = False,
        output_attentions: bool = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple]]:

        B, S, _ = hidden_states.shape

        # Project Q, K, V
        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)

        # Reshape to heads
        q = q.view(B, S, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(B, S, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = v.view(B, S, self.num_kv_heads, self.head_dim).transpose(1, 2)

        # Apply QK norm
        q = self.q_norm(q)
        k = self.k_norm(k)

        # Apply RoPE
        if position_ids is None:
            position_ids = torch.arange(S, device=hidden_states.device).unsqueeze(0)
        cos, sin = self.rotary_emb(v, position_ids)
        q, k = apply_rotary_pos_emb(q, k, cos, sin)

        # KV cache for inference
        if past_key_value is not None:
            k = torch.cat([past_key_value[0], k], dim=2)
            v = torch.cat([past_key_value[1], v], dim=2)
        present = (k, v) if use_cache else None

        # Expand KV heads to match Q heads (GQA)
        k = k.repeat_interleave(self.num_kv_groups, dim=1)
        v = v.repeat_interleave(self.num_kv_groups, dim=1)

        # Attention computation
        attn_output = self._attention(q, k, v, attention_mask, B, S)

        # Output projection
        attn_output = attn_output.transpose(1, 2).contiguous().view(B, S, -1)
        attn_output = self.o_proj(attn_output)

        return attn_output, None, present

    def _attention(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        mask: Optional[torch.Tensor],
        B: int,
        S: int,
    ) -> torch.Tensor:
        """
        Choose fastest available attention implementation.
        Priority: Flash Attention 3 > Flash Attention 2 > PyTorch SDPA > manual
        """

        # Flash Attention 3 (fastest — Hopper H100)
        if FLASH_ATTN_3_AVAILABLE and q.dtype in (torch.float16, torch.bfloat16):
            q_ = q.transpose(1, 2)   # [B, S, H, D]
            k_ = k.transpose(1, 2)
            v_ = v.transpose(1, 2)
            out = flash_attn_interface.flash_attn_func(
                q_, k_, v_, causal=True
            )
            return out.transpose(1, 2)

        # Flash Attention 2 (A100, T4, RTX)
        if FLASH_ATTN_AVAILABLE and q.dtype in (torch.float16, torch.bfloat16):
            q_ = q.transpose(1, 2)
            k_ = k.transpose(1, 2)
            v_ = v.transpose(1, 2)
            out = flash_attn_func(q_, k_, v_, causal=True)
            return out.transpose(1, 2)

        # PyTorch SDPA (built-in since 2.0, uses Flash Attention kernel when possible)
        return F.scaled_dot_product_attention(
            q, k, v,
            attn_mask=mask,
            dropout_p=self.attention_dropout if self.training else 0.0,
            is_causal=(mask is None),
        )


class MorphMLP(nn.Module):
    """
    SwiGLU feed-forward network — Llama 3.2 style.
    out = W2(SiLU(W1(x)) * W3(x))
    """

    def __init__(self, hidden_size: int, intermediate_size: int):
        super().__init__()
        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.up_proj   = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=False)
        self.act_fn    = nn.SiLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down_proj(self.act_fn(self.gate_proj(x)) * self.up_proj(x))


class MorphDecoderLayer(nn.Module):
    """
    Single transformer decoder layer.
    Pre-norm: RMSNorm → Attention → residual → RMSNorm → MLP → residual
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        intermediate_size: int,
        max_position_embeddings: int,
        rope_theta: float,
        rope_scaling_factor: float,
        rms_norm_eps: float,
        layer_idx: int,
    ):
        super().__init__()

        self.self_attn = MorphAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            rope_theta=rope_theta,
            rope_scaling_factor=rope_scaling_factor,
            layer_idx=layer_idx,
        )
        self.mlp = MorphMLP(hidden_size, intermediate_size)
        self.input_layernorm = MorphRMSNorm(hidden_size, eps=rms_norm_eps)
        self.post_attention_layernorm = MorphRMSNorm(hidden_size, eps=rms_norm_eps)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
        past_key_value: Optional[Tuple] = None,
        use_cache: bool = False,
        output_attentions: bool = False,
    ) -> Tuple:

        # Self-attention with pre-norm
        residual = hidden_states
        hidden_states = self.input_layernorm(hidden_states)
        hidden_states, attn_weights, present = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            use_cache=use_cache,
            output_attentions=output_attentions,
        )
        hidden_states = residual + hidden_states

        # MLP with pre-norm
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        outputs = (hidden_states,)
        if output_attentions:
            outputs += (attn_weights,)
        if use_cache:
            outputs += (present,)

        return outputs
