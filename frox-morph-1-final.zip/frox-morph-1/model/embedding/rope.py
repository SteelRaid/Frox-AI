"""
Frox AI Morph 1 — Rotary Position Embedding
Combines:
- Llama 3.2 RoPE with long-context scaling (text)
- Wan2.2 3D RoPE for video (temporal + height + width)
"""
import math
from typing import Optional, Tuple

import torch
import torch.nn as nn


# ── 1D RoPE (Text — Llama 3.2 style) ────────────────────────────

class MorphRotaryEmbedding(nn.Module):
    """
    Llama 3.2 RoPE with YaRN long-context scaling.
    Supports up to 128K tokens via rope_scaling_factor.
    """

    def __init__(
        self,
        dim: int,
        max_position_embeddings: int = 131072,
        base: float = 500000.0,
        scaling_factor: float = 32.0,
        device: Optional[torch.device] = None,
    ):
        super().__init__()
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.scaling_factor = scaling_factor

        # Compute inverse frequencies
        inv_freq = 1.0 / (
            base ** (torch.arange(0, dim, 2, dtype=torch.float32, device=device) / dim)
        )
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Precompute for efficiency
        self._set_cos_sin_cache(max_position_embeddings, device)

    def _set_cos_sin_cache(self, seq_len: int, device: Optional[torch.device]):
        self.max_seq_len_cached = seq_len
        t = torch.arange(seq_len, device=device, dtype=torch.float32)
        t = t / self.scaling_factor

        freqs = torch.outer(t, self.inv_freq)
        emb = torch.cat([freqs, freqs], dim=-1)
        self.register_buffer("cos_cached", emb.cos(), persistent=False)
        self.register_buffer("sin_cached", emb.sin(), persistent=False)

    def forward(
        self,
        x: torch.Tensor,
        position_ids: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # Extend cache if needed
        if position_ids.max() >= self.max_seq_len_cached:
            self._set_cos_sin_cache(position_ids.max().item() + 1, x.device)

        cos = self.cos_cached[position_ids]
        sin = self.sin_cached[position_ids]
        return cos, sin


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Rotate half the hidden dims of the input — core RoPE operation."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat([-x2, x1], dim=-1)


def apply_rotary_pos_emb(
    q: torch.Tensor,
    k: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    unsqueeze_dim: int = 1,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Apply RoPE to query and key tensors."""
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


# ── 3D RoPE (Video — from Wan2.2) ────────────────────────────────

def rope_params_3d(
    max_seq_len: int,
    dim: int,
    theta: float = 10000.0,
) -> torch.Tensor:
    """
    Compute 3D RoPE frequency parameters.
    Used for video: temporal (T) × height (H) × width (W).
    Directly from Wan2.2 wan/modules/model.py
    """
    assert dim % 2 == 0
    freqs = torch.outer(
        torch.arange(max_seq_len),
        1.0 / torch.pow(
            theta,
            torch.arange(0, dim, 2).to(torch.float64).div(dim)
        )
    )
    freqs = torch.polar(torch.ones_like(freqs), freqs)
    return freqs


def rope_apply_3d(
    x: torch.Tensor,
    grid_sizes: torch.Tensor,
    freqs: torch.Tensor,
) -> torch.Tensor:
    """
    Apply 3D RoPE to video tensor.
    x: [B, L, num_heads, head_dim]
    grid_sizes: [B, 3] — (T, H, W) for each sample
    freqs: precomputed frequency tensor

    Directly adapted from Wan2.2 wan/modules/model.py rope_apply()
    """
    n, c = x.size(2), x.size(3) // 2

    # Split frequencies for T, H, W dimensions
    freqs = freqs.split([c - 2 * (c // 3), c // 3, c // 3], dim=1)

    output = []
    for i, (f, h, w) in enumerate(grid_sizes.tolist()):
        seq_len = f * h * w

        # View as complex for rotation
        x_i = torch.view_as_complex(
            x[i, :seq_len].to(torch.float64).reshape(seq_len, n, -1, 2)
        )

        # Build 3D frequency grid
        freqs_i = torch.cat([
            freqs[0][:f].view(f, 1, 1, -1).expand(f, h, w, -1),
            freqs[1][:h].view(1, h, 1, -1).expand(f, h, w, -1),
            freqs[2][:w].view(1, 1, w, -1).expand(f, h, w, -1),
        ], dim=-1).reshape(seq_len, 1, -1)

        # Apply rotation
        x_i = torch.view_as_real(x_i * freqs_i).flatten(2)
        x_i = torch.cat([x_i, x[i, seq_len:]])
        output.append(x_i)

    return torch.stack(output).float()


# ── Sinusoidal embedding (Wan2.2 style for timestep) ─────────────

def sinusoidal_embedding_1d(dim: int, position: torch.Tensor) -> torch.Tensor:
    """
    1D sinusoidal embedding for diffusion timesteps.
    From Wan2.2 wan/modules/model.py
    """
    assert dim % 2 == 0
    half = dim // 2
    position = position.to(torch.float64)

    sinusoid = torch.outer(
        position,
        torch.pow(10000, -torch.arange(half).to(position).div(half))
    )
    return torch.cat([torch.cos(sinusoid), torch.sin(sinusoid)], dim=1)
