"""
Frox AI Morph 1 — Core Language Model
Llama 3.2 3B architecture, trained from scratch.
Supports: text, vision tokens, video tokens, tool calls.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F

from config.model_config import MorphConfig, MorphTextConfig
from model.attention.gqa import MorphDecoderLayer, MorphRMSNorm


# ── Output dataclasses ────────────────────────────────────────────

@dataclass
class MorphModelOutput:
    last_hidden_state: torch.Tensor
    past_key_values: Optional[Tuple] = None
    hidden_states: Optional[Tuple] = None
    attentions: Optional[Tuple] = None


@dataclass
class MorphCausalLMOutput:
    loss: Optional[torch.Tensor] = None
    logits: torch.Tensor = None
    past_key_values: Optional[Tuple] = None
    hidden_states: Optional[Tuple] = None
    attentions: Optional[Tuple] = None


# ── Core Model ────────────────────────────────────────────────────

class MorphModel(nn.Module):
    """
    Frox Morph 1 transformer backbone.
    Pure decoder — no encoder cross-attention.
    Multimodal tokens are injected via vision/video projectors
    into the same embedding space.
    """

    def __init__(self, config: MorphTextConfig):
        super().__init__()
        self.config = config
        self.padding_idx = config.pad_token_id

        # Token embedding
        # vocab_size set at runtime to match tokenizer
        self.embed_tokens = nn.Embedding(
            config.vocab_size,
            config.hidden_size,
            padding_idx=self.padding_idx,
        )

        # Transformer layers
        self.layers = nn.ModuleList([
            MorphDecoderLayer(
                hidden_size=config.hidden_size,
                num_heads=config.num_attention_heads,
                num_kv_heads=config.num_key_value_heads,
                head_dim=config.head_dim,
                intermediate_size=config.intermediate_size,
                max_position_embeddings=config.max_position_embeddings,
                rope_theta=config.rope_theta,
                rope_scaling_factor=config.rope_scaling_factor,
                rms_norm_eps=config.rms_norm_eps,
                layer_idx=i,
            )
            for i in range(config.num_hidden_layers)
        ])

        # Final norm
        self.norm = MorphRMSNorm(config.hidden_size, eps=config.rms_norm_eps)

        # Weight init
        self.apply(self._init_weights)

    def _init_weights(self, module: nn.Module):
        """Llama-style weight initialization."""
        std = 0.02
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=std)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=std)
            if module.padding_idx is not None:
                module.weight.data[module.padding_idx].zero_()

    def get_input_embeddings(self) -> nn.Embedding:
        return self.embed_tokens

    def set_input_embeddings(self, value: nn.Embedding):
        self.embed_tokens = value

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[Tuple]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        use_cache: bool = True,
        output_attentions: bool = False,
        output_hidden_states: bool = False,
    ) -> MorphModelOutput:

        # Get embeddings
        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)

        hidden_states = inputs_embeds
        B, S, _ = hidden_states.shape

        # Build position IDs
        if position_ids is None:
            past_len = past_key_values[0][0].shape[2] if past_key_values else 0
            position_ids = torch.arange(
                past_len, past_len + S,
                device=hidden_states.device,
            ).unsqueeze(0).expand(B, -1)

        # Build causal mask
        causal_mask = self._build_causal_mask(
            attention_mask, hidden_states.dtype, hidden_states.device, S,
            past_key_values[0][0].shape[2] if past_key_values else 0,
        )

        # Track outputs
        all_hidden_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None
        next_cache = () if use_cache else None

        # Run through all layers
        for i, layer in enumerate(self.layers):
            if output_hidden_states:
                all_hidden_states += (hidden_states,)

            past_kv = past_key_values[i] if past_key_values is not None else None

            layer_outputs = layer(
                hidden_states=hidden_states,
                attention_mask=causal_mask,
                position_ids=position_ids,
                past_key_value=past_kv,
                use_cache=use_cache,
                output_attentions=output_attentions,
            )

            hidden_states = layer_outputs[0]

            if output_attentions:
                all_attentions += (layer_outputs[1],)
            if use_cache:
                next_cache += (layer_outputs[-1],)

        # Final norm
        hidden_states = self.norm(hidden_states)

        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        return MorphModelOutput(
            last_hidden_state=hidden_states,
            past_key_values=next_cache,
            hidden_states=all_hidden_states,
            attentions=all_attentions,
        )

    def _build_causal_mask(
        self,
        attention_mask: Optional[torch.Tensor],
        dtype: torch.dtype,
        device: torch.device,
        seq_len: int,
        past_len: int,
    ) -> Optional[torch.Tensor]:
        """Build 4D causal attention mask."""
        total_len = seq_len + past_len
        causal = torch.full(
            (seq_len, total_len), fill_value=torch.finfo(dtype).min,
            dtype=dtype, device=device,
        )
        causal = torch.triu(causal, diagonal=past_len + 1)

        if attention_mask is not None:
            # Expand padding mask
            pad_mask = (1.0 - attention_mask[:, None, None, :].to(dtype))
            pad_mask = pad_mask * torch.finfo(dtype).min
            causal = causal + pad_mask[:, :, :seq_len, :]

        return causal.unsqueeze(1)


# ── Causal LM Head ────────────────────────────────────────────────

class MorphForCausalLM(nn.Module):
    """
    Frox Morph 1 — full causal language model.
    Backbone + LM head + generation utilities.
    """

    def __init__(self, config: MorphTextConfig):
        super().__init__()
        self.config = config
        self.model = MorphModel(config)

        # LM head (tied to embeddings)
        self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        # Tie weights (reduces parameters, standard practice)
        if config.tie_word_embeddings:
            self.lm_head.weight = self.model.embed_tokens.weight

    def get_input_embeddings(self) -> nn.Embedding:
        return self.model.embed_tokens

    def set_input_embeddings(self, value):
        self.model.embed_tokens = value

    def get_output_embeddings(self) -> nn.Linear:
        return self.lm_head

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[Tuple]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: bool = True,
        output_attentions: bool = False,
        output_hidden_states: bool = False,
    ) -> MorphCausalLMOutput:

        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
        )

        hidden_states = outputs.last_hidden_state
        logits = self.lm_head(hidden_states).float()

        loss = None
        if labels is not None:
            # Shift for next-token prediction
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            loss = F.cross_entropy(
                shift_logits.view(-1, shift_logits.size(-1)),
                shift_labels.view(-1),
                ignore_index=-100,
            )

        return MorphCausalLMOutput(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )

    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.Tensor] = None,
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = 50,
        repetition_penalty: float = 1.1,
        eos_token_id: Optional[int] = None,
        pad_token_id: Optional[int] = None,
        use_cache: bool = True,
        do_sample: bool = True,
    ) -> torch.LongTensor:
        """
        Autoregressive generation with KV cache.
        Supports temperature, top-p, top-k, repetition penalty.
        """
        eos_token_id = eos_token_id or self.config.eos_token_id
        pad_token_id = pad_token_id or self.config.pad_token_id

        B = input_ids.shape[0]
        generated = input_ids.clone()
        past_key_values = None
        finished = torch.zeros(B, dtype=torch.bool, device=input_ids.device)

        for step in range(max_new_tokens):
            # Use only new tokens after first pass (with KV cache)
            if past_key_values is not None:
                curr_input = generated[:, -1:]
            else:
                curr_input = generated

            outputs = self.forward(
                input_ids=curr_input,
                attention_mask=attention_mask,
                past_key_values=past_key_values,
                use_cache=use_cache,
            )

            logits = outputs.logits[:, -1, :]
            past_key_values = outputs.past_key_values

            # Repetition penalty
            if repetition_penalty != 1.0:
                for b in range(B):
                    for token_id in set(generated[b].tolist()):
                        if logits[b, token_id] < 0:
                            logits[b, token_id] *= repetition_penalty
                        else:
                            logits[b, token_id] /= repetition_penalty

            # Temperature
            if temperature != 1.0:
                logits = logits / temperature

            # Top-k
            if top_k > 0:
                top_k_vals, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < top_k_vals[:, -1:]] = float('-inf')

            # Top-p (nucleus sampling)
            if do_sample and top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cumulative_probs - F.softmax(sorted_logits, dim=-1) > top_p
                sorted_logits[sorted_indices_to_remove] = float('-inf')
                logits = torch.zeros_like(logits).scatter_(1, sorted_indices, sorted_logits)

            # Sample or greedy
            if do_sample:
                probs = F.softmax(logits, dim=-1)
                next_token = torch.multinomial(probs, num_samples=1)
            else:
                next_token = logits.argmax(dim=-1, keepdim=True)

            # Handle finished sequences
            next_token = torch.where(
                finished.unsqueeze(-1),
                torch.full_like(next_token, pad_token_id),
                next_token,
            )

            generated = torch.cat([generated, next_token], dim=-1)

            # Update attention mask
            if attention_mask is not None:
                attention_mask = torch.cat([
                    attention_mask,
                    torch.ones(B, 1, device=attention_mask.device),
                ], dim=-1)

            # Check EOS
            finished = finished | (next_token.squeeze(-1) == eos_token_id)
            if finished.all():
                break

        return generated

    def param_count(self) -> dict:
        """Return parameter counts for transparency."""
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {
            "total": total,
            "trainable": trainable,
            "total_billions": round(total / 1e9, 3),
            "trainable_billions": round(trainable / 1e9, 3),
        }

    def save(self, path: str):
        """Save model weights and config."""
        import os, json
        os.makedirs(path, exist_ok=True)
        torch.save(self.state_dict(), f"{path}/model.pt")
        # Save config
        from dataclasses import asdict
        with open(f"{path}/config.json", "w") as f:
            json.dump(asdict(self.config), f, indent=2)
        print(f"✓ Morph 1 saved to {path}")

    @classmethod
    def from_saved(cls, path: str) -> "MorphForCausalLM":
        """Load saved model."""
        import json
        with open(f"{path}/config.json") as f:
            cfg_dict = json.load(f)
        from config.model_config import MorphTextConfig
        config = MorphTextConfig(**cfg_dict)
        model = cls(config)
        state = torch.load(f"{path}/model.pt", map_location="cpu")
        model.load_state_dict(state)
        return model
