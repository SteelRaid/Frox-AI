# Frox AI Unified

This archive merges the Frox AI phases into one Vite + React project.

## Run

```bash
npm install
npm run dev
```

## Main routes

- `/` launcher
- `/phase-1`
- `/auth/*`
- `/chat-engine/*`
- `/chat-module`
- `/memory/*`
- `/voice/*`
- `/video`
