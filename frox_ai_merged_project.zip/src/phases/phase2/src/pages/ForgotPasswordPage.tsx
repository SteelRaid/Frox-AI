import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react'
import { AuthLayout } from '../components/auth/AuthLayout'
import { Input } from '../components/ui/Input'
import { Button } from '../components/ui/Button'
import { Toast, useToast } from '../components/ui/Toast'
import { useAuth } from '../contexts/AuthContext'
import { useForm } from '../hooks/useForm'
import { validateEmail } from '../lib/utils'

interface ForgotPasswordForm {
  email: string
}

export function ForgotPasswordPage() {
  const { resetPassword } = useAuth()
  const navigate = useNavigate()
  const { toast, showToast, hideToast } = useToast()
  const [isSent, setIsSent] = React.useState(false)

  const form = useForm<ForgotPasswordForm>({
    initialValues: { email: '' },
    validate: (values) => {
      const errors: Partial<Record<keyof ForgotPasswordForm, string>> = {}
      if (!values.email) {
        errors.email = 'Email is required'
      } else if (!validateEmail(values.email)) {
        errors.email = 'Please enter a valid email'
      }
      return errors
    },
    onSubmit: async (values) => {
      const { error } = await resetPassword(values.email)
      if (error) {
        showToast(error.message, 'error')
      } else {
        setIsSent(true)
        showToast('Password reset email sent!', 'success')
      }
    },
  })

  if (isSent) {
    return (
      <AuthLayout
        title="Check your email"
        subtitle="We've sent you a password reset link"
        footer={
          <Link
            to="/auth/sign-in"
            className="text-frox-400 hover:text-frox-300 font-medium transition-colors text-sm"
          >
            Back to Sign In
          </Link>
        }
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center text-center py-6"
        >
          <div className="w-16 h-16 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center mb-6">
            <CheckCircle className="w-8 h-8 text-green-400" />
          </div>
          <p className="text-neutral-400 mb-6">
            Click the link in the email to reset your password.
            If you don't see it, check your spam folder.
          </p>
          <Button variant="outline" fullWidth onClick={() => setIsSent(false)}>
            Send Again
          </Button>
        </motion.div>
      </AuthLayout>
    )
  }

  return (
    <>
      <AuthLayout
        title="Forgot password?"
        subtitle="Enter your email and we'll send you a reset link"
        footer={
          <Link
            to="/auth/sign-in"
            className="inline-flex items-center gap-2 text-frox-400 hover:text-frox-300 font-medium transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Sign In
          </Link>
        }
      >
        <form onSubmit={form.handleSubmit} className="space-y-5">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Input
              type="email"
              placeholder="Enter your email"
              label="Email"
              icon={<Mail className="w-5 h-5" />}
              value={form.values.email}
              onChange={(e) => form.setValue('email', e.target.value)}
              onBlur={() => form.setFieldTouched('email')}
              error={form.touched.email ? form.errors.email : null}
              autoComplete="email"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Button
              type="submit"
              fullWidth
              isLoading={form.isSubmitting}
            >
              Send Reset Link
            </Button>
          </motion.div>
        </form>
      </AuthLayout>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}
