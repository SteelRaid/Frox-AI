import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Mail, Lock, User, ArrowRight } from 'lucide-react'
import { AuthLayout } from '../components/auth/AuthLayout'
import { OAuthButtons } from '../components/auth/OAuthButtons'
import { Divider } from '../components/auth/Divider'
import { Input } from '../components/ui/Input'
import { Button } from '../components/ui/Button'
import { PasswordStrength } from '../components/ui/PasswordStrength'
import { Toast, useToast } from '../components/ui/Toast'
import { useAuth } from '../contexts/AuthContext'
import { useForm } from '../hooks/useForm'
import { validateEmail, validatePassword } from '../lib/utils'

interface SignUpForm {
  fullName: string
  email: string
  password: string
  confirmPassword: string
}

export function SignUpPage() {
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const { toast, showToast, hideToast } = useToast()
  const [passwordValidation, setPasswordValidation] = React.useState({
    strength: 0,
    errors: [] as string[],
  })

  const form = useForm<SignUpForm>({
    initialValues: { fullName: '', email: '', password: '', confirmPassword: '' },
    validate: (values) => {
      const errors: Partial<Record<keyof SignUpForm, string>> = {}

      if (!values.fullName.trim()) {
        errors.fullName = 'Full name is required'
      }

      if (!values.email) {
        errors.email = 'Email is required'
      } else if (!validateEmail(values.email)) {
        errors.email = 'Please enter a valid email'
      }

      if (!values.password) {
        errors.password = 'Password is required'
      } else {
        const validation = validatePassword(values.password)
        if (!validation.isValid) {
          errors.password = 'Password does not meet requirements'
        }
      }

      if (values.password !== values.confirmPassword) {
        errors.confirmPassword = 'Passwords do not match'
      }

      return errors
    },
    onSubmit: async (values) => {
      const { error } = await signUp(values.email, values.password)
      if (error) {
        showToast(error.message, 'error')
      } else {
        showToast('Check your email to verify your account!', 'success')
        navigate('/auth/verify-email', { state: { email: values.email } })
      }
    },
  })

  const handlePasswordChange = (value: string) => {
    form.setValue('password', value)
    const validation = validatePassword(value)
    setPasswordValidation(validation)
  }

  return (
    <>
      <AuthLayout
        title="Create an account"
        subtitle="Start your journey with Frox AI"
        footer={
          <p className="text-neutral-400 text-sm">
            Already have an account?{' '}
            <Link to="/auth/sign-in" className="text-frox-400 hover:text-frox-300 font-medium transition-colors">
              Sign in
            </Link>
          </p>
        }
      >
        <OAuthButtons />
        <Divider />

        <form onSubmit={form.handleSubmit} className="space-y-5">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Input
              type="text"
              placeholder="Enter your full name"
              label="Full Name"
              icon={<User className="w-5 h-5" />}
              value={form.values.fullName}
              onChange={(e) => form.setValue('fullName', e.target.value)}
              onBlur={() => form.setFieldTouched('fullName')}
              error={form.touched.fullName ? form.errors.fullName : null}
              autoComplete="name"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.25 }}
          >
            <Input
              type="email"
              placeholder="Enter your email"
              label="Email"
              icon={<Mail className="w-5 h-5" />}
              value={form.values.email}
              onChange={(e) => form.setValue('email', e.target.value)}
              onBlur={() => form.setFieldTouched('email')}
              error={form.touched.email ? form.errors.email : null}
              autoComplete="email"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Input
              type="password"
              placeholder="Create a password"
              label="Password"
              icon={<Lock className="w-5 h-5" />}
              value={form.values.password}
              onChange={(e) => handlePasswordChange(e.target.value)}
              onBlur={() => form.setFieldTouched('password')}
              error={form.touched.password ? form.errors.password : null}
              autoComplete="new-password"
            />
            <PasswordStrength 
              strength={passwordValidation.strength} 
              errors={passwordValidation.errors} 
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.35 }}
          >
            <Input
              type="password"
              placeholder="Confirm your password"
              label="Confirm Password"
              icon={<Lock className="w-5 h-5" />}
              value={form.values.confirmPassword}
              onChange={(e) => form.setValue('confirmPassword', e.target.value)}
              onBlur={() => form.setFieldTouched('confirmPassword')}
              error={form.touched.confirmPassword ? form.errors.confirmPassword : null}
              autoComplete="new-password"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
          >
            <Button
              type="submit"
              fullWidth
              isLoading={form.isSubmitting}
              className="group"
            >
              Create Account
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>

          <p className="text-xs text-neutral-500 text-center">
            By creating an account, you agree to our{' '}
            <Link to="/terms" className="text-frox-400 hover:text-frox-300">
              Terms of Service
            </Link>{' '}
            and{' '}
            <Link to="/privacy" className="text-frox-400 hover:text-frox-300">
              Privacy Policy
            </Link>
          </p>
        </form>
      </AuthLayout>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}
