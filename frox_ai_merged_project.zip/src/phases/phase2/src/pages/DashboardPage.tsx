import React from 'react'
import { motion } from 'framer-motion'
import { MessageSquare, Zap, Clock, TrendingUp, Sparkles } from 'lucide-react'
import { GlassCard } from '../components/ui/GlassCard'
import { AnimatedBackground } from '../components/ui/AnimatedBackground'
import { Navbar } from '../components/layout/Navbar'
import { Footer } from '../components/layout/Footer'
import { useAuth } from '../contexts/AuthContext'
import { useProtectedRoute } from '../hooks/useAuthRedirect'

const stats = [
  { label: 'Conversations', value: '0', icon: <MessageSquare className="w-5 h-5" />, color: 'from-frox-500/20 to-frox-600/20' },
  { label: 'Tokens Used', value: '0', icon: <Zap className="w-5 h-5" />, color: 'from-cyan-500/20 to-cyan-600/20' },
  { label: 'Session Time', value: '0m', icon: <Clock className="w-5 h-5" />, color: 'from-purple-500/20 to-purple-600/20' },
  { label: 'Efficiency', value: '100%', icon: <TrendingUp className="w-5 h-5" />, color: 'from-green-500/20 to-green-600/20' },
]

export function DashboardPage() {
  useProtectedRoute()
  const { user } = useAuth()

  return (
    <div className="min-h-screen relative">
      <AnimatedBackground />
      <Navbar />

      <main className="pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <h1 className="text-3xl font-bold text-white mb-2">
              Welcome back, {user?.email?.split('@')[0] || 'User'}!
            </h1>
            <p className="text-neutral-400">
              Here's what's happening with your Frox AI account.
            </p>
          </motion.div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <GlassCard hover>
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center text-white`}>
                      {stat.icon}
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-white">{stat.value}</p>
                      <p className="text-sm text-neutral-400">{stat.label}</p>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>

          {/* Main Content Area */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chat Area Placeholder */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="lg:col-span-2"
            >
              <GlassCard className="h-[500px] flex flex-col">
                <div className="flex items-center gap-3 mb-6">
                  <Sparkles className="w-5 h-5 text-frox-400" />
                  <h2 className="text-lg font-semibold text-white">New Conversation</h2>
                </div>
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-2xl bg-frox-500/10 border border-frox-500/20 flex items-center justify-center mx-auto mb-4">
                      <Sparkles className="w-8 h-8 text-frox-400" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">
                      Start a new conversation
                    </h3>
                    <p className="text-neutral-400 max-w-sm">
                      Ask Frox AI anything — from coding help to creative writing, research, and more.
                    </p>
                  </div>
                </div>
              </GlassCard>
            </motion.div>

            {/* Sidebar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <GlassCard className="h-[500px]">
                <h2 className="text-lg font-semibold text-white mb-4">Recent Activity</h2>
                <div className="flex flex-col items-center justify-center h-full text-neutral-500">
                  <Clock className="w-8 h-8 mb-3 opacity-50" />
                  <p className="text-sm">No recent activity</p>
                </div>
              </GlassCard>
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
