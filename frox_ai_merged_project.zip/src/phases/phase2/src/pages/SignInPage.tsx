import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Mail, Lock, ArrowRight } from 'lucide-react'
import { AuthLayout } from '../components/auth/AuthLayout'
import { OAuthButtons } from '../components/auth/OAuthButtons'
import { Divider } from '../components/auth/Divider'
import { Input } from '../components/ui/Input'
import { Button } from '../components/ui/Button'
import { Toast, useToast } from '../components/ui/Toast'
import { useAuth } from '../contexts/AuthContext'
import { useForm } from '../hooks/useForm'
import { validateEmail } from '../lib/utils'

interface SignInForm {
  email: string
  password: string
}

export function SignInPage() {
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const { toast, showToast, hideToast } = useToast()

  const form = useForm<SignInForm>({
    initialValues: { email: '', password: '' },
    validate: (values) => {
      const errors: Partial<Record<keyof SignInForm, string>> = {}
      if (!values.email) {
        errors.email = 'Email is required'
      } else if (!validateEmail(values.email)) {
        errors.email = 'Please enter a valid email'
      }
      if (!values.password) {
        errors.password = 'Password is required'
      }
      return errors
    },
    onSubmit: async (values) => {
      const { error } = await signIn(values.email, values.password)
      if (error) {
        showToast(error.message, 'error')
      } else {
        showToast('Welcome back!', 'success')
        navigate('/auth/dashboard')
      }
    },
  })

  return (
    <>
      <AuthLayout
        title="Welcome back"
        subtitle="Sign in to your Frox AI account"
        footer={
          <p className="text-neutral-400 text-sm">
            Don't have an account?{' '}
            <Link to="/auth/sign-up" className="text-frox-400 hover:text-frox-300 font-medium transition-colors">
              Sign up
            </Link>
          </p>
        }
      >
        <OAuthButtons />
        <Divider />

        <form onSubmit={form.handleSubmit} className="space-y-5">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Input
              type="email"
              placeholder="Enter your email"
              label="Email"
              icon={<Mail className="w-5 h-5" />}
              value={form.values.email}
              onChange={(e) => form.setValue('email', e.target.value)}
              onBlur={() => form.setFieldTouched('email')}
              error={form.touched.email ? form.errors.email : null}
              autoComplete="email"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Input
              type="password"
              placeholder="Enter your password"
              label="Password"
              icon={<Lock className="w-5 h-5" />}
              value={form.values.password}
              onChange={(e) => form.setValue('password', e.target.value)}
              onBlur={() => form.setFieldTouched('password')}
              error={form.touched.password ? form.errors.password : null}
              autoComplete="current-password"
            />
          </motion.div>

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="checkbox"
                className="w-4 h-4 rounded border-glass-border bg-glass-100 text-frox-500 focus:ring-frox-500/50"
              />
              <span className="text-sm text-neutral-400 group-hover:text-neutral-300 transition-colors">
                Remember me
              </span>
            </label>
            <Link
              to="/auth/forgot-password"
              className="text-sm text-frox-400 hover:text-frox-300 transition-colors"
            >
              Forgot password?
            </Link>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
          >
            <Button
              type="submit"
              fullWidth
              isLoading={form.isSubmitting}
              className="group"
            >
              Sign In
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>
        </form>
      </AuthLayout>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}
