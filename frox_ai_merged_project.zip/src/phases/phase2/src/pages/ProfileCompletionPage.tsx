import React from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { User, Link as LinkIcon, FileText, ArrowRight, Camera } from 'lucide-react'
import { AuthLayout } from '../components/auth/AuthLayout'
import { Input } from '../components/ui/Input'
import { Button } from '../components/ui/Button'
import { Toast, useToast } from '../components/ui/Toast'
import { useAuth } from '../contexts/AuthContext'
import { useForm } from '../hooks/useForm'
import { useProtectedRoute } from '../hooks/useAuthRedirect'

interface ProfileForm {
  fullName: string
  bio: string
  website: string
}

export function ProfileCompletionPage() {
  useProtectedRoute()
  const { user, updateProfile } = useAuth()
  const navigate = useNavigate()
  const { toast, showToast, hideToast } = useToast()

  const form = useForm<ProfileForm>({
    initialValues: { fullName: '', bio: '', website: '' },
    validate: (values) => {
      const errors: Partial<Record<keyof ProfileForm, string>> = {}
      if (!values.fullName.trim()) {
        errors.fullName = 'Full name is required'
      }
      if (values.website && !values.website.match(/^https?:\/\/.+/)) {
        errors.website = 'Please enter a valid URL'
      }
      return errors
    },
    onSubmit: async (values) => {
      const { error } = await updateProfile({
        full_name: values.fullName,
        bio: values.bio || null,
        website: values.website || null,
      })
      if (error) {
        showToast(error.message, 'error')
      } else {
        showToast('Profile completed successfully!', 'success')
        navigate('/auth/dashboard')
      }
    },
  })

  return (
    <>
      <AuthLayout
        title="Complete your profile"
        subtitle="Tell us a bit more about yourself"
      >
        <form onSubmit={form.handleSubmit} className="space-y-5">
          {/* Avatar placeholder */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="flex justify-center mb-6"
          >
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-frox-500/20 to-frox-700/20 border-2 border-frox-500/30 flex items-center justify-center">
                <Camera className="w-8 h-8 text-frox-400" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-frox-500 flex items-center justify-center cursor-pointer hover:bg-frox-400 transition-colors">
                <Camera className="w-4 h-4 text-white" />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <Input
              type="text"
              placeholder="Enter your full name"
              label="Full Name *"
              icon={<User className="w-5 h-5" />}
              value={form.values.fullName}
              onChange={(e) => form.setValue('fullName', e.target.value)}
              onBlur={() => form.setFieldTouched('fullName')}
              error={form.touched.fullName ? form.errors.fullName : null}
              autoComplete="name"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <label className="block text-sm font-medium text-neutral-300 mb-2">
              Bio
            </label>
            <div className="relative">
              <div className="absolute left-4 top-3 text-neutral-500">
                <FileText className="w-5 h-5" />
              </div>
              <textarea
                placeholder="Tell us about yourself..."
                rows={3}
                className="glass-input w-full pl-12 resize-none"
                value={form.values.bio}
                onChange={(e) => form.setValue('bio', e.target.value)}
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Input
              type="url"
              placeholder="https://your-website.com"
              label="Website"
              icon={<LinkIcon className="w-5 h-5" />}
              value={form.values.website}
              onChange={(e) => form.setValue('website', e.target.value)}
              onBlur={() => form.setFieldTouched('website')}
              error={form.touched.website ? form.errors.website : null}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
            className="flex gap-3"
          >
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => navigate('/auth/dashboard')}
            >
              Skip for now
            </Button>
            <Button
              type="submit"
              className="flex-1 group"
              isLoading={form.isSubmitting}
            >
              Complete Profile
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>
        </form>
      </AuthLayout>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}
