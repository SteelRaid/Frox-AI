import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Mail, RefreshCw, ArrowRight } from 'lucide-react'
import { AuthLayout } from '../components/auth/AuthLayout'
import { Button } from '../components/ui/Button'
import { Toast, useToast } from '../components/ui/Toast'
import { useAuth } from '../contexts/AuthContext'

export function VerifyEmailPage() {
  const location = useLocation()
  const navigate = useNavigate()
  const { resendVerificationEmail } = useAuth()
  const { toast, showToast, hideToast } = useToast()
  const [isResending, setIsResending] = React.useState(false)
  const [countdown, setCountdown] = React.useState(60)
  const email = (location.state as { email?: string })?.email

  React.useEffect(() => {
    if (!email) {
      navigate('/auth/sign-up')
    }
  }, [email, navigate])

  React.useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown((c) => c - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [countdown])

  const handleResend = async () => {
    if (!email || countdown > 0) return
    setIsResending(true)
    const { error } = await resendVerificationEmail(email)
    if (error) {
      showToast(error.message, 'error')
    } else {
      showToast('Verification email sent!', 'success')
      setCountdown(60)
    }
    setIsResending(false)
  }

  return (
    <>
      <AuthLayout
        title="Verify your email"
        subtitle={`We've sent a verification link to ${email}`}
        footer={
          <p className="text-neutral-400 text-sm">
            Already verified?{' '}
            <Link to="/auth/sign-in" className="text-frox-400 hover:text-frox-300 font-medium transition-colors">
              Sign in
            </Link>
          </p>
        }
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center text-center py-6"
        >
          <div className="w-16 h-16 rounded-2xl bg-frox-500/10 border border-frox-500/20 flex items-center justify-center mb-6">
            <Mail className="w-8 h-8 text-frox-400" />
          </div>

          <p className="text-neutral-400 mb-6 max-w-sm">
            Click the link in the email we sent to verify your account.
            If you don't see it, check your spam folder.
          </p>

          <div className="space-y-3 w-full">
            <Button
              variant="outline"
              fullWidth
              isLoading={isResending}
              onClick={handleResend}
              disabled={countdown > 0}
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              {countdown > 0 ? `Resend in ${countdown}s` : 'Resend Email'}
            </Button>

            <Link to="/auth/sign-in" className="block">
              <Button variant="ghost" fullWidth className="flex items-center gap-2">
                Back to Sign In
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </AuthLayout>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}
