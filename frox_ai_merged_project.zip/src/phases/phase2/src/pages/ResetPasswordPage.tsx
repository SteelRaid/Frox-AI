import React from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Lock, ArrowRight } from 'lucide-react'
import { AuthLayout } from '../components/auth/AuthLayout'
import { Input } from '../components/ui/Input'
import { Button } from '../components/ui/Button'
import { PasswordStrength } from '../components/ui/PasswordStrength'
import { Toast, useToast } from '../components/ui/Toast'
import { useAuth } from '../contexts/AuthContext'
import { useForm } from '../hooks/useForm'
import { validatePassword } from '../lib/utils'

interface ResetPasswordForm {
  password: string
  confirmPassword: string
}

export function ResetPasswordPage() {
  const { updatePassword } = useAuth()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const { toast, showToast, hideToast } = useToast()
  const [passwordValidation, setPasswordValidation] = React.useState({
    strength: 0,
    errors: [] as string[],
  })

  // Check for access token in URL (Supabase sends this)
  React.useEffect(() => {
    const accessToken = searchParams.get('access_token')
    if (!accessToken) {
      showToast('Invalid or expired reset link', 'error')
      navigate('/auth/forgot-password')
    }
  }, [searchParams, navigate, showToast])

  const form = useForm<ResetPasswordForm>({
    initialValues: { password: '', confirmPassword: '' },
    validate: (values) => {
      const errors: Partial<Record<keyof ResetPasswordForm, string>> = {}

      if (!values.password) {
        errors.password = 'Password is required'
      } else {
        const validation = validatePassword(values.password)
        if (!validation.isValid) {
          errors.password = 'Password does not meet requirements'
        }
      }

      if (values.password !== values.confirmPassword) {
        errors.confirmPassword = 'Passwords do not match'
      }

      return errors
    },
    onSubmit: async (values) => {
      const { error } = await updatePassword(values.password)
      if (error) {
        showToast(error.message, 'error')
      } else {
        showToast('Password updated successfully!', 'success')
        setTimeout(() => navigate('/auth/sign-in'), 2000)
      }
    },
  })

  const handlePasswordChange = (value: string) => {
    form.setValue('password', value)
    const validation = validatePassword(value)
    setPasswordValidation(validation)
  }

  return (
    <>
      <AuthLayout
        title="Reset your password"
        subtitle="Create a new password for your account"
      >
        <form onSubmit={form.handleSubmit} className="space-y-5">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Input
              type="password"
              placeholder="Enter new password"
              label="New Password"
              icon={<Lock className="w-5 h-5" />}
              value={form.values.password}
              onChange={(e) => handlePasswordChange(e.target.value)}
              onBlur={() => form.setFieldTouched('password')}
              error={form.touched.password ? form.errors.password : null}
              autoComplete="new-password"
            />
            <PasswordStrength 
              strength={passwordValidation.strength} 
              errors={passwordValidation.errors} 
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Input
              type="password"
              placeholder="Confirm new password"
              label="Confirm Password"
              icon={<Lock className="w-5 h-5" />}
              value={form.values.confirmPassword}
              onChange={(e) => form.setValue('confirmPassword', e.target.value)}
              onBlur={() => form.setFieldTouched('confirmPassword')}
              error={form.touched.confirmPassword ? form.errors.confirmPassword : null}
              autoComplete="new-password"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
          >
            <Button
              type="submit"
              fullWidth
              isLoading={form.isSubmitting}
              className="group"
            >
              Update Password
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </motion.div>
        </form>
      </AuthLayout>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  )
}
