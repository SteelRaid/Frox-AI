import { useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

export function useAuthRedirect(redirectTo: string = '/auth/dashboard') {
  const { isAuthenticated, isLoading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      const from = (location.state as { from?: { pathname: string } })?.from?.pathname
      navigate(from || redirectTo, { replace: true })
    }
  }, [isAuthenticated, isLoading, navigate, location, redirectTo])
}

export function useProtectedRoute() {
  const { isAuthenticated, isLoading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate('/auth/sign-in', { replace: true, state: { from: location } })
    }
  }, [isAuthenticated, isLoading, navigate, location])
}
