import { Navigate, Route, Routes } from 'react-router-dom'
import { WelcomePage } from './pages/WelcomePage'
import { SignInPage } from './pages/SignInPage'
import { SignUpPage } from './pages/SignUpPage'
import { ForgotPasswordPage } from './pages/ForgotPasswordPage'
import { ResetPasswordPage } from './pages/ResetPasswordPage'
import { VerifyEmailPage } from './pages/VerifyEmailPage'
import { ProfileCompletionPage } from './pages/ProfileCompletionPage'
import { DashboardPage } from './pages/DashboardPage'

export default function App() {
  return (
    <Routes>
      <Route path="/auth" element={<Navigate to="/auth/welcome" replace />} />
      <Route path="/auth/welcome" element={<WelcomePage />} />
      <Route path="/auth/sign-in" element={<SignInPage />} />
      <Route path="/auth/sign-up" element={<SignUpPage />} />
      <Route path="/auth/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/auth/reset-password" element={<ResetPasswordPage />} />
      <Route path="/auth/verify-email" element={<VerifyEmailPage />} />
      <Route path="/auth/profile-completion" element={<ProfileCompletionPage />} />
      <Route path="/auth/dashboard" element={<DashboardPage />} />
      <Route path="*" element={<Navigate to="/auth/welcome" replace />} />
    </Routes>
  )
}
