import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function validatePassword(password: string): {
  isValid: boolean
  strength: number
  errors: string[]
} {
  const errors: string[] = []
  let strength = 0

  if (password.length >= 8) {
    strength += 1
  } else {
    errors.push('At least 8 characters')
  }

  if (/[A-Z]/.test(password)) {
    strength += 1
  } else {
    errors.push('At least one uppercase letter')
  }

  if (/[a-z]/.test(password)) {
    strength += 1
  } else {
    errors.push('At least one lowercase letter')
  }

  if (/[0-9]/.test(password)) {
    strength += 1
  } else {
    errors.push('At least one number')
  }

  if (/[^A-Za-z0-9]/.test(password)) {
    strength += 1
  } else {
    errors.push('At least one special character')
  }

  return {
    isValid: errors.length === 0,
    strength,
    errors,
  }
}
