import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

type AnyRecord = Record<string, unknown>

function createFallbackChain() {
  const chain: AnyRecord = new Proxy(
    {},
    {
      get: (_target, prop) => {
        if (prop === 'then') return undefined
        return (..._args: unknown[]) => chain
      },
    },
  )

  return {
    select: () => chain,
    insert: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
    upsert: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
    update: () => chain,
    delete: () => chain,
    eq: () => chain,
    in: () => chain,
    order: () => chain,
    limit: () => chain,
    single: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
    maybeSingle: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
    rpc: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
  }
}

function createFallbackClient() {
  const table = () => createFallbackChain()
  return {
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => void 0 } } }),
      signUp: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
      signInWithPassword: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
      signInWithOAuth: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
      signOut: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
      resetPasswordForEmail: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
      updateUser: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
      resend: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
    },
    from: (_name: string) => table(),
    storage: {
      from: (_bucket: string) => ({
        upload: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
        remove: async () => ({ data: null, error: { message: 'Supabase is not configured', status: 503 } }),
        getPublicUrl: (path: string) => ({ data: { publicUrl: `local://${path}` } }),
      }),
    },
    channel: () => ({ on: () => createFallbackClient().channel(), subscribe: () => ({ unsubscribe: () => void 0 }) }),
  } as any
}

export const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
      },
    })
  : createFallbackClient()
