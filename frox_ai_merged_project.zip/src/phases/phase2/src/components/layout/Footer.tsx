import React from 'react'
import { Sparkles } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-glass-border bg-neutral-950/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-frox-500 to-frox-700 flex items-center justify-center">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
            <span className="text-sm font-medium text-neutral-400">Frox AI</span>
          </div>
          <p className="text-sm text-neutral-500">
            © {new Date().getFullYear()} Frox AI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
