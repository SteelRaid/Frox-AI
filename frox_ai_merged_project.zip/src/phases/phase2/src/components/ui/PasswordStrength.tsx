import React from 'react'
import { motion } from 'framer-motion'

interface PasswordStrengthProps {
  strength: number
  errors: string[]
}

const strengthLabels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong']
const strengthColors = [
  'bg-red-500',
  'bg-red-400',
  'bg-yellow-500',
  'bg-yellow-400',
  'bg-green-500',
  'bg-green-400',
]

export function PasswordStrength({ strength, errors }: PasswordStrengthProps) {
  if (errors.length === 0 && strength === 0) return null

  return (
    <div className="space-y-2 mt-2">
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((level) => (
          <motion.div
            key={level}
            className={`h-1.5 flex-1 rounded-full ${
              strength >= level ? strengthColors[strength] : 'bg-neutral-800'
            }`}
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.3, delay: level * 0.05 }}
          />
        ))}
      </div>
      <div className="flex justify-between items-center">
        <span className="text-xs text-neutral-500">
          {strength > 0 ? strengthLabels[strength] : 'Enter password'}
        </span>
        {errors.length > 0 && (
          <span className="text-xs text-neutral-500">
            {errors.length} requirement{errors.length !== 1 ? 's' : ''} missing
          </span>
        )}
      </div>
      {errors.length > 0 && (
        <ul className="space-y-1">
          {errors.map((error, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-xs text-red-400 flex items-center gap-1"
            >
              <span className="w-1 h-1 rounded-full bg-red-400" />
              {error}
            </motion.li>
          ))}
        </ul>
      )}
    </div>
  )
}
