import React from 'react'
import { motion } from 'framer-motion'

interface GlassCardProps {
  children: React.ReactNode
  className?: string
  hover?: boolean
  glow?: boolean
}

export function GlassCard({ children, className = '', hover = false, glow = false }: GlassCardProps) {
  return (
    <motion.div
      className={`
        glass-card p-6 md:p-8
        ${hover ? 'hover:bg-glass-200 transition-colors duration-300' : ''}
        ${glow ? 'glow' : ''}
        ${className}
      `}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  )
}
