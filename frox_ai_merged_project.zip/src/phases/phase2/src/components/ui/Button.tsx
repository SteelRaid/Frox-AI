import React, { forwardRef } from 'react'
import { motion } from 'framer-motion'
import { Loader2 } from 'lucide-react'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  isLoading?: boolean
  fullWidth?: boolean
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ 
    children, 
    variant = 'primary', 
    size = 'md', 
    isLoading = false, 
    fullWidth = false,
    className = '',
    disabled,
    ...props 
  }, ref) => {
    const variants = {
      primary: 'glass-button',
      outline: 'glass-button-outline',
      ghost: 'text-neutral-300 hover:text-white hover:bg-glass-100 rounded-xl px-6 py-3 transition-all duration-200',
    }

    const sizes = {
      sm: 'px-4 py-2 text-sm',
      md: 'px-6 py-3',
      lg: 'px-8 py-4 text-lg',
    }

    return (
      <motion.button
        ref={ref}
        whileTap={{ scale: 0.98 }}
        className={`
          ${variants[variant]}
          ${variant !== 'ghost' ? sizes[size] : ''}
          ${fullWidth ? 'w-full' : ''}
          ${disabled || isLoading ? 'opacity-60 cursor-not-allowed' : ''}
          inline-flex items-center justify-center gap-2 font-medium
          ${className}
        `}
        disabled={disabled || isLoading}
        {...props}
      >
        {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
        {children}
      </motion.button>
    )
  }
)

Button.displayName = 'Button'
