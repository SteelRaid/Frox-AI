import React from 'react'
import { motion } from 'framer-motion'
import { Chrome, Github } from 'lucide-react'
import { Button } from '../ui/Button'
import { useAuth } from '../../contexts/AuthContext'
import { AuthProviderType } from '../../types/index'

const providers: { id: AuthProviderType; name: string; icon: React.ReactNode }[] = [
  { id: 'google', name: 'Google', icon: <Chrome className="w-5 h-5" /> },
  { id: 'github', name: 'GitHub', icon: <Github className="w-5 h-5" /> },
]

export function OAuthButtons() {
  const { signInWithOAuth } = useAuth()
  const [isLoading, setIsLoading] = React.useState<AuthProviderType | null>(null)

  const handleOAuth = async (provider: AuthProviderType) => {
    setIsLoading(provider)
    const { error } = await signInWithOAuth(provider)
    if (error) {
      console.error('OAuth error:', error)
    }
    setIsLoading(null)
  }

  return (
    <div className="space-y-3">
      {providers.map((provider, index) => (
        <motion.div
          key={provider.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Button
            variant="outline"
            fullWidth
            isLoading={isLoading === provider.id}
            onClick={() => handleOAuth(provider.id)}
            className="flex items-center gap-3"
          >
            {provider.icon}
            <span>Continue with {provider.name}</span>
          </Button>
        </motion.div>
      ))}
    </div>
  )
}
