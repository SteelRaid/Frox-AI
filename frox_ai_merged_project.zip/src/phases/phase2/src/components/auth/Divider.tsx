import React from 'react'

export function Divider() {
  return (
    <div className="relative my-6">
      <div className="absolute inset-0 flex items-center">
        <div className="w-full border-t border-glass-border" />
      </div>
      <div className="relative flex justify-center text-sm">
        <span className="px-4 bg-neutral-900/50 text-neutral-500 backdrop-blur-sm">
          or continue with email
        </span>
      </div>
    </div>
  )
}
