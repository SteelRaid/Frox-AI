import type { VideoJobStatus } from "./types";

/**
 * Maps generic job status + progress% to the cinematic stage labels the
 * spec calls for. This is a presentational approximation — the gateway
 * only reports queued/loading_model/generating/complete today. If you
 * later have Phase 4 report a real `stage` field in
 * GET /api/video/status/:id, swap this for reading that directly.
 */
export function getStageLabel(status: VideoJobStatus, progress: number): string {
  switch (status) {
    case "queued":
      return "Queued...";
    case "loading_model":
      return "Encoding...";
    case "complete":
      return "Done";
    case "failed":
      return "Failed";
    case "cancelled":
      return "Cancelled";
    case "generating":
    default:
      if (progress < 80) return "Generating frames...";
      if (progress < 92) return "Decoding...";
      return "Encoding video...";
  }
}

export function getFrameCounts(progress: number, durationSeconds: number, fps: number) {
  const totalFrames = Math.max(1, Math.round(durationSeconds * fps));
  const currentFrame = Math.min(totalFrames, Math.round((progress / 100) * totalFrames));
  return { currentFrame, totalFrames };
}

/** Returns remaining seconds, or null if there isn't enough data yet. */
export function estimateEtaSeconds(startedAt: number, progress: number): number | null {
  if (progress <= 0) return null;
  const elapsedMs = Date.now() - startedAt;
  const totalEstimateMs = (elapsedMs / progress) * 100;
  const remainingMs = Math.max(0, totalEstimateMs - elapsedMs);
  return Math.round(remainingMs / 1000);
}

export function formatSeconds(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = Math.floor(totalSeconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}
