import { Play, Square } from "lucide-react";

export function GenerateVideoButton({
  isGenerating,
  isSubmitting,
  progress,
  onGenerate,
  onCancel,
}: {
  isGenerating: boolean;
  isSubmitting: boolean;
  progress: number;
  onGenerate: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="space-y-2">
      <button
        type="button"
        onClick={onGenerate}
        disabled={isGenerating || isSubmitting}
        className="relative w-full h-14 rounded-xl font-bold text-white overflow-hidden disabled:opacity-80 disabled:cursor-not-allowed"
        style={{ background: "linear-gradient(135deg, #5B5BF6, #4444CC)", fontFamily: "'Space Grotesk', sans-serif" }}
      >
        {isGenerating && (
          <span
            className="absolute inset-0 animate-pulse"
            style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent)" }}
          />
        )}
        <span className="relative flex items-center justify-center gap-2">
          {isGenerating ? (
            <>Generating... {progress}%</>
          ) : isSubmitting ? (
            "Starting..."
          ) : (
            <>
              <Play size={18} fill="currentColor" /> Generate Video
            </>
          )}
        </span>
      </button>

      {isGenerating && (
        <button
          type="button"
          onClick={onCancel}
          className="w-full h-10 rounded-xl border border-white/15 text-white/60 text-sm hover:text-white hover:border-white/30 flex items-center justify-center gap-2 transition-colors"
        >
          <Square size={12} /> Cancel
        </button>
      )}
    </div>
  );
}
