import { useState } from "react";
import { Sparkles, ChevronDown } from "lucide-react";
import { useVideoStore } from "../store/videoStore";
import { SourceModePills } from "./SourceModePills";
import { FileDropzone } from "./FileDropzone";
import { LabeledSelect, LabeledSegments, LabeledSlider, SeedControl } from "./FormControls";
import { GenerateVideoButton } from "./GenerateVideoButton";
import { enhancePrompt } from "../api/promptEnhance";
import type { VideoModelOption } from "../types";

const RESOLUTIONS: { label: string; width: number; height: number }[] = [
  { label: "512×320", width: 512, height: 320 },
  { label: "768×432", width: 768, height: 432 },
  { label: "1024×576", width: 1024, height: 576 },
  { label: "576×1024", width: 576, height: 1024 },
];

const MOTION_PRESETS = [
  { value: "subtle" as const, label: "Subtle" },
  { value: "moderate" as const, label: "Moderate" },
  { value: "dynamic" as const, label: "Dynamic" },
  { value: "cinematic" as const, label: "Cinematic" },
];

export function VideoControlsPanel({
  models,
  isGenerating,
  isSubmitting,
  progress,
  submitError,
  onGenerate,
  onCancel,
}: {
  models: VideoModelOption[];
  isGenerating: boolean;
  isSubmitting: boolean;
  progress: number;
  submitError: string | null;
  onGenerate: () => void;
  onCancel: () => void;
}) {
  const params = useVideoStore((s) => s.params);
  const setSourceMode = useVideoStore((s) => s.setSourceMode);
  const setPrompt = useVideoStore((s) => s.setPrompt);
  const setNegativePrompt = useVideoStore((s) => s.setNegativePrompt);
  const setSourceImage = useVideoStore((s) => s.setSourceImage);
  const setSourceVideo = useVideoStore((s) => s.setSourceVideo);
  const setModelId = useVideoStore((s) => s.setModelId);
  const setMotionPreset = useVideoStore((s) => s.setMotionPreset);
  const setDuration = useVideoStore((s) => s.setDuration);
  const setFps = useVideoStore((s) => s.setFps);
  const setResolution = useVideoStore((s) => s.setResolution);
  const setMotionStrength = useVideoStore((s) => s.setMotionStrength);
  const setGuidanceScale = useVideoStore((s) => s.setGuidanceScale);
  const setSteps = useVideoStore((s) => s.setSteps);
  const setSeed = useVideoStore((s) => s.setSeed);
  const randomizeSeed = useVideoStore((s) => s.randomizeSeed);
  const toggleSeedLock = useVideoStore((s) => s.toggleSeedLock);

  const [showNegative, setShowNegative] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhanceError, setEnhanceError] = useState<string | null>(null);

  const handleEnhance = async () => {
    setIsEnhancing(true);
    setEnhanceError(null);
    try {
      const enhanced = await enhancePrompt(params.prompt);
      setPrompt(enhanced);
    } catch (err) {
      setEnhanceError(err instanceof Error ? err.message : "Couldn't reach the AI. Check your connection and try again.");
    } finally {
      setIsEnhancing(false);
    }
  };

  const currentResolutionLabel =
    RESOLUTIONS.find((r) => r.width === params.width && r.height === params.height)?.label || "1024×576";

  return (
    <div className="w-[380px] shrink-0 h-full overflow-y-auto px-4 py-5 space-y-5 border-r border-white/5 bg-[#0B0B14]">
      <SourceModePills value={params.sourceMode} onChange={setSourceMode} />

      {params.sourceMode === "text-to-video" && (
        <div className="space-y-2">
          <textarea
            value={params.prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the video you want to create..."
            rows={4}
            className="w-full bg-[#11111E] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white/90 placeholder:text-white/30 resize-none focus:outline-none focus:border-[#5B5BF6]"
          />
          <button
            type="button"
            onClick={handleEnhance}
            disabled={isEnhancing || !params.prompt.trim()}
            className="flex items-center gap-1.5 text-xs text-[#8B8BFF] hover:text-[#A8A8FF] disabled:opacity-40"
          >
            <Sparkles size={12} /> {isEnhancing ? "Enhancing..." : "Enhance Prompt"}
          </button>
          {enhanceError && <p className="text-xs text-red-400">{enhanceError}</p>}

          <button
            type="button"
            onClick={() => setShowNegative((v) => !v)}
            className="flex items-center gap-1 text-xs text-white/40 hover:text-white/70"
          >
            <ChevronDown size={12} className={showNegative ? "rotate-180" : ""} /> Negative prompt
          </button>
          {showNegative && (
            <textarea
              value={params.negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              placeholder="What to avoid..."
              rows={2}
              className="w-full bg-[#11111E] border border-white/10 rounded-xl px-3 py-2 text-sm text-white/90 placeholder:text-white/30 resize-none focus:outline-none focus:border-[#5B5BF6]"
            />
          )}
        </div>
      )}

      {params.sourceMode === "image-to-video" && (
        <div className="space-y-2">
          <FileDropzone kind="image" file={params.sourceImage} onChange={setSourceImage} label="Upload a source image" />
          <textarea
            value={params.prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="How should the image move?"
            rows={3}
            className="w-full bg-[#11111E] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white/90 placeholder:text-white/30 resize-none focus:outline-none focus:border-[#5B5BF6]"
          />
        </div>
      )}

      {params.sourceMode === "video-to-video" && (
        <div className="space-y-2">
          <FileDropzone
            kind="video"
            file={params.sourceVideo}
            onChange={setSourceVideo}
            maxSizeBytes={100 * 1024 * 1024}
            label="Upload a source video (MP4/WebM, max 100MB)"
          />
          <textarea
            value={params.prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the style to apply..."
            rows={3}
            className="w-full bg-[#11111E] border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white/90 placeholder:text-white/30 resize-none focus:outline-none focus:border-[#5B5BF6]"
          />
        </div>
      )}

      {models.length === 0 ? (
        <p className="text-xs text-amber-400/90 bg-amber-400/10 border border-amber-400/20 rounded-lg px-3 py-2">
          Download your first model to get started.
        </p>
      ) : (
        <LabeledSelect
          label="Video Model"
          value={params.modelId || models[0]?.id || ""}
          options={models.map((m) => ({
            value: m.id,
            label: m.sizeGB ? `${m.name} · ${m.sizeGB}GB` : m.name,
          }))}
          onChange={setModelId}
        />
      )}

      <LabeledSegments label="Motion Preset" value={params.motionPreset} options={MOTION_PRESETS} onChange={setMotionPreset} />

      <div className="space-y-4 pt-1 border-t border-white/5">
        <LabeledSegments
          label="Duration"
          value={params.duration}
          options={[2, 4, 6, 8, 10, 16].map((s) => ({ value: s, label: `${s}s` }))}
          onChange={(v) => setDuration(Number(v))}
        />
        <LabeledSelect
          label="FPS"
          value={params.fps}
          options={[8, 12, 16, 24].map((f) => ({ value: f, label: `${f} fps` }))}
          onChange={(v) => setFps(Number(v))}
        />
        <LabeledSelect
          label="Resolution"
          value={currentResolutionLabel}
          options={RESOLUTIONS.map((r) => ({ value: r.label, label: r.label }))}
          onChange={(label) => {
            const r = RESOLUTIONS.find((res) => res.label === label);
            if (r) setResolution(r.width, r.height);
          }}
        />
        <LabeledSlider label="Motion Strength" value={params.motionStrength} min={0} max={2} step={0.1} onChange={setMotionStrength} />
        <LabeledSlider label="Guidance Scale" value={params.guidanceScale} min={1} max={15} step={0.5} onChange={setGuidanceScale} />
        <LabeledSlider label="Steps" value={params.steps} min={10} max={60} step={1} onChange={setSteps} />
        <SeedControl seed={params.seed} locked={params.seedLocked} onChange={setSeed} onRandomize={randomizeSeed} onToggleLock={toggleSeedLock} />
      </div>

      <div className="pt-1">
        <GenerateVideoButton isGenerating={isGenerating} isSubmitting={isSubmitting} progress={progress} onGenerate={onGenerate} onCancel={onCancel} />
        {submitError && <p className="mt-2 text-xs text-red-400">{submitError}</p>}
      </div>
    </div>
  );
}
