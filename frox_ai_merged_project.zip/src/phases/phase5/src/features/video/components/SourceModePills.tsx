import type { VideoSourceMode } from "../types";

const MODES: { value: VideoSourceMode; label: string }[] = [
  { value: "text-to-video", label: "Text to Video" },
  { value: "image-to-video", label: "Image to Video" },
  { value: "video-to-video", label: "Video to Video" },
];

export function SourceModePills({
  value,
  onChange,
}: {
  value: VideoSourceMode;
  onChange: (mode: VideoSourceMode) => void;
}) {
  return (
    <div className="flex gap-1.5 p-1 rounded-full bg-[#11111E] border border-white/10">
      {MODES.map((mode) => {
        const active = mode.value === value;
        return (
          <button
            key={mode.value}
            type="button"
            onClick={() => onChange(mode.value)}
            className={`flex-1 px-3 py-2 rounded-full text-xs font-medium transition-colors ${
              active ? "bg-[#5B5BF6] text-white shadow-[0_0_12px_rgba(91,91,246,0.5)]" : "text-white/50 hover:text-white/80"
            }`}
          >
            {mode.label}
          </button>
        );
      })}
    </div>
  );
}
