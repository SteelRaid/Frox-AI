import { Lock, Unlock, Shuffle } from "lucide-react";

export function LabeledSlider({
  label,
  value,
  min,
  max,
  step = 1,
  unit = "",
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="text-white/60">{label}</span>
        <span className="text-white/80 font-mono">
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-1.5 rounded-full bg-white/10 accent-[#5B5BF6] cursor-pointer"
      />
    </div>
  );
}

export function LabeledSegments<T extends string | number>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="space-y-1.5">
      <span className="text-xs text-white/60">{label}</span>
      <div className="flex gap-1.5 flex-wrap">
        {options.map((opt) => {
          const active = opt.value === value;
          return (
            <button
              key={opt.value}
              type="button"
              onClick={() => onChange(opt.value)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                active
                  ? "bg-[#5B5BF6]/20 border-[#5B5BF6] text-white"
                  : "bg-[#11111E] border-white/10 text-white/50 hover:border-white/25"
              }`}
            >
              {opt.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function LabeledSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string | number;
  options: { value: string | number; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs text-white/60">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-[#11111E] border border-white/10 rounded-lg px-3 py-2 text-sm text-white/90 focus:outline-none focus:border-[#5B5BF6]"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function SeedControl({
  seed,
  locked,
  onChange,
  onRandomize,
  onToggleLock,
}: {
  seed: number;
  locked: boolean;
  onChange: (v: number) => void;
  onRandomize: () => void;
  onToggleLock: () => void;
}) {
  return (
    <div className="space-y-1.5">
      <span className="text-xs text-white/60">Seed</span>
      <div className="flex items-center gap-1.5">
        <input
          type="number"
          value={seed}
          onChange={(e) => onChange(Number(e.target.value))}
          className="flex-1 bg-[#11111E] border border-white/10 rounded-lg px-3 py-2 text-sm font-mono text-white/90 focus:outline-none focus:border-[#5B5BF6]"
        />
        <button
          type="button"
          onClick={onRandomize}
          disabled={locked}
          className="p-2 rounded-lg bg-[#11111E] border border-white/10 text-white/60 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Randomize seed"
        >
          <Shuffle size={14} />
        </button>
        <button
          type="button"
          onClick={onToggleLock}
          className={`p-2 rounded-lg border transition-colors ${
            locked ? "bg-[#5B5BF6]/20 border-[#5B5BF6] text-white" : "bg-[#11111E] border-white/10 text-white/60 hover:text-white"
          }`}
          aria-label="Lock seed"
        >
          {locked ? <Lock size={14} /> : <Unlock size={14} />}
        </button>
      </div>
    </div>
  );
}
