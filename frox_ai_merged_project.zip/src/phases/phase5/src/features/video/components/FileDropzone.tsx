import { useCallback, useEffect, useRef, useState } from "react";
import { Upload, X, Film, Image as ImageIcon } from "lucide-react";

interface FileDropzoneProps {
  kind: "image" | "video";
  file: File | null;
  onChange: (file: File | null) => void;
  maxSizeBytes?: number;
  label: string;
}

const ACCEPT = {
  image: "image/png,image/jpeg,image/webp",
  video: "video/mp4,video/webm",
};

export function FileDropzone({ kind, file, onChange, maxSizeBytes, label }: FileDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!file) {
      setPreviewUrl(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const validateAndSet = useCallback(
    (f: File | undefined) => {
      if (!f) return;
      const accepted = ACCEPT[kind].split(",");
      if (!accepted.includes(f.type)) {
        setError(kind === "video" ? "Upload an MP4 or WebM file." : "Upload a PNG, JPEG, or WebP image.");
        return;
      }
      if (maxSizeBytes && f.size > maxSizeBytes) {
        setError(`This file is too large. Maximum size is ${Math.round(maxSizeBytes / 1024 / 1024)}MB.`);
        return;
      }
      setError(null);
      onChange(f);
    },
    [kind, maxSizeBytes, onChange]
  );

  if (file && previewUrl) {
    return (
      <div className="relative rounded-xl overflow-hidden border border-white/10 bg-[#11111E] group">
        {kind === "image" ? (
          <img src={previewUrl} alt="Source" className="w-full h-40 object-contain bg-black/40" />
        ) : (
          <video src={previewUrl} className="w-full h-40 object-contain bg-black/40" controls={false} muted />
        )}
        <button
          type="button"
          onClick={() => onChange(null)}
          className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 text-white/80 hover:text-white hover:bg-black/90 transition-colors opacity-0 group-hover:opacity-100"
          aria-label="Remove file"
        >
          <X size={14} />
        </button>
        <div className="px-3 py-2 text-xs text-white/50 truncate border-t border-white/10">{file.name}</div>
      </div>
    );
  }

  return (
    <div>
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          validateAndSet(e.dataTransfer.files[0]);
        }}
        onClick={() => inputRef.current?.click()}
        className={`flex flex-col items-center justify-center gap-2 h-40 rounded-xl border-2 border-dashed cursor-pointer transition-colors ${
          isDragging ? "border-[#5B5BF6] bg-[#5B5BF6]/10" : "border-white/15 bg-[#11111E] hover:border-white/30"
        }`}
      >
        {kind === "image" ? (
          <ImageIcon size={22} className="text-white/40" />
        ) : (
          <Film size={22} className="text-white/40" />
        )}
        <Upload size={14} className="text-white/30" />
        <p className="text-sm text-white/60">{label}</p>
        <p className="text-xs text-white/30">Drag and drop, or click to browse</p>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT[kind]}
          className="hidden"
          onChange={(e) => validateAndSet(e.target.files?.[0])}
        />
      </div>
      {error && <p className="mt-1.5 text-xs text-red-400">{error}</p>}
    </div>
  );
}
