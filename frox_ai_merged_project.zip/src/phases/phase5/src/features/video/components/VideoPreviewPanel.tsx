import { Heart, Scissors, Repeat, Film } from "lucide-react";
import { API_BASE } from "../api/client";
import { FroxVideoPlayer } from "./FroxVideoPlayer";
import type { VideoJob } from "../types";

interface DisplayInfo {
  stage: string;
  currentFrame: number;
  totalFrames: number;
  etaLabel: string | null;
  elapsedLabel: string;
}

export function VideoPreviewPanel({
  job,
  display,
  onSaveToGallery,
  onRegenerate,
}: {
  job: VideoJob | null;
  display: DisplayInfo | null;
  onSaveToGallery: () => void;
  onRegenerate: () => void;
}) {
  if (!job) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
        <div className="opacity-10 mb-4">
          <Film size={64} className="text-white" />
        </div>
        <p className="text-white/70 font-medium" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
          Your creation will appear here
        </p>
        <p className="text-white/30 text-sm mt-1">Set your parameters and click Generate</p>
      </div>
    );
  }

  const isGenerating = !["complete", "failed", "cancelled"].includes(job.status);

  if (isGenerating) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center px-10">
        <div className="w-full max-w-md">
          <div className="h-1.5 rounded-full bg-white/10 overflow-hidden mb-4">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{ width: `${job.progress}%`, background: "linear-gradient(90deg, #5B5BF6, #8B8BFF)" }}
            />
          </div>
          <div
            className="aspect-video rounded-xl bg-gradient-to-br from-[#1A1A2E] to-[#11111E] animate-pulse mb-4 flex items-center justify-center"
          >
            <span className="text-white/30 text-sm">{display?.stage}</span>
          </div>
          <div className="flex items-center justify-between text-xs text-white/50">
            <span>
              Frame {display?.currentFrame} / {display?.totalFrames}
            </span>
            <span>{display?.elapsedLabel} elapsed</span>
            {display?.etaLabel && <span>{display.etaLabel}</span>}
          </div>
        </div>
      </div>
    );
  }

  if (job.status === "failed") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
        <p className="text-red-400 font-medium">{job.error || "Something went wrong during creation. Try again or adjust settings."}</p>
        <button onClick={onRegenerate} className="mt-4 text-sm text-[#8B8BFF] hover:text-[#A8A8FF]">
          Try again
        </button>
      </div>
    );
  }

  if (job.status === "cancelled") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
        <p className="text-white/50">Generation cancelled.</p>
      </div>
    );
  }

  // complete
  if (!job.resultPath) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
        <p className="text-white/60">Generation marked complete, but no preview file was returned.</p>
        <p className="text-white/30 text-sm mt-1">
          This happens in mock mode without ffmpeg installed. Once your generator service is live, this resolves automatically.
        </p>
      </div>
    );
  }

  const videoUrl = `${API_BASE}${job.resultPath}`;

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-8 py-6">
      <div className="w-full max-w-2xl space-y-3">
        <FroxVideoPlayer src={videoUrl} downloadName={`frox-${job.jobId}.mp4`} />
        <div className="flex items-center gap-4 justify-center pt-1">
          <a
            href={videoUrl}
            download={`frox-${job.jobId}.mp4`}
            className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white"
          >
            Download MP4
          </a>
          <button onClick={onSaveToGallery} className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white">
            <Heart size={13} /> Save to Gallery
          </button>
          <button className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white">
            <Scissors size={13} /> Extract Frame
          </button>
          <button onClick={onRegenerate} className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white">
            <Repeat size={13} /> Regenerate
          </button>
        </div>
      </div>
    </div>
  );
}
