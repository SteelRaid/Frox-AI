import { API_BASE } from "../api/client";
import { useVideoGeneration } from "../hooks/useVideoGeneration";
import { useVideoModels } from "../hooks/useVideoModels";
import { VideoControlsPanel } from "./VideoControlsPanel";
import { VideoPreviewPanel } from "./VideoPreviewPanel";

export function CreateVideoTab() {
  const { job, display, isGenerating, isSubmitting, submitError, start, cancel, resetJob } = useVideoGeneration();
  const { models } = useVideoModels();

  const handleSaveToGallery = async () => {
    if (!job?.resultPath) return;
    try {
      await fetch(`${API_BASE}/api/gallery/save`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "video",
          filePath: job.resultPath,
          historyItemId: job.jobId,
        }),
      });
    } catch {
      // non-critical — saving to gallery failing shouldn't block the user
    }
  };

  return (
    <div className="flex h-full w-full bg-[#07070E]" style={{ fontFamily: "'Inter', sans-serif" }}>
      <VideoControlsPanel
        models={models}
        isGenerating={isGenerating}
        isSubmitting={isSubmitting}
        progress={job?.progress ?? 0}
        submitError={submitError}
        onGenerate={start}
        onCancel={cancel}
      />
      <VideoPreviewPanel job={job} display={display} onSaveToGallery={handleSaveToGallery} onRegenerate={resetJob} />
    </div>
  );
}
