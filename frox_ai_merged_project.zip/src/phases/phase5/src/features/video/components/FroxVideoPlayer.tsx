import { useEffect, useRef, useState } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, Download } from "lucide-react";
import { formatSeconds } from "../stageLabels";

export function FroxVideoPlayer({ src, downloadName }: { src: string; downloadName?: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onTime = () => setCurrentTime(v.currentTime);
    const onLoaded = () => setDuration(v.duration || 0);
    const onEnded = () => setIsPlaying(false);
    v.addEventListener("timeupdate", onTime);
    v.addEventListener("loadedmetadata", onLoaded);
    v.addEventListener("ended", onEnded);
    return () => {
      v.removeEventListener("timeupdate", onTime);
      v.removeEventListener("loadedmetadata", onLoaded);
      v.removeEventListener("ended", onEnded);
    };
  }, []);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play();
      setIsPlaying(true);
    } else {
      v.pause();
      setIsPlaying(false);
    }
  };

  const seek = (t: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = t;
    setCurrentTime(t);
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setIsMuted(v.muted);
  };

  const changeVolume = (val: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.volume = val;
    setVolume(val);
    if (val > 0 && v.muted) {
      v.muted = false;
      setIsMuted(false);
    }
  };

  const toggleFullscreen = () => {
    containerRef.current?.requestFullscreen?.();
  };

  return (
    <div ref={containerRef} className="rounded-xl overflow-hidden bg-black border border-white/10">
      <video
        ref={videoRef}
        src={src}
        className="w-full max-h-[60vh] bg-black"
        style={{ objectFit: "contain" }}
        onClick={togglePlay}
      />

      <div className="flex items-center gap-3 px-3 py-2.5 bg-[#0B0B14]">
        <button onClick={togglePlay} className="text-white/80 hover:text-white" aria-label={isPlaying ? "Pause" : "Play"}>
          {isPlaying ? <Pause size={18} /> : <Play size={18} />}
        </button>

        <input
          type="range"
          min={0}
          max={duration || 0}
          step={0.01}
          value={currentTime}
          onChange={(e) => seek(Number(e.target.value))}
          className="flex-1 h-1 rounded-full bg-white/15 accent-[#5B5BF6] cursor-pointer"
        />

        <span className="text-xs font-mono text-white/60 whitespace-nowrap">
          {formatSeconds(Math.floor(currentTime))} / {formatSeconds(Math.floor(duration || 0))}
        </span>

        <button onClick={toggleMute} className="text-white/80 hover:text-white" aria-label="Toggle mute">
          {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>
        <input
          type="range"
          min={0}
          max={1}
          step={0.05}
          value={isMuted ? 0 : volume}
          onChange={(e) => changeVolume(Number(e.target.value))}
          className="w-16 h-1 rounded-full bg-white/15 accent-[#5B5BF6] cursor-pointer"
        />

        <button onClick={toggleFullscreen} className="text-white/80 hover:text-white" aria-label="Fullscreen">
          <Maximize size={16} />
        </button>

        <a href={src} download={downloadName || "frox-video.mp4"} className="text-white/80 hover:text-white" aria-label="Download">
          <Download size={16} />
        </a>
      </div>
    </div>
  );
}
