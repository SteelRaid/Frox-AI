import { create } from "zustand";
import type { MotionPreset, VideoGenerationParams, VideoJob, VideoSourceMode } from "../types";

function randomSeed() {
  return Math.floor(Math.random() * 1_000_000_000);
}

const defaultParams: VideoGenerationParams = {
  sourceMode: "text-to-video",
  prompt: "",
  negativePrompt: "",
  sourceImage: null,
  sourceVideo: null,
  modelId: "",
  motionPreset: "moderate",
  duration: 4,
  fps: 16,
  width: 1024,
  height: 576,
  motionStrength: 1.0,
  guidanceScale: 7.0,
  steps: 25,
  seed: randomSeed(),
  seedLocked: false,
};

interface VideoStoreState {
  params: VideoGenerationParams;
  job: VideoJob | null;

  setSourceMode: (mode: VideoSourceMode) => void;
  setPrompt: (prompt: string) => void;
  setNegativePrompt: (text: string) => void;
  setSourceImage: (file: File | null) => void;
  setSourceVideo: (file: File | null) => void;
  setModelId: (id: string) => void;
  setMotionPreset: (preset: MotionPreset) => void;
  setDuration: (seconds: number) => void;
  setFps: (fps: number) => void;
  setResolution: (width: number, height: number) => void;
  setMotionStrength: (v: number) => void;
  setGuidanceScale: (v: number) => void;
  setSteps: (v: number) => void;
  setSeed: (v: number) => void;
  randomizeSeed: () => void;
  toggleSeedLock: () => void;

  setJob: (job: VideoJob | null) => void;
  updateJob: (patch: Partial<VideoJob>) => void;
  resetJob: () => void;
}

export const useVideoStore = create<VideoStoreState>((set) => ({
  params: defaultParams,
  job: null,

  setSourceMode: (mode) => set((s) => ({ params: { ...s.params, sourceMode: mode } })),
  setPrompt: (prompt) => set((s) => ({ params: { ...s.params, prompt } })),
  setNegativePrompt: (negativePrompt) => set((s) => ({ params: { ...s.params, negativePrompt } })),
  setSourceImage: (sourceImage) => set((s) => ({ params: { ...s.params, sourceImage } })),
  setSourceVideo: (sourceVideo) => set((s) => ({ params: { ...s.params, sourceVideo } })),
  setModelId: (modelId) => set((s) => ({ params: { ...s.params, modelId } })),
  setMotionPreset: (motionPreset) => set((s) => ({ params: { ...s.params, motionPreset } })),
  setDuration: (duration) => set((s) => ({ params: { ...s.params, duration } })),
  setFps: (fps) => set((s) => ({ params: { ...s.params, fps } })),
  setResolution: (width, height) => set((s) => ({ params: { ...s.params, width, height } })),
  setMotionStrength: (motionStrength) => set((s) => ({ params: { ...s.params, motionStrength } })),
  setGuidanceScale: (guidanceScale) => set((s) => ({ params: { ...s.params, guidanceScale } })),
  setSteps: (steps) => set((s) => ({ params: { ...s.params, steps } })),
  setSeed: (seed) => set((s) => ({ params: { ...s.params, seed } })),
  randomizeSeed: () =>
    set((s) => (s.params.seedLocked ? s : { params: { ...s.params, seed: randomSeed() } })),
  toggleSeedLock: () => set((s) => ({ params: { ...s.params, seedLocked: !s.params.seedLocked } })),

  setJob: (job) => set({ job }),
  updateJob: (patch) => set((s) => (s.job ? { job: { ...s.job, ...patch } } : s)),
  resetJob: () => set({ job: null }),
}));
