import { useEffect, useState } from "react";
import { API_BASE } from "../api/client";
import type { VideoModelOption } from "../types";

interface ModelEntryResponse {
  id: string;
  name: string;
  type: string;
  status: string;
  sizeBytes: number | null;
}

export function useVideoModels() {
  const [models, setModels] = useState<VideoModelOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/api/models/list`);
        const data = await res.json();
        if (cancelled) return;
        const ready: ModelEntryResponse[] = (data.models || []).filter((m: ModelEntryResponse) => m.status === "ready");
        setModels(
          ready.map((m) => ({
            id: m.id,
            name: m.name,
            sizeGB: m.sizeBytes ? Number((m.sizeBytes / 1024 ** 3).toFixed(1)) : null,
          }))
        );
      } catch {
        if (!cancelled) setModels([]);
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return { models, isLoading };
}
