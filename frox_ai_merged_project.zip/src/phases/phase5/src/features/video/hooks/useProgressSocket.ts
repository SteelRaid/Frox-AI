import { useEffect, useRef } from "react";
import { WS_BASE } from "../api/client";
import type { VideoJobStatus } from "../types";

interface ProgressEvent {
  jobId: string;
  status: VideoJobStatus;
  progress: number;
  resultPath?: string | null;
  error?: string | null;
}

/**
 * Subscribes to ws://<gateway>/ws/progress/:jobId and invokes onEvent for
 * every message. Automatically tears down the socket when jobId becomes
 * null/undefined or the component unmounts.
 */
export function useProgressSocket(jobId: string | null, onEvent: (e: ProgressEvent) => void) {
  const onEventRef = useRef(onEvent);
  onEventRef.current = onEvent;

  useEffect(() => {
    if (!jobId) return;

    const ws = new WebSocket(`${WS_BASE}/ws/progress/${jobId}`);

    ws.onmessage = (msg) => {
      try {
        const parsed = JSON.parse(msg.data) as ProgressEvent;
        onEventRef.current(parsed);
      } catch {
        // ignore malformed frame
      }
    };

    return () => {
      ws.close();
    };
  }, [jobId]);
}
