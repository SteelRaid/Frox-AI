import { useCallback, useMemo, useState } from "react";
import { useVideoStore } from "../store/videoStore";
import { cancelVideoJob, generateVideo, uploadVideoSource } from "../api/videoApi";
import { useProgressSocket } from "./useProgressSocket";
import { estimateEtaSeconds, formatSeconds, getFrameCounts, getStageLabel } from "../stageLabels";

export function useVideoGeneration() {
  const params = useVideoStore((s) => s.params);
  const job = useVideoStore((s) => s.job);
  const setJob = useVideoStore((s) => s.setJob);
  const updateJob = useVideoStore((s) => s.updateJob);
  const resetJob = useVideoStore((s) => s.resetJob);

  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useProgressSocket(job && !["complete", "failed", "cancelled"].includes(job.status) ? job.jobId : null, (evt) => {
    updateJob({
      status: evt.status,
      progress: evt.progress,
      resultPath: evt.resultPath ?? job?.resultPath ?? null,
      error: evt.error ?? null,
    });
  });

  const start = useCallback(async () => {
    setSubmitError(null);

    if (!params.prompt.trim() && params.sourceMode === "text-to-video") {
      setSubmitError("Describe what you want to see before generating.");
      return;
    }
    if (params.sourceMode === "image-to-video" && !params.sourceImage) {
      setSubmitError("Upload a source image first.");
      return;
    }
    if (params.sourceMode === "video-to-video" && !params.sourceVideo) {
      setSubmitError("Upload a source video first.");
      return;
    }

    setIsSubmitting(true);
    try {
      let sourceFilePath: string | undefined;
      const sourceFile = params.sourceMode === "image-to-video" ? params.sourceImage : params.sourceVideo;
      if (sourceFile) {
        const uploaded = await uploadVideoSource(sourceFile);
        sourceFilePath = uploaded.path;
      }

      const { jobId } = await generateVideo({
        sourceMode: params.sourceMode,
        prompt: params.prompt,
        negativePrompt: params.negativePrompt,
        sourceFilePath,
        modelId: params.modelId,
        motionPreset: params.motionPreset,
        duration: params.duration,
        fps: params.fps,
        width: params.width,
        height: params.height,
        motionStrength: params.motionStrength,
        guidanceScale: params.guidanceScale,
        steps: params.steps,
        seed: params.seed,
      });

      setJob({ jobId, status: "queued", progress: 0, startedAt: Date.now() });
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Something went wrong during creation. Try again or adjust settings.");
    } finally {
      setIsSubmitting(false);
    }
  }, [params, setJob]);

  const cancel = useCallback(async () => {
    if (!job) return;
    try {
      await cancelVideoJob(job.jobId);
      updateJob({ status: "cancelled" });
    } catch {
      // best-effort — UI still reflects last known state
    }
  }, [job, updateJob]);

  const isGenerating = !!job && !["complete", "failed", "cancelled"].includes(job.status);

  const display = useMemo(() => {
    if (!job) return null;
    const stage = getStageLabel(job.status, job.progress);
    const { currentFrame, totalFrames } = getFrameCounts(job.progress, params.duration, params.fps);
    const etaSeconds = isGenerating ? estimateEtaSeconds(job.startedAt, job.progress) : null;
    const elapsedLabel = formatSeconds(Math.floor((Date.now() - job.startedAt) / 1000));
    const etaLabel = etaSeconds !== null ? `~${formatSeconds(etaSeconds)} remaining` : null;
    return { stage, currentFrame, totalFrames, etaLabel, elapsedLabel };
  }, [job, params.duration, params.fps, isGenerating]);

  return { params, job, display, isGenerating, isSubmitting, submitError, start, cancel, resetJob };
}
