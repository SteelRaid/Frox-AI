export type VideoSourceMode = "text-to-video" | "image-to-video" | "video-to-video";
export type MotionPreset = "subtle" | "moderate" | "dynamic" | "cinematic";

export type VideoJobStatus =
  | "queued"
  | "loading_model"
  | "generating"
  | "complete"
  | "failed"
  | "cancelled";

export interface VideoModelOption {
  id: string;
  name: string;
  sizeGB: number | null;
}

export interface VideoGenerationParams {
  sourceMode: VideoSourceMode;
  prompt: string;
  negativePrompt: string;
  sourceImage: File | null; // image-to-video
  sourceVideo: File | null; // video-to-video
  modelId: string;
  motionPreset: MotionPreset;
  duration: number; // seconds — one of 2,4,6,8,10,16
  fps: number; // 8 | 12 | 16 | 24
  width: number;
  height: number;
  motionStrength: number; // 0.0–2.0
  guidanceScale: number; // 1.0–15.0
  steps: number; // 10–60
  seed: number;
  seedLocked: boolean;
}

export interface VideoJob {
  jobId: string;
  status: VideoJobStatus;
  progress: number; // 0–100
  resultPath?: string | null;
  error?: string | null;
  startedAt: number; // client-side timestamp, for ETA estimation
}
