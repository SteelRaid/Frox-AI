import { API_BASE } from "./client";

/**
 * Implements the "✦ Enhance Prompt" button by reusing the chat pipeline
 * already built in Phase 3 — spins up a scratch conversation, asks the
 * connected LLM to rewrite the prompt, reads the streamed reply, then
 * best-effort deletes the scratch conversation so it doesn't clutter the
 * Chat tab's history.
 *
 * NOTE: this is the same approach the Create Image tab's Enhance Prompt
 * button should use — worth lifting to a shared module once both exist.
 */
export async function enhancePrompt(prompt: string): Promise<string> {
  if (!prompt.trim()) return prompt;

  const convoRes = await fetch(`${API_BASE}/api/chat/conversations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: "Prompt enhancement (scratch)" }),
  });
  if (!convoRes.ok) {
    throw new Error("Couldn't reach the AI. Check your connection and try again.");
  }
  const { conversation } = await convoRes.json();

  let cleanedUp = false;
  const cleanup = () => {
    if (cleanedUp) return;
    cleanedUp = true;
    fetch(`${API_BASE}/api/chat/conversations/${conversation.id}`, { method: "DELETE" }).catch(() => {});
  };

  try {
    const res = await fetch(`${API_BASE}/api/chat/message`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        conversationId: conversation.id,
        message: `Rewrite this video-generation prompt with more vivid, specific cinematic detail — camera movement, lighting, mood, setting. Return only the rewritten prompt, nothing else:\n\n${prompt}`,
      }),
    });

    if (!res.ok || !res.body) {
      throw new Error("Couldn't reach the AI. Check your connection and try again.");
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let full = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const events = buffer.split("\n\n");
      buffer = events.pop() || "";

      for (const evt of events) {
        const line = evt.trim();
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (data === "[DONE]") continue;
        try {
          const parsed = JSON.parse(data);
          if (parsed.error) throw new Error(parsed.error);
          if (parsed.token) full += parsed.token;
        } catch {
          // ignore unparsable fragment
        }
      }
    }

    return full.trim() || prompt;
  } finally {
    cleanup();
  }
}
