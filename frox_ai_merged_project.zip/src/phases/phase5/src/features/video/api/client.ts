// Points at the Phase 3 Node.js gateway. Override via .env (Vite picks up
// VITE_-prefixed vars) once you're running behind frox-proxy/Nginx in prod.
export const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:4000";
export const WS_BASE = (import.meta.env.VITE_WS_BASE_URL as string) || API_BASE.replace(/^http/, "ws");
