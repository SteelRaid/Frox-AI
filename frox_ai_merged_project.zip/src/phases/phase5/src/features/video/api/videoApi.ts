import { API_BASE } from "./client";
import type { VideoGenerationParams } from "../types";

async function parseErrorOrThrow(res: Response, fallback: string): Promise<never> {
  const body = await res.json().catch(() => null);
  throw new Error(body?.error || fallback);
}

/** Uploads a source file for Image-to-Video / Video-to-Video mode. */
export async function uploadVideoSource(file: File): Promise<{ path: string }> {
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(`${API_BASE}/api/video/upload`, { method: "POST", body: formData });
  if (!res.ok) {
    return parseErrorOrThrow(res, "This file is too large or unsupported.");
  }
  return res.json();
}

interface GenerateVideoPayload {
  sourceMode: VideoGenerationParams["sourceMode"];
  prompt: string;
  negativePrompt?: string;
  sourceFilePath?: string;
  modelId: string;
  motionPreset: string;
  duration: number;
  fps: number;
  width: number;
  height: number;
  motionStrength: number;
  guidanceScale: number;
  steps: number;
  seed: number;
}

export async function generateVideo(
  payload: GenerateVideoPayload
): Promise<{ jobId: string; status: string }> {
  const res = await fetch(`${API_BASE}/api/video/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    return parseErrorOrThrow(res, "Something went wrong during creation. Try again or adjust settings.");
  }
  return res.json();
}

export async function cancelVideoJob(jobId: string): Promise<void> {
  const res = await fetch(`${API_BASE}/api/video/cancel/${jobId}`, { method: "POST" });
  if (!res.ok) {
    return parseErrorOrThrow(res, "Couldn't cancel this job.");
  }
}

export async function getVideoStatus(jobId: string) {
  const res = await fetch(`${API_BASE}/api/video/status/${jobId}`);
  if (!res.ok) {
    return parseErrorOrThrow(res, "Couldn't check job status.");
  }
  return res.json() as Promise<{
    jobId: string;
    status: string;
    progress: number;
    error?: string;
  }>;
}
