# Frox AI — Create Video Tab (Phase 5)

Drop the `src/features/video/` folder into your existing frontend project.
Everything is self-contained — no shadcn components assumed, just native
elements + Tailwind + `lucide-react` + `zustand` (both already in your
stack).

## Wire it in

```tsx
import { CreateVideoTab } from "@/features/video";

// wherever your tab router renders the active tab:
{activeTab === "video" && <CreateVideoTab />}
```

## Config

Add to your frontend `.env` (defaults already point at the Phase 3 gateway):

```
VITE_API_BASE_URL=http://localhost:4000
VITE_WS_BASE_URL=ws://localhost:4000
```

## What's real vs. presentational

- **Generate / cancel / progress**: fully real — hits `/api/video/generate`,
  `/api/video/cancel/:id`, and the WebSocket progress relay you already
  have running. Since you've got Phase 4 live now, jobs run through your
  actual generator instead of the gateway's mock fallback automatically —
  no frontend change needed either way.
- **Image/video upload** (Image-to-Video / Video-to-Video modes): real —
  posts to a new `/api/video/upload` route I added to the gateway (multer,
  100MB cap, saved under `uploads/video/`). The returned path is sent as
  `sourceFilePath` in the generate request — make sure your Phase 4 service
  reads that field for those two modes.
- **Enhance Prompt**: real — reuses your existing chat pipeline (spins up a
  scratch conversation, asks the connected LLM to rewrite the prompt, deletes
  the scratch conversation after). Needs Ollama running.
- **Stage labels** ("Encoding... → Generating frames... → Decoding... →
  Encoding video..."): presentational only, derived from progress% on the
  client (`stageLabels.ts`). The gateway only reports generic
  queued/loading_model/generating/complete today. If your Phase 4 service
  reports a real `stage` field in its status response, it's a one-line swap
  in `stageLabels.ts` to use that instead of the heuristic.
- **Frame counter**: real, not simulated — it's just `duration × fps` from
  whatever the user picked, scaled by progress%.
- **Model dropdown**: real — pulls from `/api/models/list`. Will show the
  "Download your first model to get started" message if your library is
  empty for video models.

## Files

```
src/features/video/
├── types.ts
├── stageLabels.ts
├── api/
│   ├── client.ts
│   ├── videoApi.ts
│   └── promptEnhance.ts
├── store/videoStore.ts
├── hooks/
│   ├── useProgressSocket.ts
│   ├── useVideoGeneration.ts
│   └── useVideoModels.ts
├── components/
│   ├── CreateVideoTab.tsx       (top-level, render this)
│   ├── VideoControlsPanel.tsx
│   ├── VideoPreviewPanel.tsx
│   ├── FroxVideoPlayer.tsx      (custom player, no native controls)
│   ├── SourceModePills.tsx
│   ├── FileDropzone.tsx
│   ├── FormControls.tsx
│   └── GenerateVideoButton.tsx
└── index.ts                     (barrel export)
```

Type-checked clean against React 18 + TS 5 strict mode before packaging.
