// ============================================================
// Frox AI – Conversation Store
// ============================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Conversation, ConversationStatus, ChatFolder, ChatProject } from '../types/index';
import { STORAGE_KEYS, MODELS, DEFAULT_SETTINGS } from '../constants/index';
import { generateId, generateTitle } from '../utils/index';

interface ConversationState {
  conversations: Conversation[];
  folders: ChatFolder[];
  projects: ChatProject[];
  activeConversationId: string | null;
  searchQuery: string;
  sortBy: 'date' | 'title';
  filterStatus: ConversationStatus | 'all';
  isLoading: boolean;
  error: string | null;
}

interface ConversationActions {
  // CRUD
  createConversation: (workspaceId: string, initialMessage?: string) => Conversation;
  updateConversation: (id: string, updates: Partial<Conversation>) => void;
  deleteConversation: (id: string) => void;
  duplicateConversation: (id: string) => void;

  // Status
  pinConversation: (id: string) => void;
  unpinConversation: (id: string) => void;
  archiveConversation: (id: string) => void;
  unarchiveConversation: (id: string) => void;
  favoriteConversation: (id: string) => void;
  unfavoriteConversation: (id: string) => void;

  // Navigation
  setActiveConversation: (id: string | null) => void;

  // Search & Filter
  setSearchQuery: (query: string) => void;
  setSortBy: (sort: 'date' | 'title') => void;
  setFilterStatus: (status: ConversationStatus | 'all') => void;

  // Folders
  createFolder: (name: string, workspaceId: string, parentId?: string) => ChatFolder;
  updateFolder: (id: string, updates: Partial<ChatFolder>) => void;
  deleteFolder: (id: string) => void;
  moveConversationToFolder: (conversationId: string, folderId: string | null) => void;

  // Projects
  createProject: (name: string, workspaceId: string) => ChatProject;
  updateProject: (id: string, updates: Partial<ChatProject>) => void;
  deleteProject: (id: string) => void;
  addConversationToProject: (conversationId: string, projectId: string) => void;
  removeConversationFromProject: (conversationId: string, projectId: string) => void;

  // Summary
  updateSummary: (id: string, summary: string) => void;

  // Computed
  getFilteredConversations: () => Conversation[];
  getConversationById: (id: string) => Conversation | undefined;
  getPinnedConversations: () => Conversation[];
  getArchivedConversations: () => Conversation[];
  getRecentConversations: (limit?: number) => Conversation[];
}

export const useConversationStore = create<ConversationState & ConversationActions>()(
  persist(
    (set, get) => ({
      // State
      conversations: [],
      folders: [],
      projects: [],
      activeConversationId: null,
      searchQuery: '',
      sortBy: 'date',
      filterStatus: 'all',
      isLoading: false,
      error: null,

      // Create
      createConversation: (workspaceId, initialMessage) => {
        const now = new Date().toISOString();
        const newConversation: Conversation = {
          id: generateId(),
          title: initialMessage ? generateTitle(initialMessage) : 'New Chat',
          workspaceId,
          messages: [],
          model: MODELS[0],
          temperature: DEFAULT_SETTINGS.temperature,
          maxTokens: DEFAULT_SETTINGS.maxTokens,
          useInternet: DEFAULT_SETTINGS.useInternet,
          useReasoning: DEFAULT_SETTINGS.useReasoning,
          status: 'active',
          favorite: false,
          createdAt: now,
          updatedAt: now,
          lastMessageAt: now,
          tokenCount: 0,
          tags: [],
        };
        set(state => ({
          conversations: [newConversation, ...state.conversations],
          activeConversationId: newConversation.id,
        }));
        return newConversation;
      },

      // Update
      updateConversation: (id, updates) => {
        set(state => ({
          conversations: state.conversations.map(c =>
            c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
          ),
        }));
      },

      // Delete
      deleteConversation: (id) => {
        set(state => ({
          conversations: state.conversations.filter(c => c.id !== id),
          activeConversationId: state.activeConversationId === id ? null : state.activeConversationId,
        }));
      },

      // Duplicate
      duplicateConversation: (id) => {
        const conversation = get().conversations.find(c => c.id === id);
        if (!conversation) return;
        const now = new Date().toISOString();
        const duplicated: Conversation = {
          ...conversation,
          id: generateId(),
          title: `${conversation.title} (Copy)`,
          messages: conversation.messages.map(m => ({ ...m, id: generateId() })),
          createdAt: now,
          updatedAt: now,
          lastMessageAt: now,
        };
        set(state => ({
          conversations: [duplicated, ...state.conversations],
        }));
      },

      // Pin/Unpin
      pinConversation: (id) => {
        get().updateConversation(id, { status: 'pinned' });
      },
      unpinConversation: (id) => {
        get().updateConversation(id, { status: 'active' });
      },

      // Archive/Unarchive
      archiveConversation: (id) => {
        get().updateConversation(id, { status: 'archived' });
      },
      unarchiveConversation: (id) => {
        get().updateConversation(id, { status: 'active' });
      },

      // Favorite
      favoriteConversation: (id) => {
        get().updateConversation(id, { favorite: true });
      },
      unfavoriteConversation: (id) => {
        get().updateConversation(id, { favorite: false });
      },

      // Navigation
      setActiveConversation: (id) => {
        set({ activeConversationId: id });
      },

      // Search & Filter
      setSearchQuery: (query) => set({ searchQuery: query }),
      setSortBy: (sort) => set({ sortBy: sort }),
      setFilterStatus: (status) => set({ filterStatus: status }),

      // Folders
      createFolder: (name, workspaceId, parentId) => {
        const folder: ChatFolder = {
          id: generateId(),
          name,
          color: '#6366f1',
          workspaceId,
          parentId,
          order: get().folders.length,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set(state => ({ folders: [...state.folders, folder] }));
        return folder;
      },
      updateFolder: (id, updates) => {
        set(state => ({
          folders: state.folders.map(f =>
            f.id === id ? { ...f, ...updates, updatedAt: new Date().toISOString() } : f
          ),
        }));
      },
      deleteFolder: (id) => {
        set(state => ({
          folders: state.folders.filter(f => f.id !== id),
          conversations: state.conversations.map(c =>
            c.folderId === id ? { ...c, folderId: undefined } : c
          ),
        }));
      },
      moveConversationToFolder: (conversationId, folderId) => {
        get().updateConversation(conversationId, { folderId: folderId || undefined });
      },

      // Projects
      createProject: (name, workspaceId) => {
        const project: ChatProject = {
          id: generateId(),
          name,
          color: '#8b5cf6',
          workspaceId,
          conversationIds: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set(state => ({ projects: [...state.projects, project] }));
        return project;
      },
      updateProject: (id, updates) => {
        set(state => ({
          projects: state.projects.map(p =>
            p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
          ),
        }));
      },
      deleteProject: (id) => {
        set(state => ({
          projects: state.projects.filter(p => p.id !== id),
        }));
      },
      addConversationToProject: (conversationId, projectId) => {
        set(state => ({
          projects: state.projects.map(p =>
            p.id === projectId
              ? { ...p, conversationIds: [...new Set([...p.conversationIds, conversationId])] }
              : p
          ),
        }));
      },
      removeConversationFromProject: (conversationId, projectId) => {
        set(state => ({
          projects: state.projects.map(p =>
            p.id === projectId
              ? { ...p, conversationIds: p.conversationIds.filter(id => id !== conversationId) }
              : p
          ),
        }));
      },

      // Summary
      updateSummary: (id, summary) => {
        get().updateConversation(id, { summary });
      },

      // Computed
      getFilteredConversations: () => {
        const state = get();
        let filtered = state.conversations;

        if (state.filterStatus !== 'all') {
          filtered = filtered.filter(c => c.status === state.filterStatus);
        }

        if (state.searchQuery) {
          const query = state.searchQuery.toLowerCase();
          filtered = filtered.filter(c =>
            c.title.toLowerCase().includes(query) ||
            c.tags.some(t => t.toLowerCase().includes(query))
          );
        }

        if (state.sortBy === 'date') {
          filtered = [...filtered].sort((a, b) => 
            new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime()
          );
        } else {
          filtered = [...filtered].sort((a, b) => a.title.localeCompare(b.title));
        }

        return filtered;
      },
      getConversationById: (id) => get().conversations.find(c => c.id === id),
      getPinnedConversations: () => get().conversations.filter(c => c.status === 'pinned'),
      getArchivedConversations: () => get().conversations.filter(c => c.status === 'archived'),
      getRecentConversations: (limit = 10) => 
        get().conversations
          .filter(c => c.status === 'active')
          .sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime())
          .slice(0, limit),
    }),
    {
      name: STORAGE_KEYS.CONVERSATIONS,
      partialize: (state) => ({
        conversations: state.conversations,
        folders: state.folders,
        projects: state.projects,
        activeConversationId: state.activeConversationId,
        sortBy: state.sortBy,
      }),
    }
  )
);
