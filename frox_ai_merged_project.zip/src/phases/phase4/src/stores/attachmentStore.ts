// ============================================================
// Frox AI – Attachment Store
// ============================================================

import { create } from 'zustand';
import type { Attachment } from '../types/index';
import { generateId } from '../utils/index';
import { FILE_CONSTRAINTS } from '../constants/index';

interface AttachmentState {
  attachments: Attachment[];
  uploadQueue: Attachment[];
  isUploading: boolean;
}

interface AttachmentActions {
  addAttachment: (file: File) => Attachment | null;
  removeAttachment: (id: string) => void;
  updateAttachment: (id: string, updates: Partial<Attachment>) => void;
  clearAttachments: () => void;
  processUploadQueue: () => Promise<void>;
  getAttachmentById: (id: string) => Attachment | undefined;
  validateFile: (file: File) => { valid: boolean; error?: string };
}

export const useAttachmentStore = create<AttachmentState & AttachmentActions>((set, get) => ({
  attachments: [],
  uploadQueue: [],
  isUploading: false,

  addAttachment: (file) => {
    const validation = get().validateFile(file);
    if (!validation.valid) {
      console.error(validation.error);
      return null;
    }

    const attachment: Attachment = {
      id: generateId(),
      name: file.name,
      type: file.type,
      size: file.size,
      url: URL.createObjectURL(file),
      mimeType: file.type,
      uploadProgress: 0,
      status: 'uploading',
      createdAt: new Date().toISOString(),
    };

    set(state => ({
      attachments: [...state.attachments, attachment],
      uploadQueue: [...state.uploadQueue, attachment],
    }));

    // Simulate upload progress
    const simulateUpload = () => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 20 + 10;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          get().updateAttachment(attachment.id, { status: 'uploaded', uploadProgress: 100 });
        } else {
          get().updateAttachment(attachment.id, { uploadProgress: progress });
        }
      }, 200);
    };
    simulateUpload();

    return attachment;
  },

  removeAttachment: (id) => {
    set(state => {
      const attachment = state.attachments.find(a => a.id === id);
      if (attachment?.url) {
        URL.revokeObjectURL(attachment.url);
      }
      return {
        attachments: state.attachments.filter(a => a.id !== id),
        uploadQueue: state.uploadQueue.filter(a => a.id !== id),
      };
    });
  },

  updateAttachment: (id, updates) => {
    set(state => ({
      attachments: state.attachments.map(a =>
        a.id === id ? { ...a, ...updates } : a
      ),
      uploadQueue: state.uploadQueue.map(a =>
        a.id === id ? { ...a, ...updates } : a
      ),
    }));
  },

  clearAttachments: () => {
    set(state => {
      state.attachments.forEach(a => {
        if (a.url) URL.revokeObjectURL(a.url);
      });
      return { attachments: [], uploadQueue: [] };
    });
  },

  processUploadQueue: async () => {
    const { uploadQueue } = get();
    if (uploadQueue.length === 0) return;

    set({ isUploading: true });
    // Process uploads sequentially
    for (const attachment of uploadQueue) {
      if (attachment.status === 'uploading') {
        // Actual upload logic would go here
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    set({ isUploading: false, uploadQueue: [] });
  },

  getAttachmentById: (id) => get().attachments.find(a => a.id === id),

  validateFile: (file) => {
    if (file.size > FILE_CONSTRAINTS.maxSize) {
      return { valid: false, error: `File size exceeds ${FILE_CONSTRAINTS.maxSize / 1024 / 1024}MB` };
    }
    const isAllowed = FILE_CONSTRAINTS.allowedTypes.some(type => {
      if (type.endsWith('/*')) {
        return file.type.startsWith(type.replace('/*', ''));
      }
      return file.type === type;
    });
    if (!isAllowed) {
      return { valid: false, error: 'File type not supported' };
    }
    return { valid: true };
  },
}));
