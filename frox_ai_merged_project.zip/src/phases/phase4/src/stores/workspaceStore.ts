// ============================================================
// Frox AI – Workspace Store
// ============================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Workspace, User } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';
import { generateId } from '../utils/index';

interface WorkspaceState {
  workspaces: Workspace[];
  activeWorkspaceId: string | null;
  currentUser: User | null;
  isLoading: boolean;
}

interface WorkspaceActions {
  createWorkspace: (name: string, description?: string) => Workspace;
  updateWorkspace: (id: string, updates: Partial<Workspace>) => void;
  deleteWorkspace: (id: string) => void;
  setActiveWorkspace: (id: string) => void;
  setCurrentUser: (user: User | null) => void;
  getActiveWorkspace: () => Workspace | undefined;
}

export const useWorkspaceStore = create<WorkspaceState & WorkspaceActions>()(
  persist(
    (set, get) => ({
      workspaces: [],
      activeWorkspaceId: null,
      currentUser: null,
      isLoading: false,

      createWorkspace: (name, description) => {
        const workspace: Workspace = {
          id: generateId(),
          name,
          description,
          color: '#6366f1',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          members: [],
        };
        set(state => ({
          workspaces: [...state.workspaces, workspace],
          activeWorkspaceId: workspace.id,
        }));
        return workspace;
      },

      updateWorkspace: (id, updates) => {
        set(state => ({
          workspaces: state.workspaces.map(w =>
            w.id === id ? { ...w, ...updates, updatedAt: new Date().toISOString() } : w
          ),
        }));
      },

      deleteWorkspace: (id) => {
        set(state => ({
          workspaces: state.workspaces.filter(w => w.id !== id),
          activeWorkspaceId: state.activeWorkspaceId === id ? null : state.activeWorkspaceId,
        }));
      },

      setActiveWorkspace: (id) => set({ activeWorkspaceId: id }),
      setCurrentUser: (user) => set({ currentUser: user }),
      getActiveWorkspace: () => get().workspaces.find(w => w.id === get().activeWorkspaceId),
    }),
    {
      name: STORAGE_KEYS.WORKSPACE,
      partialize: (state) => ({
        workspaces: state.workspaces,
        activeWorkspaceId: state.activeWorkspaceId,
      }),
    }
  )
);
