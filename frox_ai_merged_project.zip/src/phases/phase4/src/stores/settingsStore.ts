// ============================================================
// Frox AI – Settings Store
// ============================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AppSettings, KeyboardShortcut } from '../types/index';
import { STORAGE_KEYS, DEFAULT_SETTINGS, KEYBOARD_SHORTCUTS } from '../constants/index';

interface SettingsState extends AppSettings {
  isSettingsOpen: boolean;
  activeSettingsTab: string;
}

interface SettingsActions {
  updateGeneral: (settings: Partial<AppSettings['general']>) => void;
  updateAppearance: (settings: Partial<AppSettings['appearance']>) => void;
  updateEditor: (settings: Partial<AppSettings['editor']>) => void;
  updatePrivacy: (settings: Partial<AppSettings['privacy']>) => void;
  updateShortcut: (id: string, keys: string[]) => void;
  resetToDefaults: () => void;
  openSettings: (tab?: string) => void;
  closeSettings: () => void;
}

const defaultSettings: AppSettings = {
  general: {
    language: 'en',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    dateFormat: 'MMM d, yyyy',
    autoSave: true,
    autoSaveInterval: 30000,
    confirmDelete: true,
    soundEffects: false,
  },
  appearance: {
    theme: DEFAULT_SETTINGS.theme,
    fontFamily: 'Inter, system-ui, sans-serif',
    fontSize: 14,
    lineHeight: 1.6,
    borderRadius: 'md',
    sidebarWidth: 280,
    rightPanelWidth: 320,
    showAvatars: true,
    showTimestamps: true,
    showTokenCount: true,
    compactMode: false,
    accentColor: '#6366f1',
  },
  editor: {
    enterToSend: DEFAULT_SETTINGS.enterToSend,
    codeWrap: DEFAULT_SETTINGS.codeWrap,
    syntaxHighlighting: true,
    lineNumbers: true,
    wordWrap: true,
    tabSize: 2,
    spellCheck: false,
    autoComplete: true,
  },
  shortcuts: KEYBOARD_SHORTCUTS.map(s => ({ ...s })),
  privacy: {
    shareUsageData: false,
    saveHistory: true,
    encryptMessages: false,
    autoDeleteAfter: null,
  },
};

export const useSettingsStore = create<SettingsState & SettingsActions>()(
  persist(
    (set) => ({
      ...defaultSettings,
      isSettingsOpen: false,
      activeSettingsTab: 'general',

      updateGeneral: (settings) =>
        set(state => ({ general: { ...state.general, ...settings } })),

      updateAppearance: (settings) =>
        set(state => ({ appearance: { ...state.appearance, ...settings } })),

      updateEditor: (settings) =>
        set(state => ({ editor: { ...state.editor, ...settings } })),

      updatePrivacy: (settings) =>
        set(state => ({ privacy: { ...state.privacy, ...settings } })),

      updateShortcut: (id, keys) =>
        set(state => ({
          shortcuts: state.shortcuts.map(s =>
            s.id === id ? { ...s, keys } : s
          ),
        })),

      resetToDefaults: () => set({ ...defaultSettings }),

      openSettings: (tab = 'general') =>
        set({ isSettingsOpen: true, activeSettingsTab: tab }),

      closeSettings: () => set({ isSettingsOpen: false }),
    }),
    {
      name: STORAGE_KEYS.SETTINGS,
    }
  )
);
