// ============================================================
// Frox AI – Message Store
// ============================================================

import { create } from 'zustand';
import type { Message, StreamingChunk, TokenUsage } from '../types/index';
import { generateId, estimateTokens } from '../utils/index';

interface MessageState {
  messages: Message[];
  streamingMessages: Map<string, string>;
  thinkingMessages: Map<string, string>;
  isGenerating: boolean;
  abortController: AbortController | null;
  error: string | null;
}

interface MessageActions {
  // CRUD
  addMessage: (message: Omit<Message, 'id' | 'createdAt' | 'updatedAt'>) => Message;
  updateMessage: (id: string, updates: Partial<Message>) => void;
  deleteMessage: (id: string) => void;
  deleteMessagesByConversation: (conversationId: string) => void;

  // Streaming
  startStreaming: (conversationId: string) => void;
  appendStreamingChunk: (conversationId: string, chunk: string) => void;
  appendThinkingChunk: (conversationId: string, chunk: string) => void;
  finalizeStreaming: (conversationId: string, metadata?: Partial<Message['metadata']>) => Message;
  stopStreaming: () => void;

  // Edit/Regenerate
  editMessage: (id: string, newContent: string) => void;
  regenerateMessage: (id: string) => void;
  continueGeneration: (conversationId: string) => void;

  // Reactions
  addReaction: (messageId: string, emoji: string, userId: string) => void;
  removeReaction: (messageId: string, emoji: string, userId: string) => void;

  // Computed
  getMessagesByConversation: (conversationId: string) => Message[];
  getMessageById: (id: string) => Message | undefined;
  getLastMessage: (conversationId: string) => Message | undefined;
  estimateContextTokens: (conversationId: string) => number;
}

export const useMessageStore = create<MessageState & MessageActions>((set, get) => ({
  // State
  messages: [],
  streamingMessages: new Map(),
  thinkingMessages: new Map(),
  isGenerating: false,
  abortController: null,
  error: null,

  // Add
  addMessage: (message) => {
    const now = new Date().toISOString();
    const newMessage: Message = {
      ...message,
      id: generateId(),
      createdAt: now,
      updatedAt: now,
      tokens: estimateTokens(message.content),
    };
    set(state => ({ messages: [...state.messages, newMessage] }));
    return newMessage;
  },

  // Update
  updateMessage: (id, updates) => {
    set(state => ({
      messages: state.messages.map(m =>
        m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m
      ),
    }));
  },

  // Delete
  deleteMessage: (id) => {
    set(state => ({ messages: state.messages.filter(m => m.id !== id) }));
  },

  deleteMessagesByConversation: (conversationId) => {
    set(state => ({ messages: state.messages.filter(m => m.conversationId !== conversationId) }));
  },

  // Streaming
  startStreaming: (conversationId) => {
    const controller = new AbortController();
    set({
      isGenerating: true,
      abortController: controller,
      streamingMessages: new Map(get().streamingMessages).set(conversationId, ''),
      thinkingMessages: new Map(get().thinkingMessages).set(conversationId, ''),
    });
  },

  appendStreamingChunk: (conversationId, chunk) => {
    set(state => {
      const newMap = new Map(state.streamingMessages);
      newMap.set(conversationId, (newMap.get(conversationId) || '') + chunk);
      return { streamingMessages: newMap };
    });
  },

  appendThinkingChunk: (conversationId, chunk) => {
    set(state => {
      const newMap = new Map(state.thinkingMessages);
      newMap.set(conversationId, (newMap.get(conversationId) || '') + chunk);
      return { thinkingMessages: newMap };
    });
  },

  finalizeStreaming: (conversationId, metadata) => {
    const content = get().streamingMessages.get(conversationId) || '';
    const thinkingContent = get().thinkingMessages.get(conversationId) || '';

    const message = get().addMessage({
      conversationId,
      role: 'assistant',
      content,
      contentType: 'markdown',
      attachments: [],
      metadata: {
        ...metadata,
        tokensUsed: {
          prompt: 0,
          completion: estimateTokens(content),
          total: estimateTokens(content),
        },
      },
      isStreaming: false,
      thinkingContent: thinkingContent || undefined,
    });

    set(state => {
      const newStreaming = new Map(state.streamingMessages);
      newStreaming.delete(conversationId);
      const newThinking = new Map(state.thinkingMessages);
      newThinking.delete(conversationId);
      return {
        isGenerating: false,
        abortController: null,
        streamingMessages: newStreaming,
        thinkingMessages: newThinking,
      };
    });

    return message;
  },

  stopStreaming: () => {
    const controller = get().abortController;
    if (controller) {
      controller.abort();
    }
    set({ isGenerating: false, abortController: null });
  },

  // Edit
  editMessage: (id, newContent) => {
    get().updateMessage(id, { content: newContent, version: (get().getMessageById(id)?.version || 0) + 1 });
  },

  // Regenerate
  regenerateMessage: (id) => {
    const message = get().getMessageById(id);
    if (!message) return;
    get().deleteMessage(id);
    // Trigger regeneration via service
  },

  // Continue
  continueGeneration: (conversationId) => {
    // Trigger continuation via service
  },

  // Reactions
  addReaction: (messageId, emoji, userId) => {
    set(state => ({
      messages: state.messages.map(m => {
        if (m.id !== messageId) return m;
        const reactions = m.reactions || [];
        if (reactions.some(r => r.emoji === emoji && r.userId === userId)) return m;
        return {
          ...m,
          reactions: [...reactions, { emoji, userId, createdAt: new Date().toISOString() }],
        };
      }),
    }));
  },

  removeReaction: (messageId, emoji, userId) => {
    set(state => ({
      messages: state.messages.map(m => {
        if (m.id !== messageId) return m;
        return {
          ...m,
          reactions: (m.reactions || []).filter(r => !(r.emoji === emoji && r.userId === userId)),
        };
      }),
    }));
  },

  // Computed
  getMessagesByConversation: (conversationId) =>
    get().messages
      .filter(m => m.conversationId === conversationId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()),
  getMessageById: (id) => get().messages.find(m => m.id === id),
  getLastMessage: (conversationId) => {
    const msgs = get().getMessagesByConversation(conversationId);
    return msgs[msgs.length - 1];
  },
  estimateContextTokens: (conversationId) => {
    const msgs = get().getMessagesByConversation(conversationId);
    return msgs.reduce((sum, m) => sum + (m.tokens || estimateTokens(m.content)), 0);
  },
}));
