// ============================================================
// Frox AI – Notification Store
// ============================================================

import { create } from 'zustand';
import type { Notification } from '../types/index';
import { generateId } from '../utils/index';

interface NotificationState {
  notifications: Notification[];
}

interface NotificationActions {
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => string;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
  success: (title: string, message: string) => string;
  error: (title: string, message: string) => string;
  warning: (title: string, message: string) => string;
  info: (title: string, message: string) => string;
}

export const useNotificationStore = create<NotificationState & NotificationActions>((set, get) => ({
  notifications: [],

  addNotification: (notification) => {
    const id = generateId();
    const newNotification: Notification = {
      ...notification,
      id,
      createdAt: new Date().toISOString(),
      duration: notification.duration ?? 4000,
    };
    set(state => ({ notifications: [...state.notifications, newNotification] }));

    if (newNotification.duration > 0) {
      setTimeout(() => {
        get().removeNotification(id);
      }, newNotification.duration);
    }

    return id;
  },

  removeNotification: (id) => {
    set(state => ({ notifications: state.notifications.filter(n => n.id !== id) }));
  },

  clearNotifications: () => set({ notifications: [] }),

  success: (title, message) => get().addNotification({ type: 'success', title, message }),
  error: (title, message) => get().addNotification({ type: 'error', title, message }),
  warning: (title, message) => get().addNotification({ type: 'warning', title, message }),
  info: (title, message) => get().addNotification({ type: 'info', title, message }),
}));
