// ============================================================
// Frox AI – Composer Store
// ============================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { ComposerState, Attachment, AIModel } from '../types/index';
import { STORAGE_KEYS, MODELS, DEFAULT_SETTINGS, FILE_CONSTRAINTS } from '../constants/index';

interface ComposerActions {
  setText: (text: string) => void;
  appendText: (text: string) => void;
  clearText: () => void;

  addAttachment: (attachment: Attachment) => void;
  removeAttachment: (id: string) => void;
  clearAttachments: () => void;
  updateAttachmentProgress: (id: string, progress: number) => void;

  setModel: (model: AIModel) => void;
  setTemperature: (temp: number) => void;
  setMaxTokens: (tokens: number) => void;
  toggleInternet: () => void;
  toggleReasoning: () => void;

  setFocused: (focused: boolean) => void;
  setDragging: (dragging: boolean) => void;
  setRecording: (recording: boolean) => void;
  setGenerating: (generating: boolean) => void;

  reset: () => void;
  validateAttachments: () => { valid: boolean; error?: string };
}

const initialState: ComposerState = {
  text: '',
  attachments: [],
  selectedModel: MODELS[0],
  temperature: DEFAULT_SETTINGS.temperature,
  maxTokens: DEFAULT_SETTINGS.maxTokens,
  useInternet: DEFAULT_SETTINGS.useInternet,
  useReasoning: DEFAULT_SETTINGS.useReasoning,
  isFocused: false,
  isDragging: false,
  isRecording: false,
  isGenerating: false,
};

export const useComposerStore = create<ComposerState & ComposerActions>()(
  persist(
    (set, get) => ({
      ...initialState,

      setText: (text) => set({ text }),
      appendText: (text) => set(state => ({ text: state.text + text })),
      clearText: () => set({ text: '' }),

      addAttachment: (attachment) => {
        set(state => {
          if (state.attachments.length >= FILE_CONSTRAINTS.maxCount) {
            return state;
          }
          return { attachments: [...state.attachments, attachment] };
        });
      },

      removeAttachment: (id) => {
        set(state => ({ attachments: state.attachments.filter(a => a.id !== id) }));
      },

      clearAttachments: () => set({ attachments: [] }),

      updateAttachmentProgress: (id, progress) => {
        set(state => ({
          attachments: state.attachments.map(a =>
            a.id === id ? { ...a, uploadProgress: progress } : a
          ),
        }));
      },

      setModel: (model) => set({ selectedModel: model }),
      setTemperature: (temp) => set({ temperature: temp }),
      setMaxTokens: (tokens) => set({ maxTokens: tokens }),
      toggleInternet: () => set(state => ({ useInternet: !state.useInternet })),
      toggleReasoning: () => set(state => ({ useReasoning: !state.useReasoning })),

      setFocused: (focused) => set({ isFocused: focused }),
      setDragging: (dragging) => set({ isDragging: dragging }),
      setRecording: (recording) => set({ isRecording: recording }),
      setGenerating: (generating) => set({ isGenerating: generating }),

      reset: () => set({ ...initialState, selectedModel: get().selectedModel }),

      validateAttachments: () => {
        const { attachments } = get();
        const totalSize = attachments.reduce((sum, a) => sum + a.size, 0);

        if (attachments.length > FILE_CONSTRAINTS.maxCount) {
          return { valid: false, error: `Maximum ${FILE_CONSTRAINTS.maxCount} files allowed` };
        }
        if (totalSize > FILE_CONSTRAINTS.maxSize) {
          return { valid: false, error: `Total size exceeds ${FILE_CONSTRAINTS.maxSize / 1024 / 1024}MB` };
        }
        return { valid: true };
      },
    }),
    {
      name: STORAGE_KEYS.COMPOSER,
      partialize: (state) => ({
        selectedModel: state.selectedModel,
        temperature: state.temperature,
        maxTokens: state.maxTokens,
        useInternet: state.useInternet,
        useReasoning: state.useReasoning,
      }),
    }
  )
);
