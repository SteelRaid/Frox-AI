// ============================================================
// Frox AI – Theme Store
// ============================================================

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { ThemeMode } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';

interface ThemeState {
  mode: ThemeMode;
  systemPreference: 'light' | 'dark';
  isTransitioning: boolean;
}

interface ThemeActions {
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
  setSystemPreference: (preference: 'light' | 'dark') => void;
  getEffectiveMode: () => 'light' | 'dark';
  applyTheme: () => void;
}

export const useThemeStore = create<ThemeState & ThemeActions>()(
  persist(
    (set, get) => ({
      mode: 'system',
      systemPreference: 'dark',
      isTransitioning: false,

      setMode: (mode) => {
        set({ mode, isTransitioning: true });
        get().applyTheme();
        setTimeout(() => set({ isTransitioning: false }), 300);
      },

      toggleMode: () => {
        const current = get().getEffectiveMode();
        const next = current === 'light' ? 'dark' : 'light';
        set({ mode: next, isTransitioning: true });
        get().applyTheme();
        setTimeout(() => set({ isTransitioning: false }), 300);
      },

      setSystemPreference: (preference) => {
        set({ systemPreference: preference });
        if (get().mode === 'system') {
          get().applyTheme();
        }
      },

      getEffectiveMode: () => {
        const { mode, systemPreference } = get();
        if (mode === 'system') return systemPreference;
        return mode;
      },

      applyTheme: () => {
        const effectiveMode = get().getEffectiveMode();
        const root = document.documentElement;
        if (effectiveMode === 'dark') {
          root.classList.add('dark');
          root.classList.remove('light');
          root.style.colorScheme = 'dark';
        } else {
          root.classList.add('light');
          root.classList.remove('dark');
          root.style.colorScheme = 'light';
        }
      },
    }),
    {
      name: STORAGE_KEYS.THEME,
      onRehydrateStorage: () => (state) => {
        state?.applyTheme();
        // Listen for system preference changes
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        const handler = (e: MediaQueryListEvent) => {
          state?.setSystemPreference(e.matches ? 'dark' : 'light');
        };
        mediaQuery.addEventListener('change', handler);
        state?.setSystemPreference(mediaQuery.matches ? 'dark' : 'light');
      },
    }
  )
);
