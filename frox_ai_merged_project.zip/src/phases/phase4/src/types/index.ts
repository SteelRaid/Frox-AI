// ============================================================
// Frox AI – Core Type System
// ============================================================

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'user' | 'admin' | 'pro';
  preferences: UserPreferences;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  fontSize: 'sm' | 'base' | 'lg' | 'xl';
  language: string;
  sidebarCollapsed: boolean;
  showTimestamps: boolean;
  showTokenCount: boolean;
  enterToSend: boolean;
  codeWrap: boolean;
  reducedMotion: boolean;
}

export interface Workspace {
  id: string;
  name: string;
  description?: string;
  icon?: string;
  color: string;
  createdAt: string;
  updatedAt: string;
  members: WorkspaceMember[];
}

export interface WorkspaceMember {
  userId: string;
  role: 'owner' | 'admin' | 'member';
  joinedAt: string;
}

export interface Conversation {
  id: string;
  title: string;
  workspaceId: string;
  messages: Message[];
  model: AIModel;
  temperature: number;
  maxTokens: number;
  useInternet: boolean;
  useReasoning: boolean;
  status: 'active' | 'archived' | 'pinned' | 'deleted';
  favorite: boolean;
  folderId?: string;
  projectId?: string;
  createdAt: string;
  updatedAt: string;
  lastMessageAt: string;
  tokenCount: number;
  summary?: string;
  tags: string[];
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  contentType: 'text' | 'markdown' | 'image' | 'file' | 'mixed';
  attachments: Attachment[];
  metadata: MessageMetadata;
  createdAt: string;
  updatedAt: string;
  tokens?: number;
  isStreaming?: boolean;
  isError?: boolean;
  isThinking?: boolean;
  thinkingContent?: string;
  parentId?: string;
  version?: number;
  reactions?: MessageReaction[];
}

export interface MessageMetadata {
  model?: string;
  temperature?: number;
  finishReason?: string;
  latency?: number;
  tokensUsed?: TokenUsage;
  sources?: SourceReference[];
  toolCalls?: ToolCall[];
}

export interface TokenUsage {
  prompt: number;
  completion: number;
  total: number;
}

export interface SourceReference {
  title: string;
  url: string;
  snippet?: string;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  result?: unknown;
}

export interface MessageReaction {
  emoji: string;
  userId: string;
  createdAt: string;
}

export interface Attachment {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  mimeType: string;
  previewUrl?: string;
  uploadProgress?: number;
  status: 'uploading' | 'uploaded' | 'error';
  createdAt: string;
}

export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  maxTokens: number;
  contextWindow: number;
  supportsVision: boolean;
  supportsReasoning: boolean;
  supportsInternet: boolean;
  pricing: ModelPricing;
  capabilities: string[];
  isAvailable: boolean;
}

export interface ModelPricing {
  input: number;
  output: number;
  currency: string;
}

export interface ChatFolder {
  id: string;
  name: string;
  color: string;
  icon?: string;
  workspaceId: string;
  parentId?: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface ChatProject {
  id: string;
  name: string;
  description?: string;
  color: string;
  icon?: string;
  workspaceId: string;
  conversationIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface ComposerState {
  text: string;
  attachments: Attachment[];
  selectedModel: AIModel;
  temperature: number;
  maxTokens: number;
  useInternet: boolean;
  useReasoning: boolean;
  isFocused: boolean;
  isDragging: boolean;
  isRecording: boolean;
  isGenerating: boolean;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  duration?: number;
  action?: { label: string; onClick: () => void };
  createdAt: string;
}

export interface AppSettings {
  general: GeneralSettings;
  appearance: AppearanceSettings;
  editor: EditorSettings;
  shortcuts: KeyboardShortcut[];
  privacy: PrivacySettings;
}

export interface GeneralSettings {
  language: string;
  timezone: string;
  dateFormat: string;
  autoSave: boolean;
  autoSaveInterval: number;
  confirmDelete: boolean;
  soundEffects: boolean;
}

export interface AppearanceSettings {
  theme: 'light' | 'dark' | 'system';
  fontFamily: string;
  fontSize: number;
  lineHeight: number;
  borderRadius: 'sm' | 'md' | 'lg' | 'xl';
  sidebarWidth: number;
  rightPanelWidth: number;
  showAvatars: boolean;
  showTimestamps: boolean;
  showTokenCount: boolean;
  compactMode: boolean;
  accentColor: string;
}

export interface EditorSettings {
  enterToSend: boolean;
  codeWrap: boolean;
  syntaxHighlighting: boolean;
  lineNumbers: boolean;
  wordWrap: boolean;
  tabSize: number;
  spellCheck: boolean;
  autoComplete: boolean;
}

export interface KeyboardShortcut {
  id: string;
  action: string;
  keys: string[];
  description: string;
  scope: 'global' | 'composer' | 'chat' | 'sidebar';
}

export interface PrivacySettings {
  shareUsageData: boolean;
  saveHistory: boolean;
  encryptMessages: boolean;
  autoDeleteAfter: number | null;
}

export interface StreamingChunk {
  id: string;
  content: string;
  isThinking?: boolean;
  thinkingContent?: string;
  isComplete: boolean;
}

export interface SearchResult {
  conversations: Conversation[];
  messages: Message[];
  files: Attachment[];
  query: string;
  totalCount: number;
}

export type ThemeMode = 'light' | 'dark' | 'system';
export type ConversationStatus = 'active' | 'archived' | 'pinned' | 'deleted';
export type MessageRole = 'user' | 'assistant' | 'system' | 'tool';
export type ContentType = 'text' | 'markdown' | 'image' | 'file' | 'mixed';
export type AttachmentStatus = 'uploading' | 'uploaded' | 'error';
