// ============================================================
// Frox AI – useFileDrop Hook
// ============================================================

import { useState, useCallback, DragEvent } from 'react';
import { useAttachmentStore } from '../stores/index';
import { fileService } from '../services/index';

export function useFileDrop() {
  const [isDragging, setIsDragging] = useState(false);
  const addAttachment = useAttachmentStore(state => state.addAttachment);

  const handleDragEnter = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => {
      const validation = fileService.validateFile(file);
      if (validation.valid) {
        addAttachment(file);
      } else {
        console.error(validation.error);
      }
    });
  }, [addAttachment]);

  return {
    isDragging,
    dragHandlers: {
      onDragEnter: handleDragEnter,
      onDragLeave: handleDragLeave,
      onDragOver: handleDragOver,
      onDrop: handleDrop,
    },
  };
}
