// ============================================================
// Frox AI – useScrollToBottom Hook
// ============================================================

import { useRef, useCallback, useState, useEffect } from 'react';
import { SCROLL_CONFIG } from '../constants/index';

export function useScrollToBottom<T extends HTMLElement>() {
  const containerRef = useRef<T>(null);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [isAtBottom, setIsAtBottom] = useState(true);
  const autoScrollRef = useRef(true);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    const container = containerRef.current;
    if (!container) return;
    container.scrollTo({ top: container.scrollHeight, behavior });
    setIsAtBottom(true);
    autoScrollRef.current = true;
  }, []);

  const handleScroll = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;

    const { scrollTop, scrollHeight, clientHeight } = container;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    const atBottom = distanceFromBottom < SCROLL_CONFIG.threshold;

    setIsAtBottom(atBottom);
    setShowScrollButton(!atBottom && scrollHeight > clientHeight + 100);

    if (!atBottom) {
      autoScrollRef.current = false;
    }
  }, []);

  const enableAutoScroll = useCallback(() => {
    autoScrollRef.current = true;
    scrollToBottom();
  }, [scrollToBottom]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  return {
    containerRef,
    scrollToBottom,
    showScrollButton,
    isAtBottom,
    autoScrollRef,
    enableAutoScroll,
  };
}
