// ============================================================
// Frox AI – useStreaming Hook
// ============================================================

import { useState, useCallback, useRef } from 'react';
import { streamingService } from '../services/index';
import type { StreamingChunk } from '../types/index';

interface UseStreamingOptions {
  onChunk?: (chunk: StreamingChunk) => void;
  onComplete?: () => void;
  onError?: (error: Error) => void;
}

export function useStreaming(options: UseStreamingOptions = {}) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [content, setContent] = useState('');
  const [thinkingContent, setThinkingContent] = useState('');
  const abortControllerRef = useRef<AbortController | null>(null);

  const startStream = useCallback(async (endpoint: string, body: Record<string, unknown>) => {
    setIsStreaming(true);
    setContent('');
    setThinkingContent('');

    await streamingService.startStream(
      endpoint,
      body,
      {
        onChunk: (chunk) => {
          if (chunk.isThinking) {
            setThinkingContent(prev => prev + chunk.content);
          } else {
            setContent(prev => prev + chunk.content);
          }
          options.onChunk?.(chunk);
        },
        onComplete: () => {
          setIsStreaming(false);
          options.onComplete?.();
        },
        onError: (error) => {
          setIsStreaming(false);
          options.onError?.(error);
        },
      }
    );
  }, [options]);

  const stopStream = useCallback(() => {
    streamingService.stop();
    setIsStreaming(false);
  }, []);

  return {
    isStreaming,
    content,
    thinkingContent,
    startStream,
    stopStream,
  };
}
