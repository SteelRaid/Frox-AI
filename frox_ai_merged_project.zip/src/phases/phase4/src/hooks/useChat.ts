// ============================================================
// Frox AI – useChat Hook
// ============================================================

import { useCallback, useRef } from 'react';
import { useConversationStore, useMessageStore, useComposerStore, useNotificationStore } from '../stores/index';
import { chatService } from '../services/index';
import type { Message, Conversation } from '../types/index';
import { generateId } from '../utils/index';

export function useChat(conversationId: string) {
  const conversation = useConversationStore(state => state.getConversationById(conversationId));
  const messages = useMessageStore(state => state.getMessagesByConversation(conversationId));
  const addMessage = useMessageStore(state => state.addMessage);
  const startStreaming = useMessageStore(state => state.startStreaming);
  const appendStreamingChunk = useMessageStore(state => state.appendStreamingChunk);
  const appendThinkingChunk = useMessageStore(state => state.appendThinkingChunk);
  const finalizeStreaming = useMessageStore(state => state.finalizeStreaming);
  const stopStreaming = useMessageStore(state => state.stopStreaming);
  const isGenerating = useMessageStore(state => state.isGenerating);
  const updateConversation = useConversationStore(state => state.updateConversation);
  const error = useMessageStore(state => state.error);
  const errorNotification = useNotificationStore(state => state.error);

  const sendMessage = useCallback(async (content: string, attachments: Message['attachments'] = []) => {
    if (!conversation) return;

    // Add user message
    const userMessage = addMessage({
      conversationId,
      role: 'user',
      content,
      contentType: attachments.length > 0 ? 'mixed' : 'text',
      attachments,
      metadata: {},
    });

    // Update conversation
    updateConversation(conversationId, {
      lastMessageAt: new Date().toISOString(),
      title: conversation.title === 'New Chat' ? content.substring(0, 50) : conversation.title,
    });

    // Start streaming
    startStreaming(conversationId);

    try {
      const response = await chatService.sendMessage(
        {
          messages: [
            ...messages.map(m => ({ role: m.role, content: m.content })),
            { role: 'user', content },
          ],
          model: conversation.model.id,
          temperature: conversation.temperature,
          maxTokens: conversation.maxTokens,
          stream: true,
          useInternet: conversation.useInternet,
          useReasoning: conversation.useReasoning,
        },
        (chunk) => appendStreamingChunk(conversationId, chunk),
        (chunk) => appendThinkingChunk(conversationId, chunk)
      );

      finalizeStreaming(conversationId, {
        model: conversation.model.id,
        finishReason: response.metadata.finishReason,
        tokensUsed: response.metadata.tokensUsed,
        latency: response.metadata.latency,
      });

      updateConversation(conversationId, {
        tokenCount: (conversation.tokenCount || 0) + response.metadata.tokensUsed.total,
      });
    } catch (err) {
      stopStreaming();
      const errorMsg = err instanceof Error ? err.message : 'Unknown error';
      errorNotification('Generation Failed', errorMsg);

      // Add error message
      addMessage({
        conversationId,
        role: 'assistant',
        content: `Error: ${errorMsg}`,
        contentType: 'text',
        attachments: [],
        metadata: {},
        isError: true,
      });
    }
  }, [conversation, conversationId, messages, addMessage, updateConversation, startStreaming, appendStreamingChunk, appendThinkingChunk, finalizeStreaming, stopStreaming, errorNotification]);

  const regenerateMessage = useCallback(async (messageId: string) => {
    // Find the user message that triggered this response
    const messageIndex = messages.findIndex(m => m.id === messageId);
    if (messageIndex <= 0) return;

    const userMessage = messages[messageIndex - 1];
    if (userMessage.role !== 'user') return;

    // Remove the assistant message and regenerate
    // Implementation would remove the old message and trigger new generation
  }, [messages]);

  const continueGeneration = useCallback(async () => {
    if (!conversation || isGenerating) return;
    // Implementation for continuing generation
  }, [conversation, isGenerating]);

  return {
    conversation,
    messages,
    sendMessage,
    regenerateMessage,
    continueGeneration,
    isGenerating,
    error,
  };
}
