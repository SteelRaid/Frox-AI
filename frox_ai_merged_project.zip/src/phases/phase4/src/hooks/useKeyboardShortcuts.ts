// ============================================================
// Frox AI – useKeyboardShortcuts Hook
// ============================================================

import { useEffect, useCallback } from 'react';
import type { KeyboardShortcut } from '../types/index';

export function useKeyboardShortcuts(
  shortcuts: Array<{
    keys: string[];
    handler: (e: KeyboardEvent) => void;
    preventDefault?: boolean;
  }>
) {
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    const isCtrl = e.ctrlKey || e.metaKey;
    const isShift = e.shiftKey;
    const isAlt = e.altKey;

    for (const shortcut of shortcuts) {
      const { keys, handler, preventDefault = true } = shortcut;

      const keyMatch = keys.every(key => {
        switch (key.toLowerCase()) {
          case 'ctrl': return isCtrl;
          case 'shift': return isShift;
          case 'alt': return isAlt;
          case 'meta': return e.metaKey;
          default: return e.key.toLowerCase() === key.toLowerCase();
        }
      });

      if (keyMatch) {
        if (preventDefault) e.preventDefault();
        handler(e);
        break;
      }
    }
  }, [shortcuts]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);
}
