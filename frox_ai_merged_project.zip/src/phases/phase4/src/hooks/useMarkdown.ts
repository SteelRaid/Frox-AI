// ============================================================
// Frox AI – useMarkdown Hook
// ============================================================

import { useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

export function useMarkdown(content: string) {
  return useMemo(() => {
    return {
      components: {
        // Custom component overrides would go here
      },
      remarkPlugins: [remarkGfm, remarkMath],
      rehypePlugins: [rehypeKatex],
    };
  }, []);
}
