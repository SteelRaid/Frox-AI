// ============================================================
// Frox AI – Main Layout
// ============================================================

import { useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Sidebar } from '../components/sidebar/Sidebar';
import { TopBar } from '../components/layout/TopBar';
import { RightPanel } from '../components/layout/RightPanel';
import { CommandPalette } from '../components/layout/CommandPalette';
import { ToastContainer } from '../components/layout/ToastContainer';
import { MobileDrawer } from '../components/layout/MobileDrawer';
import { useLayoutStore, useThemeStore } from '../stores/index';
import { useIsMobile, useIsTablet } from '../hooks/index';
import { cn } from '../utils/index';
import { sidebarVariants } from '../animations/index';

export function MainLayout() {
  const sidebarCollapsed = useLayoutStore(state => state.sidebarCollapsed);
  const rightPanelOpen = useLayoutStore(state => state.rightPanelOpen);
  const applyTheme = useThemeStore(state => state.applyTheme);
  const isMobile = useIsMobile();
  const isTablet = useIsTablet();

  useEffect(() => {
    applyTheme();
  }, [applyTheme]);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors duration-300">
      {/* Mobile Drawer */}
      <MobileDrawer />

      {/* Sidebar */}
      {!isMobile && (
        <motion.aside
          variants={sidebarVariants}
          initial={sidebarCollapsed ? 'collapsed' : 'expanded'}
          animate={sidebarCollapsed ? 'collapsed' : 'expanded'}
          className={cn(
            "flex-shrink-0 border-r border-neutral-200 dark:border-neutral-800",
            "bg-white dark:bg-neutral-900",
            "flex flex-col overflow-hidden"
          )}
        >
          <Sidebar />
        </motion.aside>
      )}

      {/* Main Content */}
      <div className="flex flex-col flex-1 min-w-0">
        <TopBar />

        <div className="flex flex-1 min-h-0">
          {/* Chat Area */}
          <main className="flex-1 min-w-0 relative">
            <Outlet />
          </main>

          {/* Right Panel */}
          <AnimatePresence>
            {rightPanelOpen && !isMobile && !isTablet && (
              <motion.aside
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 320, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
                className="flex-shrink-0 border-l border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 overflow-hidden"
              >
                <RightPanel />
              </motion.aside>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Floating Command Palette */}
      <CommandPalette />

      {/* Toast Notifications */}
      <ToastContainer />
    </div>
  );
}
