// ============================================================
// Frox AI – Markdown Renderer
// ============================================================

import { useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { CodeBlock } from './CodeBlock';
import { MermaidDiagram } from './MermaidDiagram';
import { MathBlock } from './MathBlock';

interface MarkdownRendererProps {
  content: string;
  isStreaming?: boolean;
}

export function MarkdownRenderer({ content, isStreaming = false }: MarkdownRendererProps) {
  const components = useMemo(() => ({
    code({ node, inline, className, children, ...props }: any) {
      const match = /language-(\w+)/.exec(className || '');
      const language = match ? match[1] : '';
      const codeContent = String(children).replace(/
$/, '');

      // Check for mermaid diagrams
      if (language === 'mermaid') {
        return <MermaidDiagram content={codeContent} />;
      }

      if (inline) {
        return (
          <code className="bg-neutral-100 dark:bg-neutral-800 px-1.5 py-0.5 rounded text-sm font-mono" {...props}>
            {children}
          </code>
        );
      }

      return (
        <CodeBlock
          language={language || 'text'}
          code={codeContent}
        />
      );
    },
    table({ children }: any) {
      return (
        <div className="overflow-x-auto my-4">
          <table className="w-full border-collapse">
            {children}
          </table>
        </div>
      );
    },
    th({ children }: any) {
      return (
        <th className="border border-neutral-300 dark:border-neutral-700 px-3 py-2 bg-neutral-100 dark:bg-neutral-800 font-semibold text-left">
          {children}
        </th>
      );
    },
    td({ children }: any) {
      return (
        <td className="border border-neutral-300 dark:border-neutral-700 px-3 py-2">
          {children}
        </td>
      );
    },
    blockquote({ children }: any) {
      return (
        <blockquote className="border-l-4 border-primary-500 pl-4 italic text-neutral-600 dark:text-neutral-400 my-4">
          {children}
        </blockquote>
      );
    },
    a({ children, href }: any) {
      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary-600 dark:text-primary-400 hover:underline"
        >
          {children}
        </a>
      );
    },
    img({ src, alt }: any) {
      return (
        <img
          src={src}
          alt={alt}
          className="max-w-full rounded-lg my-4"
          loading="lazy"
        />
      );
    },
    hr() {
      return <hr className="my-6 border-neutral-300 dark:border-neutral-700" />;
    },
    ul({ children }: any) {
      return <ul className="list-disc pl-6 mb-4">{children}</ul>;
    },
    ol({ children }: any) {
      return <ol className="list-decimal pl-6 mb-4">{children}</ol>;
    },
    li({ children }: any) {
      return <li className="mb-1">{children}</li>;
    },
    h1({ children }: any) {
      return <h1 className="text-2xl font-bold mb-4 mt-6">{children}</h1>;
    },
    h2({ children }: any) {
      return <h2 className="text-xl font-bold mb-3 mt-5">{children}</h2>;
    },
    h3({ children }: any) {
      return <h3 className="text-lg font-semibold mb-2 mt-4">{children}</h3>;
    },
    p({ children }: any) {
      return <p className="mb-4 leading-relaxed">{children}</p>;
    },
  }), []);

  return (
    <div className="markdown-content">
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={components}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
