// ============================================================
// Frox AI – Math Block (KaTeX Wrapper)
// ============================================================

import { useEffect, useRef } from 'react';
import katex from 'katex';

interface MathBlockProps {
  content: string;
  display?: boolean;
}

export function MathBlock({ content, display = true }: MathBlockProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    try {
      katex.render(content, containerRef.current, {
        displayMode: display,
        throwOnError: false,
        strict: false,
      });
    } catch (err) {
      containerRef.current.textContent = content;
    }
  }, [content, display]);

  return (
    <div
      ref={containerRef}
      className={display ? 'my-4 overflow-x-auto' : 'inline'}
    />
  );
}
