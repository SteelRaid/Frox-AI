// ============================================================
// Frox AI – Code Block with Syntax Highlighting
// ============================================================

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Copy, Check, Download } from 'lucide-react';
import { copyToClipboard, downloadFile } from '../../utils/index';
import { cn } from '../../utils/index';

interface CodeBlockProps {
  language: string;
  code: string;
}

export function CodeBlock({ language, code }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const [highlighted, setHighlighted] = useState<string>('');

  useEffect(() => {
    // Simple syntax highlighting simulation
    // In production, use Shiki for proper highlighting
    setHighlighted(code);
  }, [code]);

  const handleCopy = async () => {
    const success = await copyToClipboard(code);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/plain' });
    downloadFile(blob, `code.${language || 'txt'}`);
  };

  return (
    <div className="relative group my-4 rounded-xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-neutral-900">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-neutral-800 border-b border-neutral-700">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-neutral-400 uppercase">
            {language || 'text'}
          </span>
        </div>
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 rounded text-xs text-neutral-400 hover:text-white hover:bg-neutral-700 transition-colors"
            title="Copy code"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1 px-2 py-1 rounded text-xs text-neutral-400 hover:text-white hover:bg-neutral-700 transition-colors"
            title="Download code"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Code */}
      <div className="overflow-x-auto p-4">
        <pre className="text-sm font-mono leading-relaxed">
          <code className={`language-${language}`}>
            {highlighted.split('
').map((line, i) => (
              <div key={i} className="table-row">
                <span className="table-cell text-right pr-4 text-neutral-600 select-none text-xs w-8">
                  {i + 1}
                </span>
                <span className="table-cell text-neutral-300 whitespace-pre">
                  {line || ' '}
                </span>
              </div>
            ))}
          </code>
        </pre>
      </div>
    </div>
  );
}
