// ============================================================
// Frox AI – Composer Toolbar
// ============================================================

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Thermometer, Hash, Globe, Brain, SlidersHorizontal,
  ChevronUp, ChevronDown
} from 'lucide-react';
import { useComposerStore } from '../../stores/index';
import { TEMPERATURE_RANGE, MAX_TOKENS_OPTIONS } from '../../constants/index';
import { cn } from '../../utils/index';

export function ComposerToolbar() {
  const [isExpanded, setIsExpanded] = useState(false);
  const temperature = useComposerStore(state => state.temperature);
  const setTemperature = useComposerStore(state => state.setTemperature);
  const maxTokens = useComposerStore(state => state.maxTokens);
  const setMaxTokens = useComposerStore(state => state.setMaxTokens);
  const useInternet = useComposerStore(state => state.useInternet);
  const toggleInternet = useComposerStore(state => state.toggleInternet);
  const useReasoning = useComposerStore(state => state.useReasoning);
  const toggleReasoning = useComposerStore(state => state.toggleReasoning);

  return (
    <div className="mt-2">
      {/* Quick Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 text-xs text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300 transition-colors"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Options</span>
            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>

          <button
            onClick={toggleInternet}
            className={cn(
              "flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors",
              useInternet
                ? "bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400"
                : "text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
            )}
          >
            <Globe className="w-3 h-3" />
            <span>Web</span>
          </button>

          <button
            onClick={toggleReasoning}
            className={cn(
              "flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors",
              useReasoning
                ? "bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400"
                : "text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
            )}
          >
            <Brain className="w-3 h-3" />
            <span>Reason</span>
          </button>
        </div>

        <div className="text-xs text-neutral-400 dark:text-neutral-500">
          Shift + Enter for new line
        </div>
      </div>

      {/* Expanded Options */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="pt-3 pb-1 space-y-3">
              {/* Temperature */}
              <div className="flex items-center gap-3">
                <Thermometer className="w-4 h-4 text-neutral-400 flex-shrink-0" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-neutral-500 dark:text-neutral-400">Temperature</span>
                    <span className="text-xs font-medium">{temperature}</span>
                  </div>
                  <input
                    type="range"
                    min={TEMPERATURE_RANGE.min}
                    max={TEMPERATURE_RANGE.max}
                    step={TEMPERATURE_RANGE.step}
                    value={temperature}
                    onChange={e => setTemperature(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-neutral-200 dark:bg-neutral-700 rounded-full appearance-none cursor-pointer accent-primary-500"
                  />
                </div>
              </div>

              {/* Max Tokens */}
              <div className="flex items-center gap-3">
                <Hash className="w-4 h-4 text-neutral-400 flex-shrink-0" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-neutral-500 dark:text-neutral-400">Max Tokens</span>
                    <span className="text-xs font-medium">{maxTokens.toLocaleString()}</span>
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    {MAX_TOKENS_OPTIONS.map(tokens => (
                      <button
                        key={tokens}
                        onClick={() => setMaxTokens(tokens)}
                        className={cn(
                          "px-2 py-0.5 rounded text-[10px] transition-colors",
                          maxTokens === tokens
                            ? "bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400"
                            : "bg-neutral-100 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-700"
                        )}
                      >
                        {(tokens / 1024).toFixed(tokens >= 1024 ? 0 : 1)}K
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
