// ============================================================
// Frox AI – Attachment Preview
// ============================================================

import { motion } from 'framer-motion';
import { X, File, Image, Loader2, AlertCircle } from 'lucide-react';
import type { Attachment } from '../../types/index';
import { useAttachmentStore } from '../../stores/index';
import { cn } from '../../utils/index';

interface AttachmentPreviewProps {
  attachment: Attachment;
}

export function AttachmentPreview({ attachment }: AttachmentPreviewProps) {
  const removeAttachment = useAttachmentStore(state => state.removeAttachment);
  const isImage = attachment.mimeType.startsWith('image/');

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className={cn(
        "relative group flex items-center gap-2 px-3 py-2 rounded-lg border",
        attachment.status === 'error'
          ? "border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20"
          : "border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900"
      )}
    >
      {isImage && attachment.previewUrl ? (
        <img
          src={attachment.previewUrl}
          alt={attachment.name}
          className="w-10 h-10 rounded object-cover"
        />
      ) : (
        <div className="w-10 h-10 rounded bg-neutral-200 dark:bg-neutral-800 flex items-center justify-center">
          {attachment.status === 'uploading' ? (
            <Loader2 className="w-4 h-4 animate-spin text-neutral-400" />
          ) : attachment.status === 'error' ? (
            <AlertCircle className="w-4 h-4 text-red-500" />
          ) : isImage ? (
            <Image className="w-4 h-4 text-neutral-400" />
          ) : (
            <File className="w-4 h-4 text-neutral-400" />
          )}
        </div>
      )}

      <div className="flex-1 min-w-0">
        <div className="text-xs font-medium truncate max-w-[120px]">
          {attachment.name}
        </div>
        {attachment.status === 'uploading' && attachment.uploadProgress !== undefined && (
          <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-1 mt-1">
            <div
              className="bg-primary-500 h-1 rounded-full transition-all"
              style={{ width: `${attachment.uploadProgress}%` }}
            />
          </div>
        )}
        <div className="text-[10px] text-neutral-400">
          {(attachment.size / 1024).toFixed(1)} KB
        </div>
      </div>

      <button
        onClick={() => removeAttachment(attachment.id)}
        className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
        aria-label={`Remove ${attachment.name}`}
      >
        <X className="w-3 h-3" />
      </button>
    </motion.div>
  );
}
