// ============================================================
// Frox AI – Composer (Main Input Area)
// ============================================================

import { useRef, useCallback, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Square, Paperclip, Mic } from 'lucide-react';
import { useComposerStore, useAttachmentStore } from '../../stores/index';
import { useFileDrop, useIsMobile } from '../../hooks/index';
import { ComposerInput } from './ComposerInput';
import { AttachmentPreview } from './AttachmentPreview';
import { ModelSelector } from './ModelSelector';
import { ComposerToolbar } from './ComposerToolbar';
import { cn } from '../../utils/index';

interface ComposerProps {
  onSend: (content: string, attachments: any[]) => void;
  isGenerating: boolean;
  placeholder?: string;
  conversationId?: string;
}

export function Composer({ onSend, isGenerating, placeholder = "Message Frox AI...", conversationId }: ComposerProps) {
  const text = useComposerStore(state => state.text);
  const attachments = useComposerStore(state => state.attachments);
  const setText = useComposerStore(state => state.setText);
  const clearText = useComposerStore(state => state.clearText);
  const clearAttachments = useComposerStore(state => state.clearAttachments);
  const isFocused = useComposerStore(state => state.isFocused);
  const setFocused = useComposerStore(state => state.setFocused);
  const isRecording = useComposerStore(state => state.isRecording);
  const setRecording = useComposerStore(state => state.setRecording);
  const selectedModel = useComposerStore(state => state.selectedModel);
  const isMobile = useIsMobile();

  const { isDragging, dragHandlers } = useFileDrop();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = useCallback(() => {
    if (!text.trim() && attachments.length === 0) return;
    onSend(text.trim(), attachments);
    clearText();
    clearAttachments();
  }, [text, attachments, onSend, clearText, clearAttachments]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      useAttachmentStore.getState().addAttachment(file);
    });
    e.target.value = '';
  }, []);

  const handlePaste = useCallback((e: React.ClipboardEvent) => {
    const items = Array.from(e.clipboardData.items);
    items.forEach(item => {
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile();
        if (file) {
          useAttachmentStore.getState().addAttachment(file);
        }
      }
    });
  }, []);

  return (
    <div
      className={cn(
        "border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-3",
        isDragging && "bg-primary-50 dark:bg-primary-900/10"
      )}
      {...dragHandlers}
    >
      {/* Drag Overlay */}
      <AnimatePresence>
        {isDragging && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-primary-500/10 border-2 border-dashed border-primary-500 rounded-xl flex items-center justify-center z-10 pointer-events-none"
          >
            <span className="text-primary-600 dark:text-primary-400 font-medium">
              Drop files here
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-3xl mx-auto">
        {/* Attachment Previews */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {attachments.map(attachment => (
              <AttachmentPreview key={attachment.id} attachment={attachment} />
            ))}
          </div>
        )}

        {/* Input Area */}
        <div
          className={cn(
            "relative flex items-end gap-2 rounded-2xl border transition-all",
            isFocused
              ? "border-primary-500 ring-2 ring-primary-500/20 bg-white dark:bg-neutral-900"
              : "border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900"
          )}
        >
          {/* Attach Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex-shrink-0 p-3 rounded-xl text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Attach file"
          >
            <Paperclip className="w-5 h-5" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            accept="image/*,.pdf,.doc,.docx,.txt,.md,.json,.js,.ts,.tsx,.py,.html,.css"
          />

          {/* Text Input */}
          <ComposerInput
            value={text}
            onChange={setText}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder={placeholder}
            disabled={isGenerating}
          />

          {/* Voice / Send Button */}
          <div className="flex-shrink-0 p-2">
            {isGenerating ? (
              <button
                onClick={() => {}}
                className="p-2 rounded-xl bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors"
                aria-label="Stop generation"
              >
                <Square className="w-5 h-5" />
              </button>
            ) : text.trim() || attachments.length > 0 ? (
              <button
                onClick={handleSend}
                className="p-2 rounded-xl bg-primary-600 text-white hover:bg-primary-700 transition-colors"
                aria-label="Send message"
              >
                <Send className="w-5 h-5" />
              </button>
            ) : (
              <button
                onClick={() => setRecording(!isRecording)}
                className={cn(
                  "p-2 rounded-xl transition-colors",
                  isRecording
                    ? "bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400"
                    : "text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                )}
                aria-label="Voice input"
              >
                <Mic className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Toolbar */}
        <ComposerToolbar />
      </div>
    </div>
  );
}
