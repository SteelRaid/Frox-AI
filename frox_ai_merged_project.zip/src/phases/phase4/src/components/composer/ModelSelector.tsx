// ============================================================
// Frox AI – Model Selector
// ============================================================

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Cpu, Check, Sparkles, Globe, Brain } from 'lucide-react';
import { useComposerStore } from '../../stores/index';
import { useClickOutside } from '../../hooks/index';
import { MODELS } from '../../constants/index';
import { cn } from '../../utils/index';

export function ModelSelector() {
  const [isOpen, setIsOpen] = useState(false);
  const selectedModel = useComposerStore(state => state.selectedModel);
  const setModel = useComposerStore(state => state.setModel);
  const ref = useRef<HTMLDivElement>(null);

  useClickOutside(ref, () => setIsOpen(false));

  const getModelIcon = (modelId: string) => {
    if (modelId.includes('reasoning')) return Brain;
    if (modelId.includes('mini')) return Cpu;
    if (modelId.includes('claude')) return Sparkles;
    return Globe;
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm",
          "border border-neutral-200 dark:border-neutral-800",
          "hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
        )}
      >
        {(() => {
          const Icon = getModelIcon(selectedModel.id);
          return <Icon className="w-4 h-4 text-primary-500" />;
        })()}
        <span className="font-medium">{selectedModel.name}</span>
        <ChevronDown className={cn("w-3.5 h-3.5 transition-transform", isOpen && "rotate-180")} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 4, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.97 }}
            className="absolute bottom-full left-0 mb-2 w-72 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-xl z-50 py-2"
          >
            {MODELS.map(model => {
              const Icon = getModelIcon(model.id);
              const isSelected = model.id === selectedModel.id;

              return (
                <button
                  key={model.id}
                  onClick={() => { setModel(model); setIsOpen(false); }}
                  className={cn(
                    "w-full flex items-start gap-3 px-4 py-3 text-left transition-colors",
                    isSelected
                      ? "bg-primary-50 dark:bg-primary-900/20"
                      : "hover:bg-neutral-100 dark:hover:bg-neutral-800"
                  )}
                >
                  <Icon className={cn(
                    "w-5 h-5 mt-0.5 flex-shrink-0",
                    isSelected ? "text-primary-500" : "text-neutral-400"
                  )} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={cn(
                        "text-sm font-medium",
                        isSelected && "text-primary-700 dark:text-primary-300"
                      )}>
                        {model.name}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-primary-500" />}
                    </div>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                      {model.description}
                    </p>
                    <div className="flex items-center gap-2 mt-1.5">
                      {model.supportsVision && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400">
                          Vision
                        </span>
                      )}
                      {model.supportsReasoning && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400">
                          Reasoning
                        </span>
                      )}
                      <span className="text-[10px] text-neutral-400">
                        {model.contextWindow.toLocaleString()} context
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
