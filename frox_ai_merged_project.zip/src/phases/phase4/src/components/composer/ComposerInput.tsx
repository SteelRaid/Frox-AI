// ============================================================
// Frox AI – Composer Input (Auto-growing Textarea)
// ============================================================

import { useRef, useEffect, forwardRef } from 'react';
import { cn } from '../../utils/index';

interface ComposerInputProps {
  value: string;
  onChange: (value: string) => void;
  onKeyDown?: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
  onPaste?: (e: React.ClipboardEvent<HTMLTextAreaElement>) => void;
  onFocus?: () => void;
  onBlur?: () => void;
  placeholder?: string;
  disabled?: boolean;
}

export const ComposerInput = forwardRef<HTMLTextAreaElement, ComposerInputProps>(
  ({ value, onChange, onKeyDown, onPaste, onFocus, onBlur, placeholder, disabled }, ref) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // Auto-resize
    useEffect(() => {
      const textarea = textareaRef.current;
      if (!textarea) return;
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`;
    }, [value]);

    return (
      <textarea
        ref={(node) => {
          textareaRef.current = node;
          if (typeof ref === 'function') ref(node);
          else if (ref) ref.current = node;
        }}
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={onKeyDown}
        onPaste={onPaste}
        onFocus={onFocus}
        onBlur={onBlur}
        placeholder={placeholder}
        disabled={disabled}
        rows={1}
        className={cn(
          "flex-1 w-full py-3 px-1 bg-transparent resize-none outline-none",
          "text-sm text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400",
          "max-h-[200px] min-h-[44px]"
        )}
        aria-label="Message input"
      />
    );
  }
);

ComposerInput.displayName = 'ComposerInput';
