// ============================================================
// Frox AI – Right Information Panel
// ============================================================

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Info, FileText, Settings, Clock, Hash,
  Cpu, Thermometer, Globe, Brain
} from 'lucide-react';
import { useConversationStore, useMessageStore } from '../../stores/index';
import { useLayoutStore } from '../../stores/layoutStore';
import { formatDate, estimateTokens } from '../../utils/index';
import { cn } from '../../utils/index';

export function RightPanel() {
  const rightPanelTab = useLayoutStore(state => state.rightPanelTab);
  const setRightPanelTab = useLayoutStore(state => state.setRightPanelTab);
  const activeConversationId = useConversationStore(state => state.activeConversationId);
  const conversation = useConversationStore(state =>
    activeConversationId ? state.getConversationById(activeConversationId) : null
  );
  const messages = useMessageStore(state =>
    activeConversationId ? state.getMessagesByConversation(activeConversationId) : []
  );
  const contextTokens = useMessageStore(state =>
    activeConversationId ? state.estimateContextTokens(activeConversationId) : 0
  );

  const tabs = [
    { id: 'info', label: 'Info', icon: Info },
    { id: 'files', label: 'Files', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  if (!conversation) {
    return (
      <div className="w-80 h-full flex items-center justify-center text-neutral-500 dark:text-neutral-400 text-sm">
        Select a conversation to see details
      </div>
    );
  }

  return (
    <div className="w-80 h-full flex flex-col bg-white dark:bg-neutral-900">
      {/* Tabs */}
      <div className="flex border-b border-neutral-200 dark:border-neutral-800">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setRightPanelTab(tab.id)}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium transition-colors relative",
              rightPanelTab === tab.id
                ? "text-primary-600 dark:text-primary-400"
                : "text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300"
            )}
          >
            <tab.icon className="w-4 h-4" />
            <span className="hidden lg:inline">{tab.label}</span>
            {rightPanelTab === tab.id && (
              <motion.div
                layoutId="right-panel-tab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500"
              />
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {rightPanelTab === 'info' && (
          <>
            <section>
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Info className="w-4 h-4" />
                Conversation Info
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-500 dark:text-neutral-400">Created</span>
                  <span>{formatDate(conversation.createdAt, false)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 dark:text-neutral-400">Updated</span>
                  <span>{formatDate(conversation.updatedAt, false)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 dark:text-neutral-400">Messages</span>
                  <span>{messages.length}</span>
                </div>
              </div>
            </section>

            <section>
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Hash className="w-4 h-4" />
                Token Usage
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-500 dark:text-neutral-400">Context</span>
                  <span>{contextTokens.toLocaleString()} tokens</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 dark:text-neutral-400">Total Used</span>
                  <span>{conversation.tokenCount.toLocaleString()} tokens</span>
                </div>
                <div className="w-full bg-neutral-200 dark:bg-neutral-800 rounded-full h-2 mt-2">
                  <div
                    className="bg-primary-500 h-2 rounded-full transition-all"
                    style={{ width: `${Math.min((contextTokens / conversation.model.contextWindow) * 100, 100)}%` }}
                  />
                </div>
              </div>
            </section>

            {conversation.summary && (
              <section>
                <h3 className="text-sm font-semibold mb-2">Summary</h3>
                <p className="text-sm text-neutral-600 dark:text-neutral-400 leading-relaxed">
                  {conversation.summary}
                </p>
              </section>
            )}
          </>
        )}

        {rightPanelTab === 'files' && (
          <div className="text-sm text-neutral-500 dark:text-neutral-400 text-center py-8">
            No files attached to this conversation
          </div>
        )}

        {rightPanelTab === 'settings' && (
          <>
            <section>
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Cpu className="w-4 h-4" />
                Model
              </h3>
              <div className="text-sm">{conversation.model.name}</div>
            </section>

            <section>
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Thermometer className="w-4 h-4" />
                Temperature
              </h3>
              <div className="text-sm">{conversation.temperature}</div>
            </section>

            <section>
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Globe className="w-4 h-4" />
                Internet
              </h3>
              <div className="text-sm">{conversation.useInternet ? 'Enabled' : 'Disabled'}</div>
            </section>

            <section>
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Brain className="w-4 h-4" />
                Reasoning
              </h3>
              <div className="text-sm">{conversation.useReasoning ? 'Enabled' : 'Disabled'}</div>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
