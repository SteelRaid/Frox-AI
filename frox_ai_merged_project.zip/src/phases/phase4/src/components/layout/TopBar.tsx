// ============================================================
// Frox AI – Top Navigation Bar
// ============================================================

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu, PanelRight, Search, Settings, Bell,
  Moon, Sun, Command, ChevronDown
} from 'lucide-react';
import { useLayoutStore, useThemeStore, useSettingsStore, useConversationStore } from '../../stores/index';
import { useIsMobile } from '../../hooks/index';
import { cn } from '../../utils/index';

export function TopBar() {
  const isMobile = useIsMobile();
  const toggleSidebar = useLayoutStore(state => state.toggleSidebar);
  const toggleRightPanel = useLayoutStore(state => state.toggleRightPanel);
  const rightPanelOpen = useLayoutStore(state => state.rightPanelOpen);
  const toggleMode = useThemeStore(state => state.toggleMode);
  const effectiveMode = useThemeStore(state => state.getEffectiveMode());
  const openSettings = useSettingsStore(state => state.openSettings);
  const activeConversation = useConversationStore(state =>
    state.activeConversationId ? state.getConversationById(state.activeConversationId) : null
  );
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <header className="h-14 border-b border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-md flex items-center justify-between px-4 flex-shrink-0 z-20">
      <div className="flex items-center gap-3">
        {isMobile && (
          <button
            onClick={toggleSidebar}
            className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        {activeConversation && (
          <div className="flex items-center gap-2">
            <h1 className="font-medium text-sm truncate max-w-[200px] sm:max-w-[300px] lg:max-w-[400px]">
              {activeConversation.title}
            </h1>
            <span className="text-xs text-neutral-500 dark:text-neutral-400 hidden sm:inline">
              {activeConversation.model.name}
            </span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={() => document.dispatchEvent(new CustomEvent('open-command-palette'))}
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 text-sm hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
        >
          <Search className="w-4 h-4" />
          <span>Search</span>
          <kbd className="hidden lg:inline-flex items-center gap-0.5 text-xs bg-white dark:bg-neutral-700 px-1.5 py-0.5 rounded border border-neutral-300 dark:border-neutral-600">
            <Command className="w-3 h-3" />
            <span>K</span>
          </kbd>
        </button>

        <button
          onClick={toggleMode}
          className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          aria-label="Toggle theme"
        >
          {effectiveMode === 'dark' ? (
            <Sun className="w-5 h-5" />
          ) : (
            <Moon className="w-5 h-5" />
          )}
        </button>

        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors relative"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
          </button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.97 }}
                className="absolute right-0 top-full mt-2 w-80 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-xl z-50 p-4"
              >
                <h3 className="font-semibold mb-3">Notifications</h3>
                <div className="text-sm text-neutral-500 dark:text-neutral-400 text-center py-4">
                  No new notifications
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <button
          onClick={() => openSettings()}
          className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          aria-label="Settings"
        >
          <Settings className="w-5 h-5" />
        </button>

        {!isMobile && (
          <button
            onClick={toggleRightPanel}
            className={cn(
              "p-2 rounded-lg transition-colors",
              rightPanelOpen
                ? "bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400"
                : "hover:bg-neutral-100 dark:hover:bg-neutral-800"
            )}
            aria-label="Toggle right panel"
          >
            <PanelRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </header>
  );
}
