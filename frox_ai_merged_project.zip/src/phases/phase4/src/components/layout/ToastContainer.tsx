// ============================================================
// Frox AI – Toast Notification Container
// ============================================================

import { AnimatePresence } from 'framer-motion';
import { motion } from 'framer-motion';
import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from 'lucide-react';
import { useNotificationStore } from '../../stores/index';
import { cn } from '../../utils/index';
import { toastVariants } from '../../animations/index';

const iconMap = {
  info: Info,
  success: CheckCircle,
  warning: AlertTriangle,
  error: AlertCircle,
};

const colorMap = {
  info: 'bg-blue-500/10 border-blue-500/20 text-blue-600 dark:text-blue-400',
  success: 'bg-green-500/10 border-green-500/20 text-green-600 dark:text-green-400',
  warning: 'bg-amber-500/10 border-amber-500/20 text-amber-600 dark:text-amber-400',
  error: 'bg-red-500/10 border-red-500/20 text-red-600 dark:text-red-400',
};

export function ToastContainer() {
  const notifications = useNotificationStore(state => state.notifications);
  const removeNotification = useNotificationStore(state => state.removeNotification);

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      <AnimatePresence mode="popLayout">
        {notifications.map(notification => {
          const Icon = iconMap[notification.type];
          const colors = colorMap[notification.type];

          return (
            <motion.div
              key={notification.id}
              variants={toastVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              layout
              className={cn(
                "pointer-events-auto flex items-start gap-3 p-4 rounded-xl border shadow-lg",
                "bg-white dark:bg-neutral-900",
                colors
              )}
            >
              <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-sm text-neutral-900 dark:text-neutral-100">
                  {notification.title}
                </h4>
                {notification.message && (
                  <p className="text-sm text-neutral-600 dark:text-neutral-400 mt-0.5">
                    {notification.message}
                  </p>
                )}
              </div>
              <button
                onClick={() => removeNotification(notification.id)}
                className="flex-shrink-0 p-1 rounded hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                aria-label="Dismiss notification"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
