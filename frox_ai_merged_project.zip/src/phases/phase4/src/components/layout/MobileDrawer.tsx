// ============================================================
// Frox AI – Mobile Drawer
// ============================================================

import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useLayoutStore } from '../../stores/index';
import { Sidebar } from '../sidebar/Sidebar';
import { useClickOutside } from '../../hooks/index';
import { useRef } from 'react';

export function MobileDrawer() {
  const mobileDrawerOpen = useLayoutStore(state => state.mobileDrawerOpen);
  const setMobileDrawerOpen = useLayoutStore(state => state.setMobileDrawerOpen);
  const drawerRef = useRef<HTMLDivElement>(null);

  useClickOutside(drawerRef, () => {
    if (mobileDrawerOpen) setMobileDrawerOpen(false);
  });

  return (
    <AnimatePresence>
      {mobileDrawerOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setMobileDrawerOpen(false)}
          />

          {/* Drawer */}
          <motion.div
            ref={drawerRef}
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed left-0 top-0 bottom-0 w-[280px] z-50 bg-white dark:bg-neutral-900 shadow-2xl lg:hidden flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
              <h2 className="font-semibold">Frox AI</h2>
              <button
                onClick={() => setMobileDrawerOpen(false)}
                className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                aria-label="Close drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <Sidebar isMobile />
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
