// ============================================================
// Frox AI – Command Palette
// ============================================================

import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, MessageSquare, Folder, Settings, FileText, Hash } from 'lucide-react';
import { useLayoutStore, useConversationStore, useSettingsStore } from '../../stores/index';
import { useDebounce } from '../../hooks/index';
import { cn } from '../../utils/index';
import { modalOverlay, modalContent } from '../../animations/index';
import { useNavigate } from 'react-router-dom';

interface CommandItem {
  id: string;
  title: string;
  subtitle?: string;
  icon: React.ElementType;
  action: () => void;
  category: string;
}

export function CommandPalette() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const conversations = useConversationStore(state => state.conversations);
  const setActiveConversation = useConversationStore(state => state.setActiveConversation);
  const createConversation = useConversationStore(state => state.createConversation);
  const openSettings = useSettingsStore(state => state.openSettings);
  const debouncedQuery = useDebounce(query, 150);

  useEffect(() => {
    const handleOpen = () => setIsOpen(true);
    document.addEventListener('open-command-palette', handleOpen);
    return () => document.removeEventListener('open-command-palette', handleOpen);
  }, []);

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus();
      setSelectedIndex(0);
    }
  }, [isOpen]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [debouncedQuery]);

  const commands: CommandItem[] = [
    {
      id: 'new-chat',
      title: 'New Chat',
      subtitle: 'Start a new conversation',
      icon: MessageSquare,
      action: () => {
        const conv = createConversation('default');
        navigate(`/chat/${conv.id}`);
        setIsOpen(false);
      },
      category: 'Actions',
    },
    {
      id: 'settings',
      title: 'Open Settings',
      subtitle: 'Configure preferences',
      icon: Settings,
      action: () => {
        openSettings();
        setIsOpen(false);
      },
      category: 'Actions',
    },
    ...conversations.slice(0, 10).map(conv => ({
      id: conv.id,
      title: conv.title,
      subtitle: 'Conversation',
      icon: MessageSquare,
      action: () => {
        setActiveConversation(conv.id);
        navigate(`/chat/${conv.id}`);
        setIsOpen(false);
      },
      category: 'Conversations',
    })),
  ];

  const filteredCommands = debouncedQuery
    ? commands.filter(c =>
        c.title.toLowerCase().includes(debouncedQuery.toLowerCase()) ||
        c.subtitle?.toLowerCase().includes(debouncedQuery.toLowerCase())
      )
    : commands;

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setIsOpen(false);
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(i => (i + 1) % filteredCommands.length);
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(i => (i - 1 + filteredCommands.length) % filteredCommands.length);
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      filteredCommands[selectedIndex]?.action();
    }
  }, [filteredCommands, selectedIndex]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          variants={modalOverlay}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="fixed inset-0 z-50 flex items-start justify-center pt-[20vh] bg-black/50 backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        >
          <motion.div
            variants={modalContent}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="w-full max-w-2xl mx-4 bg-white dark:bg-neutral-900 rounded-xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden"
            onClick={e => e.stopPropagation()}
            onKeyDown={handleKeyDown}
          >
            {/* Search Input */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-neutral-200 dark:border-neutral-800">
              <Search className="w-5 h-5 text-neutral-400" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search conversations, commands..."
                className="flex-1 bg-transparent outline-none text-base placeholder:text-neutral-400"
                aria-label="Command palette search"
              />
              <kbd className="hidden sm:inline-flex items-center gap-0.5 text-xs bg-neutral-100 dark:bg-neutral-800 px-2 py-1 rounded border border-neutral-300 dark:border-neutral-700 text-neutral-500">
                ESC
              </kbd>
            </div>

            {/* Results */}
            <div className="max-h-[50vh] overflow-y-auto py-2">
              {filteredCommands.length === 0 ? (
                <div className="px-4 py-8 text-center text-neutral-500 dark:text-neutral-400 text-sm">
                  No results found
                </div>
              ) : (
                filteredCommands.map((command, index) => (
                  <button
                    key={command.id}
                    onClick={command.action}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors",
                      index === selectedIndex
                        ? "bg-primary-50 dark:bg-primary-900/20"
                        : "hover:bg-neutral-100 dark:hover:bg-neutral-800"
                    )}
                  >
                    <command.icon className="w-4 h-4 text-neutral-500 dark:text-neutral-400 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{command.title}</div>
                      {command.subtitle && (
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">{command.subtitle}</div>
                      )}
                    </div>
                    <span className="text-xs text-neutral-400 dark:text-neutral-500 flex-shrink-0">
                      {command.category}
                    </span>
                  </button>
                ))
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
