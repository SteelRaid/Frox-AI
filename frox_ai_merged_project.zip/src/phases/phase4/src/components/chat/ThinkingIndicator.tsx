// ============================================================
// Frox AI – Thinking Indicator
// ============================================================

import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';
import { typingIndicator } from '../../animations/index';

export function ThinkingIndicator() {
  return (
    <div className="flex items-start gap-3 px-4 py-6 max-w-3xl mx-auto">
      <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center flex-shrink-0">
        <Brain className="w-4 h-4 text-white" />
      </div>
      <div className="flex items-center gap-1 pt-2">
        <motion.span
          variants={typingIndicator}
          animate="animate"
          className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500"
        />
        <motion.span
          variants={typingIndicator}
          animate="animate"
          transition={{ delay: 0.15 }}
          className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500"
        />
        <motion.span
          variants={typingIndicator}
          animate="animate"
          transition={{ delay: 0.3 }}
          className="w-2 h-2 rounded-full bg-neutral-400 dark:bg-neutral-500"
        />
      </div>
    </div>
  );
}
