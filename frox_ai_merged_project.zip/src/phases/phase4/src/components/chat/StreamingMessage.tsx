// ============================================================
// Frox AI – Streaming Message
// ============================================================

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { MarkdownRenderer } from '../markdown/MarkdownRenderer';
import { copyToClipboard } from '../../utils/index';
import { cn } from '../../utils/index';
import { thinkingExpand } from '../../animations/index';

interface StreamingMessageProps {
  content: string;
  thinkingContent?: string;
}

export function StreamingMessage({ content, thinkingContent }: StreamingMessageProps) {
  const [showThinking, setShowThinking] = useState(true);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const success = await copyToClipboard(content);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex items-start gap-3 px-4 py-6 max-w-3xl mx-auto group">
      {/* Avatar */}
      <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center flex-shrink-0 mt-1">
        <Brain className="w-4 h-4 text-white" />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        {/* Thinking section */}
        {thinkingContent && (
          <div className="mb-3">
            <button
              onClick={() => setShowThinking(!showThinking)}
              className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300 transition-colors mb-2"
            >
              {showThinking ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              <span>Thinking</span>
            </button>
            <AnimatePresence>
              {showThinking && (
                <motion.div
                  variants={thinkingExpand}
                  initial="hidden"
                  animate="visible"
                  exit="exit"
                  className="overflow-hidden"
                >
                  <div className="text-sm text-neutral-500 dark:text-neutral-400 bg-neutral-50 dark:bg-neutral-900/50 rounded-lg p-3 border border-neutral-200 dark:border-neutral-800">
                    <MarkdownRenderer content={thinkingContent} />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* Main content */}
        <div className="prose dark:prose-invert max-w-none">
          <MarkdownRenderer content={content} isStreaming />
          <span className="inline-block w-2 h-4 bg-primary-500 animate-pulse ml-0.5 align-middle" />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 rounded text-xs text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
    </div>
  );
}
