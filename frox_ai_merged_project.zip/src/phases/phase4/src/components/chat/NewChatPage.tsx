// ============================================================
// Frox AI – New Chat Page (Empty State with Composer)
// ============================================================

import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sparkles, Zap, Brain, Globe, Code, Image, FileText, MessageSquare } from 'lucide-react';
import { useConversationStore } from '../../stores/index';
import { Composer } from '../composer/Composer';
import { pageTransition } from '../../animations/index';

const suggestions = [
  { icon: Code, text: "Write a TypeScript function to parse JSON", color: "text-blue-500" },
  { icon: Brain, text: "Explain quantum computing in simple terms", color: "text-purple-500" },
  { icon: Globe, text: "Summarize the latest AI research trends", color: "text-green-500" },
  { icon: Image, text: "Generate a creative story about space exploration", color: "text-amber-500" },
  { icon: FileText, text: "Help me write a professional email", color: "text-rose-500" },
  { icon: Zap, text: "Debug this React component issue", color: "text-cyan-500" },
];

export function NewChatPage() {
  const navigate = useNavigate();
  const createConversation = useConversationStore(state => state.createConversation);

  const handleSend = async (content: string) => {
    const conv = createConversation('default', content);
    navigate(`/chat/${conv.id}`);
  };

  return (
    <motion.div
      variants={pageTransition}
      initial="hidden"
      animate="visible"
      exit="exit"
      className="flex flex-col h-full"
    >
      {/* Empty State */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 overflow-y-auto">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-primary-600/25">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold mb-2">How can I help you today?</h1>
          <p className="text-neutral-500 dark:text-neutral-400 max-w-md">
            Start a new conversation or try one of the suggestions below.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl w-full px-4">
          {suggestions.map((suggestion, index) => (
            <motion.button
              key={index}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => handleSend(suggestion.text)}
              className="flex items-center gap-3 p-4 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 hover:border-primary-300 dark:hover:border-primary-700 hover:shadow-md transition-all text-left group"
            >
              <suggestion.icon className={`w-5 h-5 ${suggestion.color} flex-shrink-0`} />
              <span className="text-sm text-neutral-700 dark:text-neutral-300 group-hover:text-neutral-900 dark:group-hover:text-neutral-100">
                {suggestion.text}
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Composer */}
      <Composer
        onSend={handleSend}
        isGenerating={false}
        placeholder="Message Frox AI..."
      />
    </motion.div>
  );
}
