// ============================================================
// Frox AI – Chat Page
// ============================================================

import { useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useConversationStore, useMessageStore } from '../../stores/index';
import { useChat } from '../../hooks/index';
import { MessageList } from './MessageList';
import { Composer } from '../composer/Composer';
import { EmptyState } from './EmptyState';
import { pageTransition } from '../../animations/index';

export function ChatPage() {
  const { conversationId } = useParams<{ conversationId: string }>();
  const navigate = useNavigate();
  const setActiveConversation = useConversationStore(state => state.setActiveConversation);
  const conversation = useConversationStore(state =>
    conversationId ? state.getConversationById(conversationId) : null
  );

  const { messages, sendMessage, isGenerating } = useChat(conversationId || '');

  useEffect(() => {
    if (conversationId) {
      setActiveConversation(conversationId);
    }
  }, [conversationId, setActiveConversation]);

  // Redirect if conversation doesn't exist
  useEffect(() => {
    if (conversationId && !conversation) {
      navigate('/chat-engine/chat');
    }
  }, [conversationId, conversation, navigate]);

  if (!conversation) {
    return <EmptyState />;
  }

  return (
    <motion.div
      variants={pageTransition}
      initial="hidden"
      animate="visible"
      exit="exit"
      className="flex flex-col h-full"
    >
      {/* Messages */}
      <div className="flex-1 min-h-0">
        <MessageList
          messages={messages}
          conversationId={conversationId}
          isGenerating={isGenerating}
        />
      </div>

      {/* Composer */}
      <Composer
        onSend={sendMessage}
        isGenerating={isGenerating}
        conversationId={conversationId}
      />
    </motion.div>
  );
}
