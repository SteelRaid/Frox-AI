// ============================================================
// Frox AI – Message List (Virtualized)
// ============================================================

import { useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Virtuoso } from 'react-virtuoso';
import type { Message } from '../../types/index';
import { useMessageStore } from '../../stores/index';
import { useScrollToBottom, useIsMobile } from '../../hooks/index';
import { MessageItem } from './MessageItem';
import { StreamingMessage } from './StreamingMessage';
import { ThinkingIndicator } from './ThinkingIndicator';
import { ScrollToBottom } from './ScrollToBottom';
import { EmptyState } from './EmptyState';

interface MessageListProps {
  messages: Message[];
  conversationId: string | undefined;
  isGenerating: boolean;
}

export function MessageList({ messages, conversationId, isGenerating }: MessageListProps) {
  const { containerRef, scrollToBottom, showScrollButton, enableAutoScroll } = useScrollToBottom<HTMLDivElement>();
  const streamingContent = useMessageStore(state =>
    conversationId ? state.streamingMessages.get(conversationId) || '' : ''
  );
  const thinkingContent = useMessageStore(state =>
    conversationId ? state.thinkingMessages.get(conversationId) || '' : ''
  );
  const virtuosoRef = useRef<any>(null);
  const isMobile = useIsMobile();

  // Auto-scroll when new messages arrive or streaming
  useEffect(() => {
    if (messages.length > 0 || streamingContent) {
      const timer = setTimeout(() => {
        virtuosoRef.current?.scrollToIndex({
          index: messages.length + (streamingContent ? 1 : 0) - 1,
          behavior: 'smooth',
          align: 'end',
        });
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [messages.length, streamingContent]);

  const handleScroll = useCallback(() => {
    // Custom scroll handling if needed
  }, []);

  if (messages.length === 0 && !streamingContent) {
    return <EmptyState />;
  }

  const allItems = [
    ...messages.map((msg, index) => ({ type: 'message' as const, data: msg, index })),
    ...(streamingContent ? [{ type: 'streaming' as const, data: streamingContent, index: messages.length }] : []),
  ];

  return (
    <div ref={containerRef} className="h-full relative">
      <Virtuoso
        ref={virtuosoRef}
        data={allItems}
        followOutput="smooth"
        alignToBottom
        className="h-full"
        itemContent={(_, item) => {
          if (item.type === 'message') {
            return (
              <MessageItem
                message={item.data}
                isLast={item.index === messages.length - 1 && !streamingContent}
              />
            );
          }
          return (
            <StreamingMessage
              content={item.data}
              thinkingContent={thinkingContent}
            />
          );
        }}
        components={{
          Header: () => <div className="h-4" />,
          Footer: () => (
            <AnimatePresence>
              {isGenerating && !streamingContent && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <ThinkingIndicator />
                </motion.div>
              )}
            </AnimatePresence>
          ),
        }}
      />

      <ScrollToBottom
        visible={showScrollButton}
        onClick={enableAutoScroll}
      />
    </div>
  );
}
