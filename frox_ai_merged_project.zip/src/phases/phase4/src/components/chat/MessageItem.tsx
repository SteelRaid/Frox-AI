// ============================================================
// Frox AI – Message Item
// ============================================================

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Brain, Copy, Check, RotateCcw, Pencil, Trash2,
  ChevronDown, ChevronUp, ThumbsUp, ThumbsDown, Clock
} from 'lucide-react';
import type { Message } from '../../types/index';
import { useMessageStore, useSettingsStore } from '../../stores/index';
import { MarkdownRenderer } from '../markdown/MarkdownRenderer';
import { copyToClipboard, formatDate } from '../../utils/index';
import { cn } from '../../utils/index';
import { messageVariants } from '../../animations/index';

interface MessageItemProps {
  message: Message;
  isLast: boolean;
}

export function MessageItem({ message, isLast }: MessageItemProps) {
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);
  const [showActions, setShowActions] = useState(false);
  const showTimestamps = useSettingsStore(state => state.appearance.showTimestamps);
  const showTokenCount = useSettingsStore(state => state.appearance.showTokenCount);
  const deleteMessage = useMessageStore(state => state.deleteMessage);
  const editMessage = useMessageStore(state => state.editMessage);
  const regenerateMessage = useMessageStore(state => state.regenerateMessage);
  const isUser = message.role === 'user';
  const isError = message.isError;

  const handleCopy = async () => {
    const success = await copyToClipboard(message.content);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleEdit = () => {
    if (isEditing) {
      if (editContent.trim() && editContent !== message.content) {
        editMessage(message.id, editContent.trim());
      }
      setIsEditing(false);
    } else {
      setIsEditing(true);
      setEditContent(message.content);
    }
  };

  const handleDelete = () => {
    deleteMessage(message.id);
  };

  const handleRegenerate = () => {
    regenerateMessage(message.id);
  };

  return (
    <motion.div
      variants={messageVariants}
      initial="hidden"
      animate="visible"
      className={cn(
        "group relative",
        isUser
          ? "bg-neutral-50 dark:bg-neutral-900/50"
          : "bg-white dark:bg-neutral-950"
      )}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className="flex items-start gap-3 px-4 py-6 max-w-3xl mx-auto">
        {/* Avatar */}
        <div className={cn(
          "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1",
          isUser
            ? "bg-neutral-200 dark:bg-neutral-700"
            : isError
            ? "bg-red-500"
            : "bg-primary-600"
        )}>
          {isUser ? (
            <User className="w-4 h-4 text-neutral-600 dark:text-neutral-300" />
          ) : (
            <Brain className="w-4 h-4 text-white" />
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm font-medium">
              {isUser ? 'You' : 'Frox AI'}
            </span>
            {showTimestamps && (
              <span className="text-xs text-neutral-400 dark:text-neutral-500">
                {formatDate(message.createdAt, false)}
              </span>
            )}
            {showTokenCount && message.tokens && (
              <span className="text-xs text-neutral-400 dark:text-neutral-500">
                {message.tokens} tokens
              </span>
            )}
          </div>

          {/* Message Content */}
          {isEditing ? (
            <div className="space-y-2">
              <textarea
                value={editContent}
                onChange={e => setEditContent(e.target.value)}
                className="w-full p-3 rounded-lg border border-primary-500 bg-white dark:bg-neutral-800 text-sm resize-none outline-none"
                rows={3}
                autoFocus
              />
              <div className="flex items-center gap-2">
                <button
                  onClick={handleEdit}
                  className="px-3 py-1.5 rounded-lg bg-primary-600 text-white text-sm hover:bg-primary-700 transition-colors"
                >
                  Save
                </button>
                <button
                  onClick={() => { setIsEditing(false); setEditContent(message.content); }}
                  className="px-3 py-1.5 rounded-lg border border-neutral-300 dark:border-neutral-700 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className={cn(
              "prose dark:prose-invert max-w-none",
              isError && "text-red-600 dark:text-red-400"
            )}>
              <MarkdownRenderer content={message.content} />
            </div>
          )}

          {/* Attachments */}
          {message.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {message.attachments.map(attachment => (
                <div
                  key={attachment.id}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-sm"
                >
                  <span className="truncate max-w-[200px]">{attachment.name}</span>
                  <span className="text-xs text-neutral-400">
                    {(attachment.size / 1024).toFixed(1)} KB
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Actions */}
          {!isEditing && (
            <AnimatePresence>
              {showActions && (
                <motion.div
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 4 }}
                  className="flex items-center gap-1 mt-3"
                >
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 px-2 py-1 rounded text-xs text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                    title="Copy message"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>

                  {isUser && (
                    <button
                      onClick={handleEdit}
                      className="flex items-center gap-1 px-2 py-1 rounded text-xs text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      title="Edit message"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      Edit
                    </button>
                  )}

                  {!isUser && isLast && (
                    <button
                      onClick={handleRegenerate}
                      className="flex items-center gap-1 px-2 py-1 rounded text-xs text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      title="Regenerate response"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Regenerate
                    </button>
                  )}

                  <button
                    onClick={handleDelete}
                    className="flex items-center gap-1 px-2 py-1 rounded text-xs text-red-500 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                    title="Delete message"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete
                  </button>

                  {!isUser && (
                    <>
                      <button className="p-1 rounded text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors">
                        <ThumbsUp className="w-3.5 h-3.5" />
                      </button>
                      <button className="p-1 rounded text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors">
                        <ThumbsDown className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>
      </div>
    </motion.div>
  );
}
