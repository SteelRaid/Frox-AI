// ============================================================
// Frox AI – Empty State
// ============================================================

import { MessageSquare } from 'lucide-react';

export function EmptyState() {
  return (
    <div className="h-full flex flex-col items-center justify-center text-neutral-400 dark:text-neutral-600">
      <MessageSquare className="w-12 h-12 mb-4 opacity-50" />
      <p className="text-sm">Select a conversation or start a new chat</p>
    </div>
  );
}
