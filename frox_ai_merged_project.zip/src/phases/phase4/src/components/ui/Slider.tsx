// ============================================================
// Frox AI – Slider Component
// ============================================================

import { cn } from '../../utils/index';

interface SliderProps {
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step?: number;
  label?: string;
}

export function Slider({ value, onChange, min, max, step = 1, label }: SliderProps) {
  return (
    <div className="w-full">
      {label && (
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-neutral-500 dark:text-neutral-400">{label}</span>
          <span className="text-xs font-medium">{value}</span>
        </div>
      )}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        className={cn(
          "w-full h-1.5 bg-neutral-200 dark:bg-neutral-700 rounded-full appearance-none cursor-pointer",
          "accent-primary-500"
        )}
      />
    </div>
  );
}
