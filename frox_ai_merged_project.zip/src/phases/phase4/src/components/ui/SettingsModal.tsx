// ============================================================
// Frox AI – Settings Modal
// ============================================================

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, User, Palette, Type, Keyboard, Shield, Globe,
  Moon, Sun, Monitor, Check
} from 'lucide-react';
import { useSettingsStore, useThemeStore } from '../../stores/index';
import { useFocusTrap } from '../../hooks/index';
import { useRef } from 'react';
import { cn } from '../../utils/index';
import { modalOverlay, modalContent } from '../../animations/index';

const tabs = [
  { id: 'general', label: 'General', icon: Globe },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'editor', label: 'Editor', icon: Type },
  { id: 'shortcuts', label: 'Shortcuts', icon: Keyboard },
  { id: 'privacy', label: 'Privacy', icon: Shield },
];

export function SettingsModal() {
  const isOpen = useSettingsStore(state => state.isSettingsOpen);
  const activeTab = useSettingsStore(state => state.activeSettingsTab);
  const closeSettings = useSettingsStore(state => state.closeSettings);
  const setActiveTab = useSettingsStore(state => state.openSettings);
  const general = useSettingsStore(state => state.general);
  const appearance = useSettingsStore(state => state.appearance);
  const editor = useSettingsStore(state => state.editor);
  const privacy = useSettingsStore(state => state.privacy);
  const shortcuts = useSettingsStore(state => state.shortcuts);
  const updateGeneral = useSettingsStore(state => state.updateGeneral);
  const updateAppearance = useSettingsStore(state => state.updateAppearance);
  const updateEditor = useSettingsStore(state => state.updateEditor);
  const updatePrivacy = useSettingsStore(state => state.updatePrivacy);
  const resetToDefaults = useSettingsStore(state => state.resetToDefaults);
  const modalRef = useRef<HTMLDivElement>(null);

  useFocusTrap(modalRef, isOpen);

  if (!isOpen) return null;

  return (
    <motion.div
      variants={modalOverlay}
      initial="hidden"
      animate="visible"
      exit="exit"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
      onClick={closeSettings}
    >
      <motion.div
        ref={modalRef}
        variants={modalContent}
        initial="hidden"
        animate="visible"
        exit="exit"
        className="w-full max-w-2xl bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-2xl overflow-hidden max-h-[85vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-semibold">Settings</h2>
          <button
            onClick={closeSettings}
            className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Close settings"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar Tabs */}
          <div className="w-48 border-r border-neutral-200 dark:border-neutral-800 p-3 space-y-1 overflow-y-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                  activeTab === tab.id
                    ? "bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300 font-medium"
                    : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                )}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Settings Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {activeTab === 'general' && (
              <div className="space-y-6">
                <section>
                  <h3 className="text-sm font-semibold mb-4">General Settings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Auto Save</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Automatically save conversations</div>
                      </div>
                      <Switch
                        checked={general.autoSave}
                        onChange={v => updateGeneral({ autoSave: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Confirm Delete</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Show confirmation before deleting</div>
                      </div>
                      <Switch
                        checked={general.confirmDelete}
                        onChange={v => updateGeneral({ confirmDelete: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Sound Effects</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Play sounds for notifications</div>
                      </div>
                      <Switch
                        checked={general.soundEffects}
                        onChange={v => updateGeneral({ soundEffects: v })}
                      />
                    </div>
                  </div>
                </section>
              </div>
            )}

            {activeTab === 'appearance' && (
              <div className="space-y-6">
                <section>
                  <h3 className="text-sm font-semibold mb-4">Theme</h3>
                  <div className="grid grid-cols-3 gap-3">
                    {(['light', 'dark', 'system'] as const).map(mode => (
                      <button
                        key={mode}
                        onClick={() => updateAppearance({ theme: mode })}
                        className={cn(
                          "flex flex-col items-center gap-2 p-4 rounded-xl border transition-all",
                          appearance.theme === mode
                            ? "border-primary-500 bg-primary-50 dark:bg-primary-900/20"
                            : "border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 dark:hover:border-neutral-700"
                        )}
                      >
                        {mode === 'light' && <Sun className="w-6 h-6" />}
                        {mode === 'dark' && <Moon className="w-6 h-6" />}
                        {mode === 'system' && <Monitor className="w-6 h-6" />}
                        <span className="text-sm font-medium capitalize">{mode}</span>
                        {appearance.theme === mode && <Check className="w-4 h-4 text-primary-500" />}
                      </button>
                    ))}
                  </div>
                </section>

                <section>
                  <h3 className="text-sm font-semibold mb-4">Display</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Show Timestamps</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Display message timestamps</div>
                      </div>
                      <Switch
                        checked={appearance.showTimestamps}
                        onChange={v => updateAppearance({ showTimestamps: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Show Token Count</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Display token usage information</div>
                      </div>
                      <Switch
                        checked={appearance.showTokenCount}
                        onChange={v => updateAppearance({ showTokenCount: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Compact Mode</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Reduce spacing between elements</div>
                      </div>
                      <Switch
                        checked={appearance.compactMode}
                        onChange={v => updateAppearance({ compactMode: v })}
                      />
                    </div>
                  </div>
                </section>
              </div>
            )}

            {activeTab === 'editor' && (
              <div className="space-y-6">
                <section>
                  <h3 className="text-sm font-semibold mb-4">Editor Settings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Enter to Send</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Press Enter to send messages</div>
                      </div>
                      <Switch
                        checked={editor.enterToSend}
                        onChange={v => updateEditor({ enterToSend: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Code Wrap</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Wrap long lines in code blocks</div>
                      </div>
                      <Switch
                        checked={editor.codeWrap}
                        onChange={v => updateEditor({ codeWrap: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Line Numbers</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Show line numbers in code blocks</div>
                      </div>
                      <Switch
                        checked={editor.lineNumbers}
                        onChange={v => updateEditor({ lineNumbers: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Word Wrap</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Wrap text in the editor</div>
                      </div>
                      <Switch
                        checked={editor.wordWrap}
                        onChange={v => updateEditor({ wordWrap: v })}
                      />
                    </div>
                  </div>
                </section>
              </div>
            )}

            {activeTab === 'shortcuts' && (
              <div className="space-y-4">
                <h3 className="text-sm font-semibold mb-4">Keyboard Shortcuts</h3>
                <div className="space-y-2">
                  {shortcuts.map(shortcut => (
                    <div
                      key={shortcut.id}
                      className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-colors"
                    >
                      <div>
                        <div className="text-sm font-medium">{shortcut.action}</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">{shortcut.description}</div>
                      </div>
                      <kbd className="flex items-center gap-1 px-2 py-1 rounded bg-neutral-100 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 text-xs font-mono">
                        {shortcut.keys.join('+')}
                      </kbd>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'privacy' && (
              <div className="space-y-6">
                <section>
                  <h3 className="text-sm font-semibold mb-4">Privacy Settings</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Save History</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Store conversation history locally</div>
                      </div>
                      <Switch
                        checked={privacy.saveHistory}
                        onChange={v => updatePrivacy({ saveHistory: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Share Usage Data</div>
                        <div className="text-xs text-neutral-500 dark:text-neutral-400">Help improve Frox AI</div>
                      </div>
                      <Switch
                        checked={privacy.shareUsageData}
                        onChange={v => updatePrivacy({ shareUsageData: v })}
                      />
                    </div>
                  </div>
                </section>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-neutral-200 dark:border-neutral-800">
          <button
            onClick={resetToDefaults}
            className="text-sm text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 transition-colors"
          >
            Reset to Defaults
          </button>
          <button
            onClick={closeSettings}
            className="px-4 py-2 rounded-lg bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            Done
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Switch Component
function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn(
        "relative w-11 h-6 rounded-full transition-colors",
        checked ? "bg-primary-600" : "bg-neutral-300 dark:bg-neutral-700"
      )}
      role="switch"
      aria-checked={checked}
    >
      <span
        className={cn(
          "absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform",
          checked && "translate-x-5"
        )}
      />
    </button>
  );
}
