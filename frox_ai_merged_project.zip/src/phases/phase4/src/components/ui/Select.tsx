// ============================================================
// Frox AI – Select Component
// ============================================================

import { cn } from '../../utils/index';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  label?: string;
}

export function Select({ value, onChange, options, label }: SelectProps) {
  return (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-medium mb-1">{label}</label>
      )}
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        className={cn(
          "w-full px-3 py-2 rounded-lg border bg-white dark:bg-neutral-900 text-sm",
          "border-neutral-300 dark:border-neutral-700",
          "focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
        )}
      >
        {options.map(option => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}
