// ============================================================
// Frox AI – Sidebar Component
// ============================================================

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useConversationStore, useWorkspaceStore } from '../../stores/index';
import { useLayoutStore } from '../../stores/layoutStore';
import { SidebarHeader } from './SidebarHeader';
import { SearchBar } from './SearchBar';
import { ConversationList } from './ConversationList';
import { SidebarFooter } from './SidebarFooter';
import { sidebarContentVariants } from '../../animations/index';

interface SidebarProps {
  isMobile?: boolean;
}

export function Sidebar({ isMobile = false }: SidebarProps) {
  const sidebarCollapsed = useLayoutStore(state => state.sidebarCollapsed);
  const [searchQuery, setSearchQuery] = useState('');

  const conversations = useConversationStore(state => state.getFilteredConversations());
  const pinnedConversations = useConversationStore(state => state.getPinnedConversations());
  const recentConversations = useConversationStore(state => state.getRecentConversations(5));

  const showContent = isMobile || !sidebarCollapsed;

  return (
    <div className="h-full flex flex-col">
      <SidebarHeader isMobile={isMobile} />

      {showContent && (
        <motion.div
          variants={sidebarContentVariants}
          initial="collapsed"
          animate="expanded"
          className="flex-1 overflow-y-auto flex flex-col"
        >
          <SearchBar value={searchQuery} onChange={setSearchQuery} />

          <div className="flex-1 px-3 pb-3 space-y-1">
            {pinnedConversations.length > 0 && (
              <ConversationList
                title="Pinned"
                conversations={pinnedConversations}
                icon="pin"
              />
            )}

            <ConversationList
              title="Recent"
              conversations={recentConversations}
              icon="clock"
            />

            {conversations.length > 0 && (
              <ConversationList
                title="All Conversations"
                conversations={conversations}
                icon="message"
              />
            )}
          </div>
        </motion.div>
      )}

      <SidebarFooter isMobile={isMobile} />
    </div>
  );
}
