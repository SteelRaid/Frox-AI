// ============================================================
// Frox AI – Conversation List Item
// ============================================================

import { useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MessageSquare, Pin, Archive, Trash2, Edit3, Copy,
  Star, MoreHorizontal, Check
} from 'lucide-react';
import type { Conversation } from '../../types/index';
import { useConversationStore, useMessageStore } from '../../stores/index';
import { useLayoutStore } from '../../stores/layoutStore';
import { useClickOutside, useIsMobile } from '../../hooks/index';
import { formatDate, truncate } from '../../utils/index';
import { cn } from '../../utils/index';

interface ConversationItemProps {
  conversation: Conversation;
}

export function ConversationItem({ conversation }: ConversationItemProps) {
  const navigate = useNavigate();
  const { conversationId } = useParams();
  const isMobile = useIsMobile();
  const [isHovered, setIsHovered] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(conversation.title);
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const setActiveConversation = useConversationStore(state => state.setActiveConversation);
  const pinConversation = useConversationStore(state => state.pinConversation);
  const unpinConversation = useConversationStore(state => state.unpinConversation);
  const archiveConversation = useConversationStore(state => state.archiveConversation);
  const deleteConversation = useConversationStore(state => state.deleteConversation);
  const duplicateConversation = useConversationStore(state => state.duplicateConversation);
  const favoriteConversation = useConversationStore(state => state.favoriteConversation);
  const unfavoriteConversation = useConversationStore(state => state.unfavoriteConversation);
  const updateConversation = useConversationStore(state => state.updateConversation);
  const setMobileDrawerOpen = useLayoutStore(state => state.setMobileDrawerOpen);
  const messageCount = useMessageStore(state =>
    state.getMessagesByConversation(conversation.id).length
  );

  const isActive = conversationId === conversation.id;

  useClickOutside(menuRef, () => setShowMenu(false));

  const handleClick = () => {
    setActiveConversation(conversation.id);
    navigate(`/chat/${conversation.id}`);
    if (isMobile) {
      setMobileDrawerOpen(false);
    }
  };

  const handleRename = () => {
    if (editTitle.trim() && editTitle !== conversation.title) {
      updateConversation(conversation.id, { title: editTitle.trim() });
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleRename();
    if (e.key === 'Escape') {
      setEditTitle(conversation.title);
      setIsEditing(false);
    }
  };

  return (
    <div
      className={cn(
        "group relative rounded-lg transition-colors",
        isActive
          ? "bg-primary-50 dark:bg-primary-900/20"
          : "hover:bg-neutral-100 dark:hover:bg-neutral-800"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isEditing ? (
        <div className="flex items-center gap-2 px-3 py-2">
          <input
            type="text"
            value={editTitle}
            onChange={e => setEditTitle(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={handleRename}
            autoFocus
            className="flex-1 text-sm bg-white dark:bg-neutral-800 border border-primary-500 rounded px-2 py-1 outline-none"
          />
          <button
            onClick={handleRename}
            className="p-1 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700"
          >
            <Check className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <button
          onClick={handleClick}
          className="w-full flex items-center gap-3 px-3 py-2 text-left"
        >
          <MessageSquare className={cn(
            "w-4 h-4 flex-shrink-0",
            isActive
              ? "text-primary-600 dark:text-primary-400"
              : "text-neutral-400 dark:text-neutral-500"
          )} />

          <div className="flex-1 min-w-0">
            <div className={cn(
              "text-sm truncate",
              isActive
                ? "font-medium text-primary-900 dark:text-primary-100"
                : "text-neutral-700 dark:text-neutral-300"
            )}>
              {conversation.title}
            </div>
            <div className="flex items-center gap-2 text-xs text-neutral-400 dark:text-neutral-500">
              <span>{formatDate(conversation.lastMessageAt)}</span>
              {messageCount > 0 && (
                <span>{messageCount} messages</span>
              )}
            </div>
          </div>

          <div className={cn(
            "flex items-center gap-1 flex-shrink-0",
            isHovered || isMobile ? "opacity-100" : "opacity-0",
            "transition-opacity"
          )}>
            {conversation.favorite && (
              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            )}
            {conversation.status === 'pinned' && (
              <Pin className="w-3.5 h-3.5 text-primary-500 fill-primary-500" />
            )}

            <div className="relative" ref={menuRef}>
              <button
                onClick={e => {
                  e.stopPropagation();
                  setShowMenu(!showMenu);
                }}
                className="p-1 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
                aria-label="Conversation options"
              >
                <MoreHorizontal className="w-3.5 h-3.5" />
              </button>

              <AnimatePresence>
                {showMenu && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -4 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -4 }}
                    className="absolute right-0 top-full mt-1 w-48 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg shadow-xl z-50 py-1"
                  >
                    {conversation.status !== 'pinned' ? (
                      <button
                        onClick={e => { e.stopPropagation(); pinConversation(conversation.id); setShowMenu(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      >
                        <Pin className="w-4 h-4" /> Pin
                      </button>
                    ) : (
                      <button
                        onClick={e => { e.stopPropagation(); unpinConversation(conversation.id); setShowMenu(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      >
                        <Pin className="w-4 h-4" /> Unpin
                      </button>
                    )}

                    <button
                      onClick={e => { e.stopPropagation(); setIsEditing(true); setShowMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                    >
                      <Edit3 className="w-4 h-4" /> Rename
                    </button>

                    <button
                      onClick={e => { e.stopPropagation(); duplicateConversation(conversation.id); setShowMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                    >
                      <Copy className="w-4 h-4" /> Duplicate
                    </button>

                    {conversation.favorite ? (
                      <button
                        onClick={e => { e.stopPropagation(); unfavoriteConversation(conversation.id); setShowMenu(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      >
                        <Star className="w-4 h-4" /> Unfavorite
                      </button>
                    ) : (
                      <button
                        onClick={e => { e.stopPropagation(); favoriteConversation(conversation.id); setShowMenu(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                      >
                        <Star className="w-4 h-4" /> Favorite
                      </button>
                    )}

                    <div className="my-1 border-t border-neutral-200 dark:border-neutral-800" />

                    <button
                      onClick={e => { e.stopPropagation(); archiveConversation(conversation.id); setShowMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                    >
                      <Archive className="w-4 h-4" /> Archive
                    </button>

                    <button
                      onClick={e => { e.stopPropagation(); deleteConversation(conversation.id); setShowMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" /> Delete
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </button>
      )}
    </div>
  );
}
