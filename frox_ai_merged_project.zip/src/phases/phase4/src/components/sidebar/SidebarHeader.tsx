// ============================================================
// Frox AI – Sidebar Header
// ============================================================

import { Plus, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useConversationStore, useWorkspaceStore } from '../../stores/index';
import { useLayoutStore } from '../../stores/layoutStore';
import { cn } from '../../utils/index';

interface SidebarHeaderProps {
  isMobile?: boolean;
}

export function SidebarHeader({ isMobile = false }: SidebarHeaderProps) {
  const navigate = useNavigate();
  const createConversation = useConversationStore(state => state.createConversation);
  const activeWorkspaceId = useWorkspaceStore(state => state.activeWorkspaceId);
  const sidebarCollapsed = useLayoutStore(state => state.sidebarCollapsed);
  const toggleSidebar = useLayoutStore(state => state.toggleSidebar);

  const handleNewChat = () => {
    const workspaceId = activeWorkspaceId || 'default';
    const conv = createConversation(workspaceId);
    navigate(`/chat/${conv.id}`);
  };

  return (
    <div className={cn(
      "flex items-center gap-2 p-3 border-b border-neutral-200 dark:border-neutral-800",
      sidebarCollapsed && !isMobile && "justify-center"
    )}>
      <button
        onClick={handleNewChat}
        className={cn(
          "flex items-center gap-2 px-3 py-2 rounded-lg bg-primary-600 hover:bg-primary-700 text-white text-sm font-medium transition-colors flex-1",
          sidebarCollapsed && !isMobile && "justify-center px-2"
        )}
        aria-label="New chat"
      >
        <Plus className="w-4 h-4 flex-shrink-0" />
        {(!sidebarCollapsed || isMobile) && <span>New Chat</span>}
      </button>

      {!isMobile && (
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500 dark:text-neutral-400 transition-colors flex-shrink-0"
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {sidebarCollapsed ? (
            <PanelLeftOpen className="w-4 h-4" />
          ) : (
            <PanelLeftClose className="w-4 h-4" />
          )}
        </button>
      )}
    </div>
  );
}
