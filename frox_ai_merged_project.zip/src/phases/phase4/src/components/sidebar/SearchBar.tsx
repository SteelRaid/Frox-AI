// ============================================================
// Frox AI – Sidebar Search Bar
// ============================================================

import { Search, X } from 'lucide-react';
import { cn } from '../../utils/index';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <div className="px-3 py-2">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
        <input
          type="text"
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder="Search conversations..."
          className={cn(
            "w-full pl-9 pr-8 py-2 rounded-lg text-sm",
            "bg-neutral-100 dark:bg-neutral-800",
            "border border-transparent",
            "focus:border-primary-500 focus:ring-1 focus:ring-primary-500",
            "placeholder:text-neutral-400",
            "outline-none transition-all"
          )}
          aria-label="Search conversations"
        />
        {value && (
          <button
            onClick={() => onChange('')}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 rounded hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
            aria-label="Clear search"
          >
            <X className="w-3.5 h-3.5 text-neutral-400" />
          </button>
        )}
      </div>
    </div>
  );
}
