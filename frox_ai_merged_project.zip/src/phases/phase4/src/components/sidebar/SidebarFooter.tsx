// ============================================================
// Frox AI – Sidebar Footer
// ============================================================

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Settings, LogOut, Moon, Sun, Monitor,
  ChevronUp, Folder, Archive
} from 'lucide-react';
import { useThemeStore, useSettingsStore, useConversationStore } from '../../stores/index';
import { useLayoutStore } from '../../stores/layoutStore';
import { cn } from '../../utils/index';

interface SidebarFooterProps {
  isMobile?: boolean;
}

export function SidebarFooter({ isMobile = false }: SidebarFooterProps) {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const sidebarCollapsed = useLayoutStore(state => state.sidebarCollapsed);
  const mode = useThemeStore(state => state.mode);
  const setMode = useThemeStore(state => state.setMode);
  const openSettings = useSettingsStore(state => state.openSettings);
  const archivedCount = useConversationStore(state => state.getArchivedConversations().length);

  const showContent = isMobile || !sidebarCollapsed;

  return (
    <div className="border-t border-neutral-200 dark:border-neutral-800 p-3">
      {showContent ? (
        <div className="space-y-1">
          {/* Theme Toggle */}
          <div className="flex items-center gap-1 p-1 rounded-lg bg-neutral-100 dark:bg-neutral-800 mb-2">
            {(['light', 'dark', 'system'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={cn(
                  "flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md text-xs font-medium transition-all",
                  mode === m
                    ? "bg-white dark:bg-neutral-700 shadow-sm text-neutral-900 dark:text-neutral-100"
                    : "text-neutral-500 dark:text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300"
                )}
              >
                {m === 'light' && <Sun className="w-3.5 h-3.5" />}
                {m === 'dark' && <Moon className="w-3.5 h-3.5" />}
                {m === 'system' && <Monitor className="w-3.5 h-3.5" />}
                <span className="capitalize">{m}</span>
              </button>
            ))}
          </div>

          {/* Archived Link */}
          {archivedCount > 0 && (
            <button
              onClick={() => {}}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              <Archive className="w-4 h-4" />
              <span>Archived</span>
              <span className="ml-auto text-xs bg-neutral-200 dark:bg-neutral-700 px-1.5 py-0.5 rounded-full">
                {archivedCount}
              </span>
            </button>
          )}

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-white text-sm font-medium flex-shrink-0">
                U
              </div>
              <div className="flex-1 text-left min-w-0">
                <div className="text-sm font-medium truncate">User</div>
                <div className="text-xs text-neutral-500 dark:text-neutral-400 truncate">user@example.com</div>
              </div>
              <ChevronUp className={cn(
                "w-4 h-4 text-neutral-400 transition-transform",
                showUserMenu && "rotate-180"
              )} />
            </button>

            <AnimatePresence>
              {showUserMenu && (
                <motion.div
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 4 }}
                  className="absolute bottom-full left-0 right-0 mb-1 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg shadow-xl py-1"
                >
                  <button
                    onClick={() => { openSettings(); setShowUserMenu(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                  >
                    <Settings className="w-4 h-4" /> Settings
                  </button>
                  <button
                    onClick={() => setShowUserMenu(false)}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  >
                    <LogOut className="w-4 h-4" /> Sign Out
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-2">
          <button
            onClick={() => setMode(mode === 'dark' ? 'light' : 'dark')}
            className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Toggle theme"
          >
            {mode === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button
            onClick={() => openSettings()}
            className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
          <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-white text-sm font-medium">
            U
          </div>
        </div>
      )}
    </div>
  );
}
