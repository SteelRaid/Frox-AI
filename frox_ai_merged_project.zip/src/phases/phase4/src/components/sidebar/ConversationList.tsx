// ============================================================
// Frox AI – Conversation List
// ============================================================

import { motion } from 'framer-motion';
import { Pin, Clock, MessageSquare, Folder, ChevronRight } from 'lucide-react';
import type { Conversation } from '../../types/index';
import { ConversationItem } from './ConversationItem';
import { staggerContainer, staggerItem } from '../../animations/index';

interface ConversationListProps {
  title: string;
  conversations: Conversation[];
  icon: 'pin' | 'clock' | 'message' | 'folder';
}

const iconMap = {
  pin: Pin,
  clock: Clock,
  message: MessageSquare,
  folder: Folder,
};

export function ConversationList({ title, conversations, icon }: ConversationListProps) {
  const Icon = iconMap[icon];

  if (conversations.length === 0) return null;

  return (
    <div className="mb-2">
      <div className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
        <Icon className="w-3.5 h-3.5" />
        <span>{title}</span>
        <span className="text-neutral-400 dark:text-neutral-600 ml-auto">
          {conversations.length}
        </span>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
        className="space-y-0.5"
      >
        {conversations.map(conversation => (
          <motion.div key={conversation.id} variants={staggerItem}>
            <ConversationItem conversation={conversation} />
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
