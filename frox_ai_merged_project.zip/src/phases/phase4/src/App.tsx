// ============================================================
// Frox AI – Root App Component
// ============================================================

import { Routes, Route, Navigate } from 'react-router-dom';
import { MainLayout } from './layouts/index';
import { ChatPage } from './components/chat/ChatPage';
import { NewChatPage } from './components/chat/NewChatPage';
import { SettingsModal } from './components/ui/SettingsModal';

export function App() {
  return (
    <>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/chat-engine/chat" element={<NewChatPage />} />
          <Route path="/chat-engine/chat/:conversationId" element={<ChatPage />} />
          <Route path="/chat-engine" element={<Navigate to="/chat-engine/chat" replace />} />
        </Route>
      </Routes>
      <SettingsModal />
    </>
  );
}
