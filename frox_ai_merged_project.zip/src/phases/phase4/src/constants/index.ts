// ============================================================
// Frox AI – Application Constants
// ============================================================

export const APP_NAME = 'Frox AI';
export const APP_VERSION = '1.0.0';
export const APP_DESCRIPTION = 'Advanced AI Chat Engine';

export const STORAGE_KEYS = {
  CONVERSATIONS: 'frox_conversations',
  SETTINGS: 'frox_settings',
  THEME: 'frox_theme',
  WORKSPACE: 'frox_workspace',
  COMPOSER: 'frox_composer',
  ATTACHMENTS: 'frox_attachments',
  SIDEBAR_STATE: 'frox_sidebar_state',
  USER: 'frox_user',
  OFFLINE_QUEUE: 'frox_offline_queue',
} as const;

export const API_ENDPOINTS = {
  CHAT: '/api/v1/chat',
  STREAM: '/api/v1/chat/stream',
  MODELS: '/api/v1/models',
  UPLOAD: '/api/v1/upload',
  CONVERSATIONS: '/api/v1/conversations',
  SEARCH: '/api/v1/search',
  SUMMARIZE: '/api/v1/summarize',
} as const;

export const DEFAULT_SETTINGS = {
  theme: 'dark' as const,
  fontSize: 'base' as const,
  language: 'en',
  sidebarCollapsed: false,
  showTimestamps: true,
  showTokenCount: true,
  enterToSend: true,
  codeWrap: false,
  reducedMotion: false,
  temperature: 0.7,
  maxTokens: 4096,
  useInternet: false,
  useReasoning: false,
} as const;

export const MODELS: import('../types/index').AIModel[] = [
  {
    id: 'frox-gpt-4o',
    name: 'Frox GPT-4o',
    provider: 'Frox',
    description: 'Most capable model for complex tasks',
    maxTokens: 4096,
    contextWindow: 128000,
    supportsVision: true,
    supportsReasoning: true,
    supportsInternet: true,
    pricing: { input: 0.005, output: 0.015, currency: 'USD' },
    capabilities: ['text', 'vision', 'code', 'reasoning', 'internet'],
    isAvailable: true,
  },
  {
    id: 'frox-gpt-4o-mini',
    name: 'Frox GPT-4o Mini',
    provider: 'Frox',
    description: 'Fast and cost-effective for everyday tasks',
    maxTokens: 4096,
    contextWindow: 128000,
    supportsVision: true,
    supportsReasoning: false,
    supportsInternet: true,
    pricing: { input: 0.00015, output: 0.0006, currency: 'USD' },
    capabilities: ['text', 'vision', 'code'],
    isAvailable: true,
  },
  {
    id: 'frox-claude-3-5-sonnet',
    name: 'Frox Claude 3.5 Sonnet',
    provider: 'Frox',
    description: 'Excellent for analysis and creative writing',
    maxTokens: 8192,
    contextWindow: 200000,
    supportsVision: true,
    supportsReasoning: true,
    supportsInternet: false,
    pricing: { input: 0.003, output: 0.015, currency: 'USD' },
    capabilities: ['text', 'vision', 'code', 'reasoning'],
    isAvailable: true,
  },
  {
    id: 'frox-reasoning',
    name: 'Frox Reasoning',
    provider: 'Frox',
    description: 'Deep reasoning and step-by-step problem solving',
    maxTokens: 4096,
    contextWindow: 128000,
    supportsVision: false,
    supportsReasoning: true,
    supportsInternet: true,
    pricing: { input: 0.01, output: 0.03, currency: 'USD' },
    capabilities: ['text', 'code', 'reasoning', 'math'],
    isAvailable: true,
  },
];

export const TEMPERATURE_RANGE = { min: 0, max: 2, step: 0.1 } as const;
export const MAX_TOKENS_OPTIONS = [1024, 2048, 4096, 8192, 16384, 32768, 128000] as const;

export const FILE_CONSTRAINTS = {
  maxSize: 50 * 1024 * 1024, // 50MB
  maxCount: 10,
  allowedTypes: [
    'image/*',
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain',
    'text/markdown',
    'application/zip',
    'text/*',
    'application/json',
    'application/javascript',
    'text/html',
    'text/css',
    'text/x-python',
    'text/x-java',
    'text/x-c',
    'text/x-cpp',
    'text/x-go',
    'text/x-rust',
    'text/x-typescript',
  ],
  imageTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'],
} as const;

export const ANIMATION_DURATIONS = {
  fast: 0.15,
  normal: 0.25,
  slow: 0.4,
  pageTransition: 0.3,
  sidebarCollapse: 0.35,
  messageAppear: 0.2,
  typingIndicator: 0.6,
} as const;

export const SCROLL_CONFIG = {
  threshold: 100,
  smoothBehavior: 'smooth' as const,
  debounceMs: 16,
} as const;

export const KEYBOARD_SHORTCUTS = [
  { id: 'new-chat', action: 'New Chat', keys: ['Ctrl', 'Shift', 'O'], description: 'Start a new conversation', scope: 'global' },
  { id: 'search', action: 'Search', keys: ['Ctrl', 'K'], description: 'Open search/command palette', scope: 'global' },
  { id: 'send-message', action: 'Send Message', keys: ['Enter'], description: 'Send the current message', scope: 'composer' },
  { id: 'new-line', action: 'New Line', keys: ['Shift', 'Enter'], description: 'Insert a new line', scope: 'composer' },
  { id: 'focus-composer', action: 'Focus Composer', keys: ['Ctrl', '/'], description: 'Focus the message input', scope: 'global' },
  { id: 'toggle-sidebar', action: 'Toggle Sidebar', keys: ['Ctrl', 'B'], description: 'Show/hide sidebar', scope: 'global' },
  { id: 'archive-chat', action: 'Archive Chat', keys: ['Ctrl', 'Shift', 'A'], description: 'Archive current conversation', scope: 'chat' },
  { id: 'delete-chat', action: 'Delete Chat', keys: ['Ctrl', 'Shift', 'D'], description: 'Delete current conversation', scope: 'chat' },
  { id: 'regenerate', action: 'Regenerate', keys: ['Ctrl', 'R'], description: 'Regenerate last response', scope: 'chat' },
  { id: 'settings', action: 'Settings', keys: ['Ctrl', ','], description: 'Open settings', scope: 'global' },
  { id: 'escape', action: 'Close/Cancel', keys: ['Escape'], description: 'Close modals or cancel actions', scope: 'global' },
] as const;

export const REGEX = {
  url: /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g,
  email: /[^\s@]+@[^\s@]+\.[^\s@]+/g,
  mention: /@(\w+)/g,
  codeBlock: /```(\w+)?\n([\s\S]*?)```/g,
  inlineCode: /`([^`]+)`/g,
} as const;

export const DEBOUNCE = {
  search: 300,
  resize: 150,
  scroll: 16,
  save: 500,
  typing: 200,
} as const;

export const RETRY_CONFIG = {
  maxRetries: 3,
  baseDelay: 1000,
  maxDelay: 10000,
  backoffMultiplier: 2,
} as const;

export const CONTEXT_TRIM_THRESHOLD = 0.8; // Trim when context reaches 80% of max
export const SUMMARY_TRIGGER_COUNT = 20; // Summarize after 20 messages
export const OFFLINE_QUEUE_MAX_SIZE = 50;
