// ============================================================
// Frox AI – App Provider (Composition Root)
// ============================================================

import { ReactNode } from 'react';
import { QueryProvider } from './QueryProvider';
import { ThemeProvider } from './ThemeProvider';
import { KeyboardProvider } from './KeyboardProvider';

interface AppProviderProps {
  children: ReactNode;
}

export function AppProvider({ children }: AppProviderProps) {
  return (
    <QueryProvider>
      <ThemeProvider>
        <KeyboardProvider>
          {children}
        </KeyboardProvider>
      </ThemeProvider>
    </QueryProvider>
  );
}
