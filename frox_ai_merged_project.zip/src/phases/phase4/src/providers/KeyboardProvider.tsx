// ============================================================
// Frox AI – Keyboard Shortcuts Provider
// ============================================================

import { ReactNode, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useConversationStore, useSettingsStore, useComposerStore } from '../stores/index';
import { useNotificationStore } from '../stores/notificationStore';

interface KeyboardProviderProps {
  children: ReactNode;
}

export function KeyboardProvider({ children }: KeyboardProviderProps) {
  const navigate = useNavigate();
  const createConversation = useConversationStore(state => state.createConversation);
  const activeWorkspaceId = useWorkspaceStore(state => state.activeWorkspaceId);
  const openSettings = useSettingsStore(state => state.openSettings);
  const setSearchQuery = useConversationStore(state => state.setSearchQuery);
  const toggleSidebar = useLayoutStore(state => state.toggleSidebar);
  const archiveConversation = useConversationStore(state => state.archiveConversation);
  const deleteConversation = useConversationStore(state => state.deleteConversation);
  const activeConversationId = useConversationStore(state => state.activeConversationId);
  const info = useNotificationStore(state => state.info);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Don't trigger shortcuts when typing in inputs
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
      if (e.key !== 'Escape') return;
    }

    const isCtrl = e.ctrlKey || e.metaKey;
    const isShift = e.shiftKey;

    // Ctrl+Shift+O: New Chat
    if (isCtrl && isShift && e.key === 'O') {
      e.preventDefault();
      const workspaceId = activeWorkspaceId || 'default';
      const conv = createConversation(workspaceId);
      navigate(`/chat/${conv.id}`);
    }

    // Ctrl+K: Search
    if (isCtrl && e.key === 'k') {
      e.preventDefault();
      // Open command palette
      document.dispatchEvent(new CustomEvent('open-command-palette'));
    }

    // Ctrl+B: Toggle Sidebar
    if (isCtrl && e.key === 'b') {
      e.preventDefault();
      toggleSidebar();
    }

    // Ctrl+Shift+A: Archive Chat
    if (isCtrl && isShift && e.key === 'A') {
      e.preventDefault();
      if (activeConversationId) {
        archiveConversation(activeConversationId);
        info('Archived', 'Conversation moved to archive');
      }
    }

    // Ctrl+Shift+D: Delete Chat
    if (isCtrl && isShift && e.key === 'D') {
      e.preventDefault();
      if (activeConversationId) {
        deleteConversation(activeConversationId);
        navigate('/chat-engine/chat');
      }
    }

    // Ctrl+Comma: Settings
    if (isCtrl && e.key === ',') {
      e.preventDefault();
      openSettings();
    }

    // Escape: Close modals
    if (e.key === 'Escape') {
      document.dispatchEvent(new CustomEvent('close-modals'));
    }
  }, [createConversation, activeWorkspaceId, openSettings, toggleSidebar, archiveConversation, deleteConversation, activeConversationId, info, navigate]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  return <>{children}</>;
}

// Import needed for the hook
import { useWorkspaceStore } from '../stores/workspaceStore';
import { useLayoutStore } from '../stores/layoutStore';
