// ============================================================
// Frox AI – Theme Provider
// ============================================================

import { ReactNode, useEffect } from 'react';
import { useThemeStore } from '../stores/index';

interface ThemeProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  const applyTheme = useThemeStore(state => state.applyTheme);
  const setSystemPreference = useThemeStore(state => state.setSystemPreference);

  useEffect(() => {
    applyTheme();

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => {
      setSystemPreference(e.matches ? 'dark' : 'light');
    };

    mediaQuery.addEventListener('change', handler);
    setSystemPreference(mediaQuery.matches ? 'dark' : 'light');

    return () => mediaQuery.removeEventListener('change', handler);
  }, [applyTheme, setSystemPreference]);

  return <>{children}</>;
}
