// ============================================================
// Frox AI – File Service
// ============================================================

import type { Attachment } from '../types/index';
import { FILE_CONSTRAINTS } from '../constants/index';
import { generateId, formatBytes } from '../utils/index';

class FileService {
  async uploadFile(file: File, onProgress?: (progress: number) => void): Promise<Attachment> {
    const attachment: Attachment = {
      id: generateId(),
      name: file.name,
      type: file.type,
      size: file.size,
      url: URL.createObjectURL(file),
      mimeType: file.type,
      uploadProgress: 0,
      status: 'uploading',
      createdAt: new Date().toISOString(),
    };

    // Simulate upload with progress
    return new Promise((resolve, reject) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 15 + 5;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          attachment.status = 'uploaded';
          attachment.uploadProgress = 100;
          resolve(attachment);
        } else {
          onProgress?.(progress);
          attachment.uploadProgress = progress;
        }
      }, 200);

      // Simulate occasional errors (5% chance)
      if (Math.random() < 0.05) {
        clearInterval(interval);
        attachment.status = 'error';
        reject(new Error('Upload failed'));
      }
    });
  }

  validateFile(file: File): { valid: boolean; error?: string } {
    if (file.size > FILE_CONSTRAINTS.maxSize) {
      return {
        valid: false,
        error: `File size ${formatBytes(file.size)} exceeds limit of ${formatBytes(FILE_CONSTRAINTS.maxSize)}`,
      };
    }

    const isAllowed = FILE_CONSTRAINTS.allowedTypes.some(type => {
      if (type.endsWith('/*')) {
        return file.type.startsWith(type.replace('/*', ''));
      }
      return file.type === type;
    });

    if (!isAllowed) {
      return { valid: false, error: `File type "${file.type}" is not supported` };
    }

    return { valid: true };
  }

  getFilePreviewUrl(file: File): string {
    return URL.createObjectURL(file);
  }

  revokePreviewUrl(url: string): void {
    URL.revokeObjectURL(url);
  }

  async readFileAsText(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  }

  async readFileAsDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  downloadFile(url: string, filename: string): void {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  getFileExtension(filename: string): string {
    return filename.slice(((filename.lastIndexOf('.') - 1) >>> 0) + 2);
  }

  isImageFile(mimeType: string): boolean {
    return FILE_CONSTRAINTS.imageTypes.includes(mimeType);
  }
}

export const fileService = new FileService();
