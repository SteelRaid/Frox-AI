// ============================================================
// Frox AI – Chat Service
// ============================================================

import type { Message, AIModel, Conversation } from '../types/index';
import { generateId, estimateTokens, sleep } from '../utils/index';
import { RETRY_CONFIG, CONTEXT_TRIM_THRESHOLD, SUMMARY_TRIGGER_COUNT } from '../constants/index';

interface ChatRequest {
  messages: Array<{ role: string; content: string }>;
  model: string;
  temperature: number;
  maxTokens: number;
  stream?: boolean;
  useInternet?: boolean;
  useReasoning?: boolean;
}

interface ChatResponse {
  content: string;
  thinkingContent?: string;
  metadata: {
    model: string;
    finishReason: string;
    tokensUsed: { prompt: number; completion: number; total: number };
    latency: number;
  };
}

class ChatService {
  private abortController: AbortController | null = null;

  async sendMessage(
    request: ChatRequest,
    onChunk?: (chunk: string) => void,
    onThinking?: (chunk: string) => void
  ): Promise<ChatResponse> {
    this.abortController = new AbortController();
    const startTime = Date.now();

    try {
      if (request.stream && onChunk) {
        return await this.streamMessage(request, onChunk, onThinking);
      }
      return await this.completeMessage(request);
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        throw new Error('Generation aborted by user');
      }
      throw error;
    } finally {
      this.abortController = null;
    }
  }

  private async streamMessage(
    request: ChatRequest,
    onChunk: (chunk: string) => void,
    onThinking?: (chunk: string) => void
  ): Promise<ChatResponse> {
    // Simulate streaming response
    const response = this.generateMockResponse(request);
    const content = response.content;
    const thinkingContent = response.thinkingContent;

    // Stream thinking content first if reasoning is enabled
    if (thinkingContent && onThinking) {
      const thinkingChunks = this.chunkText(thinkingContent, 5);
      for (const chunk of thinkingChunks) {
        if (this.abortController?.signal.aborted) {
          throw new Error('AbortError');
        }
        onThinking(chunk);
        await sleep(30);
      }
    }

    // Stream main content
    const chunks = this.chunkText(content, 3);
    let accumulatedContent = '';

    for (const chunk of chunks) {
      if (this.abortController?.signal.aborted) {
        throw new Error('AbortError');
      }
      accumulatedContent += chunk;
      onChunk(chunk);
      await sleep(20 + Math.random() * 30);
    }

    return {
      content: accumulatedContent,
      thinkingContent,
      metadata: {
        ...response.metadata,
        latency: Date.now() - Date.now(), // Will be calculated properly
      },
    };
  }

  private async completeMessage(request: ChatRequest): Promise<ChatResponse> {
    await sleep(500);
    return this.generateMockResponse(request);
  }

  private generateMockResponse(request: ChatRequest): ChatResponse {
    const lastMessage = request.messages[request.messages.length - 1];
    const content = lastMessage?.content.toLowerCase() || '';

    let responseText = '';
    let thinkingText = '';

    if (content.includes('code') || content.includes('function')) {
      responseText = `Here's an example function in TypeScript:

\`\`\`typescript
function calculateSum(a: number, b: number): number {
  return a + b;
}

// Usage
const result = calculateSum(5, 3);
console.log(result); // 8
\`\`\`

This function takes two numbers and returns their sum. It's fully typed with TypeScript for better developer experience and error catching.`;
    } else if (content.includes('math') || content.includes('equation')) {
      thinkingText = '1. Identify the mathematical concept requested\n2. Formulate the solution step by step\n3. Verify the result\n4. Present in clear notation';
      responseText = `The quadratic formula is given by:

$$x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$$

Where:
- $a$, $b$, and $c$ are coefficients of the quadratic equation $ax^2 + bx + c = 0$
- The discriminant $\Delta = b^2 - 4ac$ determines the nature of the roots

For example, solving $x^2 - 5x + 6 = 0$:

$$x = \frac{5 \pm \sqrt{25 - 24}}{2} = \frac{5 \pm 1}{2}$$

So $x_1 = 3$ and $x_2 = 2$`;
    } else if (content.includes('diagram') || content.includes('chart')) {
      responseText = `Here's a Mermaid diagram showing the system architecture:

\`\`\`mermaid
graph TD
    A[User Input] --> B{Composer}
    B --> C[AI Engine]
    C --> D{Response Type}
    D -->|Text| E[Markdown Renderer]
    D -->|Code| F[Syntax Highlighter]
    D -->|Math| G[KaTeX Renderer]
    E --> H[Chat Display]
    F --> H
    G --> H
\`\`\`

This diagram illustrates how user input flows through the system components.`;
    } else {
      responseText = `I understand your question about "${lastMessage?.content.substring(0, 50)}..."

This is a simulated response from the Frox AI engine. In a production environment, this would connect to actual AI providers like OpenAI, Anthropic, or custom models.

**Key features of this engine:**
- Streaming responses with real-time updates
- Markdown rendering with syntax highlighting
- Mathematical equation support via KaTeX
- Mermaid diagram generation
- File attachment handling
- Conversation context management

Would you like me to demonstrate any specific feature?`;
    }

    const promptTokens = request.messages.reduce((sum, m) => sum + estimateTokens(m.content), 0);
    const completionTokens = estimateTokens(responseText);

    return {
      content: responseText,
      thinkingText: request.useReasoning ? thinkingText : undefined,
      metadata: {
        model: request.model,
        finishReason: 'stop',
        tokensUsed: {
          prompt: promptTokens,
          completion: completionTokens,
          total: promptTokens + completionTokens,
        },
        latency: 0,
      },
    };
  }

  private chunkText(text: string, size: number): string[] {
    const chunks: string[] = [];
    for (let i = 0; i < text.length; i += size) {
      chunks.push(text.substring(i, i + size));
    }
    return chunks;
  }

  abort(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
  }

  trimContext(messages: Message[], maxTokens: number): Message[] {
    let totalTokens = messages.reduce((sum, m) => sum + (m.tokens || estimateTokens(m.content)), 0);

    if (totalTokens <= maxTokens * CONTEXT_TRIM_THRESHOLD) {
      return messages;
    }

    // Remove oldest messages until under threshold
    const trimmed = [...messages];
    while (totalTokens > maxTokens * CONTEXT_TRIM_THRESHOLD && trimmed.length > 2) {
      const removed = trimmed.shift();
      if (removed) {
        totalTokens -= removed.tokens || estimateTokens(removed.content);
      }
    }

    return trimmed;
  }

  shouldSummarize(messages: Message[]): boolean {
    return messages.length >= SUMMARY_TRIGGER_COUNT;
  }

  async summarizeConversation(messages: Message[]): Promise<string> {
    // In production, this would call the AI API
    const topics = messages
      .filter(m => m.role === 'user')
      .map(m => m.content.substring(0, 30))
      .join(', ');
    return `Conversation about: ${topics}...`;
  }

  async retryWithBackoff<T>(fn: () => Promise<T>, attempt = 0): Promise<T> {
    try {
      return await fn();
    } catch (error) {
      if (attempt >= RETRY_CONFIG.maxRetries) {
        throw error;
      }
      const delay = Math.min(
        RETRY_CONFIG.baseDelay * Math.pow(RETRY_CONFIG.backoffMultiplier, attempt),
        RETRY_CONFIG.maxDelay
      );
      await sleep(delay);
      return this.retryWithBackoff(fn, attempt + 1);
    }
  }
}

export const chatService = new ChatService();
