// ============================================================
// Frox AI – Streaming Service
// ============================================================

import type { StreamingChunk } from '../types/index';
import { generateId } from '../utils/index';

type StreamCallback = (chunk: StreamingChunk) => void;
type CompleteCallback = () => void;
type ErrorCallback = (error: Error) => void;

interface StreamHandlers {
  onChunk: StreamCallback;
  onComplete?: CompleteCallback;
  onError?: ErrorCallback;
}

class StreamingService {
  private eventSource: EventSource | null = null;
  private abortController: AbortController | null = null;
  private isStreaming = false;

  async startStream(
    endpoint: string,
    body: Record<string, unknown>,
    handlers: StreamHandlers
  ): Promise<void> {
    if (this.isStreaming) {
      this.stop();
    }

    this.abortController = new AbortController();
    this.isStreaming = true;

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: this.abortController.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (this.isStreaming) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.substring(6);
            if (data === '[DONE]') {
              this.isStreaming = false;
              handlers.onComplete?.();
              return;
            }
            try {
              const parsed = JSON.parse(data);
              handlers.onChunk({
                id: generateId(),
                content: parsed.content || '',
                isThinking: parsed.is_thinking || false,
                thinkingContent: parsed.thinking_content,
                isComplete: false,
              });
            } catch {
              // Handle plain text chunks
              handlers.onChunk({
                id: generateId(),
                content: data,
                isComplete: false,
              });
            }
          }
        }
      }

      handlers.onComplete?.();
    } catch (error) {
      if (error instanceof Error && error.name !== 'AbortError') {
        handlers.onError?.(error);
      }
    } finally {
      this.isStreaming = false;
      this.abortController = null;
    }
  }

  stop(): void {
    this.isStreaming = false;
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
  }

  get isActive(): boolean {
    return this.isStreaming;
  }
}

export const streamingService = new StreamingService();
