// ============================================================
// Frox AI – Search Service
// ============================================================

import type { Conversation, Message, Attachment, SearchResult } from '../types/index';

class SearchService {
  searchConversations(
    conversations: Conversation[],
    query: string
  ): Conversation[] {
    if (!query.trim()) return conversations;
    const lowerQuery = query.toLowerCase();
    return conversations.filter(c =>
      c.title.toLowerCase().includes(lowerQuery) ||
      c.tags.some(t => t.toLowerCase().includes(lowerQuery)) ||
      c.summary?.toLowerCase().includes(lowerQuery)
    );
  }

  searchMessages(
    messages: Message[],
    query: string
  ): Message[] {
    if (!query.trim()) return messages;
    const lowerQuery = query.toLowerCase();
    return messages.filter(m =>
      m.content.toLowerCase().includes(lowerQuery) ||
      m.attachments.some(a => a.name.toLowerCase().includes(lowerQuery))
    );
  }

  searchFiles(
    attachments: Attachment[],
    query: string
  ): Attachment[] {
    if (!query.trim()) return attachments;
    const lowerQuery = query.toLowerCase();
    return attachments.filter(a =>
      a.name.toLowerCase().includes(lowerQuery) ||
      a.type.toLowerCase().includes(lowerQuery)
    );
  }

  performGlobalSearch(
    query: string,
    conversations: Conversation[],
    messages: Message[],
    attachments: Attachment[]
  ): SearchResult {
    const foundConversations = this.searchConversations(conversations, query);
    const foundMessages = this.searchMessages(messages, query);
    const foundFiles = this.searchFiles(attachments, query);

    return {
      conversations: foundConversations,
      messages: foundMessages,
      files: foundFiles,
      query,
      totalCount: foundConversations.length + foundMessages.length + foundFiles.length,
    };
  }

  fuzzySearch<T extends { name?: string; title?: string }>(
    items: T[],
    query: string,
    key: keyof T
  ): T[] {
    if (!query.trim()) return items;
    const lowerQuery = query.toLowerCase();
    const terms = lowerQuery.split(/\s+/);

    return items.filter(item => {
      const value = String(item[key] || '').toLowerCase();
      return terms.every(term => value.includes(term));
    });
  }
}

export const searchService = new SearchService();
