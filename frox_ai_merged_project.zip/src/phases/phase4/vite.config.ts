import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    target: 'esnext',
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-react': ['react', 'react-dom', 'react-router-dom'],
          'vendor-markdown': ['react-markdown', 'remark-gfm', 'rehype-katex', 'remark-math', 'katex'],
          'vendor-ui': ['framer-motion', 'lucide-react', 'react-virtuoso'],
          'vendor-utils': ['zustand', '@tanstack/react-query', 'date-fns', 'uuid', 'zod'],
          'vendor-mermaid': ['mermaid'],
          'vendor-shiki': ['shiki'],
        }
      }
    }
  },
  optimizeDeps: {
    include: ['react', 'react-dom', 'framer-motion']
  }
})
