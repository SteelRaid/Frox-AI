# Frox AI – Phase 4: AI Chat Engine

A production-quality AI chat experience built with React 19, TypeScript, Vite, and Tailwind CSS.

## Features

- **Streaming AI Responses** – Real-time token-by-token streaming with thinking indicators
- **Premium Markdown Rendering** – GitHub Flavored Markdown, KaTeX math, Mermaid diagrams
- **Syntax Highlighting** – Code blocks with line numbers and copy functionality
- **Advanced Composer** – Auto-growing textarea, drag-and-drop uploads, paste support
- **Conversation Management** – Pin, archive, favorite, search, sort conversations
- **Model Selector** – Multiple AI models with temperature and token controls
- **Responsive Design** – Collapsible sidebar, mobile drawer, tablet/desktop layouts
- **Right Info Panel** – Conversation details, token usage, model settings
- **Command Palette** – Quick search and navigation with keyboard shortcuts
- **Theme System** – Light, dark, and system theme modes
- **Accessibility** – ARIA labels, keyboard navigation, focus management
- **Performance** – Virtualized message lists, code splitting, lazy loading

## Tech Stack

- React 19 + TypeScript
- Vite (build tool)
- Tailwind CSS 4
- Framer Motion (animations)
- Zustand (state management)
- React Router (routing)
- React Query (data fetching)
- React Markdown + remark-gfm + rehype-katex
- KaTeX (math rendering)
- Mermaid (diagrams)
- React Virtuoso (virtualization)
- Lucide React (icons)

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Project Structure

```
src/
  components/     # React components
    chat/         # Chat page, message list, message items
    composer/     # Input area, attachments, model selector
    sidebar/      # Navigation sidebar, conversation list
    markdown/     # Markdown renderer, code blocks, diagrams
    layout/       # Top bar, right panel, command palette, toasts
    ui/           # Reusable UI components
  stores/         # Zustand state stores
  hooks/          # Custom React hooks
  services/       # Business logic services
  providers/      # Context providers
  layouts/        # Page layouts
  types/          # TypeScript types
  utils/          # Utility functions
  constants/      # App constants
  animations/     # Framer Motion variants
  styles/         # Global styles
```

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+Shift+O | New Chat |
| Ctrl+K | Open Command Palette |
| Ctrl+B | Toggle Sidebar |
| Ctrl+Shift+A | Archive Chat |
| Ctrl+Shift+D | Delete Chat |
| Ctrl+, | Open Settings |
| Escape | Close Modals |

## License

MIT
