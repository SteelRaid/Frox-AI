# Frox AI — Phase 7 Memory Engine

This phase adds a dedicated long-term memory system for Frox AI.

## Includes
- Intelligent memory capture, ranking, search, summarization, and cleanup
- Knowledge base, projects, collections, tags, and attachments
- IndexedDB cache with Dexie
- Supabase-ready schema, RLS, triggers, and storage policies
- Semantic search with Fuse.js plus local ranking heuristics
- Realtime sync queue, conflict resolution, and offline support
- Dashboard, editor, timeline, graph, and search pages

## Notes
The project is structured as a standalone Vite app and follows the same architectural style as the earlier Frox phases.
