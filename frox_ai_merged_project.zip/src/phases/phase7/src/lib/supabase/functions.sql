create or replace function search_memories(
  p_workspace_id uuid,
  p_query text,
  p_limit integer default 20
)
returns table (
  id uuid,
  title text,
  summary text,
  score numeric,
  updated_at timestamptz
)
language sql
as $$
  select
    m.id,
    m.title,
    m.summary,
    greatest(
      0,
      1 - coalesce(ts_rank_cd(to_tsvector('english', m.title || ' ' || m.summary || ' ' || m.content), plainto_tsquery('english', p_query)), 0)
      + coalesce(m.importance, 0)
      + case when m.pinned then 0.2 else 0 end
    ) as score,
    m.updated_at
  from memories m
  where m.workspace_id = p_workspace_id
    and m.status <> 'deleted'
    and (
      p_query = '' or
      to_tsvector('english', m.title || ' ' || m.summary || ' ' || m.content) @@ plainto_tsquery('english', p_query)
    )
  order by score desc, m.updated_at desc
  limit p_limit;
$$;

create or replace function archive_expired_memories(p_workspace_id uuid)
returns integer
language plpgsql
as $$
declare
  archived_count integer := 0;
begin
  update memories
  set status = 'archived',
      archived_at = now(),
      updated_at = now()
  where workspace_id = p_workspace_id
    and status = 'active'
    and expires_at is not null
    and expires_at <= now();

  get diagnostics archived_count = row_count;
  return archived_count;
end;
$$;

create or replace function cleanup_deleted_memories(p_workspace_id uuid, p_days integer default 180)
returns integer
language plpgsql
as $$
declare
  deleted_count integer := 0;
begin
  delete from memories
  where workspace_id = p_workspace_id
    and status = 'deleted'
    and updated_at < now() - make_interval(days => p_days);

  get diagnostics deleted_count = row_count;
  return deleted_count;
end;
$$;
