alter table workspaces enable row level security;
alter table projects enable row level security;
alter table collections enable row level security;
alter table memory_folders enable row level security;
alter table memories enable row level security;
alter table memory_versions enable row level security;
alter table memory_relations enable row level security;
alter table attachments enable row level security;
alter table knowledge_notes enable row level security;
alter table saved_searches enable row level security;
alter table sync_events enable row level security;
alter table audit_logs enable row level security;

create policy "workspace_select" on workspaces for select using (true);
create policy "workspace_modify" on workspaces for all using (true) with check (true);

create policy "projects_access" on projects for all using (true) with check (true);
create policy "collections_access" on collections for all using (true) with check (true);
create policy "folders_access" on memory_folders for all using (true) with check (true);
create policy "memories_access" on memories for all using (true) with check (true);
create policy "versions_access" on memory_versions for all using (true) with check (true);
create policy "relations_access" on memory_relations for all using (true) with check (true);
create policy "attachments_access" on attachments for all using (true) with check (true);
create policy "notes_access" on knowledge_notes for all using (true) with check (true);
create policy "searches_access" on saved_searches for all using (true) with check (true);
create policy "sync_access" on sync_events for all using (true) with check (true);
create policy "audit_access" on audit_logs for select using (true);
