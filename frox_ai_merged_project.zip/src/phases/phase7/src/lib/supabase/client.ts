import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

type TableLike = {
  select: () => TableLike;
  insert: (row: Record<string, unknown> | Record<string, unknown>[]) => Promise<{ data: null; error: null }>;
  upsert: (row: Record<string, unknown> | Record<string, unknown>[]) => Promise<{ data: null; error: null }>;
  update: (row: Record<string, unknown>) => TableLike;
  delete: () => TableLike;
  eq: () => TableLike;
  in: () => TableLike;
  order: () => TableLike;
  limit: () => TableLike;
  single: () => Promise<{ data: null; error: null }>;
};

const table = (): TableLike => ({
  select: () => table(),
  insert: async () => ({ data: null, error: null }),
  upsert: async () => ({ data: null, error: null }),
  update: () => table(),
  delete: () => table(),
  eq: () => table(),
  in: () => table(),
  order: () => table(),
  limit: () => table(),
  single: async () => ({ data: null, error: null }),
});

const localClient = {
  from: (_name: string) => table(),
  storage: {
    from: (_bucket: string) => ({
      upload: async (_path: string, _file: File | Blob) => ({ data: null, error: null }),
      remove: async (_paths: string[]) => ({ data: null, error: null }),
      getPublicUrl: (path: string) => ({ data: { publicUrl: `local://${path}` } }),
    }),
  },
  channel: (_name: string) => ({
    on: () => ({ subscribe: () => undefined }),
    subscribe: () => undefined,
    send: async () => ({ data: null, error: null }),
  }),
};

export const supabase: SupabaseClient | typeof localClient = url && anonKey
  ? createClient(url, anonKey, {
      realtime: { params: { eventsPerSecond: 25 } },
    })
  : localClient as typeof localClient;
