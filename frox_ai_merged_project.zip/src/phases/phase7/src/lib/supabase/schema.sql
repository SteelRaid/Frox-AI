create extension if not exists pgcrypto;
create extension if not exists vector;

create table if not exists workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  owner_id uuid,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text not null,
  summary text not null default '',
  instructions text not null default '',
  architecture text not null default '',
  coding_standards text not null default '',
  roadmap text not null default '',
  todos text not null default '',
  status text not null default 'active',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists collections (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  parent_id uuid references collections(id) on delete cascade,
  name text not null,
  description text,
  color text not null default '#8b5cf6',
  icon text,
  sort_order integer not null default 0,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists memory_folders (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  parent_id uuid references memory_folders(id) on delete cascade,
  name text not null,
  description text,
  sort_order integer not null default 0,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists memories (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  collection_id uuid references collections(id) on delete set null,
  folder_id uuid references memory_folders(id) on delete set null,
  conversation_id text,
  parent_id uuid references memories(id) on delete set null,
  title text not null,
  content text not null,
  summary text not null default '',
  type text not null,
  scope text not null,
  visibility text not null default 'private',
  status text not null default 'active',
  pinned boolean not null default false,
  favorite boolean not null default false,
  importance numeric(4,3) not null default 0,
  confidence numeric(4,3) not null default 0,
  quality numeric(4,3) not null default 0,
  tags text[] not null default '{}',
  keywords text[] not null default '{}',
  labels text[] not null default '{}',
  entities jsonb not null default '[]'::jsonb,
  metadata jsonb not null default '{}'::jsonb,
  source text not null default 'user',
  notes text,
  expires_at timestamptz,
  archived_at timestamptz,
  embedding vector(1536),
  checksum text not null,
  version integer not null default 1,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  accessed_at timestamptz not null default now()
);

create table if not exists memory_versions (
  id uuid primary key default gen_random_uuid(),
  memory_id uuid not null references memories(id) on delete cascade,
  version integer not null,
  diff_summary text not null,
  snapshot text not null,
  created_at timestamptz not null default now()
);

create table if not exists memory_relations (
  id uuid primary key default gen_random_uuid(),
  from_memory_id uuid not null references memories(id) on delete cascade,
  to_memory_id uuid not null references memories(id) on delete cascade,
  relation text not null,
  weight numeric(4,3) not null default 0.5,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists attachments (
  id uuid primary key default gen_random_uuid(),
  memory_id uuid not null references memories(id) on delete cascade,
  name text not null,
  mime_type text not null,
  size bigint not null default 0,
  bucket text not null,
  path text not null,
  public_url text,
  checksum text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists knowledge_notes (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  project_id uuid references projects(id) on delete cascade,
  title text not null,
  body text not null,
  tags text[] not null default '{}',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists saved_searches (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  name text not null,
  query text not null,
  filters jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists sync_events (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  type text not null,
  entity_id text not null,
  payload jsonb not null default '{}'::jsonb,
  processed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references workspaces(id) on delete cascade,
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
