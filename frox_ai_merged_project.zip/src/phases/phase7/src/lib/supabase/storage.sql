insert into storage.buckets (id, name, public)
values
  ('memory-attachments', 'memory-attachments', true),
  ('memory-exports', 'memory-exports', false),
  ('memory-avatars', 'memory-avatars', true),
  ('memory-private', 'memory-private', false)
on conflict (id) do nothing;

create policy "memory_attachments_read" on storage.objects for select using (bucket_id = 'memory-attachments');
create policy "memory_attachments_write" on storage.objects for insert with check (bucket_id = 'memory-attachments');
create policy "memory_attachments_update" on storage.objects for update using (bucket_id = 'memory-attachments');
create policy "memory_attachments_delete" on storage.objects for delete using (bucket_id = 'memory-attachments');

create policy "memory_exports_rw" on storage.objects for all using (bucket_id = 'memory-exports') with check (bucket_id = 'memory-exports');
create policy "memory_avatars_rw" on storage.objects for all using (bucket_id = 'memory-avatars') with check (bucket_id = 'memory-avatars');
create policy "memory_private_rw" on storage.objects for all using (bucket_id = 'memory-private') with check (bucket_id = 'memory-private');
