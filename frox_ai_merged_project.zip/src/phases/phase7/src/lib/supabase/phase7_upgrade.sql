-- Phase 7 upgrade: memory intelligence, retrieval, policy, and analytics
create extension if not exists pgcrypto;
create extension if not exists vector;

create table if not exists public.memory_layers (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  project_id uuid null,
  name text not null,
  layer_type text not null,
  description text not null default '',
  importance numeric(4,3) not null default 0.5,
  visibility text not null default 'private',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.memory_signals (
  id uuid primary key default gen_random_uuid(),
  memory_id uuid not null references public.memories(id) on delete cascade,
  workspace_id uuid not null,
  signal_type text not null,
  signal_value text not null,
  weight numeric(4,3) not null default 0.5,
  created_at timestamptz not null default now()
);

create table if not exists public.memory_context_slots (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  memory_id uuid not null references public.memories(id) on delete cascade,
  slot_name text not null,
  slot_order integer not null default 0,
  rationale text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.memory_policy_events (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  memory_id uuid not null references public.memories(id) on delete cascade,
  action text not null,
  reason text not null,
  priority numeric(4,3) not null default 0.5,
  created_at timestamptz not null default now()
);

create index if not exists memory_layers_workspace_idx on public.memory_layers (workspace_id, updated_at desc);
create index if not exists memory_signals_workspace_idx on public.memory_signals (workspace_id, signal_type, created_at desc);
create index if not exists memory_context_slots_workspace_idx on public.memory_context_slots (workspace_id, slot_name, slot_order);
create index if not exists memory_policy_events_workspace_idx on public.memory_policy_events (workspace_id, action, created_at desc);
create index if not exists memories_workspace_importance_idx on public.memories (workspace_id, importance desc, updated_at desc);
create index if not exists memories_workspace_confidence_idx on public.memories (workspace_id, confidence desc, updated_at desc);
create index if not exists memories_workspace_type_idx on public.memories (workspace_id, type, status, pinned);
create index if not exists memories_workspace_project_idx on public.memories (workspace_id, project_id, updated_at desc);

create or replace function public.bump_memory_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function public.create_memory_policy_event(
  p_workspace_id uuid,
  p_memory_id uuid,
  p_action text,
  p_reason text,
  p_priority numeric default 0.5
)
returns uuid
language plpgsql
as $$
declare
  v_id uuid;
begin
  insert into public.memory_policy_events (workspace_id, memory_id, action, reason, priority)
  values (p_workspace_id, p_memory_id, p_action, p_reason, p_priority)
  returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.create_memory_signal(
  p_memory_id uuid,
  p_workspace_id uuid,
  p_signal_type text,
  p_signal_value text,
  p_weight numeric default 0.5
)
returns uuid
language plpgsql
as $$
declare
  v_id uuid;
begin
  insert into public.memory_signals (memory_id, workspace_id, signal_type, signal_value, weight)
  values (p_memory_id, p_workspace_id, p_signal_type, p_signal_value, p_weight)
  returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.rank_memory_score(
  p_importance numeric,
  p_confidence numeric,
  p_quality numeric,
  p_recency numeric,
  p_similarity numeric,
  p_entity_affinity numeric,
  p_project_affinity numeric
)
returns numeric
language sql
immutable
as $$
  select greatest(0, least(1,
    (coalesce(p_importance, 0) * 0.24) +
    (coalesce(p_confidence, 0) * 0.14) +
    (coalesce(p_quality, 0) * 0.14) +
    (coalesce(p_recency, 0) * 0.16) +
    (coalesce(p_similarity, 0) * 0.16) +
    (coalesce(p_entity_affinity, 0) * 0.09) +
    (coalesce(p_project_affinity, 0) * 0.07)
  ));
$$;

create or replace function public.upsert_memory_context_slot(
  p_workspace_id uuid,
  p_memory_id uuid,
  p_slot_name text,
  p_slot_order integer,
  p_rationale text default ''
)
returns uuid
language plpgsql
as $$
declare
  v_id uuid;
begin
  insert into public.memory_context_slots (workspace_id, memory_id, slot_name, slot_order, rationale)
  values (p_workspace_id, p_memory_id, p_slot_name, p_slot_order, p_rationale)
  on conflict do nothing
  returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.cleanup_expired_memories()
returns integer
language plpgsql
as $$
declare
  v_deleted integer := 0;
begin
  delete from public.memories
  where expires_at is not null and expires_at < now() - interval '1 day';
  get diagnostics v_deleted = row_count;
  return v_deleted;
end;
$$;

revoke all on function public.rank_memory_score from public;
grant execute on function public.rank_memory_score to authenticated;
grant execute on function public.create_memory_policy_event to authenticated;
grant execute on function public.create_memory_signal to authenticated;
grant execute on function public.upsert_memory_context_slot to authenticated;
grant execute on function public.cleanup_expired_memories to service_role;
