create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_workspaces_updated on workspaces;
create trigger trg_workspaces_updated
before update on workspaces
for each row execute function set_updated_at();

drop trigger if exists trg_projects_updated on projects;
create trigger trg_projects_updated
before update on projects
for each row execute function set_updated_at();

drop trigger if exists trg_collections_updated on collections;
create trigger trg_collections_updated
before update on collections
for each row execute function set_updated_at();

drop trigger if exists trg_memories_updated on memories;
create trigger trg_memories_updated
before update on memories
for each row execute function set_updated_at();

drop trigger if exists trg_knowledge_notes_updated on knowledge_notes;
create trigger trg_knowledge_notes_updated
before update on knowledge_notes
for each row execute function set_updated_at();

create or replace function insert_memory_version()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'UPDATE' and old.version is distinct from new.version then
    insert into memory_versions (memory_id, version, diff_summary, snapshot)
    values (new.id, new.version, 'Auto version snapshot', row_to_json(new)::text);
  end if;
  return new;
end;
$$;

drop trigger if exists trg_memory_version_insert on memories;
create trigger trg_memory_version_insert
after update on memories
for each row execute function insert_memory_version();

create or replace function log_memory_activity()
returns trigger
language plpgsql
as $$
begin
  insert into audit_logs (workspace_id, action, entity_type, entity_id, payload)
  values (
    coalesce(new.workspace_id, old.workspace_id),
    tg_op,
    tg_table_name,
    coalesce(new.id::text, old.id::text),
    jsonb_build_object('old', to_jsonb(old), 'new', to_jsonb(new))
  );
  return coalesce(new, old);
end;
$$;

drop trigger if exists trg_memory_audit on memories;
create trigger trg_memory_audit
after insert or update or delete on memories
for each row execute function log_memory_activity();
