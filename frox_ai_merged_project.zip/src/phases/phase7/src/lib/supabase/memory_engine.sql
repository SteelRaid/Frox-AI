-- Phase 7: Memory Engine extensions for Supabase/Postgres
create extension if not exists pgcrypto;
create extension if not exists vector;

create table if not exists memory_audit_logs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id uuid not null,
  before jsonb,
  after jsonb,
  created_at timestamptz not null default now()
);

create table if not exists memory_events (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  memory_id uuid references memories(id) on delete cascade,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create materialized view if not exists memory_search_index as
select
  m.id,
  m.workspace_id,
  m.project_id,
  m.collection_id,
  m.conversation_id,
  m.type,
  m.scope,
  m.visibility,
  m.status,
  m.pinned,
  m.favorite,
  m.updated_at,
  setweight(to_tsvector('english', coalesce(m.title, '')), 'A') ||
  setweight(to_tsvector('english', coalesce(m.summary, '')), 'B') ||
  setweight(to_tsvector('english', coalesce(m.content, '')), 'C') ||
  setweight(to_tsvector('english', coalesce(array_to_string(m.tags, ' '), '')), 'C') ||
  setweight(to_tsvector('english', coalesce(array_to_string(m.keywords, ' '), '')), 'C') as document
from memories m
where m.deleted_at is null;

create index if not exists idx_memories_workspace_updated on memories(workspace_id, updated_at desc);
create index if not exists idx_memories_workspace_project on memories(workspace_id, project_id);
create index if not exists idx_memories_workspace_collection on memories(workspace_id, collection_id);
create index if not exists idx_memories_type_status on memories(type, status);
create index if not exists idx_memories_pinned_importance on memories(pinned desc, importance desc);
create index if not exists idx_memories_tags_gin on memories using gin(tags);
create index if not exists idx_memories_keywords_gin on memories using gin(keywords);
create index if not exists idx_memories_labels_gin on memories using gin(labels);
create index if not exists idx_memories_entities_gin on memories using gin(entities);
create index if not exists idx_memory_search_index_document on memory_search_index using gin(document);

create or replace function touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function audit_memory_change()
returns trigger language plpgsql as $$
begin
  insert into memory_audit_logs (workspace_id, actor_id, action, entity_type, entity_id, before, after)
  values (
    coalesce(new.workspace_id, old.workspace_id),
    null,
    tg_op,
    'memory',
    coalesce(new.id, old.id),
    to_jsonb(old),
    to_jsonb(new)
  );
  return coalesce(new, old);
end;
$$;

create or replace function archive_stale_memories(retention_days integer default 120)
returns integer language plpgsql as $$
declare archived_count integer := 0;
begin
  update memories
    set status = 'archived', archived_at = now(), updated_at = now()
  where status = 'active'
    and pinned = false
    and favorite = false
    and updated_at < now() - make_interval(days => retention_days);
  get diagnostics archived_count = row_count;
  return archived_count;
end;
$$;

create or replace function delete_expired_memories()
returns integer language plpgsql as $$
declare deleted_count integer := 0;
begin
  delete from memories
  where deleted_at is not null
    or (expires_at is not null and expires_at <= now());
  get diagnostics deleted_count = row_count;
  return deleted_count;
end;
$$;

create or replace function refresh_memory_search_index()
returns trigger language plpgsql as $$
begin
  refresh materialized view concurrently memory_search_index;
  return null;
end;
$$;

create trigger trig_memories_touch_updated_at
before update on memories
for each row execute function touch_updated_at();

create trigger trig_memories_audit
after insert or update or delete on memories
for each row execute function audit_memory_change();

create trigger trig_projects_touch_updated_at
before update on projects
for each row execute function touch_updated_at();

create trigger trig_collections_touch_updated_at
before update on collections
for each row execute function touch_updated_at();

create or replace view memory_workspace_snapshot as
select
  workspace_id,
  count(*) as memory_count,
  count(*) filter (where status = 'active') as active_count,
  count(*) filter (where pinned = true) as pinned_count,
  count(*) filter (where visibility = 'private') as private_count,
  count(*) filter (where visibility = 'shared') as shared_count,
  count(*) filter (where status = 'archived') as archived_count
from memories
where deleted_at is null
group by workspace_id;
