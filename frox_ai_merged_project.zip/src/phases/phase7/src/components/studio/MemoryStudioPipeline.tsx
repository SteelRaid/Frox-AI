import { ArrowRightLeft, BrainCircuit, Filter, ShieldCheck, Sparkles, Wand2 } from 'lucide-react';
import { Card } from '../ui/index';
import type { MemoryIntelligenceReport } from '../../types/index';

interface MemoryStudioPipelineProps {
  report: MemoryIntelligenceReport;
}

const steps = [
  { label: 'Ingest', icon: Sparkles, detail: 'Capture raw conversation or file inputs.' },
  { label: 'Extract', icon: Wand2, detail: 'Pull entities, topics, and durable signals.' },
  { label: 'Score', icon: BrainCircuit, detail: 'Rank by relevance, recency, quality, and confidence.' },
  { label: 'Filter', icon: Filter, detail: 'Reject transient or low-value memories.' },
  { label: 'Policy', icon: ShieldCheck, detail: 'Apply retention, privacy, and visibility rules.' },
  { label: 'Route', icon: ArrowRightLeft, detail: 'Inject context in the correct order for the model.' },
];

export function MemoryStudioPipeline({ report }: MemoryStudioPipelineProps) {
  return (
    <Card className="border-white/10 bg-white/5 p-5">
      <div className="mb-4">
        <div className="text-sm uppercase tracking-[0.25em] text-neutral-500">Pipeline</div>
        <h2 className="mt-1 text-lg font-semibold text-white">Memory processing stack</h2>
      </div>
      <div className="grid gap-3">
        {steps.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={step.label} className="flex items-start gap-3 rounded-2xl border border-white/10 bg-neutral-950/50 p-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-violet-500/15 text-violet-300">
                <Icon className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-4">
                  <div className="text-sm font-semibold text-white">{index + 1}. {step.label}</div>
                  <div className="text-xs text-neutral-500">{report.ranking[index]?.score ? `score ${report.ranking[index].score.toFixed(2)}` : 'idle'}</div>
                </div>
                <div className="mt-1 text-sm text-neutral-400">{step.detail}</div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
