import { BellRing, CircleCheckBig, CircleDashed, GitMerge, LocateFixed, MessageSquareMore } from 'lucide-react';
import { Card } from '../ui/index';
import type { MemoryIntelligenceReport } from '../../types/index';

interface MemoryStudioSignalsProps {
  report: MemoryIntelligenceReport;
}

export function MemoryStudioSignals({ report }: MemoryStudioSignalsProps) {
  const entries = [
    { label: 'Most relevant memory', value: report.ranking[0]?.title ?? 'None', icon: CircleCheckBig },
    { label: 'Policy action', value: report.policy[0]?.action ?? 'retain', icon: BellRing },
    { label: 'Context slots', value: report.context.slots.length, icon: MessageSquareMore },
    { label: 'Injection order', value: report.context.injectionOrder.length, icon: LocateFixed },
    { label: 'Signals', value: report.signals.join(' • ') || 'No signals detected', icon: CircleDashed },
    { label: 'Conflict mode', value: 'merge-first', icon: GitMerge },
  ];

  return (
    <Card className="border-white/10 bg-white/5 p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <div className="text-sm uppercase tracking-[0.25em] text-neutral-500">Signals</div>
          <h2 className="mt-1 text-lg font-semibold text-white">What the engine is thinking</h2>
        </div>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {entries.map((entry) => {
          const Icon = entry.icon;
          return (
            <div key={entry.label} className="rounded-2xl border border-white/10 bg-neutral-950/50 p-4">
              <div className="flex items-center gap-2 text-sm text-neutral-400"><Icon className="h-4 w-4" /> {entry.label}</div>
              <div className="mt-2 text-sm font-medium text-white">{String(entry.value)}</div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
