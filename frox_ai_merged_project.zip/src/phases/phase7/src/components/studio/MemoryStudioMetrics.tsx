import { Activity, Archive, Database, Layers3, PenTool, Workflow } from 'lucide-react';
import { Card } from '../ui/index';
import type { MemoryWorkspaceInsight } from '../../types/index';

interface MemoryStudioMetricsProps {
  insight: MemoryWorkspaceInsight;
}

const metrics = [
  { label: 'Total memories', icon: Database },
  { label: 'Active memories', icon: Activity },
  { label: 'Pinned memories', icon: Layers3 },
  { label: 'Stale memories', icon: Archive },
  { label: 'Top entities', icon: PenTool },
  { label: 'Activity score', icon: Workflow },
];

export function MemoryStudioMetrics({ insight }: MemoryStudioMetricsProps) {
  const values = [
    insight.totalMemories,
    insight.activeMemories,
    insight.pinnedMemories,
    insight.staleMemories,
    insight.topEntities.slice(0, 5).join(', ') || 'None',
    insight.activityScore.toFixed(2),
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {metrics.map((metric, index) => {
        const Icon = metric.icon;
        return (
          <Card key={metric.label} className="border-white/10 bg-white/5 p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm text-neutral-400">{metric.label}</div>
                <div className="mt-2 text-2xl font-semibold text-white">{values[index]}</div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-neutral-950/60 p-3 text-violet-300">
                <Icon className="h-5 w-5" />
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
