import { Brain, Cpu, Shield, Sparkles } from 'lucide-react';
import { Card, Badge, Button } from '../ui/index';
import type { MemoryIntelligenceReport } from '../../types/index';

interface MemoryStudioHeaderProps {
  report: MemoryIntelligenceReport;
  onRefresh?: () => void;
}

export function MemoryStudioHeader({ report, onRefresh }: MemoryStudioHeaderProps) {
  return (
    <Card className="border-white/10 bg-white/5 p-5 shadow-2xl shadow-violet-500/10">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-violet-300">
            <Brain className="h-5 w-5" />
            <span className="text-sm font-semibold uppercase tracking-[0.3em]">Memory Intelligence Studio</span>
          </div>
          <h1 className="text-2xl font-semibold text-white md:text-3xl">Core memory orchestration, ranking, and context injection</h1>
          <p className="max-w-3xl text-sm leading-6 text-neutral-300">
            This layer ranks durable memories, resolves policy actions, condenses context for prompts, and exposes a real-time control surface for the AI memory engine.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge className="bg-emerald-500/15 text-emerald-300">{report.selectedMemoryIds.length} selected</Badge>
          <Badge className="bg-sky-500/15 text-sky-300">{report.ranking.length} ranked</Badge>
          <Badge className="bg-amber-500/15 text-amber-300">{report.policy.length} policy checks</Badge>
          <Button onClick={onRefresh} className="rounded-2xl bg-violet-500/90 text-white hover:bg-violet-500">
            <Sparkles className="mr-2 h-4 w-4" /> Refresh intelligence
          </Button>
        </div>
      </div>
      <div className="mt-5 grid gap-3 md:grid-cols-3">
        <div className="rounded-2xl border border-white/10 bg-neutral-950/60 p-4">
          <div className="flex items-center gap-2 text-sm text-neutral-400"><Cpu className="h-4 w-4" /> Active query</div>
          <div className="mt-2 text-sm font-medium text-white">{report.query || 'No search query yet'}</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-neutral-950/60 p-4">
          <div className="flex items-center gap-2 text-sm text-neutral-400"><Shield className="h-4 w-4" /> Context budget</div>
          <div className="mt-2 text-sm font-medium text-white">{report.context.totalTokens} tokens in play</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-neutral-950/60 p-4">
          <div className="flex items-center gap-2 text-sm text-neutral-400"><Sparkles className="h-4 w-4" /> Signals</div>
          <div className="mt-2 flex flex-wrap gap-2">
            {report.signals.slice(0, 5).map((signal) => (
              <Badge key={signal} variant="secondary">{signal}</Badge>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
