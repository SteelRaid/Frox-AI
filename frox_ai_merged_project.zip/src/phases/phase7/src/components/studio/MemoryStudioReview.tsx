import { AlertTriangle, GitMerge, ListChecks, Star } from 'lucide-react';
import { Card } from '../ui/index';
import type { MemoryIntelligenceReport } from '../../types/index';

interface MemoryStudioReviewProps {
  report: MemoryIntelligenceReport;
}

export function MemoryStudioReview({ report }: MemoryStudioReviewProps) {
  const topRanking = report.ranking.slice(0, 6);
  const topPolicy = report.policy.slice(0, 6);

  return (
    <Card className="border-white/10 bg-white/5 p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <div className="text-sm uppercase tracking-[0.25em] text-neutral-500">Review</div>
          <h2 className="mt-1 text-lg font-semibold text-white">Ranking and policy decisions</h2>
        </div>
        <div className="rounded-2xl border border-white/10 bg-neutral-950/50 px-3 py-2 text-xs text-neutral-400">
          {topRanking.length} ranked / {topPolicy.length} policy
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-neutral-950/50 p-4">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white"><Star className="h-4 w-4 text-amber-300" /> Top ranked memories</div>
          <div className="space-y-2">
            {topRanking.map((item, index) => (
              <div key={item.id} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-medium text-white">{index + 1}. {item.title}</div>
                  <div className="text-xs text-violet-300">{item.score.toFixed(2)}</div>
                </div>
                <div className="mt-2 flex flex-wrap gap-2 text-xs text-neutral-400">
                  {item.reasons.slice(0, 3).map((reason) => (
                    <span key={reason} className="rounded-full border border-white/10 bg-neutral-950/50 px-2 py-1">{reason}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-neutral-950/50 p-4">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white"><ListChecks className="h-4 w-4 text-emerald-300" /> Policy results</div>
          <div className="space-y-2">
            {topPolicy.map((item) => (
              <div key={item.memoryId} className="rounded-2xl border border-white/10 bg-white/5 p-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-medium text-white">{item.action}</div>
                  <div className="text-xs text-neutral-400">priority {item.priority.toFixed(2)}</div>
                </div>
                <div className="mt-1 text-sm text-neutral-400">{item.reason}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm text-amber-100">
        <div className="flex items-center gap-2 font-semibold"><AlertTriangle className="h-4 w-4" /> Merge opportunities</div>
        <p className="mt-2 text-amber-50/80">
          The intelligence layer can surface merge candidates, duplicate signals, and review actions so the workspace stays compact and useful.
        </p>
        <div className="mt-3 flex items-center gap-2 text-xs text-amber-100/70">
          <GitMerge className="h-4 w-4" /> {report.policy.filter((item) => item.action === 'review' || item.action === 'promote').length} high-priority review candidates
        </div>
      </div>
    </Card>
  );
}
