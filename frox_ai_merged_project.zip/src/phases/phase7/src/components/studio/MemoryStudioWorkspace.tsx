import { ClipboardList, FolderKanban, LibraryBig, MessageCircleMore, Pin, Search } from 'lucide-react';
import { Card } from '../ui/index';
import type { MemoryIntelligenceReport } from '../../types/index';

interface MemoryStudioWorkspaceProps {
  report: MemoryIntelligenceReport;
}

export function MemoryStudioWorkspace({ report }: MemoryStudioWorkspaceProps) {
  const slots = report.context.slots;
  return (
    <Card className="border-white/10 bg-white/5 p-5">
      <div className="mb-4 flex items-center justify-between gap-4">
        <div>
          <div className="text-sm uppercase tracking-[0.25em] text-neutral-500">Workspace</div>
          <h2 className="mt-1 text-lg font-semibold text-white">Context slots and injection order</h2>
        </div>
        <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-neutral-950/50 px-3 py-2 text-xs text-neutral-400">
          <Search className="h-4 w-4" /> {report.context.injectionOrder.length} entries
        </div>
      </div>
      <div className="grid gap-3 xl:grid-cols-2">
        {slots.map((slot, index) => {
          const iconMap = [Pin, ClipboardList, MessageCircleMore, LibraryBig, FolderKanban, Pin, ClipboardList];
          const Icon = iconMap[index] ?? ClipboardList;
          return (
            <div key={slot.title} className="rounded-2xl border border-white/10 bg-neutral-950/50 p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white"><Icon className="h-4 w-4 text-violet-300" /> {slot.title}</div>
                <div className="text-xs text-neutral-500">limit {slot.limit}</div>
              </div>
              <div className="mt-1 text-sm text-neutral-400">{slot.rationale}</div>
              <div className="mt-3 flex flex-wrap gap-2">
                {slot.items.slice(0, 4).map((item) => (
                  <span key={item.id} className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-neutral-300">{item.title}</span>
                ))}
                {!slot.items.length && <span className="text-xs text-neutral-500">No items in this slot</span>}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-4 rounded-2xl border border-white/10 bg-neutral-950/60 p-4">
        <div className="text-sm font-semibold text-white">Condensed context</div>
        <p className="mt-2 text-sm leading-6 text-neutral-300">{report.context.condensedSummary || 'The router did not find enough content to condense.'}</p>
      </div>
    </Card>
  );
}
