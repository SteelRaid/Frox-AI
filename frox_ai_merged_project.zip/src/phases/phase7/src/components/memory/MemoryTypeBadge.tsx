import type { MemoryType } from '../../types/index';
import { cn } from '../../lib/utils';

export function MemoryTypeBadge({ type }: { type: MemoryType }) {
  return <span className={cn('rounded-full border border-violet-400/20 bg-violet-500/10 px-2 py-1 text-[11px] uppercase tracking-[0.2em] text-violet-200')}>{type.replace('_', ' ')}</span>;
}
