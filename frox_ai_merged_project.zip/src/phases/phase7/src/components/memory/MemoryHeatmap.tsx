import type { HeatmapCell } from '../../types/index';

export function MemoryHeatmap({ cells }: { cells: HeatmapCell[] }) {
  return (
    <div className="grid grid-cols-7 gap-2 rounded-3xl border border-white/10 bg-white/5 p-4">
      {cells.map((cell) => (
        <div key={cell.date} className="aspect-square rounded-lg border border-white/10" style={{ opacity: 0.2 + cell.intensity * 0.8 }} title={`${cell.date}: ${cell.intensity}`} />
      ))}
    </div>
  );
}
