import { useMemoryStore } from '../../stores/index';
import { MemoryTimelineView } from '../timeline/index';

export function MemoryTimeline() {
  const recent = useMemoryStore((state) => state.memories.slice(0, 8));
  return <MemoryTimelineView memoryId={recent[0]?.id} />;
}
