import { useMemoryStore, useSearchStore } from '../../stores/index';
import { MEMORY_TYPES } from '../../constants/index';

export function MemoryFilters() {
  const memories = useMemoryStore((state) => state.memories);
  const filters = useSearchStore((state) => state.filters);
  const setFilters = useSearchStore((state) => state.setFilters);

  return (
    <div className="flex flex-wrap gap-2 rounded-3xl border border-white/10 bg-white/5 p-3">
      <select className="rounded-2xl bg-neutral-950/70 px-3 py-2 text-sm" value={filters.types[0] ?? ''} onChange={(e) => setFilters({ types: e.target.value ? [e.target.value] : [] })}>
        <option value="">All types</option>
        {MEMORY_TYPES.map((type) => <option key={type} value={type}>{type}</option>)}
      </select>
      <span className="rounded-2xl bg-white/5 px-3 py-2 text-sm text-neutral-300">{memories.length} memories</span>
      <button className="rounded-2xl bg-white/5 px-3 py-2 text-sm">Pinned</button>
      <button className="rounded-2xl bg-white/5 px-3 py-2 text-sm">Archived</button>
    </div>
  );
}
