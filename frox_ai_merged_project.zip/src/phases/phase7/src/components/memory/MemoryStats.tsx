import { useMemoryStore } from '../../stores/index';

export function MemoryStats() {
  const stats = useMemoryStore((state) => state.stats);
  return (
    <div className="grid grid-cols-2 gap-3 rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glass">
      <Stat label="Total" value={stats.total} />
      <Stat label="Pinned" value={stats.pinned} />
      <Stat label="Archived" value={stats.archived} />
      <Stat label="Updated today" value={stats.updatedToday} />
    </div>
  );
}
function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-2xl bg-black/20 p-3"><div className="text-[11px] uppercase tracking-[0.25em] text-neutral-500">{label}</div><div className="mt-1 text-2xl font-semibold">{value}</div></div>;
}
