import { motion } from 'framer-motion';
import { Archive, Copy, Pin, Share2, Trash2 } from 'lucide-react';
import type { MemoryItem } from '../../types/index';
import { cn } from '../../lib/utils';
import { MemoryTypeBadge } from './MemoryTypeBadge';
import { cardHover } from '../../animations/index';
import { useMemoryStore } from '../../stores/index';

export function MemoryCard({ memory }: { memory: MemoryItem }) {
  const setSelected = useMemoryStore((state) => state.setSelectedMemory);
  const pinMemory = useMemoryStore((state) => state.pinMemory);
  const archiveMemory = useMemoryStore((state) => state.archiveMemory);
  const duplicateMemory = useMemoryStore((state) => state.duplicateMemory);
  const deleteMemory = useMemoryStore((state) => state.deleteMemory);

  return (
    <motion.article {...cardHover} className={cn('rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glass transition')}
      onClick={() => setSelected(memory.id)}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <MemoryTypeBadge type={memory.type} />
            {memory.pinned ? <Pin className="h-3.5 w-3.5 text-amber-300" /> : null}
          </div>
          <h3 className="mt-3 text-base font-semibold text-white">{memory.title}</h3>
          <p className="mt-2 line-clamp-3 text-sm text-neutral-400">{memory.summary}</p>
        </div>
        <div className="rounded-2xl border border-white/10 bg-neutral-950/60 px-2 py-1 text-xs text-neutral-400">{Math.round(memory.importance * 100)}</div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-neutral-400">
        {memory.tags.slice(0, 4).map((tag) => <span key={tag} className="rounded-full bg-white/5 px-2 py-1">#{tag}</span>)}
      </div>
      <div className="mt-4 flex items-center gap-2 opacity-90">
        <button onClick={(e) => { e.stopPropagation(); void pinMemory(memory.id, !memory.pinned); }} className="rounded-xl border border-white/10 bg-white/5 p-2 hover:bg-white/10"><Pin className="h-4 w-4" /></button>
        <button onClick={(e) => { e.stopPropagation(); void duplicateMemory(memory.id); }} className="rounded-xl border border-white/10 bg-white/5 p-2 hover:bg-white/10"><Copy className="h-4 w-4" /></button>
        <button onClick={(e) => { e.stopPropagation(); void archiveMemory(memory.id); }} className="rounded-xl border border-white/10 bg-white/5 p-2 hover:bg-white/10"><Archive className="h-4 w-4" /></button>
        <button onClick={(e) => { e.stopPropagation(); void deleteMemory(memory.id); }} className="rounded-xl border border-white/10 bg-white/5 p-2 hover:bg-white/10"><Trash2 className="h-4 w-4" /></button>
        <button className="ml-auto rounded-xl border border-white/10 bg-white/5 p-2 hover:bg-white/10"><Share2 className="h-4 w-4" /></button>
      </div>
    </motion.article>
  );
}
