import { Virtuoso } from 'react-virtuoso';
import { useMemoryStore } from '../../stores/index';
import { MemoryCard } from './MemoryCard';

export function MemoryList() {
  const memories = useMemoryStore((state) => state.memories);
  return (
    <div className="h-[calc(100vh-160px)] rounded-3xl border border-white/10 bg-black/20 p-3">
      <Virtuoso
        style={{ height: '100%' }}
        data={memories}
        itemContent={(_, memory) => <div className="p-2"><MemoryCard memory={memory} /></div>}
      />
    </div>
  );
}
