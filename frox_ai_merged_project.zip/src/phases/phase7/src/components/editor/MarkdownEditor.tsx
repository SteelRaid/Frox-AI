import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

export function MarkdownEditor({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <textarea value={value} onChange={(e) => onChange(e.target.value)} className="min-h-[320px] rounded-3xl border border-white/10 bg-black/30 p-4 text-sm outline-none" />
      <div className="prose prose-invert max-w-none rounded-3xl border border-white/10 bg-white/5 p-4">
        <ReactMarkdown remarkPlugins={[remarkGfm, remarkMath]} rehypePlugins={[rehypeKatex]}>{value || 'Preview...'}</ReactMarkdown>
      </div>
    </div>
  );
}
