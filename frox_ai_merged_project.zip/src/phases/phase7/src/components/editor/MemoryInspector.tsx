import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Shield, Tag, Wand2 } from 'lucide-react';
import { useMemoryEngine } from '../../hooks/useMemoryEngine';
import { Card } from '../ui/index';

export function MemoryInspector() {
  const { selected, decisions, context } = useMemoryEngine();
  if (!selected) {
    return <Card className="border-white/10 bg-white/5 p-5 text-sm text-neutral-400">Select a memory to inspect its decision trail and context bundle.</Card>;
  }
  return (
    <Card className="border-white/10 bg-white/5 p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-base font-semibold text-white">Memory Inspector</h3>
          <p className="mt-1 text-sm text-neutral-400">Decision, context, and safety metadata for {selected.title}.</p>
        </div>
        <Wand2 className="h-4 w-4 text-violet-300" />
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <Field label="Action" value={decisions?.action ?? selected.type} />
        <Field label="Confidence" value={decisions ? `${Math.round(decisions.confidence * 100)}%` : `${Math.round(selected.confidence * 100)}%`} />
        <Field label="Tags" value={selected.tags.join(', ')} icon={<Tag className="h-4 w-4" />} />
        <Field label="Visibility" value={selected.visibility} icon={<Shield className="h-4 w-4" />} />
      </div>
      {context ? (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="mt-4 overflow-auto rounded-3xl border border-white/10 bg-neutral-950/70 p-4 text-xs leading-6 text-neutral-300 whitespace-pre-wrap">
          <div className="text-sm font-medium text-white">Context summary</div>
          <p className="mt-2">{context.summary}</p>
          <div className="mt-4 text-sm font-medium text-white">Recent context</div>
          <p className="mt-2">{context.recent.map((item) => `• ${item.title}: ${item.summary}`).join('\n')}</p>
        </motion.div>
      ) : null}
    </Card>
  );
}

function Field({ label, value, icon }: { label: string; value: string; icon?: ReactNode }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-neutral-950/60 p-4">
      <p className="flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-neutral-500">{icon}{label}</p>
      <p className="mt-2 text-sm text-white">{value || '—'}</p>
    </div>
  );
}
