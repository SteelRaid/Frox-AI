import type { MemoryItem } from '../../types/index';
export function MemoryPreview({ memory }: { memory: MemoryItem }) {
  return <div className="rounded-3xl border border-white/10 bg-white/5 p-4"><div className="text-sm font-semibold">{memory.title}</div><p className="mt-2 text-sm text-neutral-400">{memory.summary}</p></div>;
}
