import { useEditorStore } from '../../stores/index';
import { MarkdownEditor } from './MarkdownEditor';

export function MemoryEditor() {
  const draft = useEditorStore((state) => state.draft);
  const setDraft = useEditorStore((state) => state.setDraft);
  return <MarkdownEditor value={draft.content} onChange={(content) => setDraft({ content, summary: content.slice(0, 240), title: content.slice(0, 70) })} />;
}
