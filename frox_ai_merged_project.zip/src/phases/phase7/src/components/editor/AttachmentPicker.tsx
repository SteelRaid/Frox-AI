import { Paperclip } from 'lucide-react';

export function AttachmentPicker({ onSelect }: { onSelect: (files: FileList) => void }) {
  return <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm"><Paperclip className="h-4 w-4" /><input type="file" multiple className="hidden" onChange={(e) => e.target.files && onSelect(e.target.files)} />Attach files</label>;
}
