import type { KnowledgeBaseEntry } from '../../types/index';
export function KnowledgeNoteCard({ note }: { note: KnowledgeBaseEntry }) { return <div className="rounded-3xl border border-white/10 bg-white/5 p-4"><div className="text-sm font-semibold">{note.title}</div><p className="mt-2 text-sm text-neutral-400">{note.summary}</p></div>; }
