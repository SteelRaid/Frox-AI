import type { MemoryProject } from '../../types/index';
export function ProjectKnowledgeCard({ project }: { project: MemoryProject }) { return <div className="rounded-3xl border border-white/10 bg-white/5 p-4"><div className="text-sm font-semibold">{project.name}</div><p className="mt-2 text-sm text-neutral-400">{project.summary}</p></div>; }
