import { useMemoryStore } from '../../stores/index';
export function KnowledgeGraphSummary() { const total = useMemoryStore((s) => s.memories.length); return <div className="rounded-3xl border border-white/10 bg-white/5 p-4 text-sm text-neutral-300">{total} memories available for graph clustering.</div>; }
