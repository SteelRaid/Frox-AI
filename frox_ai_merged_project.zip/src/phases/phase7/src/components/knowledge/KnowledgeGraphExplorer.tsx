import { motion } from 'framer-motion';
import { Share2, Sparkles } from 'lucide-react';
import { useMemoryEngine } from '../../hooks/useMemoryEngine';
import { Card } from '../ui/index';

export function KnowledgeGraphExplorer() {
  const { graph } = useMemoryEngine();
  return (
    <Card className="overflow-hidden border-white/10 bg-white/5 p-0">
      <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
        <div>
          <h3 className="text-base font-semibold text-white">Knowledge Graph Explorer</h3>
          <p className="text-sm text-neutral-400">Clusters, links, and neighborhood intelligence.</p>
        </div>
        <div className="rounded-2xl bg-white/5 p-2 text-violet-300"><Sparkles className="h-4 w-4" /></div>
      </div>
      <div className="grid gap-3 p-5">
        {graph.clusters.slice(0, 4).map((cluster) => (
          <motion.div key={cluster.id} whileHover={{ x: 2 }} className="rounded-3xl border border-white/10 bg-neutral-950/60 p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-medium text-white">{cluster.label}</p>
                <p className="text-xs text-neutral-500">{cluster.memoryIds.length} memories • density {cluster.density.toFixed(2)}</p>
              </div>
              <Share2 className="h-4 w-4 text-neutral-500" />
            </div>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}
