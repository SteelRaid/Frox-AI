import { useKnowledgeStore } from '../../stores/index';
import { KnowledgeNoteCard } from './KnowledgeNoteCard';
export function KnowledgeBasePanel() {
  const notes = useKnowledgeStore((state) => state.notes);
  return <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{notes.map((note) => <KnowledgeNoteCard key={note.id} note={note} />)}</div>;
}
