import { cn } from '../../lib/utils';
import type { HTMLAttributes, ReactNode } from 'react';
export function Badge({ className, children, ...props }: HTMLAttributes<HTMLSpanElement> & { children: ReactNode }) { return <span className={cn('inline-flex rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[11px] uppercase tracking-[0.2em] text-neutral-300', className)} {...props}>{children}</span>; }
