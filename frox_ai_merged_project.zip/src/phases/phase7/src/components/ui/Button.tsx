import { cn } from '../../lib/utils';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
export function Button({ className, children, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) { return <button className={cn('inline-flex items-center justify-center rounded-2xl bg-violet-500 px-4 py-2 text-sm font-medium text-white shadow-lg shadow-violet-500/20 transition hover:bg-violet-400 disabled:opacity-50', className)} {...props}>{children}</button>; }
