import { cn } from '../../lib/utils';
import type { InputHTMLAttributes } from 'react';
export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) { return <input className={cn('w-full rounded-2xl border border-white/10 bg-neutral-950/60 px-4 py-3 text-sm outline-none placeholder:text-neutral-600 focus:border-violet-400/60', className)} {...props} />; }
