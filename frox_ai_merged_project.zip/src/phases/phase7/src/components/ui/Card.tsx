import { cn } from '../../lib/utils';
import type { HTMLAttributes, ReactNode } from 'react';
export function Card({ className, children, ...props }: HTMLAttributes<HTMLDivElement> & { children: ReactNode }) { return <div className={cn('rounded-3xl border border-white/10 bg-white/5 shadow-glass backdrop-blur-xl', className)} {...props}>{children}</div>; }
