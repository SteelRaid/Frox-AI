import { useMemoryStore } from '../../stores/index';
import { TimelineItem } from './TimelineItem';

export function MemoryTimelineView({ memoryId }: { memoryId?: string }) {
  const memory = useMemoryStore((state) => state.memories.find((item) => item.id === memoryId));
  const recent = useMemoryStore((state) => state.memories.slice(0, 5));
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glass">
      <div className="text-sm font-semibold">Timeline</div>
      <div className="mt-3 space-y-2">{(memory ? [memory, ...recent] : recent).map((item) => <TimelineItem key={item.id} memory={item} />)}</div>
    </div>
  );
}
