export function TimelineHeader() { return <div className="text-sm font-semibold text-white">Memory timeline</div>; }
