import type { MemoryItem } from '../../types/index';
import { formatRelativeTime } from '../../utils/index';
export function TimelineItem({ memory }: { memory: MemoryItem }) {
  return <div className="rounded-2xl border border-white/10 bg-white/5 p-3"><div className="text-sm font-medium">{memory.title}</div><div className="text-xs text-neutral-500">{formatRelativeTime(memory.updatedAt)}</div></div>;
}
