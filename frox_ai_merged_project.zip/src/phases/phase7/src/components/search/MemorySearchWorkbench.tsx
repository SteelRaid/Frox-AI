import { Search, SlidersHorizontal } from 'lucide-react';
import { useSearchStore } from '../../stores/index';
import { Card, Input } from '../ui/index';
import { useMemoryEngine } from '../../hooks/useMemoryEngine';

export function MemorySearchWorkbench() {
  const query = useSearchStore((state) => state.query);
  const setQuery = useSearchStore((state) => state.setQuery);
  const { similar } = useMemoryEngine();
  return (
    <Card className="border-white/10 bg-white/5 p-5">
      <div className="flex items-center gap-3">
        <div className="rounded-2xl bg-white/5 p-3 text-violet-300"><Search className="h-4 w-4" /></div>
        <div className="flex-1">
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search memories, projects, people, tools, and prompts" />
        </div>
        <button className="rounded-2xl border border-white/10 bg-white/5 p-3 text-neutral-300"><SlidersHorizontal className="h-4 w-4" /></button>
      </div>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {similar.slice(0, 4).map((result) => (
          <div key={result.memory.id} className="rounded-2xl border border-white/10 bg-neutral-950/60 p-3 text-sm text-neutral-300">
            <div className="font-medium text-white">{result.memory.title}</div>
            <div className="mt-1 text-xs text-neutral-500">Score {result.score.toFixed(2)} • {result.reasons.join(' • ')}</div>
          </div>
        ))}
      </div>
    </Card>
  );
}
