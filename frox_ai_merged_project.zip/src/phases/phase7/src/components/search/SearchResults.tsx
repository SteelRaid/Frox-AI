import { Virtuoso } from 'react-virtuoso';
import { useMemorySearch } from '../../hooks/index';
import { MemoryCard } from '../memory/index';

export function SearchResults() {
  const results = useMemorySearch();
  return (
    <div className="rounded-3xl border border-white/10 bg-black/20 p-3">
      <Virtuoso
        style={{ height: '70vh' }}
        data={results}
        itemContent={(_, result) => <div className="p-2"><MemoryCard memory={result.item} /></div>}
      />
    </div>
  );
}
