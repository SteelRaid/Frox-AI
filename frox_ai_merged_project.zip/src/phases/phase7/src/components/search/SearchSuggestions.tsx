import { useSearchStore } from '../../stores/index';

export function SearchSuggestions() {
  const suggestions = useSearchStore((state) => state.suggestions);
  if (!suggestions.length) return null;
  return <div className="rounded-3xl border border-white/10 bg-white/5 p-3 text-sm text-neutral-300">{suggestions.slice(0, 6).map((suggestion) => <div key={suggestion.id}>#{suggestion.value}</div>)}</div>;
}
