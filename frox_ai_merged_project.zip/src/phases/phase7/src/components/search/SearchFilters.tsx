import { useSearchStore } from '../../stores/index';

export function SearchFilters() {
  const filters = useSearchStore((state) => state.filters);
  const setFilters = useSearchStore((state) => state.setFilters);
  return (
    <div className="flex flex-wrap gap-2 rounded-3xl border border-white/10 bg-white/5 p-3">
      <button onClick={() => setFilters({ pinnedOnly: !filters.pinnedOnly })} className="rounded-2xl bg-white/5 px-3 py-2 text-sm">Pinned</button>
      <button onClick={() => setFilters({ archivedOnly: !filters.archivedOnly })} className="rounded-2xl bg-white/5 px-3 py-2 text-sm">Archived</button>
      <button onClick={() => setFilters({ favoritesOnly: !filters.favoritesOnly })} className="rounded-2xl bg-white/5 px-3 py-2 text-sm">Favorites</button>
    </div>
  );
}
