import { Search } from 'lucide-react';
import { useSearchStore } from '../../stores/index';

export function SearchBar() {
  const query = useSearchStore((state) => state.query);
  const setQuery = useSearchStore((state) => state.setQuery);
  return (
    <div className="flex items-center gap-3 rounded-3xl border border-white/10 bg-white/5 px-4 py-3">
      <Search className="h-4 w-4 text-neutral-500" />
      <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search memory by keyword, person, project, or tag" className="w-full bg-transparent text-sm outline-none placeholder:text-neutral-600" />
    </div>
  );
}
