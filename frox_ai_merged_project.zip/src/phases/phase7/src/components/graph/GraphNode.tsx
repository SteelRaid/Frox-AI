import type { GraphNode as GraphNodeType } from '../../types/index';
export function GraphNode({ node }: { node: GraphNodeType }) {
  return <div className="absolute rounded-full border border-violet-300/30 bg-violet-500/20 px-3 py-2 text-xs text-violet-100 shadow-glass" style={{ left: node.x, top: node.y, width: node.size * 3, height: node.size * 3 }}>{node.label}</div>;
}
