import { buildGraphFromMemories } from '../../utils/index';
import { useMemoryStore } from '../../stores/index';
import { GraphNode } from './GraphNode';
import { GraphLegend } from './GraphLegend';

export function KnowledgeGraph() {
  const memories = useMemoryStore((state) => state.memories);
  const { nodes } = buildGraphFromMemories(memories);
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glass">
      <div className="flex items-center justify-between"><div className="text-sm font-semibold">Knowledge Graph</div><GraphLegend /></div>
      <div className="relative mt-4 h-[420px] overflow-hidden rounded-3xl border border-white/10 bg-black/20">
        {nodes.map((node) => <GraphNode key={node.id} node={node} />)}
      </div>
    </div>
  );
}
