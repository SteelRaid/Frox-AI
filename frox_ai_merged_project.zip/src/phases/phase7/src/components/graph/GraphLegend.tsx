export function GraphLegend() { return <div className="flex gap-2 text-xs text-neutral-400"><span>Memory</span><span>Project</span><span>Person</span></div>; }
