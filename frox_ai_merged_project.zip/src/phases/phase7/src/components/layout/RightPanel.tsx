import { useMemoryStore } from '../../stores/index';
import { MemoryStats } from '../memory/index';
import { MemoryTimelineView } from '../timeline/index';

export function RightPanel() {
  const selectedMemoryId = useMemoryStore((state) => state.selectedMemoryId);
  const memory = useMemoryStore((state) => state.memories.find((item) => item.id === selectedMemoryId) ?? null);

  return (
    <aside className="hidden w-[360px] shrink-0 border-l border-white/10 bg-white/5 p-4 backdrop-blur-xl xl:flex xl:flex-col xl:gap-4">
      <MemoryStats />
      <div className="rounded-3xl border border-white/10 bg-neutral-900/60 p-4 shadow-glass">
        <div className="text-sm font-semibold">Active memory</div>
        <div className="mt-2 text-sm text-neutral-400">{memory ? memory.title : 'Select a memory to inspect details, versions, and relationships.'}</div>
      </div>
      <MemoryTimelineView memoryId={selectedMemoryId ?? undefined} />
    </aside>
  );
}
