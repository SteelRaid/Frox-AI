export function ToastStack() {
  return (
    <div className="pointer-events-none fixed right-4 top-4 z-50 space-y-2">
      <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-neutral-300 shadow-glass backdrop-blur-xl">Sync ready.</div>
    </div>
  );
}
