import { NavLink } from 'react-router-dom';
import { Brain, FolderKanban, LayoutDashboard, Search, Settings, Sparkles } from 'lucide-react';
import { ROUTES } from '../../constants/index';
import { cn } from '../../lib/utils';

const items = [
  { to: ROUTES.dashboard, label: 'Dashboard', icon: LayoutDashboard },
  { to: ROUTES.library, label: 'Library', icon: Brain },
  { to: ROUTES.search, label: 'Search', icon: Search },
  { to: ROUTES.projects, label: 'Projects', icon: FolderKanban },
  { to: ROUTES.knowledge, label: 'Knowledge', icon: Sparkles },
  { to: ROUTES.settings, label: 'Settings', icon: Settings },
];

export function Sidebar() {
  return (
    <aside className="hidden w-[292px] shrink-0 border-r border-white/10 bg-white/5 p-4 backdrop-blur-xl lg:flex lg:flex-col">
      <div className="mb-6 rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glass">
        <div className="text-xs uppercase tracking-[0.3em] text-violet-300/80">Frox AI</div>
        <div className="mt-1 text-lg font-semibold">Memory Engine</div>
        <div className="mt-2 text-sm text-neutral-400">Long-term context, knowledge, and project intelligence.</div>
      </div>
      <nav className="space-y-2">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} className={({ isActive }) => cn('flex items-center gap-3 rounded-2xl px-4 py-3 text-sm transition', isActive ? 'bg-violet-500/15 text-violet-200' : 'text-neutral-300 hover:bg-white/5 hover:text-white')}>
            <Icon className="h-4 w-4" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="mt-auto rounded-3xl border border-white/10 bg-white/5 p-4 text-xs text-neutral-400">
        Offline cache, realtime sync, and semantic search are wired in.
      </div>
    </aside>
  );
}
