import { Bell, Search, SlidersHorizontal } from 'lucide-react';
import { useSearchStore } from '../../stores/index';
import { cn } from '../../lib/utils';

export function TopBar() {
  const query = useSearchStore((state) => state.query);
  const setQuery = useSearchStore((state) => state.setQuery);
  return (
    <header className={cn('border-b border-white/10 bg-neutral-950/80 px-4 py-3 backdrop-blur-xl md:px-6')}>
      <div className="flex items-center gap-3">
        <div className="flex flex-1 items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-neutral-300">
          <Search className="h-4 w-4 text-neutral-500" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search memories, projects, people…" className="w-full bg-transparent outline-none placeholder:text-neutral-600" />
        </div>
        <button className="rounded-2xl border border-white/10 bg-white/5 p-3 text-neutral-300 transition hover:bg-white/10"><SlidersHorizontal className="h-4 w-4" /></button>
        <button className="rounded-2xl border border-white/10 bg-white/5 p-3 text-neutral-300 transition hover:bg-white/10"><Bell className="h-4 w-4" /></button>
      </div>
    </header>
  );
}
