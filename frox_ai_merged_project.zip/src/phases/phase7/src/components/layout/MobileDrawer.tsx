export function MobileDrawer() {
  return (
    <div className="lg:hidden">
      <div className="border-b border-white/10 bg-neutral-950/90 px-4 py-3 text-sm text-neutral-300 backdrop-blur-xl">Frox Memory Engine</div>
    </div>
  );
}
