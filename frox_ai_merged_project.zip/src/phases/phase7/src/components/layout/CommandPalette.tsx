import { Command } from 'lucide-react';

export function CommandPalette() {
  return (
    <div className="pointer-events-none fixed bottom-6 left-1/2 z-50 w-[min(92vw,780px)] -translate-x-1/2 rounded-3xl border border-white/10 bg-neutral-950/80 px-4 py-3 text-sm text-neutral-400 shadow-glass backdrop-blur-xl">
      <div className="flex items-center gap-3"><Command className="h-4 w-4 text-violet-300" />Global commands, memory creation, cleanup, export, and search are wired through the app stores.</div>
    </div>
  );
}
