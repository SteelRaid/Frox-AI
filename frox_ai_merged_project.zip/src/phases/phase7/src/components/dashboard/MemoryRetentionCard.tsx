import { motion } from 'framer-motion';
import { ArchiveRestore, Clock3, Trash2 } from 'lucide-react';
import { useMemoryRetention } from '../../hooks/index';

export function MemoryRetentionCard() {
  const report = useMemoryRetention();
  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl"
    >
      <div className="flex items-center gap-2">
        <ArchiveRestore className="h-5 w-5 text-cyan-300" />
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">Retention</p>
          <h3 className="mt-1 text-lg font-semibold text-white">Archive and expiration sweep</h3>
        </div>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <Stat icon={ArchiveRestore} label="Retained" value={report.retained} />
        <Stat icon={Clock3} label="Expired" value={report.expired} />
        <Stat icon={Trash2} label="Deleted" value={report.deleted} />
      </div>
    </motion.section>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof ArchiveRestore; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <Icon className="h-4 w-4 text-neutral-400" />
      <div className="mt-2 text-xl font-semibold text-white">{value}</div>
      <div className="mt-1 text-xs uppercase tracking-[0.3em] text-neutral-500">{label}</div>
    </div>
  );
}
