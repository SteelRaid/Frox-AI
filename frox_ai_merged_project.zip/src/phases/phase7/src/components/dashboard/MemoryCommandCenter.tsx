import { motion } from 'framer-motion';
import { BrainCircuit, Import, Search, ShieldCheck, Sparkles, Workflow } from 'lucide-react';
import { useMemoryEngine } from '../../hooks/useMemoryEngine';
import { Card } from '../ui/index';

const actions = [
  { icon: Sparkles, title: 'Smart memory suggestions', body: 'Auto-detect, score, and classify reusable knowledge.' },
  { icon: Search, title: 'Hybrid retrieval', body: 'Keyword, fuzzy, semantic, recent, and project-aware search.' },
  { icon: Workflow, title: 'Context injection', body: 'Build a compact prompt bundle for every conversation.' },
  { icon: ShieldCheck, title: 'Retention policy', body: 'Archive, compress, and delete stale memory safely.' },
];

export function MemoryCommandCenter() {
  const { analytics, graph } = useMemoryEngine();
  return (
    <Card className="overflow-hidden border-white/10 bg-white/5 p-0">
      <div className="border-b border-white/10 px-6 py-5">
        <div className="flex items-center gap-3">
          <div className="rounded-2xl border border-violet-400/20 bg-violet-500/10 p-3 text-violet-300">
            <BrainCircuit className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Memory Command Center</h3>
            <p className="text-sm text-neutral-400">Live engine status for retrieval, ranking, and graph intelligence.</p>
          </div>
        </div>
      </div>
      <div className="grid gap-4 p-6 md:grid-cols-2">
        {actions.map(({ icon: Icon, title, body }) => (
          <motion.div key={title} whileHover={{ y: -2 }} className="rounded-3xl border border-white/10 bg-neutral-950/60 p-4">
            <div className="mb-3 flex items-center gap-3">
              <div className="rounded-2xl bg-white/5 p-2 text-violet-300"><Icon className="h-4 w-4" /></div>
              <h4 className="font-medium text-white">{title}</h4>
            </div>
            <p className="text-sm leading-6 text-neutral-400">{body}</p>
          </motion.div>
        ))}
      </div>
      <div className="grid gap-4 border-t border-white/10 px-6 py-5 sm:grid-cols-3">
        <Metric label="Memories" value={analytics.total} />
        <Metric label="Graph nodes" value={graph.nodes.length} />
        <Metric label="Graph edges" value={graph.edges.length} />
      </div>
    </Card>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}
