import { motion } from 'framer-motion';
import { Database, HardDriveUpload } from 'lucide-react';
import { useMemoryStats } from '../../hooks/index';

export function StorageUsageCard() {
  const { total, recent } = useMemoryStats();
  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl"
    >
      <div className="flex items-center gap-2">
        <Database className="h-5 w-5 text-violet-300" />
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">Storage</p>
          <h3 className="mt-1 text-lg font-semibold text-white">Workspace memory footprint</h3>
        </div>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Metric icon={Database} label="Total memories" value={total} />
        <Metric icon={HardDriveUpload} label="Recent" value={recent.length} />
      </div>
    </motion.section>
  );
}

function Metric({ icon: Icon, label, value }: { icon: typeof Database; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <Icon className="h-4 w-4 text-neutral-400" />
      <div className="mt-2 text-xl font-semibold text-white">{value}</div>
      <div className="mt-1 text-xs uppercase tracking-[0.3em] text-neutral-500">{label}</div>
    </div>
  );
}
