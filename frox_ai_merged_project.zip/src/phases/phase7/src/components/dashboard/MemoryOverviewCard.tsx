import { useMemoryAnalytics } from '../../hooks/index';

export function MemoryOverviewCard() {
  const analytics = useMemoryAnalytics();
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl">
      <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">Overview</p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <Stat label="Total" value={analytics.total} />
        <Stat label="Active" value={analytics.active} />
        <Stat label="Pinned" value={analytics.pinned} />
        <Stat label="Archived" value={analytics.archived} />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <div className="text-xs uppercase tracking-[0.3em] text-neutral-500">{label}</div>
      <div className="mt-2 text-xl font-semibold text-white">{value}</div>
    </div>
  );
}
