import { motion } from 'framer-motion';
import { BrainCircuit, Sigma, Sparkles, TrendingUp } from 'lucide-react';
import { useMemoryAnalytics } from '../../hooks/index';

const items = [
  { label: 'Signal density', icon: Sparkles },
  { label: 'Update velocity', icon: TrendingUp },
  { label: 'Entity surface', icon: BrainCircuit },
  { label: 'Graph complexity', icon: Sigma },
];

export function MemoryInsightsCard() {
  const analytics = useMemoryAnalytics();
  const values = [
    `${Math.round(analytics.averageImportance * 100)}%`,
    `${Math.round(analytics.updateVelocity * 100)}%`,
    `${analytics.topEntities.slice(0, 3).join(', ') || '—'}`,
    `${analytics.timeline.length} days`,
  ];

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">Memory insights</p>
          <h3 className="mt-2 text-lg font-semibold text-white">Signal quality and retrieval strength</h3>
        </div>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {items.map((item, index) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="rounded-2xl border border-white/10 bg-black/20 p-4">
              <div className="flex items-center gap-2 text-neutral-300">
                <Icon className="h-4 w-4" />
                <span className="text-sm">{item.label}</span>
              </div>
              <div className="mt-3 text-xl font-semibold text-white">{values[index]}</div>
            </div>
          );
        })}
      </div>
    </motion.section>
  );
}
