import { motion } from 'framer-motion';
import { Lightbulb, Merge, Pin, Trash2 } from 'lucide-react';
import { useMemoryStore } from '../../stores/index';
import { useMemorySuggestions } from '../../hooks/index';

export function MemorySuggestionsCard() {
  const memories = useMemoryStore((state) => state.memories);
  const workspaceId = useMemoryStore((state) => state.activeWorkspaceId);
  const active = memories[0];
  const suggestions = useMemorySuggestions(active?.content ?? '');

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl"
    >
      <div className="flex items-center gap-2">
        <Lightbulb className="h-5 w-5 text-amber-300" />
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">AI suggestions</p>
          <h3 className="mt-1 text-lg font-semibold text-white">What the memory engine would do</h3>
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {suggestions.length ? suggestions.map((suggestion) => (
          <div key={suggestion.id} className="rounded-2xl border border-white/10 bg-black/20 p-4">
            <div className="flex items-center gap-2 text-sm font-medium text-white">
              {suggestion.kind === 'merge' ? <Merge className="h-4 w-4" /> : suggestion.kind === 'pin' ? <Pin className="h-4 w-4" /> : suggestion.kind === 'forget' ? <Trash2 className="h-4 w-4" /> : <Lightbulb className="h-4 w-4" />}
              <span>{suggestion.title}</span>
            </div>
            <p className="mt-2 text-sm text-neutral-400">{suggestion.reason}</p>
            <div className="mt-3 text-xs text-neutral-500">Confidence {Math.round(suggestion.confidence * 100)}%</div>
          </div>
        )) : (
          <div className="rounded-2xl border border-dashed border-white/10 bg-black/20 p-4 text-sm text-neutral-400">
            No current suggestions for workspace {workspaceId}.
          </div>
        )}
      </div>
    </motion.section>
  );
}
