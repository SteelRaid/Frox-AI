import { motion } from 'framer-motion';
import { Activity, Clock3 } from 'lucide-react';
import { useMemoryStore } from '../../stores/index';

export function RecentActivityCard() {
  const memories = useMemoryStore((state) => state.memories);
  const recent = memories.slice().sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 5);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl"
    >
      <div className="flex items-center gap-2">
        <Activity className="h-5 w-5 text-emerald-300" />
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">Activity</p>
          <h3 className="mt-1 text-lg font-semibold text-white">Recent memory updates</h3>
        </div>
      </div>
      <div className="mt-4 space-y-2">
        {recent.map((memory) => (
          <div key={memory.id} className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-neutral-300">
            <div className="flex items-center gap-2 text-white">
              <Clock3 className="h-4 w-4 text-neutral-500" />
              <span className="font-medium">{memory.title}</span>
            </div>
            <p className="mt-1 text-neutral-400">Updated {new Date(memory.updatedAt).toLocaleString()}</p>
          </div>
        ))}
      </div>
    </motion.section>
  );
}
