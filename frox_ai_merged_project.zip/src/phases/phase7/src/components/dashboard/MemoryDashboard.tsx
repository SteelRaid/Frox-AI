import { MemoryStats, MemoryFilters, MemoryList } from '../memory/index';
import { KnowledgeGraphPanel } from './KnowledgeGraphPanel';
import { StorageUsageCard } from './StorageUsageCard';
import { RecentActivityCard } from './RecentActivityCard';
import { MemoryInsightsCard } from './MemoryInsightsCard';
import { MemorySuggestionsCard } from './MemorySuggestionsCard';
import { MemoryRetentionCard } from './MemoryRetentionCard';
import { MemoryCommandCenter } from './MemoryCommandCenter';

export function MemoryDashboard() {
  return (
    <div className="space-y-6 p-4 md:p-6 lg:p-8">
      <MemoryCommandCenter />
      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-4">
          <MemoryStats />
          <MemoryFilters />
          <MemoryList />
        </div>
        <div className="space-y-4">
          <KnowledgeGraphPanel />
          <StorageUsageCard />
          <RecentActivityCard />
          <MemoryInsightsCard />
          <MemorySuggestionsCard />
          <MemoryRetentionCard />
        </div>
      </div>
    </div>
  );
}
