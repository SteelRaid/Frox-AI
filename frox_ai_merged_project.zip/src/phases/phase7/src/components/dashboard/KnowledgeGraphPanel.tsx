import { motion } from 'framer-motion';
import { Share2 } from 'lucide-react';
import { useMemoryStore } from '../../stores/index';
import { memoryGraphService } from '../../services/index';

export function KnowledgeGraphPanel() {
  const memories = useMemoryStore((state) => state.memories);
  const graph = memoryGraphService.buildGraph(memories);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glass backdrop-blur-xl"
    >
      <div className="flex items-center gap-2">
        <Share2 className="h-5 w-5 text-cyan-300" />
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">Graph</p>
          <h3 className="mt-1 text-lg font-semibold text-white">Knowledge graph summary</h3>
        </div>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Metric label="Nodes" value={graph.nodes.length} />
        <Metric label="Edges" value={graph.edges.length} />
        <Metric label="Density" value={`${Math.round(graph.density * 100)}%`} />
        <Metric label="Clusters" value={graph.clusters} />
      </div>
    </motion.section>
  );
}

function Metric({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <div className="text-xs uppercase tracking-[0.3em] text-neutral-500">{label}</div>
      <div className="mt-2 text-xl font-semibold text-white">{value}</div>
    </div>
  );
}
