import { Outlet } from 'react-router-dom';
import { Sidebar } from '../components/layout/index';
import { TopBar } from '../components/layout/index';
import { RightPanel } from '../components/layout/index';
import { CommandPalette } from '../components/layout/index';
import { ToastStack } from '../components/layout/index';
import { cn } from '../lib/utils';

export function MemoryLayout() {
  return (
    <div className={cn('min-h-screen bg-neutral-950 text-neutral-100 flex overflow-hidden')}>
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar />
        <main className="flex min-w-0 flex-1 overflow-hidden">
          <div className="flex-1 min-w-0 overflow-y-auto">
            <Outlet />
          </div>
          <RightPanel />
        </main>
      </div>
      <CommandPalette />
      <ToastStack />
    </div>
  );
}
