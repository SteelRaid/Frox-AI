import type { ReactNode } from 'react';
export function SidebarLayout({ children }: { children: ReactNode }) {
  return <div className="flex h-full flex-col">{children}</div>;
}
