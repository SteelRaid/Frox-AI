import type { ReactNode } from 'react';
import { cn } from '../lib/utils';

export function DashboardLayout({ children }: { children: ReactNode }) {
  return <div className={cn('p-4 md:p-6 lg:p-8')}>{children}</div>;
}
