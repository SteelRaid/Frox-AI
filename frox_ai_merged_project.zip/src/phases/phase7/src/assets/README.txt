Place application art assets here when integrating with the full Frox media pipeline.
