import { KnowledgeBasePanel } from '../components/knowledge/index';
export function KnowledgeBasePage() { return <div className="p-4 md:p-6 lg:p-8"><KnowledgeBasePanel /></div>; }
