import { MemoryFilters, MemoryList } from '../components/memory/index';
export function LibraryPage() { return <div className="space-y-4 p-4 md:p-6 lg:p-8"><MemoryFilters /><MemoryList /></div>; }
