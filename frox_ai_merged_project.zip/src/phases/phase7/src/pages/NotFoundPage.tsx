import { Link } from 'react-router-dom';
import { ROUTES } from '../constants/index';
export function NotFoundPage() { return <div className="flex min-h-screen items-center justify-center p-8 text-center"><div><h1 className="text-3xl font-bold">Page not found</h1><Link to={ROUTES.dashboard} className="mt-4 inline-block rounded-2xl bg-violet-500 px-4 py-2 text-white">Back to dashboard</Link></div></div>; }
