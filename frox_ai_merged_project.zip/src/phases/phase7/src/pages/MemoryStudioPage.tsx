import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
import { memoryEntityEngine, memoryIntelligenceEngine } from '../engine/index';
import { MemoryStudioHeader, MemoryStudioMetrics, MemoryStudioPipeline, MemoryStudioSignals, MemoryStudioWorkspace, MemoryStudioReview } from '../components/studio/index';

export function MemoryStudioPage() {
  const memories = useMemoryStore((state) => state.memories);
  const projects = useMemoryStore((state) => state.projects);
  const collections = useMemoryStore((state) => state.collections);
  const workspaceId = useMemoryStore((state) => state.activeWorkspaceId);
  const selectedMemoryId = useMemoryStore((state) => state.selectedMemoryId);

  const report = useMemo(
    () =>
      memoryIntelligenceEngine.analyze(memories, projects, collections, {
        workspaceId,
        projectId: memories.find((item) => item.id === selectedMemoryId)?.projectId,
        conversationId: memories.find((item) => item.id === selectedMemoryId)?.conversationId,
        query: memories.find((item) => item.id === selectedMemoryId)?.title ?? '',
      }),
    [memories, projects, collections, workspaceId, selectedMemoryId]
  );

  const insight = useMemo(() => memoryEntityEngine.summarizeWorkspace(memories, workspaceId), [memories, workspaceId]);

  return (
    <div className="space-y-6 p-4 md:p-6 xl:p-8">
      <MemoryStudioHeader report={report} />
      <MemoryStudioMetrics insight={insight} />
      <MemoryStudioReview report={report} />
      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="space-y-6">
          <MemoryStudioPipeline report={report} />
          <MemoryStudioWorkspace report={report} />
        </div>
        <div className="space-y-6">
          <MemoryStudioSignals report={report} />
        </div>
      </div>
    </div>
  );
}
