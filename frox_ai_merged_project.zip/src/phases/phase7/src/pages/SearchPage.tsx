import { SearchBar, SearchResults } from '../components/search/index';
export function SearchPage() { return <div className="space-y-4 p-4 md:p-6 lg:p-8"><SearchBar /><SearchResults /></div>; }
