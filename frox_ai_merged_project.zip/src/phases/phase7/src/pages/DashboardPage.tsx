import { MemoryDashboard } from '../components/dashboard/index';
export function DashboardPage() { return <MemoryDashboard />; }
