import { useSettingsStore } from '../stores/index';
export function SettingsPage() {
  const settings = useSettingsStore();
  const updateSettings = useSettingsStore((state) => state.updateSettings);
  return (
    <div className="space-y-4 p-4 md:p-6 lg:p-8">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
        <h1 className="text-xl font-semibold">Memory Settings</h1>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <label className="flex items-center justify-between rounded-2xl bg-black/20 p-4"><span>Smart memory</span><input type="checkbox" checked={settings.smartMemory} onChange={(e) => updateSettings({ smartMemory: e.target.checked })} /></label>
          <label className="flex items-center justify-between rounded-2xl bg-black/20 p-4"><span>Semantic search</span><input type="checkbox" checked={settings.semanticSearch} onChange={(e) => updateSettings({ semanticSearch: e.target.checked })} /></label>
        </div>
      </div>
    </div>
  );
}
