import { useMemoryStore } from '../stores/index';
import { ProjectKnowledgeCard } from '../components/knowledge/index';
export function ProjectsPage() { const projects = useMemoryStore((state) => state.projects); return <div className="space-y-4 p-4 md:p-6 lg:p-8">{projects.map((project) => <ProjectKnowledgeCard key={project.id} project={project} />)}</div>; }
