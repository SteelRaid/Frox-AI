import { useParams } from 'react-router-dom';
import { useMemoryStore } from '../stores/index';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
export function MemoryDetailPage() {
  const { id } = useParams();
  const memory = useMemoryStore((state) => state.memories.find((item) => item.id === id));
  if (!memory) return <div className="p-8 text-neutral-400">Memory not found.</div>;
  return <div className="space-y-4 p-4 md:p-6 lg:p-8"><h1 className="text-2xl font-semibold">{memory.title}</h1><div className="rounded-3xl border border-white/10 bg-white/5 p-6 prose prose-invert max-w-none"><ReactMarkdown remarkPlugins={[remarkGfm]}>{memory.content}</ReactMarkdown></div></div>;
}
