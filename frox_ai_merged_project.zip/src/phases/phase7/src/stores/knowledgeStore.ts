import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { KnowledgeBaseEntry, KnowledgeCluster } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';

interface KnowledgeState {
  notes: KnowledgeBaseEntry[];
  clusters: KnowledgeCluster[];
}
interface KnowledgeActions {
  addNote: (note: KnowledgeBaseEntry) => void;
  addCluster: (cluster: KnowledgeCluster) => void;
  removeNote: (id: string) => void;
}

export const useKnowledgeStore = create<KnowledgeState & KnowledgeActions>()(
  persist(
    (set) => ({
      notes: [],
      clusters: [],
      addNote: (note) => set((state) => ({ notes: [note, ...state.notes] })),
      addCluster: (cluster) => set((state) => ({ clusters: [cluster, ...state.clusters] })),
      removeNote: (id) => set((state) => ({ notes: state.notes.filter((item) => item.id !== id) })),
    }),
    { name: STORAGE_KEYS.memoryStore + '.knowledge', storage: createJSONStorage(() => localStorage) }
  )
);
