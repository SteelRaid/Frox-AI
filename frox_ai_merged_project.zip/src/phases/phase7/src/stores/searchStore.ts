import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { MemorySearchFilter, SavedSearch, SearchSuggestion } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';

interface SearchState {
  query: string;
  filters: MemorySearchFilter;
  suggestions: SearchSuggestion[];
  savedSearches: SavedSearch[];
}

interface SearchActions {
  setQuery: (query: string) => void;
  setFilters: (filters: Partial<MemorySearchFilter>) => void;
  setSuggestions: (suggestions: SearchSuggestion[]) => void;
  addSavedSearch: (search: SavedSearch) => void;
  removeSavedSearch: (id: string) => void;
}

const defaultFilters: MemorySearchFilter = { query: '', types: [], tags: [], scope: [] };

export const useSearchStore = create<SearchState & SearchActions>()(
  persist(
    (set) => ({
      query: '',
      filters: defaultFilters,
      suggestions: [],
      savedSearches: [],
      setQuery: (query) => set({ query }),
      setFilters: (filters) => set((state) => ({ filters: { ...state.filters, ...filters } })),
      setSuggestions: (suggestions) => set({ suggestions }),
      addSavedSearch: (search) => set((state) => ({ savedSearches: [search, ...state.savedSearches] })),
      removeSavedSearch: (id) => set((state) => ({ savedSearches: state.savedSearches.filter((item) => item.id !== id) })),
    }),
    { name: STORAGE_KEYS.searchStore, storage: createJSONStorage(() => localStorage) }
  )
);
