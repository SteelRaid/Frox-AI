import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { MemoryType, MemoryVisibility } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';

interface EditorDraft {
  title: string;
  content: string;
  summary: string;
  type: MemoryType;
  visibility: MemoryVisibility;
  tags: string[];
  projectId?: string;
  collectionId?: string;
}

interface EditorState {
  draft: EditorDraft;
  isDirty: boolean;
}

interface EditorActions {
  setDraft: (draft: Partial<EditorDraft>) => void;
  resetDraft: () => void;
  markDirty: (dirty: boolean) => void;
}

const initialDraft: EditorDraft = { title: '', content: '', summary: '', type: 'knowledge', visibility: 'private', tags: [] };

export const useEditorStore = create<EditorState & EditorActions>()(
  persist(
    (set) => ({
      draft: initialDraft,
      isDirty: false,
      setDraft: (draft) => set((state) => ({ draft: { ...state.draft, ...draft }, isDirty: true })),
      resetDraft: () => set({ draft: initialDraft, isDirty: false }),
      markDirty: (isDirty) => set({ isDirty }),
    }),
    { name: STORAGE_KEYS.editorStore, storage: createJSONStorage(() => localStorage) }
  )
);
