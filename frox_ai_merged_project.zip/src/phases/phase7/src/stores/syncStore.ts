import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { SyncState } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';

interface SyncActions {
  setSyncState: (state: Partial<SyncState>) => void;
}

export const useSyncStore = create<SyncState & SyncActions>()(
  persist(
    (set) => ({
      pending: 0,
      isOnline: navigator.onLine,
      lastSyncAt: undefined,
      lastError: undefined,
      setSyncState: (state) => set((prev) => ({ ...prev, ...state })),
    }),
    { name: STORAGE_KEYS.syncStore, storage: createJSONStorage(() => localStorage) }
  )
);
