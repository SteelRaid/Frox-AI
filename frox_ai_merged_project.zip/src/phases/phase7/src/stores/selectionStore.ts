import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { STORAGE_KEYS } from '../constants/index';

interface SelectionState {
  selectedIds: string[];
}
interface SelectionActions {
  toggleId: (id: string) => void;
  setSelectedIds: (ids: string[]) => void;
  clearSelectedIds: () => void;
}

export const useSelectionStore = create<SelectionState & SelectionActions>()(
  persist(
    (set) => ({
      selectedIds: [],
      toggleId: (id) => set((state) => ({ selectedIds: state.selectedIds.includes(id) ? state.selectedIds.filter((item) => item !== id) : [...state.selectedIds, id] })),
      setSelectedIds: (selectedIds) => set({ selectedIds }),
      clearSelectedIds: () => set({ selectedIds: [] }),
    }),
    { name: STORAGE_KEYS.selectionStore, storage: createJSONStorage(() => localStorage) }
  )
);
