import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { STORAGE_KEYS } from '../constants/index';

interface DashboardState {
  activeSection: 'overview' | 'timeline' | 'graph' | 'storage' | 'activity';
  selectedRange: '7d' | '30d' | '90d' | '1y';
  compactMode: boolean;
}

interface DashboardActions {
  setActiveSection: (section: DashboardState['activeSection']) => void;
  setSelectedRange: (range: DashboardState['selectedRange']) => void;
  setCompactMode: (value: boolean) => void;
}

export const useDashboardStore = create<DashboardState & DashboardActions>()(
  persist(
    (set) => ({
      activeSection: 'overview',
      selectedRange: '30d',
      compactMode: false,
      setActiveSection: (activeSection) => set({ activeSection }),
      setSelectedRange: (selectedRange) => set({ selectedRange }),
      setCompactMode: (compactMode) => set({ compactMode }),
    }),
    { name: STORAGE_KEYS.dashboardStore, storage: createJSONStorage(() => localStorage) }
  )
);
