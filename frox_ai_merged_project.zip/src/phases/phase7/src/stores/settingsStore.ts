import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { MemorySettings } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';

interface SettingsState extends MemorySettings {}
interface SettingsActions {
  updateSettings: (updates: Partial<MemorySettings>) => void;
  resetSettings: () => void;
}

const initialSettings: MemorySettings = {
  memoryLimits: { maxActiveMemories: 10000, maxPinnedMemories: 200, maxAttachmentsPerMemory: 16, maxMemoryLength: 50000 },
  retentionPolicy: { shortTermDays: 7, temporaryHours: 24, archiveAfterDays: 180, deleteAfterDays: 1095 },
  privacyControls: { allowPersonalMemories: true, allowWorkspaceMemories: true, allowSharedMemories: true, allowAutoSuggestions: true, requireManualApprovalForPrivate: false },
  autoSave: true,
  smartMemory: true,
  semanticSearch: true,
  offlineMode: true,
  encryption: false,
};

export const useSettingsStore = create<SettingsState & SettingsActions>()(
  persist(
    (set) => ({
      ...initialSettings,
      updateSettings: (updates) => set((state) => ({ ...state, ...updates })),
      resetSettings: () => set(initialSettings),
    }),
    { name: STORAGE_KEYS.settingsStore, storage: createJSONStorage(() => localStorage) }
  )
);
