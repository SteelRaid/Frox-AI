import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { MemoryAttachment, MemoryCollection, MemoryItem, MemoryProject, MemoryRelation, MemoryStats } from '../types/index';
import { STORAGE_KEYS } from '../constants/index';
import { createMemoryId } from '../utils/index';
import { memoryService } from '../services/index';

interface MemoryState {
  memories: MemoryItem[];
  collections: MemoryCollection[];
  projects: MemoryProject[];
  relations: MemoryRelation[];
  attachments: MemoryAttachment[];
  activeWorkspaceId: string;
  selectedMemoryId: string | null;
  stats: MemoryStats;
  isHydrated: boolean;
}

interface MemoryActions {
  hydrate: () => Promise<void>;
  setWorkspace: (workspaceId: string) => void;
  addMemory: (memory: MemoryItem) => Promise<void>;
  createMemory: (input: Parameters<typeof memoryService.createMemory>[0]) => Promise<MemoryItem>;
  updateMemory: (id: string, updates: Partial<MemoryItem>) => Promise<MemoryItem>;
  deleteMemory: (id: string) => Promise<void>;
  archiveMemory: (id: string) => Promise<MemoryItem>;
  restoreMemory: (id: string) => Promise<MemoryItem>;
  duplicateMemory: (id: string) => Promise<MemoryItem>;
  pinMemory: (id: string, pinned?: boolean) => Promise<MemoryItem>;
  mergeMemories: (primaryId: string, secondaryId: string) => Promise<MemoryItem>;
  splitMemory: (id: string, parts: string[]) => Promise<MemoryItem[]>;
  setSelectedMemory: (id: string | null) => void;
  setStats: (stats: MemoryStats) => void;
  addCollection: (collection: MemoryCollection) => Promise<void>;
  addProject: (project: MemoryProject) => Promise<void>;
  addRelation: (relation: MemoryRelation) => Promise<void>;
  addAttachment: (attachment: MemoryAttachment) => Promise<void>;
}

export const useMemoryStore = create<MemoryState & MemoryActions>()(
  persist(
    (set, get) => ({
      memories: [],
      collections: [],
      projects: [],
      relations: [],
      attachments: [],
      activeWorkspaceId: 'workspace-default',
      selectedMemoryId: null,
      stats: { total: 0, active: 0, pinned: 0, archived: 0, deleted: 0, privateCount: 0, sharedCount: 0, avgImportance: 0, avgConfidence: 0, storageBytes: 0, updatedToday: 0 },
      isHydrated: false,
      hydrate: async () => {
        const memories = await memoryService.hydrateLocalCache();
        set({ memories, isHydrated: true });
      },
      setWorkspace: (workspaceId) => set({ activeWorkspaceId: workspaceId }),
      addMemory: async (memory) => set((state) => ({ memories: [memory, ...state.memories] })),
      createMemory: async (input) => {
        const memory = await memoryService.createMemory(input);
        set((state) => ({ memories: [memory, ...state.memories] }));
        return memory;
      },
      updateMemory: async (id, updates) => {
        const memory = await memoryService.updateMemory(id, updates);
        set((state) => ({ memories: state.memories.map((item) => (item.id === id ? memory : item)) }));
        return memory;
      },
      deleteMemory: async (id) => {
        await memoryService.deleteMemory(id);
        set((state) => ({ memories: state.memories.filter((item) => item.id !== id) }));
      },
      archiveMemory: async (id) => {
        const memory = await memoryService.archiveMemory(id);
        set((state) => ({ memories: state.memories.map((item) => (item.id === id ? memory : item)) }));
        return memory;
      },
      restoreMemory: async (id) => {
        const memory = await memoryService.restoreMemory(id);
        set((state) => ({ memories: state.memories.map((item) => (item.id === id ? memory : item)) }));
        return memory;
      },
      duplicateMemory: async (id) => {
        const memory = await memoryService.duplicateMemory(id);
        set((state) => ({ memories: [memory, ...state.memories] }));
        return memory;
      },
      pinMemory: async (id, pinned = true) => {
        const memory = await memoryService.pinMemory(id, pinned);
        set((state) => ({ memories: state.memories.map((item) => (item.id === id ? memory : item)) }));
        return memory;
      },
      mergeMemories: async (primaryId, secondaryId) => {
        const memory = await memoryService.mergeMemories(primaryId, secondaryId);
        set((state) => ({ memories: state.memories.filter((item) => item.id !== secondaryId).map((item) => (item.id === primaryId ? memory : item)) }));
        return memory;
      },
      splitMemory: async (id, parts) => {
        const items = await memoryService.splitMemory(id, parts);
        set((state) => ({ memories: [...items, ...state.memories] }));
        return items;
      },
      setSelectedMemory: (id) => set({ selectedMemoryId: id }),
      setStats: (stats) => set({ stats }),
      addCollection: async (collection) => {
        await memoryService.addCollection(collection);
        set((state) => ({ collections: [collection, ...state.collections] }));
      },
      addProject: async (project) => {
        await memoryService.addProject(project);
        set((state) => ({ projects: [project, ...state.projects] }));
      },
      addRelation: async (relation) => {
        await memoryService.addRelation(relation);
        set((state) => ({ relations: [relation, ...state.relations] }));
      },
      addAttachment: async (attachment) => {
        await memoryService.addAttachment(attachment.memoryId, attachment);
        set((state) => ({ attachments: [attachment, ...state.attachments] }));
      },
    }),
    {
      name: STORAGE_KEYS.memoryStore,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        activeWorkspaceId: state.activeWorkspaceId,
        selectedMemoryId: state.selectedMemoryId,
        stats: state.stats,
      }),
    }
  )
);
