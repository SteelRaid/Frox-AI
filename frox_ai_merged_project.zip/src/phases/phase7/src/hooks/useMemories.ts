import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
export function useMemories() {
  const memories = useMemoryStore((state) => state.memories);
  const stats = useMemoryStore((state) => state.stats);
  return useMemo(() => ({ memories, stats }), [memories, stats]);
}
