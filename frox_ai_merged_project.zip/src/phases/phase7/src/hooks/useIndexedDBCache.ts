import { useEffect } from 'react';
import { memoryCache } from '../cache/index';
export function useIndexedDBCache() {
  useEffect(() => {
    memoryCache.getAll().catch(() => undefined);
  }, []);
}
