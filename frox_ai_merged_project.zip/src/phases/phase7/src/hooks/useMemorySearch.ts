import { useMemo } from 'react';
import { useDebouncedValue } from './useDebouncedValue';
import { useMemoryStore, useSearchStore } from '../stores/index';
import { searchService } from '../services/index';
export function useMemorySearch() {
  const memories = useMemoryStore((state) => state.memories);
  const query = useSearchStore((state) => state.query);
  const debounced = useDebouncedValue(query, 180);
  return useMemo(() => searchService.search(memories, debounced), [memories, debounced]);
}
