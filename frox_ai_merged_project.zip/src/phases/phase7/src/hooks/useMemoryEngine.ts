import { useMemo } from 'react';
import { memoryAnalyticsEngine, memoryContextBuilder, memoryDecisionEngine, memoryIntelligenceEngine, memoryKnowledgeGraph, memorySimilarityEngine } from '../engine/index';
import { useMemoryStore } from '../stores/index';

export function useMemoryEngine() {
  const memories = useMemoryStore((state) => state.memories);
  const projects = useMemoryStore((state) => state.projects);
  const collections = useMemoryStore((state) => state.collections);
  const selectedMemoryId = useMemoryStore((state) => state.selectedMemoryId);
  const workspaceId = useMemoryStore((state) => state.activeWorkspaceId);

  return useMemo(() => {
    const selected = memories.find((memory) => memory.id === selectedMemoryId) ?? memories[0];
    const intelligence = memoryIntelligenceEngine.analyze(memories, projects, collections, {
      workspaceId,
      projectId: selected?.projectId,
      conversationId: selected?.conversationId,
      query: selected?.title ?? '',
    });

    return {
      selected,
      decisions: selected ? memoryDecisionEngine.analyze(selected.content, selected) : null,
      analytics: memoryAnalyticsEngine.snapshot(memories),
      dashboard: memoryAnalyticsEngine.dashboard(memories),
      graph: memoryKnowledgeGraph.build(memories),
      context: selected ? memoryContextBuilder.build(memories, projects, collections, selected.workspaceId, selected.title, selected.projectId, selected.conversationId) : null,
      similar: selected ? memorySimilarityEngine.rank(selected, memories, 8) : [],
      intelligence,
      retention: memoryIntelligenceEngine.retentionPlan(memories, workspaceId),
    };
  }, [memories, projects, collections, selectedMemoryId, workspaceId]);
}
