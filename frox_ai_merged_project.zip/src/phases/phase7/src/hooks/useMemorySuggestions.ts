import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
import { suggestionService } from '../services/index';
export function useMemorySuggestions(text: string) {
  const workspaceId = useMemoryStore((state) => state.activeWorkspaceId);
  return useMemo(() => suggestionService.analyze(text, workspaceId), [text, workspaceId]);
}
