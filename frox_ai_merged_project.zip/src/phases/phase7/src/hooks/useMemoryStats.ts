import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
export function useMemoryStats() {
  const memories = useMemoryStore((state) => state.memories);
  return useMemo(() => ({
    total: memories.length,
    pinned: memories.filter((item) => item.pinned).length,
    archived: memories.filter((item) => item.status === 'archived').length,
    recent: memories.slice(0, 8),
  }), [memories]);
}
