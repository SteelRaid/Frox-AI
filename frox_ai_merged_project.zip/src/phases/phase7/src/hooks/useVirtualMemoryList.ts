import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
export function useVirtualMemoryList() {
  const memories = useMemoryStore((state) => state.memories);
  return useMemo(() => memories.slice(0, 200), [memories]);
}
