import { useEffect } from 'react';
export function useAutoSave<T>(value: T, onSave: (value: T) => void, delay = 500) {
  useEffect(() => {
    const handle = window.setTimeout(() => onSave(value), delay);
    return () => window.clearTimeout(handle);
  }, [value, onSave, delay]);
}
