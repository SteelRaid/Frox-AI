import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
import { memoryAnalyticsService } from '../services/index';

export function useMemoryAnalytics() {
  const memories = useMemoryStore((state) => state.memories);
  return useMemo(() => memoryAnalyticsService.buildSnapshot(memories), [memories]);
}
