import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
import { memoryRetentionService } from '../services/index';

export function useMemoryRetention() {
  const memories = useMemoryStore((state) => state.memories);
  return useMemo(() => memoryRetentionService.retentionReport(memories), [memories]);
}
