import { useMemo } from 'react';
import { useMemoryStore } from '../stores/index';
import { memoryContextService } from '../services/index';

export function useMemoryContext(query: string, projectId?: string, conversationId?: string) {
  const memories = useMemoryStore((state) => state.memories);
  const projects = useMemoryStore((state) => state.projects);
  const collections = useMemoryStore((state) => state.collections);
  const workspaceId = useMemoryStore((state) => state.activeWorkspaceId);

  return useMemo(
    () => memoryContextService.buildBundle(memories, projects, collections, workspaceId, query, projectId, conversationId),
    [memories, projects, collections, workspaceId, query, projectId, conversationId]
  );
}
