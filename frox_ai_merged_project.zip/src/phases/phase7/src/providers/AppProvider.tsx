import type { ReactNode } from 'react';
import { QueryProvider } from './QueryProvider';
import { SettingsProvider } from './SettingsProvider';
import { MemoryProvider } from './MemoryProvider';
import { SyncProvider } from './SyncProvider';

export function AppProvider({ children }: { children: ReactNode }) {
  return (
    <QueryProvider>
      <SettingsProvider>
        <MemoryProvider>
          <SyncProvider>{children}</SyncProvider>
        </MemoryProvider>
      </SettingsProvider>
    </QueryProvider>
  );
}
