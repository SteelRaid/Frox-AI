import type { ReactNode } from 'react';
import { useEffect } from 'react';
import { useMemoryStore } from '../stores/index';
import { useServiceWorkerSync } from '../hooks/index';

export function MemoryProvider({ children }: { children: ReactNode }) {
  const hydrate = useMemoryStore((state) => state.hydrate);
  useServiceWorkerSync();
  useEffect(() => { void hydrate(); }, [hydrate]);
  return <>{children}</>;
}
