import type { ReactNode } from 'react';
import { useEffect } from 'react';
import { useSyncStore } from '../stores/index';

export function SyncProvider({ children }: { children: ReactNode }) {
  const setSyncState = useSyncStore((state) => state.setSyncState);
  useEffect(() => {
    const update = () => setSyncState({ isOnline: navigator.onLine });
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, [setSyncState]);
  return <>{children}</>;
}
