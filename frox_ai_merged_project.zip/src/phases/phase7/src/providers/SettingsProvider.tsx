import type { ReactNode } from 'react';
import { useEffect } from 'react';
import { useSettingsStore } from '../stores/index';

export function SettingsProvider({ children }: { children: ReactNode }) {
  const settings = useSettingsStore();
  useEffect(() => {
    document.documentElement.classList.toggle('dark', true);
    document.documentElement.style.colorScheme = 'dark';
  }, [settings.autoSave]);
  return <>{children}</>;
}
