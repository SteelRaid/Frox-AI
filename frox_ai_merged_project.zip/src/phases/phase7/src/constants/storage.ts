export const STORAGE_KEYS = {
  memoryStore: 'frox.memory.store',
  searchStore: 'frox.memory.search',
  settingsStore: 'frox.memory.settings',
  dashboardStore: 'frox.memory.dashboard',
  selectionStore: 'frox.memory.selection',
  editorStore: 'frox.memory.editor',
  syncStore: 'frox.memory.sync',
};

export const SUPABASE_BUCKETS = {
  attachments: 'memory-attachments',
  exports: 'memory-exports',
  avatars: 'memory-avatars',
};
