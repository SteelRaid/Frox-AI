export const UI = {
  sidebarWidth: 292,
  rightPanelWidth: 360,
  mobileBreakpoint: 1024,
  tabletBreakpoint: 1280,
};
