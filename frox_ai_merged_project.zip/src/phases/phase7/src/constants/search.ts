export const SEARCH_MIN_QUERY_LENGTH = 2;
export const SEARCH_MAX_RESULTS = 250;
export const SEARCH_DEFAULT_LIMIT = 40;
export const SEARCH_SUGGESTION_LIMIT = 12;
export const SEARCH_FIELDS = ['title', 'content', 'summary', 'tags', 'keywords', 'entities'] as const;
