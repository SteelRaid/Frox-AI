import type { MemoryType } from '../types/index';

export const MEMORY_TYPES: MemoryType[] = [
  'conversation','long_term','short_term','temporary','pinned','project','workspace','coding','personality','preference','task','goal','instruction','document','image','voice','file','calendar','reminder','relationship','knowledge','ai_generated','system','private','shared','archived','deleted','hidden'
];

export const MEMORY_TYPE_GROUPS: Record<string, MemoryType[]> = {
  core: ['conversation', 'long_term', 'short_term', 'temporary', 'pinned'],
  workspace: ['project', 'workspace', 'coding', 'knowledge'],
  personal: ['personality', 'preference', 'relationship'],
  action: ['task', 'goal', 'instruction', 'reminder', 'calendar'],
  content: ['document', 'image', 'voice', 'file', 'ai_generated', 'system'],
  visibility: ['private', 'shared', 'archived', 'deleted', 'hidden'],
};

export const MEMORY_IMPORTANCE_WEIGHTS = {
  pinned: 1.4,
  project: 1.3,
  instruction: 1.25,
  preference: 1.2,
  goal: 1.2,
  reminder: 1.15,
};

export const DEFAULT_MEMORY_RETENTION_DAYS = 365;
export const DEFAULT_SHORT_TERM_RETENTION_DAYS = 7;
export const DEFAULT_TEMPORARY_RETENTION_HOURS = 24;
