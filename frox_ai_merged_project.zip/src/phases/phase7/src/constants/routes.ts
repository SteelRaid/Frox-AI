export const ROUTES = {
  dashboard: '/memory',
  library: '/memory/library',
  search: '/memory/search',
  projects: '/memory/projects',
  knowledge: '/memory/knowledge',
  settings: '/memory/settings',
  studio: '/memory/studio',
  memory: (id: string) => `/memory/${id}`,
};
