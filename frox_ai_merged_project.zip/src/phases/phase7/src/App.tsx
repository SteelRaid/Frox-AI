import { Navigate, Route, Routes } from 'react-router-dom';
import { MemoryLayout } from './layouts/index';
import { ROUTES } from './constants/index';
import { DashboardPage, LibraryPage, SearchPage, ProjectsPage, KnowledgeBasePage, SettingsPage, MemoryDetailPage, NotFoundPage, MemoryStudioPage } from './pages/index';

export default function App() {
  return (
    <Routes>
      <Route element={<MemoryLayout />}>
        <Route path={ROUTES.dashboard} element={<DashboardPage />} />
        <Route path={ROUTES.library} element={<LibraryPage />} />
        <Route path={ROUTES.search} element={<SearchPage />} />
        <Route path={ROUTES.projects} element={<ProjectsPage />} />
        <Route path={ROUTES.knowledge} element={<KnowledgeBasePage />} />
        <Route path={ROUTES.settings} element={<SettingsPage />} />
        <Route path={ROUTES.studio} element={<MemoryStudioPage />} />
        <Route path="/memory/:id" element={<MemoryDetailPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
      <Route path="/" element={<Navigate to={ROUTES.dashboard} replace />} />
    </Routes>
  );
}
