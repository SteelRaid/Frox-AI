export const createSearchWorker = () => new Worker(new URL('./memorySearch.worker.ts', import.meta.url), { type: 'module' });
export const createSummaryWorker = () => new Worker(new URL('./memorySummary.worker.ts', import.meta.url), { type: 'module' });
export const createIndexWorker = () => new Worker(new URL('./memoryIndex.worker.ts', import.meta.url), { type: 'module' });
