/// <reference lib="webworker" />
import { searchService } from '../services/index';
import type { MemoryItem } from '../types/index';

type MessagePayload =
  | { type: 'search'; query: string; memories: MemoryItem[]; limit?: number }
  | { type: 'suggest'; query: string; memories: MemoryItem[] };

self.onmessage = (event: MessageEvent<MessagePayload>) => {
  const payload = event.data;
  if (payload.type === 'search') {
    const results = searchService.search(payload.memories, payload.query, payload.limit ?? 20);
    self.postMessage({ type: 'search:result', results });
    return;
  }
  const suggestions = searchService.suggest(payload.memories, payload.query);
  self.postMessage({ type: 'suggest:result', suggestions });
};

export {};
