/// <reference lib="webworker" />
import type { MemoryItem } from '../types/index';
import { tokenize } from '../utils/index';

type IndexRecord = {
  id: string;
  tokens: string[];
  tags: string[];
  updatedAt: string;
};

const index = new Map<string, IndexRecord>();

self.onmessage = (event: MessageEvent<{ type: 'index' | 'remove' | 'clear'; memory?: MemoryItem; id?: string }>) => {
  const payload = event.data;
  if (payload.type === 'clear') {
    index.clear();
    self.postMessage({ type: 'index:cleared' });
    return;
  }
  if (payload.type === 'remove' && payload.id) {
    index.delete(payload.id);
    self.postMessage({ type: 'index:removed', id: payload.id });
    return;
  }
  if (payload.type === 'index' && payload.memory) {
    index.set(payload.memory.id, {
      id: payload.memory.id,
      tokens: tokenize(`${payload.memory.title} ${payload.memory.summary} ${payload.memory.content}`),
      tags: payload.memory.tags,
      updatedAt: payload.memory.updatedAt,
    });
    self.postMessage({ type: 'index:stored', id: payload.memory.id });
  }
};

export {};
