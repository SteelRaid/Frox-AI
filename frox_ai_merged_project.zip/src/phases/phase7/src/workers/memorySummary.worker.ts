/// <reference lib="webworker" />

self.onmessage = (event: MessageEvent<{ type: 'summarize'; text: string; maxLength?: number }>) => {
  const maxLength = event.data.maxLength ?? 220;
  const normalized = event.data.text.replace(/\s+/g, ' ').trim();
  const summary = normalized.length > maxLength ? `${normalized.slice(0, maxLength).trim()}…` : normalized;
  self.postMessage({ type: 'summary:result', summary });
};

export {};
