export const fadeInUp = {
  initial: { opacity: 0, y: 18 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -12 },
};

export const cardHover = {
  whileHover: { y: -4, scale: 1.01 },
  whileTap: { scale: 0.99 },
};

export const sidebarSlide = {
  initial: { x: -22, opacity: 0 },
  animate: { x: 0, opacity: 1 },
  exit: { x: -22, opacity: 0 },
};
