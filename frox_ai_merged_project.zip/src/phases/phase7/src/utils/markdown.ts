export const plainTextToMarkdown = (value: string) =>
  value
    .split(/\n{2,}/)
    .map((block) => block.trim())
    .filter(Boolean)
    .map((block) => (block.startsWith('#') ? block : block.replace(/^-\s+/gm, '- ')))
    .join('\n\n');

export const markdownToPlainText = (value: string) =>
  value
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    .replace(/`{1,3}([\s\S]*?)`{1,3}/g, '$1')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

export const summarizeMarkdown = (value: string, maxLength = 240) => {
  const plain = markdownToPlainText(value).replace(/\s+/g, ' ').trim();
  return plain.length > maxLength ? `${plain.slice(0, maxLength).trim()}…` : plain;
};

export const createMarkdownPreview = (title: string, body: string, bullets: string[] = []) => {
  const bulletBlock = bullets.length
    ? `\n\n## Highlights\n${bullets.map((item) => `- ${item}`).join('\n')}`
    : '';
  return `# ${title}\n\n${body.trim()}${bulletBlock}`.trim();
};

export const wrapBlockquote = (value: string) =>
  value
    .split(/\n/)
    .map((line) => `> ${line}`)
    .join('\n');

export const markdownToSearchText = (value: string) =>
  markdownToPlainText(value)
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
