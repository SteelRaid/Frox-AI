import type { MemoryAttachment } from '../types/index';

export const humanFileSize = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB'];
  let value = bytes / 1024;
  let idx = 0;
  while (value >= 1024 && idx < units.length - 1) {
    value /= 1024;
    idx += 1;
  }
  return `${value.toFixed(1)} ${units[idx]}`;
};

export const isPreviewableImage = (mimeType: string) => mimeType.startsWith('image/');
export const attachmentLabel = (file: Pick<MemoryAttachment, 'name' | 'mimeType' | 'size'>) => `${file.name} · ${file.mimeType} · ${humanFileSize(file.size)}`;
