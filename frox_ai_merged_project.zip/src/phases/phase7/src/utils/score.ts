import type { MemoryEntity, MemoryItem } from '../types/index';
import { clamp } from '../lib/utils';
import { isExpired } from './dates';

export function computeImportance(memory: Pick<MemoryItem, 'pinned' | 'type' | 'content' | 'tags' | 'labels' | 'updatedAt' | 'expiresAt'>) {
  const lengthScore = clamp(memory.content.length / 1800, 0, 1);
  const tagScore = clamp((memory.tags.length + memory.labels.length) / 10, 0, 1);
  const freshnessBonus = isExpired(memory.expiresAt) ? -0.35 : 0.08;
  const typeBoost = ['instruction', 'goal', 'project', 'preference', 'coding', 'knowledge'].includes(memory.type) ? 0.18 : 0;
  const pinnedBoost = memory.pinned ? 0.3 : 0;
  const recencyDays = Math.max(0, (Date.now() - new Date(memory.updatedAt).getTime()) / (1000 * 60 * 60 * 24));
  const recencyBoost = clamp(1 - recencyDays / 30, 0, 1) * 0.15;
  return clamp(0.15 + lengthScore * 0.32 + tagScore * 0.2 + typeBoost + pinnedBoost + freshnessBonus + recencyBoost, 0, 1);
}

export function computeConfidence(memory: Pick<MemoryItem, 'content' | 'entities' | 'keywords'>) {
  const entitySignal = clamp(memory.entities.length / 8, 0, 1) * 0.35;
  const keywordSignal = clamp(memory.keywords.length / 12, 0, 1) * 0.25;
  const lengthSignal = clamp(memory.content.length / 250, 0, 1) * 0.4;
  return clamp(0.12 + entitySignal + keywordSignal + lengthSignal, 0, 1);
}

export function computeQuality(memory: Pick<MemoryItem, 'summary' | 'content' | 'tags' | 'keywords'>) {
  const summaryScore = memory.summary.trim().length > 0 ? 0.2 : 0;
  const tagBalance = clamp(memory.tags.length / 8, 0, 1) * 0.25;
  const keywordBalance = clamp(memory.keywords.length / 12, 0, 1) * 0.25;
  const contentScore = clamp(memory.content.length / 1800, 0, 1) * 0.3;
  return clamp(summaryScore + tagBalance + keywordBalance + contentScore, 0, 1);
}

export function computeRecencyScore(updatedAt: string) {
  const ageDays = (Date.now() - new Date(updatedAt).getTime()) / (1000 * 60 * 60 * 24);
  return clamp(1 - ageDays / 30, 0, 1);
}

export function computeEntityAffinity(entities: MemoryEntity[], queryTerms: string[]) {
  const names = entities.map((entity) => entity.name.toLowerCase());
  const hits = queryTerms.filter((term) => names.some((name) => name.includes(term))).length;
  return clamp(hits / Math.max(1, queryTerms.length), 0, 1);
}

export function computeDuplicateScore(a: MemoryItem, b: MemoryItem) {
  const tokensA = new Set(`${a.title} ${a.summary} ${a.content} ${a.tags.join(' ')}`.toLowerCase().split(/\s+/).filter(Boolean));
  const tokensB = new Set(`${b.title} ${b.summary} ${b.content} ${b.tags.join(' ')}`.toLowerCase().split(/\s+/).filter(Boolean));
  const shared = [...tokensA].filter((token) => tokensB.has(token)).length;
  const union = new Set([...tokensA, ...tokensB]).size || 1;
  const jaccard = shared / union;
  const titleOverlap = a.title.toLowerCase() === b.title.toLowerCase() ? 0.2 : 0;
  const entityOverlap = a.entities.length && b.entities.length
    ? a.entities.filter((x) => b.entities.some((y) => y.id === x.id)).length / Math.max(a.entities.length, b.entities.length)
    : 0;
  return clamp(jaccard * 0.6 + entityOverlap * 0.25 + titleOverlap, 0, 1);
}
