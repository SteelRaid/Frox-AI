import type { MemoryItem } from '../types/index';

export const canEditMemory = (memory: MemoryItem, workspaceRole: 'owner' | 'admin' | 'member' = 'member') => {
  if (memory.visibility === 'hidden') return workspaceRole !== 'member';
  if (memory.visibility === 'private') return workspaceRole === 'owner' || workspaceRole === 'admin';
  return true;
};
