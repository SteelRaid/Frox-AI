export const normalizeText = (value: string) => value.toLowerCase().replace(/\s+/g, ' ').trim();
export const tokenize = (value: string) => normalizeText(value).split(/[^\p{L}\p{N}_]+/u).filter(Boolean);
export const unique = <T>(items: T[]) => Array.from(new Set(items));
