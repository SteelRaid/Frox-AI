import type { GraphEdge, GraphNode } from '../types/index';

export function buildGraphFromMemories(memories: { id: string; title: string; type: string; tags: string[]; entities: { id: string; name: string; type: string; confidence: number }[] }[]) {
  const nodes: GraphNode[] = memories.slice(0, 40).map((memory, index) => ({
    id: memory.id,
    label: memory.title,
    type: 'memory',
    x: 60 + (index % 8) * 120,
    y: 80 + Math.floor(index / 8) * 110,
    size: 18 + Math.min(memory.tags.length * 2, 18),
  }));
  const edges: GraphEdge[] = [];
  for (let i = 1; i < nodes.length; i += 1) {
    edges.push({ id: `edge-${i}`, source: nodes[i - 1].id, target: nodes[i].id, weight: 0.45, relation: 'related' });
  }
  return { nodes, edges };
}
