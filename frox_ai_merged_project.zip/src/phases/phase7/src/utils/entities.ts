import type { MemoryEntity } from '../types/index';
import { unique } from './normalize';

const NAME_PATTERN = /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})\b/g;
const PROJECT_PATTERN = /\b(project|workspace|repo|application|app|system)\s+([A-Za-z0-9_-]{3,64})\b/gi;
const TOOL_PATTERN = /\b(react|supabase|vite|zustand|tailwindcss|tailwind|fuse\.js|dexie|framer motion|typescript|markdown|postgres|sql|web worker|service worker)\b/gi;
const LOCATION_PATTERN = /\b(?:in|at|from|near|around)\s+([A-Z][A-Za-z0-9]*(?:\s+[A-Z][A-Za-z0-9]*){0,3})\b/g;
const PERSON_HINT_PATTERN = /\b(i|we|user|friend|developer|designer|student|manager|teacher|founder)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})\b/g;

function pushUnique(items: MemoryEntity[], entity: MemoryEntity) {
  if (!items.some((item) => item.id === entity.id)) items.push(entity);
}

export function extractPeople(text: string) {
  const items: MemoryEntity[] = [];
  for (const match of text.matchAll(NAME_PATTERN)) {
    const name = match[1].trim();
    pushUnique(items, { id: `person:${name.toLowerCase()}`, type: 'person', name, confidence: 0.78 });
  }
  for (const match of text.matchAll(PERSON_HINT_PATTERN)) {
    const name = match[2].trim();
    pushUnique(items, { id: `person:${name.toLowerCase()}`, type: 'person', name, confidence: 0.64 });
  }
  return items;
}

export function extractProjects(text: string) {
  const items: MemoryEntity[] = [];
  for (const match of text.matchAll(PROJECT_PATTERN)) {
    const name = match[2].trim();
    pushUnique(items, { id: `project:${name.toLowerCase()}`, type: 'project', name, confidence: 0.82 });
  }
  return items;
}

export function extractTools(text: string) {
  const items: MemoryEntity[] = [];
  for (const match of text.matchAll(TOOL_PATTERN)) {
    const name = match[0].trim();
    pushUnique(items, { id: `tool:${name.toLowerCase()}`, type: 'tool', name, confidence: 0.74 });
  }
  return items;
}

export function extractLocations(text: string) {
  const items: MemoryEntity[] = [];
  for (const match of text.matchAll(LOCATION_PATTERN)) {
    const name = match[1].trim();
    pushUnique(items, { id: `location:${name.toLowerCase()}`, type: 'location', name, confidence: 0.7 });
  }
  return items;
}

export function extractEntities(text: string): MemoryEntity[] {
  return unique([
    ...extractPeople(text),
    ...extractProjects(text),
    ...extractTools(text),
    ...extractLocations(text),
  ]);
}

export function extractTopics(text: string) {
  const words = text
    .toLowerCase()
    .replace(/[^a-z0-9\s_-]/g, ' ')
    .split(/\s+/)
    .filter((token) => token.length > 4);
  return unique(words).slice(0, 16);
}
