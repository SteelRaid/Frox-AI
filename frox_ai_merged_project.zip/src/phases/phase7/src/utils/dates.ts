import { differenceInDays, formatDistanceToNow, parseISO } from 'date-fns';
export const formatRelativeTime = (value: string) => formatDistanceToNow(parseISO(value), { addSuffix: true });
export const daysBetween = (a: string, b: string) => differenceInDays(parseISO(a), parseISO(b));
export const isExpired = (expiresAt?: string | null) => Boolean(expiresAt && new Date(expiresAt).getTime() < Date.now());
