import { v4 as uuidv4 } from 'uuid';
export const createMemoryId = (prefix = 'memory') => `${prefix}_${uuidv4().replace(/-/g, '').slice(0, 16)}`;
