import type { MemoryItem, MemoryProject, MemoryCollection, MemoryStats } from '../types/index';
import JSZip from 'jszip';
import jsPDF from 'jspdf';
import { plainTextToMarkdown } from './markdown';

type ExportBundle = {
  memories: MemoryItem[];
  projects?: MemoryProject[];
  collections?: MemoryCollection[];
  stats?: MemoryStats;
};

function escapeCsvCell(value: unknown) {
  return `"${String(value ?? '').split('"').join('""')}"`;
}

export function exportMemoriesToJSON(memories: MemoryItem[]) {
  return JSON.stringify(memories, null, 2);
}

export function exportMemoriesToMarkdown(memories: MemoryItem[]) {
  return memories
    .map((memory) => {
      const body = plainTextToMarkdown(memory.content);
      return [
        `# ${memory.title}`,
        '',
        body,
        '',
        `- Type: ${memory.type}`,
        `- Scope: ${memory.scope}`,
        `- Visibility: ${memory.visibility}`,
        `- Importance: ${memory.importance.toFixed(3)}`,
        `- Confidence: ${memory.confidence.toFixed(3)}`,
        `- Quality: ${memory.quality.toFixed(3)}`,
        `- Tags: ${memory.tags.join(', ') || 'None'}`,
        `- Updated: ${memory.updatedAt}`,
      ].join('\n');
    })
    .join('\n\n---\n\n');
}

export function exportMemoriesToCSV(memories: MemoryItem[]) {
  const header = ['id', 'title', 'type', 'scope', 'visibility', 'importance', 'confidence', 'quality', 'tags', 'updatedAt'];
  const rows = memories.map((memory) => [
    memory.id,
    memory.title,
    memory.type,
    memory.scope,
    memory.visibility,
    memory.importance,
    memory.confidence,
    memory.quality,
    memory.tags.join('|'),
    memory.updatedAt,
  ]);
  return [header, ...rows].map((row) => row.map(escapeCsvCell).join(',')).join('\n');
}

export async function exportMemoriesToZip(memories: MemoryItem[]) {
  const zip = new JSZip();
  zip.file('memories.json', exportMemoriesToJSON(memories));
  zip.file('memories.md', exportMemoriesToMarkdown(memories));
  zip.file('memories.csv', exportMemoriesToCSV(memories));
  return zip.generateAsync({ type: 'blob' });
}

export function exportMemoriesToPDF(memories: MemoryItem[]) {
  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.text('Frox AI Memory Export', 14, 18);
  doc.setFontSize(10);
  let y = 30;

  for (const memory of memories.slice(0, 40)) {
    const lines = doc.splitTextToSize(`${memory.title} — ${memory.summary}`, 180) as string[];
    doc.text(lines, 14, y);
    y += lines.length * 5 + 8;
    if (y > 270) {
      doc.addPage();
      y = 20;
    }
  }

  return doc.output('blob');
}

export async function exportMemoryBundleToZip(bundle: ExportBundle) {
  const zip = new JSZip();
  zip.file('memories.json', JSON.stringify(bundle.memories, null, 2));
  zip.file('memories.md', exportMemoriesToMarkdown(bundle.memories));
  zip.file('memories.csv', exportMemoriesToCSV(bundle.memories));
  if (bundle.projects) zip.file('projects.json', JSON.stringify(bundle.projects, null, 2));
  if (bundle.collections) zip.file('collections.json', JSON.stringify(bundle.collections, null, 2));
  if (bundle.stats) zip.file('stats.json', JSON.stringify(bundle.stats, null, 2));
  return zip.generateAsync({ type: 'blob' });
}
