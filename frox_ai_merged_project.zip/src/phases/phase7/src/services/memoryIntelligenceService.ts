import type { MemoryCollection, MemoryItem, MemoryIntelligenceReport, MemoryProject } from '../types/index';
import { memoryIntelligenceEngine } from '../engine/index';

export class MemoryIntelligenceService {
  analyze(memories: MemoryItem[], projects: MemoryProject[], collections: MemoryCollection[], workspaceId: string, query = '', projectId?: string, conversationId?: string): MemoryIntelligenceReport {
    return memoryIntelligenceEngine.analyze(memories, projects, collections, { workspaceId, query, projectId, conversationId });
  }
}

export const memoryIntelligenceService = new MemoryIntelligenceService();
