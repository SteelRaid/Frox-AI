import { supabase } from '../lib/supabase/index';
import type { MemoryAttachment } from '../types/index';
import { createMemoryId } from '../utils/index';
import { SUPABASE_BUCKETS } from '../constants/index';

export class StorageService {
  async uploadAttachment(workspaceId: string, memoryId: string, file: File): Promise<MemoryAttachment> {
    const path = `${workspaceId}/${memoryId}/${createMemoryId('file')}-${file.name}`;
    await supabase.storage.from(SUPABASE_BUCKETS.attachments).upload(path, file);
    const publicUrl = supabase.storage.from(SUPABASE_BUCKETS.attachments).getPublicUrl(path).data.publicUrl;
    return {
      id: createMemoryId('attachment'),
      memoryId,
      name: file.name,
      mimeType: file.type || 'application/octet-stream',
      size: file.size,
      bucket: SUPABASE_BUCKETS.attachments,
      path,
      publicUrl,
      createdAt: new Date().toISOString(),
    };
  }
}

export const storageService = new StorageService();
