import type { GraphEdge, GraphNode, MemoryItem } from '../types/index';

export interface KnowledgeGraphSummary {
  nodes: GraphNode[];
  edges: GraphEdge[];
  density: number;
  clusters: number;
}

export class MemoryGraphService {
  buildGraph(memories: MemoryItem[]): KnowledgeGraphSummary {
    const limited = memories.slice(0, 80);
    const nodes: GraphNode[] = limited.map((memory, index) => ({
      id: memory.id,
      label: memory.title,
      type: memory.projectId ? 'project' : memory.collectionId ? 'collection' : memory.entities[0]?.type === 'person' ? 'person' : 'memory',
      x: 80 + (index % 8) * 120,
      y: 100 + Math.floor(index / 8) * 110,
      size: 16 + Math.min(18, memory.tags.length * 2 + (memory.pinned ? 6 : 0)),
    }));

    const edges: GraphEdge[] = [];
    for (let i = 0; i < limited.length; i += 1) {
      for (let j = i + 1; j < limited.length; j += 1) {
        const a = limited[i];
        const b = limited[j];
        const sharedTags = a.tags.filter((tag) => b.tags.includes(tag)).length;
        const sharedEntities = a.entities.filter((entity) => b.entities.some((candidate) => candidate.id === entity.id)).length;
        const sameProject = Boolean(a.projectId && b.projectId && a.projectId === b.projectId);
        const weight = sharedTags * 0.16 + sharedEntities * 0.25 + (sameProject ? 0.35 : 0);
        if (weight >= 0.35) {
          edges.push({
            id: `edge-${a.id}-${b.id}`,
            source: a.id,
            target: b.id,
            weight: Number(Math.min(1, weight).toFixed(3)),
            relation: sameProject ? 'project-link' : sharedEntities > 0 ? 'entity-link' : 'tag-link',
          });
        }
      }
    }

    const density = nodes.length > 1 ? edges.length / (nodes.length * (nodes.length - 1) / 2) : 0;
    const clusters = Math.max(1, new Set(nodes.map((node) => node.type)).size);

    return { nodes, edges, density, clusters };
  }
}

export const memoryGraphService = new MemoryGraphService();
