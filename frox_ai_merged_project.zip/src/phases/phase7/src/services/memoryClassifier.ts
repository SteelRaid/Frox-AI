import type { MemoryIntakeDecision, MemoryItem, MemoryScope, MemoryType, MemoryVisibility } from '../types/index';
import { extractEntities, extractTopics } from '../utils/index';

const REMEMBER_PATTERNS = [
  /\bremember this\b/i,
  /\bkeep this in mind\b/i,
  /\bnote that\b/i,
  /\bsave this\b/i,
  /\bimportant\b/i,
];

const FORGET_PATTERNS = [
  /\bforget this\b/i,
  /\bdon't remember\b/i,
  /\bdo not remember\b/i,
  /\bignore this\b/i,
];

const PIN_PATTERNS = [
  /\bpin this\b/i,
  /\bvery important\b/i,
  /\bmust remember\b/i,
  /\bcore preference\b/i,
];

const INSTRUCTION_PATTERNS = [
  /\buse\b.*\bwhen\b/i,
  /\balways\b/i,
  /\bnever\b/i,
  /\bfollow\b.*\bstyle\b/i,
  /\bbest practice\b/i,
];

const GOAL_PATTERNS = [
  /\bgoal\b/i,
  /\bobjective\b/i,
  /\bplan to\b/i,
  /\bwant to\b/i,
  /\baim to\b/i,
];

const PROJECT_PATTERNS = [
  /\bproject\b/i,
  /\bworkspace\b/i,
  /\bfeature\b/i,
  /\bmodule\b/i,
  /\brepository\b/i,
  /\bapp\b/i,
];

const PREFERENCE_PATTERNS = [
  /\bi prefer\b/i,
  /\bmy preference\b/i,
  /\bi like\b/i,
  /\bi usually\b/i,
  /\bi want\b/i,
  /\bpreferred\b/i,
];

function scorePatterns(text: string, patterns: RegExp[]) {
  return patterns.reduce((score, pattern) => score + (pattern.test(text) ? 1 : 0), 0);
}

export class MemoryClassifier {
  classify(text: string, existing?: Partial<MemoryItem>): MemoryIntakeDecision {
    const normalized = text.trim();
    const entityCount = extractEntities(normalized).length;
    const topics = extractTopics(normalized);
    const contentLength = normalized.length;

    if (!normalized) {
      return {
        action: 'ignore',
        reason: 'Empty content should not be stored as memory.',
        confidence: 1,
        memoryType: existing?.type ?? 'short_term',
        scope: existing?.scope ?? 'conversation',
        visibility: existing?.visibility ?? 'private',
        tags: [],
        keywords: [],
      };
    }

    if (scorePatterns(normalized, FORGET_PATTERNS) > 0) {
      return {
        action: 'forget',
        reason: 'The text explicitly requests forgetting or ignoring.',
        confidence: 0.99,
        memoryType: existing?.type ?? 'temporary',
        scope: existing?.scope ?? 'conversation',
        visibility: existing?.visibility ?? 'private',
        tags: ['forget'],
        keywords: topics.slice(0, 8),
      };
    }

    const rememberScore = scorePatterns(normalized, REMEMBER_PATTERNS);
    const pinScore = scorePatterns(normalized, PIN_PATTERNS);
    const instructionScore = scorePatterns(normalized, INSTRUCTION_PATTERNS);
    const goalScore = scorePatterns(normalized, GOAL_PATTERNS);
    const projectScore = scorePatterns(normalized, PROJECT_PATTERNS);
    const preferenceScore = scorePatterns(normalized, PREFERENCE_PATTERNS);

    let memoryType: MemoryType = existing?.type ?? 'knowledge';
    let scope: MemoryScope = existing?.scope ?? (projectScore > 0 ? 'project' : 'workspace');
    let visibility: MemoryVisibility = existing?.visibility ?? 'private';
    let action: MemoryIntakeDecision['action'] = 'remember';
    let reason = 'Useful signal detected for long-term retrieval.';

    if (instructionScore > 0) {
      memoryType = 'instruction';
      reason = 'The content looks like a reusable instruction or rule.';
    } else if (goalScore > 0) {
      memoryType = 'goal';
      reason = 'The content describes an objective or goal.';
    } else if (preferenceScore > 0) {
      memoryType = 'preference';
      reason = 'The content expresses a user preference.';
    } else if (projectScore > 0 || entityCount >= 2) {
      memoryType = 'project';
      scope = 'project';
      reason = 'The content contains project-like structure or multiple entities.';
    } else if (pinScore > 0) {
      memoryType = 'pinned';
      action = 'pin';
      reason = 'The content is explicitly marked important.';
    } else if (rememberScore > 0 || contentLength > 120) {
      memoryType = existing?.type ?? 'knowledge';
      reason = contentLength > 120 ? 'The content is information-dense enough to be retained.' : 'The text asks to remember this.';
    } else {
      action = 'ignore';
      reason = 'The content appears too weak or repetitive to store as long-term memory.';
      memoryType = existing?.type ?? 'short_term';
    }

    if (existing?.type && existing.type !== memoryType && action === 'remember') {
      action = 'update';
      reason = `This memory looks like a better fit for ${memoryType}.`;
    }

    const confidence = Math.min(
      0.98,
      0.32 +
        rememberScore * 0.18 +
        pinScore * 0.16 +
        instructionScore * 0.16 +
        goalScore * 0.14 +
        preferenceScore * 0.14 +
        Math.min(entityCount / 6, 1) * 0.12 +
        Math.min(contentLength / 600, 1) * 0.1
    );

    const tags = Array.from(
      new Set([
        ...topics.slice(0, 6),
        ...(instructionScore > 0 ? ['instruction'] : []),
        ...(goalScore > 0 ? ['goal'] : []),
        ...(preferenceScore > 0 ? ['preference'] : []),
        ...(projectScore > 0 ? ['project'] : []),
        ...(pinScore > 0 ? ['pinned'] : []),
      ])
    );

    return {
      action,
      reason,
      confidence,
      memoryType,
      scope,
      visibility,
      tags,
      keywords: topics.slice(0, 10),
    };
  }
}

export const memoryClassifier = new MemoryClassifier();
