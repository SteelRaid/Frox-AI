import Fuse from 'fuse.js';
import type { MemoryItem, MemorySearchResult, SavedSearch, MemorySearchFilter } from '../types/index';
import { normalizeText, tokenize } from '../utils/index';
import { SEARCH_DEFAULT_LIMIT } from '../constants/index';
import { computeEntityAffinity, computeRecencyScore } from '../utils/score';

const fuseOptions: Fuse.IFuseOptions<MemoryItem> = {
  includeScore: true,
  ignoreLocation: true,
  threshold: 0.33,
  keys: ['title', 'content', 'summary', 'tags', 'keywords', 'labels', 'entities.name', 'projectId', 'conversationId'],
};

export class SearchService {
  search(memories: MemoryItem[], query: string, limit = SEARCH_DEFAULT_LIMIT, filters?: Partial<MemorySearchFilter>): MemorySearchResult[] {
    const normalized = normalizeText(query);
    const filtered = this.applyFilters(memories, filters);

    if (!normalized) {
      return filtered
        .slice()
        .sort((a, b) => this.rankRecent(b) - this.rankRecent(a))
        .slice(0, limit)
        .map((item) => ({ item, score: this.rankRecent(item), highlights: [], reasons: ['recent'] }));
    }

    const queryTokens = tokenize(normalized);
    const fuse = new Fuse(filtered, fuseOptions);
    const fused = fuse.search(normalized).slice(0, limit * 3);

    const results = fused
      .map((result) => {
        const item = result.item;
        const score = this.computeHybridScore(item, queryTokens, result.score ?? 0);
        return {
          item,
          score,
          highlights: this.collectHighlights(item, queryTokens),
          reasons: this.reasonsFor(item, queryTokens),
        };
      })
      .sort((a, b) => b.score - a.score);

    return results.slice(0, limit);
  }

  searchByCategory(memories: MemoryItem[], filter: MemorySearchFilter, limit = SEARCH_DEFAULT_LIMIT) {
    const q = filter.query ?? '';
    return this.search(memories, q, limit, filter);
  }

  suggest(memories: MemoryItem[], query: string): string[] {
    const normalized = normalizeText(query);
    const terms = new Set<string>(tokenize(normalized));
    for (const memory of memories.slice(0, 80)) {
      memory.tags.forEach((tag) => terms.add(tag.toLowerCase()));
      memory.keywords.forEach((keyword) => terms.add(keyword.toLowerCase()));
      memory.entities.forEach((entity) => terms.add(entity.name.toLowerCase()));
    }
    return Array.from(terms)
      .filter((term) => !normalized || term.includes(normalized) || normalized.includes(term))
      .slice(0, 16);
  }

  rankSavedSearches(searches: SavedSearch[], query: string): SavedSearch[] {
    const q = normalizeText(query);
    return searches.slice().sort((a, b) => {
      const scoreA = normalizeText(a.name).includes(q) ? 2 : 0;
      const scoreB = normalizeText(b.name).includes(q) ? 2 : 0;
      return scoreB - scoreA;
    });
  }

  recentSuggestions(memories: MemoryItem[], limit = 8) {
    return memories
      .slice()
      .sort((a, b) => this.rankRecent(b) - this.rankRecent(a))
      .slice(0, limit)
      .map((memory) => memory.title);
  }

  private applyFilters(memories: MemoryItem[], filters?: Partial<MemorySearchFilter>) {
    if (!filters) return memories;
    return memories.filter((memory) => {
      if (filters.workspaceId && memory.workspaceId !== filters.workspaceId) return false;
      if (filters.projectId && memory.projectId !== filters.projectId) return false;
      if (filters.collectionId && memory.collectionId !== filters.collectionId) return false;
      if (filters.conversationId && memory.conversationId !== filters.conversationId) return false;
      if (filters.pinnedOnly && !memory.pinned) return false;
      if (filters.archivedOnly && memory.status !== 'archived') return false;
      if (filters.favoritesOnly && !memory.favorite) return false;
      if (filters.scope?.length && !filters.scope.includes(memory.scope)) return false;
      if (filters.types?.length && !filters.types.includes(memory.type)) return false;
      if (filters.tags?.length && !filters.tags.some((tag) => memory.tags.includes(tag))) return false;
      if (filters.updatedAfter && new Date(memory.updatedAt).getTime() < new Date(filters.updatedAfter).getTime()) return false;
      if (filters.updatedBefore && new Date(memory.updatedAt).getTime() > new Date(filters.updatedBefore).getTime()) return false;
      return true;
    });
  }

  private computeHybridScore(item: MemoryItem, queryTokens: string[], fuseScore: number) {
    const content = `${item.title} ${item.summary} ${item.content} ${item.tags.join(' ')} ${item.keywords.join(' ')}`.toLowerCase();
    const tokenMatches = queryTokens.reduce((acc, token) => acc + (content.includes(token) ? 1 : 0), 0);
    const recency = computeRecencyScore(item.updatedAt);
    const importance = item.importance;
    const entityAffinity = computeEntityAffinity(item.entities, queryTokens);
    const quality = item.quality;
    return (1 - fuseScore) * 0.38 + tokenMatches * 0.08 + recency * 0.18 + importance * 0.18 + entityAffinity * 0.1 + quality * 0.08;
  }

  private rankRecent(item: MemoryItem) {
    return computeRecencyScore(item.updatedAt) + item.importance * 0.2 + (item.pinned ? 0.2 : 0);
  }

  private collectHighlights(item: MemoryItem, queryTokens: string[]) {
    const haystack = `${item.title} ${item.summary} ${item.content}`.toLowerCase();
    return queryTokens.filter((token) => haystack.includes(token)).slice(0, 5);
  }

  private reasonsFor(item: MemoryItem, queryTokens: string[]) {
    const reasons = [] as string[];
    if (item.pinned) reasons.push('pinned');
    if (item.projectId) reasons.push('project');
    if (item.importance > 0.7) reasons.push('important');
    if (queryTokens.some((token) => item.tags.some((tag) => tag.toLowerCase().includes(token)))) reasons.push('tag match');
    if (item.entities.length > 0) reasons.push('entity match');
    return reasons.length ? reasons : ['semantic match'];
  }
}

export const searchService = new SearchService();
