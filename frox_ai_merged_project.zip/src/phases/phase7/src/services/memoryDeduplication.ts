import type { MemoryItem, MemoryRelation } from '../types/index';
import { computeDuplicateScore, summarizeText, unique, createMemoryId } from '../utils/index';

export interface DuplicateCandidate {
  memory: MemoryItem;
  score: number;
  overlapReasons: string[];
}

export interface MergePlan {
  title: string;
  content: string;
  summary: string;
  tags: string[];
  keywords: string[];
  entities: MemoryItem['entities'];
}

export class MemoryDeduplicationService {
  findCandidates(target: MemoryItem, memories: MemoryItem[], threshold = 0.58): DuplicateCandidate[] {
    return memories
      .filter((memory) => memory.id !== target.id)
      .map((memory) => {
        const score = computeDuplicateScore(target, memory);
        const overlapReasons = this.buildOverlapReasons(target, memory, score);
        return { memory, score, overlapReasons };
      })
      .filter((candidate) => candidate.score >= threshold)
      .sort((a, b) => b.score - a.score);
  }

  shouldMerge(target: MemoryItem, candidate: MemoryItem) {
    return computeDuplicateScore(target, candidate) >= 0.72;
  }

  buildMergePlan(primary: MemoryItem, secondary: MemoryItem): MergePlan {
    return {
      title: primary.title.length >= secondary.title.length ? primary.title : secondary.title,
      content: this.mergeContent(primary, secondary),
      summary: summarizeText(`${primary.summary} ${secondary.summary}`, 260),
      tags: unique([...primary.tags, ...secondary.tags]),
      keywords: unique([...primary.keywords, ...secondary.keywords]),
      entities: this.mergeEntities(primary.entities, secondary.entities),
    };
  }

  createRelation(fromMemoryId: string, toMemoryId: string, score: number): MemoryRelation {
    return {
      id: createMemoryId('relation'),
      fromMemoryId,
      toMemoryId,
      relation: score >= 0.85 ? 'duplicate' : 'references',
      weight: Number(score.toFixed(3)),
      createdAt: new Date().toISOString(),
    };
  }

  mergeMemorySet(memories: MemoryItem[]) {
    const used = new Set<string>();
    const merged: MemoryItem[] = [];
    for (const memory of memories) {
      if (used.has(memory.id)) continue;
      const candidate = memories.find((item) => item.id !== memory.id && this.shouldMerge(memory, item));
      if (!candidate) {
        merged.push(memory);
        used.add(memory.id);
        continue;
      }
      used.add(memory.id);
      used.add(candidate.id);
      const plan = this.buildMergePlan(memory, candidate);
      merged.push({
        ...memory,
        title: plan.title,
        content: plan.content,
        summary: plan.summary,
        tags: plan.tags,
        keywords: plan.keywords,
        entities: plan.entities,
        version: Math.max(memory.version, candidate.version) + 1,
        updatedAt: new Date().toISOString(),
        checksum: `${memory.checksum.slice(0, 16)}${candidate.checksum.slice(0, 16)}`,
      });
    }
    return merged;
  }

  private mergeContent(primary: MemoryItem, secondary: MemoryItem) {
    const header = `Merged on ${new Date().toISOString()}`;
    return [header, '', primary.content.trim(), '', secondary.content.trim()].join('\n');
  }

  private mergeEntities(first: MemoryItem['entities'], second: MemoryItem['entities']) {
    return unique([...first, ...second].filter(Boolean));
  }

  private buildOverlapReasons(a: MemoryItem, b: MemoryItem, score: number) {
    const reasons = [] as string[];
    if (a.title.toLowerCase() === b.title.toLowerCase()) reasons.push('same title');
    if (a.projectId && a.projectId === b.projectId) reasons.push('same project');
    if (a.conversationId && a.conversationId === b.conversationId) reasons.push('same conversation');
    if (a.tags.some((tag) => b.tags.includes(tag))) reasons.push('shared tags');
    if (a.entities.some((entity) => b.entities.some((candidate) => candidate.id === entity.id))) reasons.push('shared entities');
    if (score > 0.8) reasons.push('high semantic overlap');
    return reasons.length ? reasons : ['semantic overlap'];
  }
}

export const memoryDeduplicationService = new MemoryDeduplicationService();
