import type { KnowledgeBaseEntry, MemoryItem, MemoryProject } from '../types/index';
import { createMemoryId, summarizeText } from '../utils/index';

export class KnowledgeService {
  createEntryFromMemory(memory: MemoryItem): KnowledgeBaseEntry {
    return {
      id: createMemoryId('kb'),
      workspaceId: memory.workspaceId,
      projectId: memory.projectId,
      title: memory.title,
      summary: memory.summary,
      content: memory.content,
      sourceMemoryIds: [memory.id],
      tags: memory.tags,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }

  summarizeProject(project: MemoryProject, memories: MemoryItem[]) {
    const related = memories.filter((m) => m.projectId === project.id);
    const summary = related.slice(0, 5).map((m) => m.summary || m.title).join(' · ');
    return summarizeText(`${project.summary} ${summary}`, 320);
  }
}

export const knowledgeService = new KnowledgeService();
