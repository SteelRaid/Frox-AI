import { exportMemoriesToCSV, exportMemoriesToJSON, exportMemoriesToMarkdown, exportMemoriesToPDF, exportMemoriesToZip } from '../utils/index';
import type { MemoryItem } from '../types/index';

export type ExportFormat = 'json' | 'markdown' | 'csv' | 'pdf' | 'zip';

export class ImportExportService {
  export(memories: MemoryItem[], format: ExportFormat) {
    switch (format) {
      case 'json':
        return new Blob([exportMemoriesToJSON(memories)], { type: 'application/json' });
      case 'markdown':
        return new Blob([exportMemoriesToMarkdown(memories)], { type: 'text/markdown' });
      case 'csv':
        return new Blob([exportMemoriesToCSV(memories)], { type: 'text/csv' });
      case 'pdf':
        return exportMemoriesToPDF(memories);
      case 'zip':
        return exportMemoriesToZip(memories);
    }
  }
}

export const importExportService = new ImportExportService();
