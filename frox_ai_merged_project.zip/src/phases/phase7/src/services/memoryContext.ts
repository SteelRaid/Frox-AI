import type { MemoryCollection, MemoryContextBundle, MemoryItem, MemoryProject } from '../types/index';
import { normalizeText, tokenize } from '../utils/index';
import { searchService } from './searchService';

export interface ContextOptions {
  recentLimit?: number;
  relevantLimit?: number;
  pinnedLimit?: number;
  instructionLimit?: number;
  preferenceLimit?: number;
  goalLimit?: number;
}

export class MemoryContextService {
  buildBundle(
    memories: MemoryItem[],
    projects: MemoryProject[],
    collections: MemoryCollection[],
    workspaceId: string,
    query: string,
    projectId?: string,
    conversationId?: string,
    options: ContextOptions = {}
  ): MemoryContextBundle {
    const normalized = normalizeText(query);
    const recentLimit = options.recentLimit ?? 12;
    const relevantLimit = options.relevantLimit ?? 16;
    const pinnedLimit = options.pinnedLimit ?? 6;

    const workspaceMemories = memories.filter((item) => item.workspaceId === workspaceId && item.status !== 'deleted');
    const projectMemories = projectId ? workspaceMemories.filter((item) => item.projectId === projectId) : workspaceMemories;
    const conversationMemories = conversationId ? workspaceMemories.filter((item) => item.conversationId === conversationId) : [];

    const recent = [...conversationMemories, ...projectMemories, ...workspaceMemories]
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, recentLimit);

    const relevant = searchService.search(workspaceMemories, normalized, relevantLimit).map((result) => result.item);

    const pinned = workspaceMemories
      .filter((item) => item.pinned || item.type === 'pinned')
      .sort((a, b) => b.importance - a.importance)
      .slice(0, pinnedLimit);

    const instruction = workspaceMemories.filter((item) => item.type === 'instruction').slice(0, options.instructionLimit ?? 6);
    const preferences = workspaceMemories.filter((item) => item.type === 'preference').slice(0, options.preferenceLimit ?? 6);
    const goals = workspaceMemories.filter((item) => item.type === 'goal').slice(0, options.goalLimit ?? 6);

    return {
      workspaceId,
      projectId,
      conversationId,
      query,
      recent,
      relevant,
      pinned,
      instruction,
      preferences,
      goals,
      projects: projectId ? projects.filter((project) => project.id === projectId || project.workspaceId === workspaceId) : projects.filter((project) => project.workspaceId === workspaceId),
      collections: collections.filter((collection) => collection.workspaceId === workspaceId),
    };
  }

  createContextPrompt(bundle: MemoryContextBundle) {
    const blocks = [
      `Workspace: ${bundle.workspaceId}`,
      bundle.projectId ? `Project: ${bundle.projectId}` : null,
      bundle.conversationId ? `Conversation: ${bundle.conversationId}` : null,
      bundle.query ? `Query: ${bundle.query}` : null,
      bundle.pinned.length ? this.formatSection('Pinned memories', bundle.pinned) : null,
      bundle.instruction.length ? this.formatSection('Instructions', bundle.instruction) : null,
      bundle.preferences.length ? this.formatSection('Preferences', bundle.preferences) : null,
      bundle.goals.length ? this.formatSection('Goals', bundle.goals) : null,
      bundle.relevant.length ? this.formatSection('Relevant memories', bundle.relevant) : null,
      bundle.recent.length ? this.formatSection('Recent memories', bundle.recent) : null,
    ].filter(Boolean);

    return blocks.join('\n\n');
  }

  suggestContextTokens(bundle: MemoryContextBundle) {
    const tokens = new Set<string>();
    for (const memory of [...bundle.relevant, ...bundle.pinned, ...bundle.preferences, ...bundle.goals]) {
      tokenize(`${memory.title} ${memory.summary} ${memory.tags.join(' ')} ${memory.keywords.join(' ')}`).forEach((token) => tokens.add(token));
    }
    return Array.from(tokens).slice(0, 48);
  }

  private formatSection(title: string, memories: MemoryItem[]) {
    return [title, ...memories.slice(0, 6).map((memory) => `- ${memory.title}: ${memory.summary}`)].join('\n');
  }
}

export const memoryContextService = new MemoryContextService();
