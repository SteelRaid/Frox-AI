import type { MemoryItem, MemoryRetentionReport } from '../types/index';

export interface RetentionPolicy {
  temporaryDays: number;
  archiveAfterDays: number;
  deleteAfterDays: number;
  pinProtected: boolean;
}

export class MemoryRetentionService {
  defaultPolicy: RetentionPolicy = {
    temporaryDays: 7,
    archiveAfterDays: 45,
    deleteAfterDays: 180,
    pinProtected: true,
  };

  evaluate(memory: MemoryItem, policy: RetentionPolicy = this.defaultPolicy) {
    const ageDays = (Date.now() - new Date(memory.updatedAt).getTime()) / (1000 * 60 * 60 * 24);
    const expired = memory.expiresAt ? new Date(memory.expiresAt).getTime() <= Date.now() : false;
    const shouldArchive = !memory.pinned && (expired || ageDays >= policy.archiveAfterDays);
    const shouldDelete = memory.status === 'deleted' || (!memory.pinned && ageDays >= policy.deleteAfterDays);
    return {
      ageDays,
      expired,
      shouldArchive,
      shouldDelete,
      keepWarm: memory.type === 'instruction' || memory.type === 'goal' || memory.type === 'preference',
    };
  }

  retentionReport(memories: MemoryItem[], policy: RetentionPolicy = this.defaultPolicy): MemoryRetentionReport {
    let archived = 0;
    let deleted = 0;
    let expired = 0;
    let retained = 0;
    for (const memory of memories) {
      const result = this.evaluate(memory, policy);
      if (result.expired) expired += 1;
      if (result.shouldDelete) deleted += 1;
      else if (result.shouldArchive) archived += 1;
      else retained += 1;
    }
    return { archived, deleted, expired, retained };
  }

  applyPolicy(memories: MemoryItem[], policy: RetentionPolicy = this.defaultPolicy) {
    return memories.map((memory) => {
      const result = this.evaluate(memory, policy);
      if (result.shouldDelete) return { ...memory, status: 'deleted' as const };
      if (result.shouldArchive) return { ...memory, status: 'archived' as const, archivedAt: memory.archivedAt ?? new Date().toISOString() };
      return memory;
    });
  }
}

export const memoryRetentionService = new MemoryRetentionService();
