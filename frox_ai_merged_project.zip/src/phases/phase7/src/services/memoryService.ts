import type {
  DashboardSnapshot,
  MemoryAnalyticsSnapshot,
  MemoryAttachment,
  MemoryCollection,
  MemoryContextBundle,
  MemoryItem,
  MemoryProject,
  MemoryRelation,
  MemoryRetentionReport,
  MemoryStats,
} from '../types/index';
import { createMemoryId, summarizeText, tokenize, extractEntities, plainTextToMarkdown } from '../utils/index';
import { computeConfidence, computeImportance, computeQuality } from '../utils/score';
import { db, memoryCache } from '../cache/index';
import { supabase } from '../lib/supabase/index';
import { SUPABASE_BUCKETS } from '../constants/index';
import { suggestionService } from './suggestionService';
import { searchService } from './searchService';
import { memoryPipelineService } from './memoryPipeline';
import { memoryRetentionService } from './memoryRetention';
import { memoryAnalyticsService } from './memoryAnalytics';
import { memoryContextService } from './memoryContext';
import { memoryDeduplicationService } from './memoryDeduplication';
import { memoryGraphService } from './memoryGraphService';
import { syncService } from './syncService';
import { memoryContextRouter, memoryEntityEngine, memoryIntelligenceEngine, memoryPolicyEngine, memoryRanker } from '../engine/index';

const toISOString = () => new Date().toISOString();

function normalizeDraft(input: Partial<MemoryItem> & Pick<MemoryItem, 'workspaceId' | 'title' | 'content' | 'type' | 'scope' | 'visibility' | 'source'>): MemoryItem {
  const now = toISOString();
  const entities = input.entities ?? extractEntities(input.content);
  const keywords = input.keywords ?? tokenize(`${input.title} ${input.content}`).slice(0, 18);
  const summary = input.summary ?? summarizeText(input.content, 220);
  const item: MemoryItem = {
    id: input.id ?? createMemoryId('memory'),
    projectId: input.projectId,
    collectionId: input.collectionId,
    conversationId: input.conversationId,
    parentId: input.parentId,
    folderId: input.folderId,
    notes: input.notes,
    labels: input.labels ?? [],
    workspaceId: input.workspaceId,
    title: input.title,
    content: input.content,
    summary,
    type: input.type,
    scope: input.scope,
    visibility: input.visibility,
    status: input.status ?? 'active',
    pinned: input.pinned ?? false,
    favorite: input.favorite ?? false,
    importance: input.importance ?? computeImportance({ pinned: Boolean(input.pinned), type: input.type, content: input.content, tags: input.tags ?? [], labels: input.labels ?? [], updatedAt: now, expiresAt: input.expiresAt ?? null }),
    confidence: input.confidence ?? computeConfidence({ content: input.content, entities, keywords }),
    quality: input.quality ?? computeQuality({ summary, content: input.content, tags: input.tags ?? [], keywords }),
    tags: input.tags ?? Array.from(new Set(keywords.slice(0, 6).concat(entities.map((e) => e.name.toLowerCase())))),
    keywords,
    entities,
    source: input.source,
    expiresAt: input.expiresAt ?? null,
    archivedAt: input.archivedAt ?? null,
    createdAt: input.createdAt ?? now,
    updatedAt: input.updatedAt ?? now,
    accessedAt: input.accessedAt ?? now,
    version: input.version ?? 1,
    checksum: input.checksum ?? '',
    embedding: input.embedding ?? null,
  };
  item.checksum = item.checksum || `${item.title}:${item.content}`.slice(0, 64);
  return item;
}

export class MemoryService {
  async hydrateLocalCache() {
    const memories = await db.memories.toArray();
    if (memories.length) return memories;
    return [] as MemoryItem[];
  }

  async listMemories(workspaceId: string) {
    const cached = await db.memories.where('workspaceId').equals(workspaceId).toArray();
    return cached.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async listWorkspaceSnapshot(workspaceId: string): Promise<DashboardSnapshot> {
    const memories = await this.listMemories(workspaceId);
    return memoryAnalyticsService.buildDashboardSnapshot(memories);
  }

  async getAnalytics(workspaceId: string): Promise<MemoryAnalyticsSnapshot> {
    const memories = await this.listMemories(workspaceId);
    return memoryAnalyticsService.buildSnapshot(memories);
  }

  async getRetentionReport(workspaceId: string): Promise<MemoryRetentionReport> {
    const memories = await this.listMemories(workspaceId);
    return memoryRetentionService.retentionReport(memories);
  }

  async buildContext(workspaceId: string, query: string, projectId?: string, conversationId?: string): Promise<MemoryContextBundle> {
    const memories = await this.listMemories(workspaceId);
    const projects = await db.projects.where('workspaceId').equals(workspaceId).toArray();
    const collections = await db.collections.where('workspaceId').equals(workspaceId).toArray();
    return memoryContextService.buildBundle(memories, projects, collections, workspaceId, query, projectId, conversationId);
  }

  async createMemory(input: Partial<MemoryItem> & Pick<MemoryItem, 'workspaceId' | 'title' | 'content' | 'type' | 'scope' | 'visibility' | 'source'>) {
    const memory = normalizeDraft(input);
    await memoryCache.upsert(memory);
    await db.versions.add({ id: createMemoryId('version'), memoryId: memory.id, version: memory.version, diffSummary: 'Created memory', snapshot: JSON.stringify(memory), createdAt: toISOString() });
    await supabase.from('memories').upsert(memory);
    await syncService.pushEvent(syncService.makeCreateEvent(memory.workspaceId, memory.id, memory));
    return memory;
  }

  async ingestText(input: { workspaceId: string; projectId?: string; conversationId?: string; text: string; title?: string; source?: MemoryItem['source'] }) {
    const memories = await this.listMemories(input.workspaceId);
    const result = memoryPipelineService.evaluate(
      {
        workspaceId: input.workspaceId,
        projectId: input.projectId,
        conversationId: input.conversationId,
        title: input.title,
        content: input.text,
        source: input.source ?? 'ai',
      },
      memories
    );

    if (result.decision.action === 'ignore') return result;
    if (result.decision.action === 'forget') return result;

    const draft = normalizeDraft({
      workspaceId: input.workspaceId,
      projectId: input.projectId,
      conversationId: input.conversationId,
      title: input.title ?? result.draft?.title ?? summarizeText(input.text, 72),
      content: input.text,
      summary: result.draft?.summary ?? summarizeText(input.text, 220),
      type: result.decision.memoryType,
      scope: result.decision.scope,
      visibility: result.decision.visibility,
      status: 'active',
      pinned: result.decision.action === 'pin',
      favorite: false,
      importance: result.draft?.importance,
      confidence: result.draft?.confidence,
      quality: result.draft?.quality,
      tags: result.decision.tags,
      keywords: result.decision.keywords,
      entities: extractEntities(input.text),
      source: input.source ?? 'ai',
      labels: [],
    });

    const duplicates = memories.filter((memory) => result.duplicateIds.includes(memory.id));
    if (result.decision.action === 'merge' && duplicates.length > 0) {
      const merged = await this.mergeMemories(draft.id, duplicates[0].id);
      return { ...result, draft: merged };
    }

    if (result.decision.action === 'update' && duplicates.length > 0) {
      const existing = duplicates[0];
      const updated = await this.updateMemory(existing.id, {
        title: draft.title,
        content: draft.content,
        summary: draft.summary,
        type: draft.type,
        scope: draft.scope,
        visibility: draft.visibility,
        pinned: draft.pinned,
        tags: draft.tags,
        keywords: draft.keywords,
        entities: draft.entities,
      });
      return { ...result, draft: updated };
    }

    const created = await this.createMemory(draft);
    return { ...result, draft: created };
  }

  async updateMemory(id: string, updates: Partial<MemoryItem>) {
    const existing = await db.memories.get(id);
    if (!existing) throw new Error('Memory not found');
    const merged: MemoryItem = {
      ...existing,
      ...updates,
      tags: updates.tags ?? existing.tags,
      keywords: updates.keywords ?? existing.keywords,
      entities: updates.entities ?? existing.entities,
      version: existing.version + 1,
      updatedAt: toISOString(),
      accessedAt: toISOString(),
    };
    merged.importance = updates.importance ?? computeImportance(merged);
    merged.confidence = updates.confidence ?? computeConfidence({ content: merged.content, entities: merged.entities, keywords: merged.keywords });
    merged.quality = updates.quality ?? computeQuality({ summary: merged.summary, content: merged.content, tags: merged.tags, keywords: merged.keywords });
    merged.checksum = `${merged.title}:${merged.content}`.slice(0, 64);

    await db.versions.add({
      id: createMemoryId('version'),
      memoryId: id,
      version: merged.version,
      diffSummary: `Updated memory: ${Object.keys(updates).slice(0, 6).join(', ') || 'content'}`,
      snapshot: JSON.stringify(merged),
      createdAt: toISOString(),
    });

    await memoryCache.upsert(merged);
    await supabase.from('memories').upsert(merged);
    await syncService.pushEvent(syncService.makeCreateEvent(merged.workspaceId, merged.id, merged));
    return merged;
  }

  async deleteMemory(id: string) {
    const existing = await db.memories.get(id);
    if (!existing) return;
    await db.memories.delete(id);
    await supabase.from('memories').delete().eq('id', id);
    await syncService.pushEvent({ id: createMemoryId('sync'), workspaceId: existing.workspaceId, type: 'delete', entityId: id, payload: { id }, createdAt: toISOString() });
  }

  async archiveMemory(id: string) {
    return this.updateMemory(id, { status: 'archived', archivedAt: toISOString() });
  }

  async restoreMemory(id: string) {
    return this.updateMemory(id, { status: 'active', archivedAt: null });
  }

  async duplicateMemory(id: string) {
    const existing = await db.memories.get(id);
    if (!existing) throw new Error('Memory not found');
    return this.createMemory({
      workspaceId: existing.workspaceId,
      projectId: existing.projectId,
      collectionId: existing.collectionId,
      conversationId: existing.conversationId,
      parentId: existing.parentId,
      folderId: existing.folderId,
      notes: existing.notes,
      labels: existing.labels,
      title: `${existing.title} (Copy)`,
      content: existing.content,
      summary: existing.summary,
      type: existing.type,
      scope: existing.scope,
      visibility: existing.visibility,
      status: existing.status,
      pinned: existing.pinned,
      favorite: existing.favorite,
      source: 'import',
      tags: existing.tags,
      keywords: existing.keywords,
      entities: existing.entities,
      expiresAt: existing.expiresAt,
      archivedAt: existing.archivedAt,
      embedding: existing.embedding ?? undefined,
    } as Partial<MemoryItem> & Pick<MemoryItem, 'workspaceId' | 'title' | 'content' | 'type' | 'scope' | 'visibility' | 'source'>);
  }

  async pinMemory(id: string, pinned = true) {
    return this.updateMemory(id, { pinned, type: pinned ? 'pinned' : 'long_term' });
  }

  async mergeMemories(primaryId: string, secondaryId: string) {
    const [a, b] = await Promise.all([db.memories.get(primaryId), db.memories.get(secondaryId)]);
    if (!a || !b) throw new Error('Memory not found');
    const merged = await this.updateMemory(primaryId, memoryDeduplicationService.buildMergePlan(a, b));
    await db.memories.delete(secondaryId);
    await supabase.from('memories').delete().eq('id', secondaryId);
    return merged;
  }

  async splitMemory(id: string, parts: string[]) {
    const existing = await db.memories.get(id);
    if (!existing) throw new Error('Memory not found');
    const children: MemoryItem[] = [];
    for (const part of parts) {
      children.push(await this.createMemory({
        workspaceId: existing.workspaceId,
        projectId: existing.projectId,
        collectionId: existing.collectionId,
        conversationId: existing.conversationId,
        parentId: existing.id,
        title: summarizeText(part, 64),
        content: part,
        summary: summarizeText(part, 220),
        type: existing.type,
        scope: existing.scope,
        visibility: existing.visibility,
        source: 'ai',
      }));
    }
    return children;
  }

  async getStats(workspaceId: string): Promise<MemoryStats> {
    const memories = await db.memories.where('workspaceId').equals(workspaceId).toArray();
    const active = memories.filter((item) => item.status === 'active').length;
    const pinned = memories.filter((item) => item.pinned).length;
    const archived = memories.filter((item) => item.status === 'archived').length;
    const deleted = memories.filter((item) => item.status === 'deleted').length;
    const privateCount = memories.filter((item) => item.visibility === 'private').length;
    const sharedCount = memories.filter((item) => item.visibility === 'shared').length;
    const avgImportance = memories.length ? memories.reduce((acc, item) => acc + item.importance, 0) / memories.length : 0;
    const avgConfidence = memories.length ? memories.reduce((acc, item) => acc + item.confidence, 0) / memories.length : 0;
    const storageBytes = memories.reduce((acc, item) => acc + item.content.length + item.summary.length, 0);
    const updatedToday = memories.filter((item) => new Date(item.updatedAt).toDateString() === new Date().toDateString()).length;
    return { total: memories.length, active, pinned, archived, deleted, privateCount, sharedCount, avgImportance, avgConfidence, storageBytes, updatedToday };
  }

  async search(workspaceId: string, query: string) {
    const memories = await this.listMemories(workspaceId);
    return searchService.search(memories, query);
  }

  async searchWithFilters(workspaceId: string, query: string, filters: Record<string, unknown> = {}) {
    const memories = await this.listMemories(workspaceId);
    return searchService.search(memories, query, 24, { workspaceId, ...(filters as any) });
  }

  async suggestionsFromText(text: string, workspaceId: string, projectId?: string, conversationId?: string) {
    return suggestionService.analyze(text, workspaceId, projectId, conversationId);
  }

  async getMemoryContext(workspaceId: string, query: string, projectId?: string, conversationId?: string) {
    return this.buildContext(workspaceId, query, projectId, conversationId);
  }

  async addAttachment(memoryId: string, attachment: MemoryAttachment) {
    await db.attachments.put(attachment);
    await supabase.from('attachments').upsert(attachment);
    return attachment;
  }

  async uploadAttachment(memoryId: string, file: File, bucket = SUPABASE_BUCKETS.attachments) {
    const path = `${memoryId}/${createMemoryId('attachment')}-${file.name}`;
    const { data, error } = await supabase.storage.from(bucket).upload(path, file, { upsert: true });
    if (error) throw error;
    const publicUrl = supabase.storage.from(bucket).getPublicUrl(data.path).data.publicUrl;
    return this.addAttachment(memoryId, {
      id: createMemoryId('attachment'),
      memoryId,
      name: file.name,
      mimeType: file.type || 'application/octet-stream',
      size: file.size,
      bucket,
      path: data.path,
      publicUrl,
      createdAt: toISOString(),
    });
  }

  async addProject(project: MemoryProject) {
    await db.projects.put(project);
    await supabase.from('projects').upsert(project);
    return project;
  }

  async addCollection(collection: MemoryCollection) {
    await db.collections.put(collection);
    await supabase.from('collections').upsert(collection);
    return collection;
  }

  async addRelation(relation: MemoryRelation) {
    await db.relations.put(relation);
    await supabase.from('memory_relations').upsert(relation);
    return relation;
  }

  async retentionSweep(workspaceId: string) {
    const memories = await this.listMemories(workspaceId);
    const applied = memoryRetentionService.applyPolicy(memories);
    await db.memories.bulkPut(applied);
    return memoryRetentionService.retentionReport(applied);
  }

  async archiveExpiredMemories(workspaceId: string) {
    const memories = await this.listMemories(workspaceId);
    const due = memories.filter((memory) => memory.expiresAt && new Date(memory.expiresAt).getTime() <= Date.now());
    for (const memory of due) {
      await this.archiveMemory(memory.id);
    }
    return due.length;
  }

  async getGraph(workspaceId: string) {
    const memories = await this.listMemories(workspaceId);
    return memoryGraphService.buildGraph(memories);
  }

  async getAnalyticsBundle(workspaceId: string) {
    const memories = await this.listMemories(workspaceId);
    return {
      analytics: memoryAnalyticsService.buildSnapshot(memories),
      dashboard: memoryAnalyticsService.buildDashboardSnapshot(memories),
      retention: memoryRetentionService.retentionReport(memories),
      graph: memoryGraphService.buildGraph(memories),
    };
  }

  async exportMemories(workspaceId: string) {
    const memories = await this.listMemories(workspaceId);
    return {
      json: JSON.stringify(memories, null, 2),
      markdown: plainTextToMarkdown(memories.map((memory) => `# ${memory.title}\n\n${memory.content}`).join('\n\n')),
    };
  }

  analyzeWorkspace(workspaceId: string, query = '') {
    return Promise.all([
      db.memories.where('workspaceId').equals(workspaceId).toArray(),
      db.projects.where('workspaceId').equals(workspaceId).toArray(),
      db.collections.where('workspaceId').equals(workspaceId).toArray(),
    ]).then(([items, projects, collections]) =>
      memoryIntelligenceEngine.analyze(items, projects, collections, { workspaceId, query })
    );
  }

  rankWorkspaceMemories(workspaceId: string, query = '', limit = 12) {
    return db.memories.where('workspaceId').equals(workspaceId).toArray().then((items) => memoryRanker.rank(items, query, { limit }));
  }

  buildWorkspaceContext(workspaceId: string, query: string, projectId?: string, conversationId?: string) {
    return Promise.all([
      db.memories.where('workspaceId').equals(workspaceId).toArray(),
      db.projects.where('workspaceId').equals(workspaceId).toArray(),
      db.collections.where('workspaceId').equals(workspaceId).toArray(),
    ]).then(([items, projects, collections]) =>
      memoryContextRouter.build(items, projects, collections, workspaceId, query, projectId, conversationId)
    );
  }

  inspectWorkspace(workspaceId: string) {
    return db.memories.where('workspaceId').equals(workspaceId).toArray().then((items) => memoryEntityEngine.summarizeWorkspace(items, workspaceId));
  }

  planWorkspaceRetention(workspaceId: string) {
    return db.memories.where('workspaceId').equals(workspaceId).toArray().then((items) => memoryPolicyEngine.plan(items, { workspaceId }));
  }

  listDuplicateCandidates(workspaceId: string) {
    return db.memories.where('workspaceId').equals(workspaceId).toArray().then((items) => memoryPolicyEngine.identifyDuplicates(items));
  }

  computeLocalSuggestions(text: string, workspaceId: string, projectId?: string, conversationId?: string) {
    return suggestionService.analyze(text, workspaceId, projectId, conversationId);
  }
}

export const memoryService = new MemoryService();
