import type { MemoryIntakeResult, MemoryItem, MemorySuggestion } from '../types/index';
import { createMemoryId, extractEntities, extractTopics, summarizeText, tokenize } from '../utils/index';
import { memoryClassifier } from './memoryClassifier';
import { memoryDeduplicationService } from './memoryDeduplication';
import { computeConfidence, computeImportance, computeQuality } from '../utils/score';

export interface IntakeInput {
  workspaceId: string;
  projectId?: string;
  conversationId?: string;
  title?: string;
  content: string;
  existing?: MemoryItem | null;
  source?: MemoryItem['source'];
  visibility?: MemoryItem['visibility'];
}

export class MemoryPipelineService {
  evaluate(input: IntakeInput, memories: MemoryItem[] = []): MemoryIntakeResult {
    const decision = memoryClassifier.classify(input.content, input.existing ?? undefined);
    const entities = extractEntities(input.content);
    const topics = extractTopics(input.content);
    const keywords = Array.from(new Set([...topics, ...tokenize(input.content)]));
    const title = input.title ?? summarizeText(input.content, 72);
    const summary = summarizeText(input.content, 240);

    const draft: Partial<MemoryItem> = {
      id: createMemoryId('memory'),
      workspaceId: input.workspaceId,
      projectId: input.projectId,
      conversationId: input.conversationId,
      title,
      content: input.content,
      summary,
      type: decision.memoryType,
      scope: decision.scope,
      visibility: input.visibility ?? decision.visibility,
      status: 'active',
      pinned: decision.action === 'pin',
      favorite: false,
      importance: computeImportance({
        pinned: decision.action === 'pin',
        type: decision.memoryType,
        content: input.content,
        tags: decision.tags,
        labels: [],
        updatedAt: new Date().toISOString(),
        expiresAt: null,
      }),
      confidence: computeConfidence({ content: input.content, entities, keywords }),
      quality: computeQuality({ summary, content: input.content, tags: decision.tags, keywords }),
      tags: decision.tags,
      keywords,
      entities,
      source: input.source ?? 'ai',
      labels: [],
      notes: undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      accessedAt: new Date().toISOString(),
      version: 1,
      checksum: '',
    };

    const duplicateIds = memories
      .filter((memory) => memory.workspaceId === input.workspaceId)
      .filter((memory) => memory.status !== 'deleted')
      .filter((memory) => memory.projectId === input.projectId || !input.projectId)
      .filter((memory) => memory.conversationId === input.conversationId || !input.conversationId)
      .filter((memory) => memory.tags.some((tag) => decision.tags.includes(tag)) || memory.entities.some((entity) => entities.some((candidate) => candidate.id === entity.id)))
      .filter((memory) => memory.content !== input.content)
      .map((memory) => memory.id)
      .slice(0, 5);

    const suggestions: MemorySuggestion[] = [];
    if (decision.action === 'remember' || decision.action === 'pin') {
      suggestions.push({
        id: createMemoryId('suggestion'),
        kind: decision.action === 'pin' ? 'pin' : 'remember',
        title: decision.action === 'pin' ? 'Pin this memory' : 'Remember this memory',
        reason: decision.reason,
        confidence: decision.confidence,
        createdAt: new Date().toISOString(),
      });
    }
    if (duplicateIds.length > 0) {
      suggestions.push({
        id: createMemoryId('suggestion'),
        kind: 'merge',
        title: 'Possible duplicate memory',
        reason: 'The content overlaps with existing memories in the same workspace.',
        confidence: Math.min(0.95, decision.confidence + 0.05),
        createdAt: new Date().toISOString(),
      });
    }
    if (decision.action === 'forget') {
      suggestions.push({
        id: createMemoryId('suggestion'),
        kind: 'forget',
        title: 'Forget this information',
        reason: decision.reason,
        confidence: decision.confidence,
        createdAt: new Date().toISOString(),
      });
    }

    return { decision, draft, duplicateIds, suggestions };
  }
}

export const memoryPipelineService = new MemoryPipelineService();
