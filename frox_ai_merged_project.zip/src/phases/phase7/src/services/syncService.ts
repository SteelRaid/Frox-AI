import type { ConflictRecord, MemoryItem, SyncEvent, SyncState } from '../types/index';
import { supabase } from '../lib/supabase/index';
import { createMemoryId } from '../utils/index';

export class SyncService {
  async pushEvent(event: SyncEvent) {
    await supabase.from('sync_events').insert(event);
  }

  reconcile(local: MemoryItem, remote: MemoryItem): { winner: MemoryItem; conflict?: ConflictRecord } {
    if (local.version > remote.version) return { winner: local };
    if (remote.version > local.version) return { winner: remote };
    if (new Date(local.updatedAt).getTime() >= new Date(remote.updatedAt).getTime()) return { winner: local };
    return { winner: remote };
  }

  makeCreateEvent(workspaceId: string, entityId: string, payload: Record<string, unknown>): SyncEvent {
    return { id: createMemoryId('sync'), workspaceId, type: 'create', entityId, payload, createdAt: new Date().toISOString() };
  }

  buildState(pending: number, isOnline: boolean, lastSyncAt?: string, lastError?: string): SyncState {
    return { pending, isOnline, lastSyncAt, lastError };
  }
}

export const syncService = new SyncService();
