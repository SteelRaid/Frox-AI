import type { MemoryItem, MemorySuggestion } from '../types/index';
import { createMemoryId, extractEntities, extractTopics, summarizeText, tokenize } from '../utils/index';

const preferencePattern = /\b(i prefer|my preference|i like|i usually|i often|i want|preferred)\b/i;
const rememberPattern = /\b(remember this|keep this in mind|note that|save this)\b/i;
const forgetPattern = /\b(don't remember|do not remember|forget this|ignore this|discard this)\b/i;
const projectPattern = /\b(project|workspace|module|feature|architecture|roadmap|todo|milestone)\b/i;
const instructionPattern = /\b(always|never|must|should|follow|use|avoid|prefer)\b/i;
const goalPattern = /\b(goal|objective|plan to|aim to|want to|intention)\b/i;
const codingPattern = /\b(code|typescript|react|supabase|vite|zod|zustand|tailwind|sql|api)\b/i;

export class SuggestionService {
  analyze(text: string, workspaceId: string, projectId?: string, conversationId?: string): MemorySuggestion[] {
    const normalized = text.trim();
    if (!normalized) return [];

    const entities = extractEntities(normalized);
    const topics = extractTopics(normalized);
    const tokenCount = tokenize(normalized).length;
    const suggestions: MemorySuggestion[] = [];

    const push = (kind: MemorySuggestion['kind'], title: string, reason: string, confidence: number) => {
      suggestions.push({
        id: createMemoryId('suggestion'),
        kind,
        title,
        reason,
        confidence,
        createdAt: new Date().toISOString(),
      });
    };

    if (rememberPattern.test(normalized)) push('remember', 'User asked to remember this', 'The text is framed as an explicit memory request.', 0.99);
    if (forgetPattern.test(normalized)) push('forget', 'Forget this memory', 'The text explicitly asks to forget or ignore.', 0.99);
    if (preferencePattern.test(normalized)) push('remember', 'Preference detected', 'The text looks like a stable preference or habit.', 0.92);
    if (instructionPattern.test(normalized)) push('remember', 'Reusable instruction detected', 'The text reads like a durable rule or instruction.', 0.88);
    if (goalPattern.test(normalized)) push('remember', 'Goal detected', 'The text expresses a goal or objective.', 0.86);
    if (codingPattern.test(normalized)) push('update', 'Coding context detected', 'The content contains developer-oriented context.', 0.82);

    if (projectPattern.test(normalized) || entities.some((entity) => entity.type === 'project')) {
      push('update', 'Project memory candidate', 'The content is related to project structure or project entities.', 0.84);
    }

    if (entities.length >= 2) {
      push('update', 'Entity-rich memory', 'Multiple entities were detected, which usually helps future retrieval.', 0.79);
    }

    if (tokenCount > 45) {
      push('pin', 'Long-form important memory', 'Long, information-dense text often deserves pinning or stronger retention.', 0.74);
    }

    if (suggestions.length === 0 && topics.length > 0) {
      push('remember', 'General knowledge memory', 'The text contains reusable topical information.', 0.56);
    }

    return suggestions.slice(0, 8);
  }

  buildMemoryDraft(text: string, workspaceId: string, type: MemoryItem['type'] = 'knowledge', projectId?: string, conversationId?: string): Partial<MemoryItem> {
    const entities = extractEntities(text);
    const keywords = tokenize(text).slice(0, 14);
    const summary = summarizeText(text, 240);
    return {
      workspaceId,
      projectId,
      conversationId,
      title: summarizeText(text, 72),
      content: text,
      summary,
      type,
      scope: projectId ? 'project' : 'workspace',
      visibility: 'private',
      status: 'active',
      pinned: false,
      favorite: false,
      importance: 0.62,
      confidence: 0.72,
      quality: 0.58,
      tags: Array.from(new Set(entities.map((e) => e.name.toLowerCase()).concat(keywords.slice(0, 4)))),
      keywords,
      entities,
      source: 'ai',
      labels: [],
      checksum: '',
      accessedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: 1,
    };
  }
}

export const suggestionService = new SuggestionService();
