import type { DashboardSnapshot, HeatmapCell, MemoryAnalyticsSnapshot, MemoryItem } from '../types/index';
import { buildGraphFromMemories } from '../utils/graph';
import { computeRecencyScore } from '../utils/score';

function startOfDayKey(date: Date) {
  return date.toISOString().slice(0, 10);
}

export class MemoryAnalyticsService {
  buildSnapshot(memories: MemoryItem[]): MemoryAnalyticsSnapshot {
    const active = memories.filter((item) => item.status === 'active');
    const topTags = this.topTags(memories, 12);
    const topEntities = this.topEntities(memories, 12);
    const timeline = this.timeline(memories);
    const updateVelocity = memories.length
      ? memories.filter((item) => computeRecencyScore(item.updatedAt) > 0.6).length / memories.length
      : 0;

    return {
      total: memories.length,
      active: active.length,
      pinned: memories.filter((item) => item.pinned).length,
      archived: memories.filter((item) => item.status === 'archived').length,
      privateCount: memories.filter((item) => item.visibility === 'private').length,
      sharedCount: memories.filter((item) => item.visibility === 'shared').length,
      updateVelocity,
      averageImportance: memories.length ? memories.reduce((sum, item) => sum + item.importance, 0) / memories.length : 0,
      averageConfidence: memories.length ? memories.reduce((sum, item) => sum + item.confidence, 0) / memories.length : 0,
      topTags,
      topEntities,
      timeline,
    };
  }

  buildDashboardSnapshot(memories: MemoryItem[]): DashboardSnapshot {
    const sorted = memories.slice().sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    const recentMemories = sorted.slice(0, 8);
    const pinnedMemories = sorted.filter((item) => item.pinned).slice(0, 8);
    const storageUsage = memories.reduce((sum, item) => sum + item.content.length + item.summary.length, 0);
    const graph = buildGraphFromMemories(memories);
    return {
      totalMemories: memories.length,
      recentMemories,
      pinnedMemories,
      storageUsage,
      series: this.series(memories),
      heatmap: this.timeline(memories),
      nodes: graph.nodes,
      edges: graph.edges,
    };
  }

  series(memories: MemoryItem[]) {
    const counts = new Map<string, number>();
    for (const memory of memories) {
      const key = startOfDayKey(new Date(memory.updatedAt));
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-14)
      .map(([label, value]) => ({ label, value }));
  }

  timeline(memories: MemoryItem[]): HeatmapCell[] {
    const counts = new Map<string, number>();
    for (const memory of memories) {
      const key = startOfDayKey(new Date(memory.updatedAt));
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-30)
      .map(([date, value]) => ({ date, intensity: Math.min(1, value / 6) }));
  }

  private topTags(memories: MemoryItem[], limit: number) {
    const counts = new Map<string, number>();
    for (const memory of memories) {
      for (const tag of memory.tags) counts.set(tag, (counts.get(tag) ?? 0) + 1);
    }
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([tag]) => tag);
  }

  private topEntities(memories: MemoryItem[], limit: number) {
    const counts = new Map<string, number>();
    for (const memory of memories) {
      for (const entity of memory.entities) counts.set(entity.name, (counts.get(entity.name) ?? 0) + 1);
    }
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([entity]) => entity);
  }
}

export const memoryAnalyticsService = new MemoryAnalyticsService();
