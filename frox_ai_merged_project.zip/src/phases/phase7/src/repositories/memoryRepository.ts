import { db, memoryCache } from '../cache/index';
import { supabase } from '../lib/supabase/index';
import type { MemoryAttachment, MemoryCollection, MemoryItem, MemoryProject, MemoryRelation, SavedSearch } from '../types/index';

export class MemoryRepository {
  async listMemories(workspaceId: string) {
    const cached = await db.memories.where('workspaceId').equals(workspaceId).toArray();
    return cached.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  async upsertMemory(memory: MemoryItem) {
    await memoryCache.upsert(memory);
    await supabase.from('memories').upsert(memory);
    return memory;
  }

  async removeMemory(id: string) {
    await db.memories.delete(id);
    await supabase.from('memories').delete().eq('id', id);
  }

  async replaceAllMemories(memories: MemoryItem[]) {
    await db.transaction('rw', db.memories, async () => {
      await db.memories.clear();
      await db.memories.bulkPut(memories);
    });
  }

  async upsertProject(project: MemoryProject) {
    await db.projects.put(project);
    await supabase.from('projects').upsert(project);
    return project;
  }

  async upsertCollection(collection: MemoryCollection) {
    await db.collections.put(collection);
    await supabase.from('collections').upsert(collection);
    return collection;
  }

  async addRelation(relation: MemoryRelation) {
    await db.relations.put(relation);
    await supabase.from('memory_relations').upsert(relation);
    return relation;
  }

  async addAttachment(attachment: MemoryAttachment) {
    await db.attachments.put(attachment);
    await supabase.from('attachments').upsert(attachment);
    return attachment;
  }

  async saveSearch(search: SavedSearch) {
    await db.searches.put(search);
    return search;
  }
}

export const memoryRepository = new MemoryRepository();
