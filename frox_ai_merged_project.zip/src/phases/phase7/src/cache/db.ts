import Dexie, { type Table } from 'dexie';
import type { MemoryAttachment, MemoryItem, MemoryProject, MemoryRelation, MemoryVersion, SavedSearch, SyncEvent, MemoryCollection, KnowledgeNote } from '../types/index';

export class FroxMemoryDB extends Dexie {
  memories!: Table<MemoryItem, string>;
  projects!: Table<MemoryProject, string>;
  collections!: Table<MemoryCollection, string>;
  relations!: Table<MemoryRelation, string>;
  versions!: Table<MemoryVersion, string>;
  attachments!: Table<MemoryAttachment, string>;
  searches!: Table<SavedSearch, string>;
  notes!: Table<KnowledgeNote, string>;
  syncEvents!: Table<SyncEvent, string>;

  constructor() {
    super('frox-memory-engine');
    this.version(1).stores({
      memories: 'id, workspaceId, projectId, collectionId, conversationId, type, status, pinned, favorite, updatedAt, accessedAt, importance, confidence, quality, checksum',
      projects: 'id, workspaceId, status, updatedAt',
      collections: 'id, workspaceId, projectId, parentId, updatedAt',
      relations: 'id, fromMemoryId, toMemoryId, relation, createdAt',
      versions: 'id, memoryId, version, createdAt',
      attachments: 'id, memoryId, bucket, createdAt',
      searches: 'id, workspaceId, updatedAt',
      notes: 'id, workspaceId, projectId, updatedAt',
      syncEvents: 'id, workspaceId, type, entityId, createdAt',
    });
  }
}

export const db = new FroxMemoryDB();
