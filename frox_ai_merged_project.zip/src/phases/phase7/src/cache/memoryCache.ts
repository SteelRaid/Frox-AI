import { db } from './db';
import type { MemoryItem } from '../types/index';

export const memoryCache = {
  async hydrate(memories: MemoryItem[]) {
    await db.memories.bulkPut(memories);
  },
  async getAll() {
    return db.memories.toArray();
  },
  async upsert(memory: MemoryItem) {
    await db.memories.put(memory);
    return memory;
  },
  async remove(id: string) {
    await db.memories.delete(id);
  },
};
