import type { MemoryItem, MemoryRankingInsight } from '../types/index';
import { computeEntityAffinity, computeRecencyScore, computeDuplicateScore } from '../utils/score';
import { normalizeText, tokenize } from '../utils/index';
import { memorySimilarityEngine } from './memorySimilarity';

export interface MemoryRankerOptions {
  query?: string;
  projectId?: string;
  conversationId?: string;
  limit?: number;
}

export class MemoryRanker {
  score(memory: MemoryItem, query = '', reference?: MemoryItem | null) {
    const normalized = normalizeText(query);
    const queryTokens = tokenize(normalized);
    const text = normalizeText(`${memory.title} ${memory.summary} ${memory.content}`);
    const keywordHits = queryTokens.filter((token) => text.includes(token)).length;
    const tagHits = queryTokens.filter((token) => memory.tags.some((tag) => tag.toLowerCase().includes(token))).length;
    const keywordScore = queryTokens.length ? (keywordHits + tagHits) / queryTokens.length : 0;
    const recency = computeRecencyScore(memory.updatedAt);
    const importance = memory.importance;
    const confidence = memory.confidence;
    const quality = memory.quality;
    const entityAffinity = computeEntityAffinity(memory.entities, queryTokens);
    const projectAffinity = reference?.projectId && memory.projectId && reference.projectId === memory.projectId ? 1 : 0;
    const conversationAffinity = reference?.conversationId && memory.conversationId && reference.conversationId === memory.conversationId ? 1 : 0;
    const similarity = reference ? memorySimilarityEngine.score(reference, memory) : 0;
    const duplicateBias = reference ? computeDuplicateScore(reference, memory) * 0.15 : 0;

    return {
      score: this.clamp(
        keywordScore * 0.24 +
        recency * 0.16 +
        importance * 0.2 +
        confidence * 0.12 +
        quality * 0.12 +
        entityAffinity * 0.08 +
        projectAffinity * 0.04 +
        conversationAffinity * 0.03 +
        similarity * 0.09 +
        duplicateBias,
      ),
      factors: { recency, importance, confidence, quality, similarity, entityAffinity, projectAffinity },
      reasons: this.reasons(memory, keywordHits, tagHits, projectAffinity, conversationAffinity, similarity),
    };
  }

  rank(memories: MemoryItem[], query = '', options: MemoryRankerOptions = {}): MemoryRankingInsight[] {
    const reference = memories.find((item) => item.projectId === options.projectId || item.conversationId === options.conversationId) ?? memories[0] ?? null;
    return memories
      .map((memory) => {
        const result = this.score(memory, query, reference ?? memory);
        return {
          id: memory.id,
          title: memory.title,
          score: result.score,
          factors: result.factors,
          reasons: result.reasons,
        } satisfies MemoryRankingInsight;
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, options.limit ?? 20);
  }

  topByImportance(memories: MemoryItem[], limit = 10) {
    return [...memories]
      .sort((a, b) => b.importance - a.importance || b.updatedAt.localeCompare(a.updatedAt))
      .slice(0, limit);
  }

  private reasons(memory: MemoryItem, keywordHits: number, tagHits: number, projectAffinity: number, conversationAffinity: number, similarity: number) {
    const reasons = [] as string[];
    if (memory.pinned) reasons.push('pinned');
    if (memory.favorite) reasons.push('favorite');
    if (memory.status === 'archived') reasons.push('archived');
    if (keywordHits > 0) reasons.push('keyword match');
    if (tagHits > 0) reasons.push('tag match');
    if (projectAffinity > 0) reasons.push('same project');
    if (conversationAffinity > 0) reasons.push('same conversation');
    if (similarity > 0.45) reasons.push('high semantic similarity');
    if (memory.type === 'instruction' || memory.type === 'goal' || memory.type === 'preference') reasons.push('high value type');
    return reasons.length ? reasons : ['general relevance'];
  }

  private clamp(value: number) {
    return Math.max(0, Math.min(1, value));
  }
}

export const memoryRanker = new MemoryRanker();
