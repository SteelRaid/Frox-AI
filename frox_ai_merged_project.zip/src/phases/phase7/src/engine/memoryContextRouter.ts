import type { MemoryCollection, MemoryContextBundle, MemoryContextPlan, MemoryItem, MemoryProject } from '../types/index';
import { summarizeText } from '../utils/index';
import { memoryRanker } from './memoryRanker';

export interface ContextRouterOptions {
  budget?: number;
  recentLimit?: number;
  relevantLimit?: number;
  pinnedLimit?: number;
}

export class MemoryContextRouter {
  build(
    memories: MemoryItem[],
    projects: MemoryProject[],
    collections: MemoryCollection[],
    workspaceId: string,
    query: string,
    projectId?: string,
    conversationId?: string,
    options: ContextRouterOptions = {}
  ): MemoryContextPlan {
    const budget = options.budget ?? 6000;
    const recentLimit = options.recentLimit ?? 6;
    const relevantLimit = options.relevantLimit ?? 10;
    const pinnedLimit = options.pinnedLimit ?? 6;
    const workspaceMemories = memories.filter((memory) => memory.workspaceId === workspaceId && memory.status !== 'deleted');

    const pinned = workspaceMemories.filter((memory) => memory.pinned).slice(0, pinnedLimit);
    const recent = [...workspaceMemories].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, recentLimit);
    const ranked = memoryRanker.rank(workspaceMemories, query, { projectId, conversationId, limit: relevantLimit });
    const relevant = ranked
      .map((entry) => workspaceMemories.find((memory) => memory.id === entry.id))
      .filter((item): item is MemoryItem => Boolean(item));

    const instructions = workspaceMemories.filter((memory) => memory.type === 'instruction' || /\b(always|never|must|should)\b/i.test(memory.content)).slice(0, 4);
    const preferences = workspaceMemories.filter((memory) => memory.type === 'preference' || /\b(i prefer|my preference|favorite|usually)\b/i.test(memory.content)).slice(0, 4);
    const goals = workspaceMemories.filter((memory) => memory.type === 'goal' || /\b(goal|objective|want to|intend to)\b/i.test(memory.content)).slice(0, 4);
    const supporting = workspaceMemories.filter((memory) => ![...pinned, ...recent, ...relevant, ...instructions, ...preferences, ...goals].some((item) => item.id === memory.id)).slice(0, 8);

    const slots = [
      { title: 'Pinned', items: pinned, limit: pinnedLimit, rationale: 'Always injected first because the user explicitly pinned them.' },
      { title: 'Recent', items: recent, limit: recentLimit, rationale: 'Recent context preserves immediate continuity.' },
      { title: 'Relevant', items: relevant, limit: relevantLimit, rationale: 'Ranked by semantic and factual relevance to the current query.' },
      { title: 'Instructions', items: instructions, limit: 4, rationale: 'Long-lived behavioral instructions and constraints.' },
      { title: 'Preferences', items: preferences, limit: 4, rationale: 'Stable preferences that shape output style.' },
      { title: 'Goals', items: goals, limit: 4, rationale: 'Task and goal memories help steer the conversation.' },
      { title: 'Supporting', items: supporting, limit: 8, rationale: 'Extra knowledge that enriches context without overwhelming it.' },
    ];

    const ordered = slots.flatMap((slot) => slot.items.map((item) => item.id));
    const selected = slots.flatMap((slot) => slot.items);
    const condensedSummary = summarizeText(selected.map((item) => `${item.title}: ${item.summary || item.content}`).join('\n\n'), 480);
    const totalTokens = Math.min(budget, selected.reduce((sum, item) => sum + Math.max(1, item.content.split(/\s+/).length), 0));

    return {
      workspaceId,
      projectId,
      conversationId,
      query,
      slots,
      condensedSummary,
      totalTokens,
      injectionOrder: ordered,
    };
  }

  toBundle(
    plan: MemoryContextPlan,
    projects: MemoryProject[] = [],
    collections: MemoryCollection[] = []
  ): MemoryContextBundle {
    const map = new Map(plan.slots.map((slot) => [slot.title, slot.items] as const));
    return {
      workspaceId: plan.workspaceId,
      projectId: plan.projectId,
      conversationId: plan.conversationId,
      query: plan.query,
      recent: map.get('Recent') ?? [],
      relevant: map.get('Relevant') ?? [],
      pinned: map.get('Pinned') ?? [],
      instruction: map.get('Instructions') ?? [],
      preferences: map.get('Preferences') ?? [],
      goals: map.get('Goals') ?? [],
      projects,
      collections,
    };
  }
}

export const memoryContextRouter = new MemoryContextRouter();
