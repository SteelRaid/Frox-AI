import type { MemoryCollection, MemoryContextPlan, MemoryItem, MemoryIntelligenceReport, MemoryProject, MemoryRetentionPlan } from '../types/index';
import { memoryContextRouter } from './memoryContextRouter';
import { memoryEntityEngine } from './memoryEntityEngine';
import { memoryPolicyEngine } from './memoryPolicyEngine';
import { memoryRanker } from './memoryRanker';
import { memorySimilarityEngine } from './memorySimilarity';

export interface IntelligenceOptions {
  workspaceId: string;
  projectId?: string;
  conversationId?: string;
  budget?: number;
  query?: string;
}

export class MemoryIntelligenceEngine {
  analyze(
    memories: MemoryItem[],
    projects: MemoryProject[],
    collections: MemoryCollection[],
    options: IntelligenceOptions
  ): MemoryIntelligenceReport {
    const workspaceMemories = memories.filter((memory) => memory.workspaceId === options.workspaceId && memory.status !== 'deleted');
    const ranking = memoryRanker.rank(workspaceMemories, options.query ?? '', {
      projectId: options.projectId,
      conversationId: options.conversationId,
      limit: 24,
    });
    const selectedMemoryIds = ranking.slice(0, 8).map((item) => item.id);
    const policy = memoryPolicyEngine.plan(workspaceMemories, { workspaceId: options.workspaceId }).actions;
    const context: MemoryContextPlan = memoryContextRouter.build(
      workspaceMemories,
      projects,
      collections,
      options.workspaceId,
      options.query ?? '',
      options.projectId,
      options.conversationId,
      { budget: options.budget ?? 6000 }
    );
    const signals = this.extractSignals(workspaceMemories, options.query ?? '');

    return {
      workspaceId: options.workspaceId,
      query: options.query ?? '',
      selectedMemoryIds,
      ranking,
      policy,
      context,
      signals,
    };
  }

  buildConflictNarrative(primary: MemoryItem, secondary: MemoryItem) {
    const similarity = memorySimilarityEngine.score(primary, secondary);
    const higherValue = primary.importance >= secondary.importance ? primary : secondary;
    const lowerValue = higherValue.id === primary.id ? secondary : primary;
    return {
      similarity,
      winnerId: higherValue.id,
      loserId: lowerValue.id,
      reason: similarity > 0.8 ? 'High duplication detected.' : 'The memories overlap but still carry different nuance.',
      recommendation: similarity > 0.8 ? 'merge' : 'review',
    };
  }

  retentionPlan(memories: MemoryItem[], workspaceId: string): MemoryRetentionPlan {
    return memoryPolicyEngine.plan(memories.filter((memory) => memory.workspaceId === workspaceId), { workspaceId });
  }

  private extractSignals(memories: MemoryItem[], query: string) {
    const text = `${query} ${memories.slice(0, 20).map((memory) => `${memory.title} ${memory.summary} ${memory.content}`).join(' ')}`;
    const insight = memoryEntityEngine.inspect(text);
    const signals = new Set<string>();
    if (insight.people.length) signals.add('people');
    if (insight.projects.length) signals.add('projects');
    if (insight.tools.length) signals.add('tools');
    if (insight.locations.length) signals.add('locations');
    if (insight.topics.some((topic) => /memory|context|prompt|workflow/.test(topic))) signals.add('workflow');
    if (insight.topics.some((topic) => /design|ui|ux/.test(topic))) signals.add('design');
    if (insight.topics.some((topic) => /code|api|sql|react|supabase/.test(topic))) signals.add('engineering');
    return [...signals];
  }
}

export const memoryIntelligenceEngine = new MemoryIntelligenceEngine();
