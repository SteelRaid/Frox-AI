import type { MemoryItem, MemoryRankedItem, MemoryScoringBreakdown, MemorySimilaritySignal } from '../types/index';
import { normalizeText, tokenize } from '../utils/index';
import { computeRecencyScore } from '../utils/score';

export class MemorySimilarityEngine {
  signal(a: MemoryItem, b: MemoryItem): MemorySimilaritySignal {
    const textA = normalizeText(`${a.title} ${a.summary} ${a.content}`);
    const textB = normalizeText(`${b.title} ${b.summary} ${b.content}`);
    const tokensA = new Set(tokenize(textA));
    const tokensB = new Set(tokenize(textB));
    const title = this.overlap(tokenize(a.title), tokenize(b.title));
    const summary = this.overlap(tokenize(a.summary), tokenize(b.summary));
    const tags = this.overlap(a.tags, b.tags);
    const keywords = this.overlap(a.keywords, b.keywords);
    const entities = this.entityOverlap(a.entities, b.entities);
    const text = this.overlap(Array.from(tokensA), Array.from(tokensB));
    const projectAffinity = a.projectId && b.projectId && a.projectId === b.projectId ? 1 : 0;
    const conversationAffinity = a.conversationId && b.conversationId && a.conversationId === b.conversationId ? 1 : 0;
    const recency = 1 - Math.min(1, Math.abs(new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime()) / (1000 * 60 * 60 * 24 * 365));
    return { text, title, summary, tags, keywords, entities, projectAffinity, conversationAffinity, recency, importance: (a.importance + b.importance) / 2 };
  }

  score(a: MemoryItem, b: MemoryItem): number {
    const signal = this.signal(a, b);
    const score = signal.text * 0.26 + signal.title * 0.14 + signal.summary * 0.12 + signal.tags * 0.12 + signal.keywords * 0.1 + signal.entities * 0.1 + signal.projectAffinity * 0.06 + signal.conversationAffinity * 0.04 + signal.recency * 0.08 + signal.importance * 0.08;
    return Math.max(0, Math.min(1, score));
  }

  rank(target: MemoryItem, memories: MemoryItem[], limit = 12): MemoryRankedItem[] {
    return memories
      .filter((memory) => memory.id !== target.id)
      .map((memory) => {
        const signal = this.signal(target, memory);
        const score = this.score(target, memory);
        return {
          memory,
          score,
          breakdown: this.breakdown(signal),
          reasons: this.reasons(signal),
        };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  cluster(memories: MemoryItem[], threshold = 0.45) {
    const clusters: MemoryItem[][] = [];
    const remaining = [...memories];
    while (remaining.length) {
      const seed = remaining.shift()!;
      const cluster = [seed];
      for (let i = remaining.length - 1; i >= 0; i -= 1) {
        const candidate = remaining[i];
        if (this.score(seed, candidate) >= threshold) {
          cluster.push(candidate);
          remaining.splice(i, 1);
        }
      }
      clusters.push(cluster);
    }
    return clusters;
  }

  private overlap(a: string[], b: string[]) {
    if (!a.length || !b.length) return 0;
    const setA = new Set(a.map((item) => item.toLowerCase()));
    const setB = new Set(b.map((item) => item.toLowerCase()));
    let matches = 0;
    for (const token of setA) if (setB.has(token)) matches += 1;
    return matches / Math.max(setA.size, setB.size);
  }

  private entityOverlap(a: MemoryItem['entities'], b: MemoryItem['entities']) {
    if (!a.length || !b.length) return 0;
    const ids = new Set(b.map((entity) => entity.id));
    const matches = a.filter((entity) => ids.has(entity.id)).length;
    return matches / Math.max(a.length, b.length);
  }

  private breakdown(signal: MemorySimilaritySignal): MemoryScoringBreakdown {
    return {
      importance: signal.importance,
      confidence: Math.min(1, 0.6 + signal.entities * 0.1 + signal.tags * 0.1),
      quality: Math.min(1, 0.4 + signal.summary * 0.3 + signal.title * 0.2),
      relevance: (signal.text + signal.tags + signal.keywords) / 3,
      similarity: (signal.text + signal.title + signal.summary + signal.tags + signal.keywords + signal.entities) / 6,
      recency: signal.recency,
    };
  }

  private reasons(signal: MemorySimilaritySignal) {
    const reasons = ['semantic overlap'];
    if (signal.projectAffinity > 0) reasons.push('same project');
    if (signal.conversationAffinity > 0) reasons.push('same conversation');
    if (signal.entities > 0.2) reasons.push('shared entities');
    if (signal.tags > 0.2) reasons.push('shared tags');
    return reasons;
  }
}

export const memorySimilarityEngine = new MemorySimilarityEngine();
