import type { MemoryCollection, MemoryContextBundle, MemoryItem, MemoryProject } from '../types/index';
import { normalizeText, tokenize } from '../utils/index';
import { memorySimilarityEngine } from './memorySimilarity';

export interface ContextBudget {
  recent: number;
  relevant: number;
  supporting: number;
  pinned: number;
  instructions: number;
  preferences: number;
  goals: number;
}

const defaultBudget: ContextBudget = {
  recent: 10,
  relevant: 14,
  supporting: 8,
  pinned: 6,
  instructions: 5,
  preferences: 5,
  goals: 5,
};

export class MemoryContextBuilder {
  build(
    memories: MemoryItem[],
    projects: MemoryProject[],
    collections: MemoryCollection[],
    workspaceId: string,
    query: string,
    projectId?: string,
    conversationId?: string,
    budget: Partial<ContextBudget> = {}
  ): MemoryContextBundle {
    const b = { ...defaultBudget, ...budget };
    const normalized = normalizeText(query);
    const workspaceMemories = memories.filter((item) => item.workspaceId === workspaceId && item.status !== 'deleted');
    const scopeMemories = projectId ? workspaceMemories.filter((item) => item.projectId === projectId) : workspaceMemories;
    const conversationMemories = conversationId ? scopeMemories.filter((item) => item.conversationId === conversationId) : [];

    const recent = [...conversationMemories, ...scopeMemories]
      .sort((a, b) => new Date(b.accessedAt).getTime() - new Date(a.accessedAt).getTime())
      .slice(0, b.recent);

    const relevant = this.sortByQueryAffinity(scopeMemories, normalized).slice(0, b.relevant);
    const supporting = this.buildSupporting(scopeMemories, relevant).slice(0, b.supporting);
    const pinned = scopeMemories.filter((item) => item.pinned || item.type === 'pinned').sort((a, b) => b.importance - a.importance).slice(0, b.pinned);
    const instructions = scopeMemories.filter((item) => item.type === 'instruction').sort((a, b) => b.importance - a.importance).slice(0, b.instructions);
    const preferences = scopeMemories.filter((item) => item.type === 'preference').sort((a, b) => b.importance - a.importance).slice(0, b.preferences);
    const goals = scopeMemories.filter((item) => item.type === 'goal').sort((a, b) => b.importance - a.importance).slice(0, b.goals);

    return {
      workspaceId,
      projectId,
      conversationId,
      query,
      recent,
      relevant,
      pinned,
      instruction: instructions,
      preferences,
      goals,
      projects: projects.filter((project) => project.workspaceId === workspaceId && (!projectId || project.id === projectId)),
      collections: collections.filter((collection) => collection.workspaceId === workspaceId && (!projectId || collection.projectId === projectId || !collection.projectId)),
      supporting,
      summary: this.buildSummary(normalized, relevant, pinned, instructions, preferences, goals),
    };
  }

  renderPrompt(bundle: MemoryContextBundle) {
    return [
      `Memory Context for workspace ${bundle.workspaceId}`,
      bundle.projectId ? `Project: ${bundle.projectId}` : null,
      bundle.conversationId ? `Conversation: ${bundle.conversationId}` : null,
      bundle.query ? `Query: ${bundle.query}` : null,
      this.section('Pinned', bundle.pinned),
      this.section('Instructions', bundle.instruction),
      this.section('Preferences', bundle.preferences),
      this.section('Goals', bundle.goals),
      this.section('Relevant', bundle.relevant),
      this.section('Recent', bundle.recent),
      this.section('Supporting', bundle.supporting),
      bundle.summary ? `Summary: ${bundle.summary}` : null,
    ].filter(Boolean).join('\n\n');
  }

  tokens(bundle: MemoryContextBundle) {
    const tokens = new Set<string>();
    for (const memory of [...bundle.pinned, ...bundle.instruction, ...bundle.preferences, ...bundle.goals, ...bundle.relevant, ...bundle.supporting]) {
      tokenize(`${memory.title} ${memory.summary} ${memory.content} ${memory.tags.join(' ')} ${memory.keywords.join(' ')}`).forEach((token) => tokens.add(token));
    }
    return Array.from(tokens).slice(0, 64);
  }

  private section(title: string, memories: MemoryItem[]) {
    if (!memories.length) return null;
    return `${title}:\n${memories.map((memory) => `- ${memory.title}: ${memory.summary || memory.content.slice(0, 140)}`).join('\n')}`;
  }

  private buildSummary(query: string, relevant: MemoryItem[], pinned: MemoryItem[], instructions: MemoryItem[], preferences: MemoryItem[], goals: MemoryItem[]) {
    const parts = [
      query ? `focus on ${query}` : 'workspace memory',
      relevant[0]?.title,
      pinned[0]?.title,
      instructions[0]?.title,
      preferences[0]?.title,
      goals[0]?.title,
    ].filter(Boolean);
    return parts.join(' • ');
  }

  private sortByQueryAffinity(memories: MemoryItem[], query: string) {
    const normalized = normalizeText(query);
    if (!normalized) return memories.slice().sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    return memories
      .slice()
      .sort((a, b) => memorySimilarityEngine.score(this.queryMemory(normalized, a), a) - memorySimilarityEngine.score(this.queryMemory(normalized, b), b))
      .reverse();
  }

  private buildSupporting(memories: MemoryItem[], relevant: MemoryItem[]) {
    const ids = new Set(relevant.map((item) => item.id));
    const supporting = memories.filter((memory) => !ids.has(memory.id)).filter((memory) => relevant.some((item) => memorySimilarityEngine.score(memory, item) >= 0.32));
    return supporting.sort((a, b) => b.importance - a.importance);
  }

  private queryMemory(query: string, memory: MemoryItem): MemoryItem {
    return {
      ...memory,
      id: `query:${query}`,
      title: query,
      content: query,
      summary: query,
      keywords: tokenize(query),
      tags: tokenize(query).slice(0, 6),
    };
  }
}

export const memoryContextBuilder = new MemoryContextBuilder();
