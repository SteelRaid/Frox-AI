import type { GraphEdge, GraphNode, MemoryItem } from '../types/index';

export interface GraphCluster {
  id: string;
  label: string;
  memoryIds: string[];
  density: number;
  centroid: { x: number; y: number };
}

export interface GraphSnapshot {
  nodes: GraphNode[];
  edges: GraphEdge[];
  clusters: GraphCluster[];
  density: number;
  averageDegree: number;
}

export class MemoryKnowledgeGraph {
  build(memories: MemoryItem[]): GraphSnapshot {
    const nodes = memories.slice(0, 120).map((memory, index) => ({
      id: memory.id,
      label: memory.title,
      type: this.nodeType(memory),
      x: 90 + (index % 10) * 122,
      y: 100 + Math.floor(index / 10) * 104,
      size: 18 + Math.min(20, memory.tags.length * 2 + (memory.pinned ? 6 : 0)),
    } satisfies GraphNode));

    const edges: GraphEdge[] = [];
    for (let i = 0; i < memories.length; i += 1) {
      for (let j = i + 1; j < memories.length; j += 1) {
        const a = memories[i];
        const b = memories[j];
        const weight = this.linkWeight(a, b);
        if (weight >= 0.32) {
          edges.push({
            id: `edge-${a.id}-${b.id}`,
            source: a.id,
            target: b.id,
            weight: Number(weight.toFixed(3)),
            relation: this.relation(a, b),
          });
        }
      }
    }

    const clusters = this.cluster(memories, edges);
    const density = nodes.length > 1 ? edges.length / (nodes.length * (nodes.length - 1) / 2) : 0;
    const averageDegree = nodes.length ? (edges.length * 2) / nodes.length : 0;
    return { nodes, edges, clusters, density, averageDegree };
  }

  neighborhood(memories: MemoryItem[], targetId: string, depth = 1) {
    const byId = new Map(memories.map((memory) => [memory.id, memory] as const));
    const visited = new Set<string>([targetId]);
    const frontier = [targetId];
    for (let step = 0; step < depth; step += 1) {
      const next: string[] = [];
      for (const id of frontier) {
        const node = byId.get(id);
        if (!node) continue;
        for (const candidate of memories) {
          if (visited.has(candidate.id)) continue;
          if (this.linkWeight(node, candidate) >= 0.32) {
            visited.add(candidate.id);
            next.push(candidate.id);
          }
        }
      }
      frontier.splice(0, frontier.length, ...next);
    }
    return Array.from(visited).map((id) => byId.get(id)).filter(Boolean) as MemoryItem[];
  }

  private nodeType(memory: MemoryItem): GraphNode['type'] {
    if (memory.projectId) return 'project';
    if (memory.collectionId) return 'collection';
    if (memory.entities.some((entity) => entity.type === 'person')) return 'person';
    if (memory.tags.some((tag) => ['topic', 'idea', 'research'].includes(tag))) return 'topic';
    return 'memory';
  }

  private relation(a: MemoryItem, b: MemoryItem) {
    if (a.projectId && b.projectId && a.projectId === b.projectId) return 'project-link';
    if (a.conversationId && b.conversationId && a.conversationId === b.conversationId) return 'conversation-link';
    if (a.entities.some((entity) => b.entities.some((candidate) => candidate.id === entity.id))) return 'entity-link';
    return 'tag-link';
  }

  private linkWeight(a: MemoryItem, b: MemoryItem) {
    const tagHits = this.overlap(a.tags, b.tags);
    const keywordHits = this.overlap(a.keywords, b.keywords);
    const entityHits = this.entityOverlap(a.entities, b.entities);
    const sameProject = a.projectId && b.projectId && a.projectId === b.projectId ? 1 : 0;
    const sameConversation = a.conversationId && b.conversationId && a.conversationId === b.conversationId ? 1 : 0;
    const recency = 1 - Math.min(1, Math.abs(new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime()) / (1000 * 60 * 60 * 24 * 365));
    return tagHits * 0.18 + keywordHits * 0.15 + entityHits * 0.28 + sameProject * 0.22 + sameConversation * 0.1 + recency * 0.07;
  }

  private overlap(a: string[], b: string[]) {
    if (!a.length || !b.length) return 0;
    const setA = new Set(a.map((item) => item.toLowerCase()));
    const setB = new Set(b.map((item) => item.toLowerCase()));
    let hits = 0;
    for (const token of setA) if (setB.has(token)) hits += 1;
    return hits / Math.max(setA.size, setB.size);
  }

  private entityOverlap(a: MemoryItem['entities'], b: MemoryItem['entities']) {
    if (!a.length || !b.length) return 0;
    const ids = new Set(b.map((entity) => entity.id));
    const hits = a.filter((entity) => ids.has(entity.id)).length;
    return hits / Math.max(a.length, b.length);
  }

  private cluster(memories: MemoryItem[], edges: GraphEdge[]) {
    const adjacency = new Map<string, Set<string>>();
    for (const memory of memories) adjacency.set(memory.id, new Set());
    for (const edge of edges) {
      adjacency.get(edge.source)?.add(edge.target);
      adjacency.get(edge.target)?.add(edge.source);
    }

    const visited = new Set<string>();
    const clusters: GraphCluster[] = [];
    for (const memory of memories) {
      if (visited.has(memory.id)) continue;
      const queue = [memory.id];
      const component: string[] = [];
      while (queue.length) {
        const current = queue.shift()!;
        if (visited.has(current)) continue;
        visited.add(current);
        component.push(current);
        const neighbors = adjacency.get(current) ?? new Set<string>();
        for (const next of neighbors) if (!visited.has(next)) queue.push(next);
      }
      const avgX = component.length ? component.reduce((sum, id) => sum + (memories.findIndex((item) => item.id === id) % 10), 0) / component.length : 0;
      const avgY = component.length ? component.reduce((sum, id) => sum + Math.floor(memories.findIndex((item) => item.id === id) / 10), 0) / component.length : 0;
      const edgeCount = edges.filter((edge) => component.includes(edge.source) && component.includes(edge.target)).length;
      clusters.push({
        id: `cluster-${clusters.length + 1}`,
        label: component[0] ? memories.find((item) => item.id === component[0])?.title ?? `Cluster ${clusters.length + 1}` : `Cluster ${clusters.length + 1}`,
        memoryIds: component,
        density: component.length > 1 ? edgeCount / (component.length * (component.length - 1) / 2) : 0,
        centroid: { x: avgX, y: avgY },
      });
    }
    return clusters;
  }
}

export const memoryKnowledgeGraph = new MemoryKnowledgeGraph();
