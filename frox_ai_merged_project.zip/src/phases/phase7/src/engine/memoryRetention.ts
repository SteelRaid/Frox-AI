import type { MemoryItem, MemoryRetentionReport } from '../types/index';
import type { MemoryRetentionPlan } from '../types/engine';
import type { MemorySettings } from '../types/index';

export interface RetentionInput {
  memories: MemoryItem[];
  settings: MemorySettings;
}

export class MemoryRetentionEngine {
  evaluate({ memories, settings }: RetentionInput): MemoryRetentionPlan {
    const actions = memories.map((memory) => this.decide(memory, settings));
    const report: MemoryRetentionReport = {
      archived: actions.filter((action) => action.action === 'archive').length,
      deleted: actions.filter((action) => action.action === 'delete').length,
      expired: actions.filter((action) => action.reason.includes('expired')).length,
      retained: actions.filter((action) => action.action === 'retain' || action.action === 'promote').length,
    };
    return { actions, report };
  }

  decide(memory: MemoryItem, settings: MemorySettings) {
    const now = Date.now();
    const created = new Date(memory.createdAt).getTime();
    const updated = new Date(memory.updatedAt).getTime();
    const ageDays = (now - created) / (1000 * 60 * 60 * 24);
    const staleDays = (now - updated) / (1000 * 60 * 60 * 24);
    const temporaryHours = settings.retentionPolicy.temporaryHours;
    const archiveAfterDays = settings.retentionPolicy.archiveAfterDays;
    const deleteAfterDays = settings.retentionPolicy.deleteAfterDays;

    if (memory.status === 'deleted') return { memoryId: memory.id, action: 'delete', reason: 'already deleted', targetStatus: 'deleted' as const };
    if (memory.status === 'temporary' && ageDays * 24 >= temporaryHours) return { memoryId: memory.id, action: 'delete', reason: 'temporary memory expired', targetStatus: 'deleted' as const };
    if (memory.expiresAt && new Date(memory.expiresAt).getTime() <= now) return { memoryId: memory.id, action: 'delete', reason: 'memory expired by explicit expiration date', targetStatus: 'deleted' as const };
    if (memory.favorite || memory.pinned) return { memoryId: memory.id, action: 'promote', reason: 'favorite or pinned memory should stay visible', targetStatus: 'active' as const };
    if (memory.importance >= 0.86 && memory.status !== 'archived') return { memoryId: memory.id, action: 'retain', reason: 'high-importance memory retained', targetStatus: 'active' as const };
    if (ageDays >= deleteAfterDays) return { memoryId: memory.id, action: 'delete', reason: 'memory aged past delete retention threshold', targetStatus: 'deleted' as const };
    if (ageDays >= archiveAfterDays || staleDays >= archiveAfterDays) return { memoryId: memory.id, action: 'archive', reason: 'memory aged past archive retention threshold', targetStatus: 'archived' as const };
    if (memory.quality < 0.25 || memory.confidence < 0.22) return { memoryId: memory.id, action: 'compress', reason: 'low-quality memory should be compressed', targetStatus: memory.status };
    return { memoryId: memory.id, action: 'retain', reason: 'memory still useful', targetStatus: 'active' as const };
  }
}

export const memoryRetentionEngine = new MemoryRetentionEngine();
