import type { ConflictRecord, MemoryItem, MemorySyncSnapshot, SyncEvent } from '../types/index';
import { createMemoryId } from '../utils/index';

export class MemorySyncCoordinator {
  snapshot(pending: SyncEvent[], conflicts: ConflictRecord[] = []): MemorySyncSnapshot {
    return {
      pending: pending.length,
      conflicts: conflicts.length,
      lastPushAt: pending.at(-1)?.createdAt,
      lastPullAt: conflicts.at(-1)?.createdAt,
      lastError: conflicts.at(-1) ? 'conflict detected during sync' : undefined,
    };
  }

  makeUpdateEvent(workspaceId: string, memory: MemoryItem): SyncEvent {
    return {
      id: createMemoryId('sync'),
      workspaceId,
      type: 'update',
      entityId: memory.id,
      payload: { memory },
      createdAt: new Date().toISOString(),
    };
  }

  resolveConflict(local: MemoryItem, remote: MemoryItem): { winner: MemoryItem; loser: MemoryItem; merged: MemoryItem; reason: string } {
    const winner = local.updatedAt >= remote.updatedAt ? local : remote;
    const loser = winner.id === local.id ? remote : local;
    const merged: MemoryItem = {
      ...winner,
      summary: winner.summary.length >= loser.summary.length ? winner.summary : loser.summary,
      content: winner.content.length >= loser.content.length ? winner.content : loser.content,
      tags: Array.from(new Set([...local.tags, ...remote.tags])),
      keywords: Array.from(new Set([...local.keywords, ...remote.keywords])).slice(0, 32),
      entities: [...local.entities, ...remote.entities].filter((entity, index, all) => all.findIndex((candidate) => candidate.id === entity.id) === index),
      updatedAt: new Date().toISOString(),
      version: Math.max(local.version, remote.version) + 1,
    };
    return {
      winner,
      loser,
      merged,
      reason: winner === local ? 'local copy is newer' : 'remote copy is newer',
    };
  }
}

export const memorySyncCoordinator = new MemorySyncCoordinator();
