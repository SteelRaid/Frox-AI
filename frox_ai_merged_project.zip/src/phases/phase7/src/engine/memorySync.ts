import type { ConflictRecord, MemoryItem, SyncEvent, SyncState } from '../types/index';
import type { SyncConflictResolution } from '../types/engine';
import { createMemoryId } from '../utils/index';
import { supabase } from '../lib/supabase/index';

export class MemorySyncEngine {
  createEvent(workspaceId: string, type: SyncEvent['type'], entityId: string, payload: Record<string, unknown>): SyncEvent {
    return {
      id: createMemoryId('sync'),
      workspaceId,
      type,
      entityId,
      payload,
      createdAt: new Date().toISOString(),
    };
  }

  buildState(pending: number, isOnline: boolean, lastSyncAt?: string, lastError?: string): SyncState {
    return { pending, isOnline, lastSyncAt, lastError };
  }

  resolve(local: MemoryItem, remote: MemoryItem): SyncConflictResolution {
    if (local.version !== remote.version) {
      return local.version > remote.version
        ? { winner: local, loser: remote, reason: 'local version is newer' }
        : { winner: remote, loser: local, reason: 'remote version is newer' };
    }
    if (new Date(local.updatedAt).getTime() >= new Date(remote.updatedAt).getTime()) {
      return { winner: local, loser: remote, reason: 'local timestamp wins tie-breaker' };
    }
    return { winner: remote, loser: local, reason: 'remote timestamp wins tie-breaker' };
  }

  async push(event: SyncEvent) {
    await supabase.from('sync_events').insert(event);
  }

  annotateConflict(local: MemoryItem, remote: MemoryItem): ConflictRecord {
    return {
      id: createMemoryId('conflict'),
      entityId: local.id,
      localVersion: local.version,
      remoteVersion: remote.version,
      resolution: 'merged',
      createdAt: new Date().toISOString(),
    };
  }
}

export const memorySyncEngine = new MemorySyncEngine();
