import type { MemoryDecisionExplanation, MemoryDecisionSignal, MemoryItem } from '../types/index';
import { extractEntities, extractTopics, normalizeText, tokenize } from '../utils/index';

const stablePreferencePattern = /\b(i prefer|my preference|i usually|i often|i like|preferred|favorite)\b/i;
const explicitMemoryPattern = /\b(remember this|keep this in mind|save this|note this|store this)\b/i;
const explicitForgetPattern = /\b(forget this|don't remember|do not remember|ignore this|discard this)\b/i;
const projectPattern = /\b(project|workspace|roadmap|architecture|module|feature|milestone|planning)\b/i;
const instructionPattern = /\b(always|never|must|should|avoid|follow|use|prefer)\b/i;
const goalPattern = /\b(goal|objective|aim|plan to|intend to|want to achieve)\b/i;
const codingPattern = /\b(typescript|react|supabase|vite|zustand|tailwind|sql|api|worker|cache|dexie)\b/i;
const repetitivePattern = /(\b\w+\b)(?:\s+\1){2,}/i;

export interface MemoryDecisionResult {
  action: 'remember' | 'update' | 'ignore' | 'forget' | 'merge' | 'pin';
  memoryType: MemoryItem['type'];
  scope: MemoryItem['scope'];
  visibility: MemoryItem['visibility'];
  confidence: number;
  reason: string;
  tags: string[];
  keywords: string[];
  signal: MemoryDecisionSignal;
  explanation: MemoryDecisionExplanation;
}

export class MemoryDecisionEngine {
  analyze(text: string, existing?: MemoryItem | null): MemoryDecisionResult {
    const normalized = normalizeText(text);
    const entities = extractEntities(normalized);
    const topics = extractTopics(normalized);
    const tokens = tokenize(normalized);

    const signal: MemoryDecisionSignal = {
      keywordHits: this.countHits(normalized, [stablePreferencePattern, projectPattern, instructionPattern, goalPattern, codingPattern, explicitMemoryPattern]),
      entityHits: entities.length,
      repeatedPatternHits: repetitivePattern.test(normalized) ? 1 : 0,
      stablePreference: stablePreferencePattern.test(normalized),
      projectIntent: projectPattern.test(normalized),
      instructionIntent: instructionPattern.test(normalized),
      goalIntent: goalPattern.test(normalized),
      codingIntent: codingPattern.test(normalized),
      explicitMemoryRequest: explicitMemoryPattern.test(normalized),
      explicitForgetRequest: explicitForgetPattern.test(normalized),
    };

    const tags = this.buildTags(normalized, topics, entities);
    const keywords = this.buildKeywords(tokens, topics, entities);

    if (signal.explicitForgetRequest) {
      return {
        action: 'forget',
        memoryType: existing?.type ?? 'temporary',
        scope: existing?.scope ?? 'conversation',
        visibility: existing?.visibility ?? 'private',
        confidence: 0.99,
        reason: 'The text explicitly asks to forget or ignore the information.',
        tags,
        keywords,
        signal,
        explanation: {
          action: 'forget',
          reasoning: ['Matched an explicit forget pattern.', 'The content should not be retained as a stable memory.'],
          confidence: 0.99,
        },
      };
    }

    if (existing && this.isUpdateCandidate(normalized, existing)) {
      return {
        action: 'update',
        memoryType: existing.type,
        scope: existing.scope,
        visibility: existing.visibility,
        confidence: 0.87,
        reason: 'This looks like a refinement or correction to an existing memory.',
        tags,
        keywords,
        signal,
        explanation: {
          action: 'update',
          reasoning: ['An existing memory was supplied.', 'The new text is structurally similar to the existing memory but adds detail or a correction.'],
          confidence: 0.87,
        },
      };
    }

    const base = this.scoreDecision(signal, entities, topics, existing);
    return {
      ...base,
      tags,
      keywords,
      signal,
    };
  }

  private scoreDecision(signal: MemoryDecisionSignal, entities: ReturnType<typeof extractEntities>, topics: string[], existing?: MemoryItem | null): Omit<MemoryDecisionResult, 'tags' | 'keywords' | 'signal'> {
    const importanceBase = Math.min(1, 0.15 + signal.keywordHits * 0.08 + signal.entityHits * 0.05 + topics.length * 0.04);
    const explain = (action: MemoryDecisionResult['action'], reason: string, reasoning: string[], memoryType: MemoryItem['type'], scope: MemoryItem['scope']): Omit<MemoryDecisionResult, 'tags' | 'keywords' | 'signal'> => ({
      action,
      memoryType,
      scope,
      visibility: existing?.visibility ?? 'private',
      confidence: Math.min(0.98, 0.7 + importanceBase),
      reason,
      explanation: { action, reasoning, confidence: Math.min(0.98, 0.7 + importanceBase) },
    });

    if (signal.stablePreference) {
      return explain('pin', 'The content looks like a stable preference and should be kept easy to retrieve.', ['Detected preference phrasing.', 'Stable preferences are high-value memories.'], 'preference', existing?.scope ?? 'workspace');
    }

    if (signal.explicitMemoryRequest || signal.instructionIntent || signal.goalIntent || signal.projectIntent) {
      return explain(
        'remember',
        `The content looks reusable because it appears to be ${this.describeSignal(signal)}.`,
        ['Explicit memory or durable intent detected.', 'This content should be available for future context injection.'],
        signal.goalIntent ? 'goal' : signal.instructionIntent ? 'instruction' : signal.projectIntent ? 'project' : 'knowledge',
        existing?.scope ?? (signal.projectIntent ? 'project' : 'workspace')
      );
    }

    if (signal.codingIntent || entities.some((entity) => entity.type === 'tool' || entity.type === 'project')) {
      return explain(
        'remember',
        'The content contains durable developer or project context.',
        ['Coding or project terminology was detected.', 'This is likely useful in future conversation turns.'],
        signal.codingIntent ? 'coding' : 'knowledge',
        existing?.scope ?? 'workspace'
      );
    }

    if (signal.repeatedPatternHits || tokenize(normalizeText(entities.map((entity) => entity.name).join(' '))).length === 0) {
      return {
        action: 'ignore',
        memoryType: existing?.type ?? 'temporary',
        scope: existing?.scope ?? 'conversation',
        visibility: existing?.visibility ?? 'private',
        confidence: 0.56,
        reason: 'The content does not appear durable enough for long-term storage.',
        explanation: {
          action: 'ignore',
          reasoning: ['The message is repetitive or too thin to be a useful memory.', 'Low-value content is intentionally filtered out.'],
          confidence: 0.56,
        },
      };
    }

    return {
      action: 'remember',
      memoryType: 'knowledge',
      scope: existing?.scope ?? 'workspace',
      visibility: existing?.visibility ?? 'private',
      confidence: 0.63,
      reason: 'The text looks useful enough to retain for future retrieval.',
      explanation: {
        action: 'remember',
        reasoning: ['The message contains reusable information.', 'It is not obviously transient or noisy.'],
        confidence: 0.63,
      },
    };
  }

  private buildTags(normalized: string, topics: string[], entities: ReturnType<typeof extractEntities>) {
    const tags = new Set<string>();
    topics.forEach((topic) => tags.add(topic.toLowerCase()));
    entities.forEach((entity) => tags.add(entity.name.toLowerCase()));
    if (/\b(ui|ux|design)\b/i.test(normalized)) tags.add('design');
    if (/\b(api|backend|database|schema|sql)\b/i.test(normalized)) tags.add('backend');
    if (/\b(memory|context|recall)\b/i.test(normalized)) tags.add('memory');
    return Array.from(tags).slice(0, 10);
  }

  private buildKeywords(tokens: string[], topics: string[], entities: ReturnType<typeof extractEntities>) {
    const keywords = new Set<string>(tokens.slice(0, 18));
    topics.forEach((topic) => keywords.add(topic.toLowerCase()));
    entities.forEach((entity) => keywords.add(entity.name.toLowerCase()));
    return Array.from(keywords).slice(0, 24);
  }

  private countHits(text: string, patterns: RegExp[]) {
    return patterns.reduce((count, pattern) => (pattern.test(text) ? count + 1 : count), 0);
  }

  private describeSignal(signal: MemoryDecisionSignal) {
    if (signal.stablePreference) return 'a stable preference';
    if (signal.instructionIntent) return 'an instruction';
    if (signal.goalIntent) return 'a goal';
    if (signal.projectIntent) return 'project context';
    if (signal.codingIntent) return 'coding context';
    return 'reusable knowledge';
  }

  private isUpdateCandidate(normalized: string, existing: MemoryItem) {
    const existingText = normalizeText(`${existing.title} ${existing.summary} ${existing.content}`);
    if (!existingText) return false;
    if (normalized === existingText) return true;
    const overlap = tokenize(normalized).filter((token) => existingText.includes(token)).length;
    return overlap >= Math.max(3, Math.floor(tokenize(existingText).length * 0.25));
  }
}

export const memoryDecisionEngine = new MemoryDecisionEngine();
