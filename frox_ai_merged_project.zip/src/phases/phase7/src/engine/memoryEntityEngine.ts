import type { MemoryEntity, MemoryItem, MemoryWorkspaceInsight } from '../types/index';
import { extractEntities, extractLocations, extractPeople, extractProjects, extractTools, extractTopics } from '../utils/entities';
import { normalizeText } from '../utils/index';

export interface EntityInsight {
  entities: MemoryEntity[];
  topics: string[];
  people: MemoryEntity[];
  projects: MemoryEntity[];
  tools: MemoryEntity[];
  locations: MemoryEntity[];
}

export class MemoryEntityEngine {
  inspect(text: string): EntityInsight {
    const normalized = normalizeText(text);
    return {
      entities: extractEntities(normalized),
      topics: extractTopics(normalized),
      people: extractPeople(normalized),
      projects: extractProjects(normalized),
      tools: extractTools(normalized),
      locations: extractLocations(normalized),
    };
  }

  summarizeWorkspace(memories: MemoryItem[], workspaceId: string): MemoryWorkspaceInsight {
    const workspaceMemories = memories.filter((memory) => memory.workspaceId === workspaceId);
    const topTags = this.topTerms(workspaceMemories.flatMap((memory) => memory.tags));
    const topEntities = this.topTerms(workspaceMemories.flatMap((memory) => memory.entities.map((entity) => entity.name)));
    const staleMemories = workspaceMemories.filter((memory) => new Date(memory.updatedAt).getTime() < Date.now() - 1000 * 60 * 60 * 24 * 45).length;
    const activityScore = workspaceMemories.reduce((acc, memory) => acc + memory.importance * 0.35 + memory.confidence * 0.2 + (memory.pinned ? 0.4 : 0), 0) / Math.max(1, workspaceMemories.length);

    return {
      workspaceId,
      totalMemories: workspaceMemories.length,
      activeMemories: workspaceMemories.filter((memory) => memory.status === 'active').length,
      pinnedMemories: workspaceMemories.filter((memory) => memory.pinned).length,
      projects: new Set(workspaceMemories.map((memory) => memory.projectId).filter(Boolean)).size,
      collections: new Set(workspaceMemories.map((memory) => memory.collectionId).filter(Boolean)).size,
      topTags,
      topEntities,
      activityScore,
      storageBytes: workspaceMemories.reduce((acc, memory) => acc + memory.content.length + memory.summary.length, 0),
      staleMemories,
    };
  }

  private topTerms(items: string[]) {
    const counts = new Map<string, number>();
    for (const item of items) {
      const key = item.toLowerCase().trim();
      if (!key) continue;
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([term]) => term);
  }
}

export const memoryEntityEngine = new MemoryEntityEngine();
