import JSZip from 'jszip';
import { jsPDF } from 'jspdf';
import type { ExportBundle, ExportOptions, ImportResult } from '../types/engine';
import type { MemoryAttachment, MemoryCollection, MemoryItem, MemoryProject, MemoryRelation, SavedSearch } from '../types/index';

export class MemoryImportExportEngine {
  exportJson(bundle: ExportBundle, options: ExportOptions = {}) {
    const payload: ExportBundle = {
      ...bundle,
      memories: bundle.memories,
      projects: options.includeProjects === false ? [] : bundle.projects,
      collections: options.includeCollections === false ? [] : bundle.collections,
      attachments: options.includeAttachments === false ? [] : bundle.attachments,
      relations: options.includeRelations === false ? [] : bundle.relations,
      savedSearches: options.includeSearches === false ? [] : bundle.savedSearches,
    };
    return JSON.stringify(payload, null, options.pretty === false ? 0 : 2);
  }

  exportMarkdown(bundle: ExportBundle) {
    const lines = [
      `# Memory Export`,
      `Workspace: ${bundle.workspaceId}`,
      `Exported: ${bundle.exportedAt}`,
      '',
      '## Memories',
      ...bundle.memories.map((memory) => `- **${memory.title}** — ${memory.summary}`),
      '',
      '## Projects',
      ...bundle.projects.map((project) => `- **${project.name}** — ${project.summary}`),
      '',
      '## Collections',
      ...bundle.collections.map((collection) => `- **${collection.name}**`),
    ];
    return lines.join('\n');
  }

  exportCsv(memories: MemoryItem[]) {
    const header = ['id', 'title', 'type', 'scope', 'visibility', 'status', 'importance', 'confidence', 'quality', 'tags', 'keywords'];
    const rows = memories.map((memory) => [
      memory.id,
      this.escape(memory.title),
      memory.type,
      memory.scope,
      memory.visibility,
      memory.status,
      String(memory.importance),
      String(memory.confidence),
      String(memory.quality),
      this.escape(memory.tags.join('|')),
      this.escape(memory.keywords.join('|')),
    ]);
    return [header.join(','), ...rows.map((row) => row.join(','))].join('\n');
  }

  async exportZip(bundle: ExportBundle) {
    const zip = new JSZip();
    zip.file('memories.json', this.exportJson(bundle));
    zip.file('memories.md', this.exportMarkdown(bundle));
    zip.file('memories.csv', this.exportCsv(bundle.memories));
    zip.file('manifest.json', JSON.stringify({ workspaceId: bundle.workspaceId, exportedAt: bundle.exportedAt, counts: this.counts(bundle) }, null, 2));
    return zip.generateAsync({ type: 'blob' });
  }

  exportPdf(bundle: ExportBundle) {
    const pdf = new jsPDF({ unit: 'pt', format: 'a4' });
    let y = 40;
    const addLine = (line: string) => {
      if (y > 760) {
        pdf.addPage();
        y = 40;
      }
      pdf.text(line.slice(0, 110), 40, y);
      y += 16;
    };
    addLine('Memory Export');
    addLine(`Workspace: ${bundle.workspaceId}`);
    addLine(`Exported: ${bundle.exportedAt}`);
    y += 10;
    addLine('Memories');
    for (const memory of bundle.memories.slice(0, 80)) addLine(`- ${memory.title} :: ${memory.summary}`);
    return pdf.output('blob');
  }

  importJson(json: string): ImportResult {
    const parsed = JSON.parse(json) as Partial<ExportBundle>;
    return {
      memories: Array.isArray(parsed.memories) ? parsed.memories as MemoryItem[] : [],
      projects: Array.isArray(parsed.projects) ? parsed.projects as MemoryProject[] : [],
      collections: Array.isArray(parsed.collections) ? parsed.collections as MemoryCollection[] : [],
      attachments: Array.isArray(parsed.attachments) ? parsed.attachments as MemoryAttachment[] : [],
      relations: Array.isArray(parsed.relations) ? parsed.relations as MemoryRelation[] : [],
      savedSearches: Array.isArray(parsed.savedSearches) ? parsed.savedSearches as SavedSearch[] : [],
      warnings: [],
    };
  }

  private counts(bundle: ExportBundle) {
    return { memories: bundle.memories.length, projects: bundle.projects.length, collections: bundle.collections.length, attachments: bundle.attachments.length, relations: bundle.relations.length, searches: bundle.savedSearches.length };
  }

  private escape(text: string) {
    return `"${text.replace(/"/g, '""')}"`;
  }
}

export const memoryImportExportEngine = new MemoryImportExportEngine();
