import type { MemoryCompressionResult, MemoryItem } from '../types/index';
import { extractEntities, extractTopics, summarizeText, tokenize } from '../utils/index';

export class MemoryCompressionEngine {
  compress(memory: MemoryItem, maxTokens = 120): MemoryCompressionResult {
    const tokens = tokenize(`${memory.title} ${memory.summary} ${memory.content}`);
    const highlights = this.highlights(memory);
    const keywords = Array.from(new Set([...memory.keywords, ...extractTopics(memory.content), ...tokenize(memory.title)])).slice(0, 18);
    const entities = extractEntities(memory.content);
    const compressedContent = this.compressContent(memory.content, maxTokens);
    return {
      summary: summarizeText(memory.content, 180),
      compressedContent,
      highlights,
      keywords,
      entities,
      tokenCount: tokens.length,
      compressionRatio: compressedContent.length / Math.max(1, memory.content.length),
    };
  }

  chunk(text: string, chunkSize = 2200) {
    const chunks: string[] = [];
    for (let index = 0; index < text.length; index += chunkSize) chunks.push(text.slice(index, index + chunkSize));
    return chunks;
  }

  private compressContent(text: string, maxTokens: number) {
    const tokens = tokenize(text);
    if (tokens.length <= maxTokens) return text;
    const head = tokens.slice(0, Math.floor(maxTokens * 0.5)).join(' ');
    const tail = tokens.slice(-Math.floor(maxTokens * 0.2)).join(' ');
    const middle = tokens.slice(Math.floor(maxTokens * 0.5), Math.floor(maxTokens * 0.8)).join(' ');
    return [head, middle, tail].filter(Boolean).join(' • ');
  }

  private highlights(memory: MemoryItem) {
    const parts = [memory.title, memory.summary, ...memory.tags.slice(0, 4), ...memory.entities.map((entity) => entity.name).slice(0, 4)];
    return Array.from(new Set(parts.filter(Boolean))).slice(0, 8);
  }
}

export const memoryCompressionEngine = new MemoryCompressionEngine();
