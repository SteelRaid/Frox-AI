import type { DecryptionInput, EncryptionResult } from '../types/engine';

function encode(bytes: Uint8Array) {
  return btoa(String.fromCharCode(...bytes));
}

function decode(text: string) {
  return Uint8Array.from(atob(text), (character) => character.charCodeAt(0));
}

async function deriveKey(password: string, salt: Uint8Array) {
  const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, keyMaterial, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

export class MemoryEncryptionEngine {
  async encrypt(text: string, password: string): Promise<EncryptionResult> {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveKey(password, salt);
    const cipherBuffer = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
    return { cipherText: encode(new Uint8Array(cipherBuffer)), iv: encode(iv), salt: encode(salt) };
  }

  async decrypt(payload: DecryptionInput, password: string) {
    const salt = decode(payload.salt);
    const iv = decode(payload.iv);
    const key = await deriveKey(password, salt);
    const plainBuffer = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, decode(payload.cipherText));
    return new TextDecoder().decode(plainBuffer);
  }
}

export const memoryEncryptionEngine = new MemoryEncryptionEngine();
