import type { MemoryItem, MemoryPolicyDecision, MemoryPolicySummary, MemoryRetentionPlan } from '../types/index';
import { DEFAULT_MEMORY_RETENTION_DAYS, DEFAULT_SHORT_TERM_RETENTION_DAYS, DEFAULT_TEMPORARY_RETENTION_HOURS } from '../constants/index';
import { isExpired } from '../utils/dates';
import { computeDuplicateScore, computeRecencyScore } from '../utils/score';

export interface PolicyInputs {
  workspaceId: string;
  now?: number;
}

export class MemoryPolicyEngine {
  evaluate(memory: MemoryItem, inputs: PolicyInputs = { workspaceId: memory.workspaceId }): MemoryPolicyDecision {
    const now = inputs.now ?? Date.now();
    const ageHours = (now - new Date(memory.updatedAt).getTime()) / (1000 * 60 * 60);
    const ageDays = ageHours / 24;
    const recency = computeRecencyScore(memory.updatedAt);

    if (memory.status === 'deleted') {
      return { memoryId: memory.id, action: 'delete', reason: 'Memory is already deleted.', priority: 1, targetStatus: 'deleted' };
    }

    if (memory.expiresAt && isExpired(memory.expiresAt)) {
      return { memoryId: memory.id, action: 'archive', reason: 'Memory has expired.', priority: 0.95, targetStatus: 'archived' };
    }

    if (memory.pinned || memory.type === 'instruction' || memory.type === 'goal' || memory.type === 'preference') {
      return { memoryId: memory.id, action: 'promote', reason: 'High-value durable memory type.', priority: 0.9 + memory.importance * 0.05, targetStatus: 'active' };
    }

    if (memory.type === 'temporary' || memory.scope === 'conversation') {
      if (ageHours > DEFAULT_TEMPORARY_RETENTION_HOURS) {
        return { memoryId: memory.id, action: 'archive', reason: 'Temporary or conversation memory aged out.', priority: 0.82, targetStatus: 'archived' };
      }
      return { memoryId: memory.id, action: 'retain', reason: 'Recent transient memory still useful.', priority: 0.56 + recency * 0.1, targetStatus: 'active' };
    }

    if (memory.type === 'short_term' && ageDays > DEFAULT_SHORT_TERM_RETENTION_DAYS) {
      return { memoryId: memory.id, action: 'compress', reason: 'Short-term memory should be compacted after the retention window.', priority: 0.72, targetStatus: 'archived' };
    }

    if (ageDays > DEFAULT_MEMORY_RETENTION_DAYS && memory.importance < 0.35) {
      return { memoryId: memory.id, action: 'archive', reason: 'Old low-importance memory should be archived.', priority: 0.7, targetStatus: 'archived' };
    }

    if (memory.importance > 0.84 || memory.confidence > 0.86) {
      return { memoryId: memory.id, action: 'promote', reason: 'Strong memory confidence or importance.', priority: 0.88, targetStatus: 'active' };
    }

    if (recency < 0.2 && memory.quality < 0.34) {
      return { memoryId: memory.id, action: 'review', reason: 'Stale memory with low quality should be reviewed before retention.', priority: 0.63, targetStatus: 'active' };
    }

    return { memoryId: memory.id, action: 'retain', reason: 'Memory is still valid and worth keeping.', priority: 0.5 + memory.importance * 0.2, targetStatus: 'active' };
  }

  plan(memories: MemoryItem[], inputs: PolicyInputs): MemoryRetentionPlan {
    const actions = memories.map((memory) => this.evaluate(memory, inputs));
    const report: MemoryPolicySummary = { retained: 0, archived: 0, deleted: 0, compressed: 0, promoted: 0, reviewed: 0 };
    for (const action of actions) {
      switch (action.action) {
        case 'archive':
          report.archived += 1;
          break;
        case 'delete':
          report.deleted += 1;
          break;
        case 'compress':
          report.compressed += 1;
          break;
        case 'promote':
        case 'pin':
          report.promoted += 1;
          break;
        case 'review':
          report.reviewed += 1;
          break;
        case 'retain':
        default:
          report.retained += 1;
          break;
      }
    }
    return { actions, report };
  }

  identifyDuplicates(memories: MemoryItem[]) {
    const pairs: Array<{ primary: MemoryItem; secondary: MemoryItem; score: number }> = [];
    for (let i = 0; i < memories.length; i += 1) {
      for (let j = i + 1; j < memories.length; j += 1) {
        const score = computeDuplicateScore(memories[i], memories[j]);
        if (score > 0.74) pairs.push({ primary: memories[i], secondary: memories[j], score });
      }
    }
    return pairs.sort((a, b) => b.score - a.score);
  }
}

export const memoryPolicyEngine = new MemoryPolicyEngine();
