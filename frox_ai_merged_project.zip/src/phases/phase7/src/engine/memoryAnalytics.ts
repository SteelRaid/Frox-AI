import type { DashboardSnapshot, HeatmapCell, MemoryAnalyticsSnapshot, MemoryItem } from '../types/index';
import { buildGraphFromMemories } from '../utils/graph';
import { computeRecencyScore } from '../utils/score';

export class MemoryAnalyticsEngine {
  snapshot(memories: MemoryItem[]): MemoryAnalyticsSnapshot {
    const total = memories.length;
    const active = memories.filter((memory) => memory.status === 'active').length;
    const pinned = memories.filter((memory) => memory.pinned).length;
    const archived = memories.filter((memory) => memory.status === 'archived').length;
    const privateCount = memories.filter((memory) => memory.visibility === 'private').length;
    const sharedCount = memories.filter((memory) => memory.visibility === 'shared').length;
    const averageImportance = total ? memories.reduce((sum, memory) => sum + memory.importance, 0) / total : 0;
    const averageConfidence = total ? memories.reduce((sum, memory) => sum + memory.confidence, 0) / total : 0;
    const updateVelocity = total ? memories.filter((memory) => computeRecencyScore(memory.updatedAt) > 0.6).length / total : 0;
    return {
      total,
      active,
      pinned,
      archived,
      privateCount,
      sharedCount,
      averageImportance,
      averageConfidence,
      updateVelocity,
      topTags: this.topTags(memories),
      topEntities: this.topEntities(memories),
      timeline: this.timeline(memories),
    };
  }

  dashboard(memories: MemoryItem[]): DashboardSnapshot {
    const sorted = memories.slice().sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    const graph = buildGraphFromMemories(memories);
    return {
      totalMemories: memories.length,
      recentMemories: sorted.slice(0, 8),
      pinnedMemories: sorted.filter((memory) => memory.pinned).slice(0, 8),
      storageUsage: memories.reduce((sum, memory) => sum + memory.content.length + memory.summary.length, 0),
      series: this.series(memories),
      heatmap: this.timeline(memories),
      nodes: graph.nodes,
      edges: graph.edges,
    };
  }

  series(memories: MemoryItem[]) {
    const counts = new Map<string, number>();
    for (const memory of memories) {
      const key = memory.updatedAt.slice(0, 10);
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b)).slice(-14).map(([label, value]) => ({ label, value }));
  }

  timeline(memories: MemoryItem[]): HeatmapCell[] {
    const counts = new Map<string, number>();
    for (const memory of memories) {
      const key = memory.updatedAt.slice(0, 10);
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return Array.from(counts.entries()).sort(([a], [b]) => a.localeCompare(b)).slice(-30).map(([date, value]) => ({ date, intensity: Math.min(1, value / 6) }));
  }

  private topTags(memories: MemoryItem[]) {
    const counts = new Map<string, number>();
    for (const memory of memories) for (const tag of memory.tags) counts.set(tag, (counts.get(tag) ?? 0) + 1);
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([tag]) => tag);
  }

  private topEntities(memories: MemoryItem[]) {
    const counts = new Map<string, number>();
    for (const memory of memories) for (const entity of memory.entities) counts.set(entity.name, (counts.get(entity.name) ?? 0) + 1);
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([entity]) => entity);
  }
}

export const memoryAnalyticsEngine = new MemoryAnalyticsEngine();
