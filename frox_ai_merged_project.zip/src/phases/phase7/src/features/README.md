This phase is organized without an additional feature layer so the memory engine stays easy to extend inside Frox AI's existing architecture.
