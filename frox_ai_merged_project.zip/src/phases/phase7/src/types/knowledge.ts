import type { MemoryItem, MemoryProject } from './memory';

export interface KnowledgeBaseEntry {
  id: string;
  workspaceId: string;
  projectId?: string;
  title: string;
  summary: string;
  content: string;
  sourceMemoryIds: string[];
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface KnowledgeCluster {
  id: string;
  title: string;
  memoryIds: string[];
  description: string;
}

export interface KnowledgeBaseState {
  notes: KnowledgeBaseEntry[];
  clusters: KnowledgeCluster[];
  projects: MemoryProject[];
  memories: MemoryItem[];
}
