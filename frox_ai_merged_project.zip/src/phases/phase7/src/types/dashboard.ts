import type { MemoryItem } from './memory';

export interface DashboardSeriesPoint {
  label: string;
  value: number;
}

export interface HeatmapCell {
  date: string;
  intensity: number;
}

export interface GraphNode {
  id: string;
  label: string;
  type: 'memory' | 'project' | 'person' | 'topic' | 'collection';
  x: number;
  y: number;
  size: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  weight: number;
  relation: string;
}

export interface DashboardSnapshot {
  totalMemories: number;
  recentMemories: MemoryItem[];
  pinnedMemories: MemoryItem[];
  storageUsage: number;
  series: DashboardSeriesPoint[];
  heatmap: HeatmapCell[];
  nodes: GraphNode[];
  edges: GraphEdge[];
}
