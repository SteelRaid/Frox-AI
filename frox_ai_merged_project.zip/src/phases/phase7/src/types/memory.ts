import type { HeatmapCell } from './dashboard';
export type MemoryVisibility = 'private' | 'shared' | 'workspace' | 'system' | 'hidden';
export type MemoryStatus = 'active' | 'temporary' | 'archived' | 'deleted';
export type MemoryScope = 'conversation' | 'project' | 'workspace' | 'global';
export type MemorySource = 'user' | 'assistant' | 'system' | 'ai' | 'import';
export type MemoryType =
  | 'conversation'
  | 'long_term'
  | 'short_term'
  | 'temporary'
  | 'pinned'
  | 'project'
  | 'workspace'
  | 'coding'
  | 'personality'
  | 'preference'
  | 'task'
  | 'goal'
  | 'instruction'
  | 'document'
  | 'image'
  | 'voice'
  | 'file'
  | 'calendar'
  | 'reminder'
  | 'relationship'
  | 'knowledge'
  | 'ai_generated'
  | 'system'
  | 'private'
  | 'shared'
  | 'archived'
  | 'deleted'
  | 'hidden';

export interface MemoryEntity {
  id: string;
  type: 'person' | 'project' | 'tool' | 'location' | 'topic' | 'file' | 'organization';
  name: string;
  confidence: number;
}

export interface MemoryAttachment {
  id: string;
  memoryId: string;
  name: string;
  mimeType: string;
  size: number;
  bucket: string;
  path: string;
  publicUrl?: string;
  createdAt: string;
}

export interface MemoryVersion {
  id: string;
  memoryId: string;
  version: number;
  diffSummary: string;
  snapshot: string;
  createdAt: string;
}

export interface MemoryRelation {
  id: string;
  fromMemoryId: string;
  toMemoryId: string;
  relation: 'duplicate' | 'supports' | 'refines' | 'contradicts' | 'references' | 'belongs_to';
  weight: number;
  createdAt: string;
}

export interface MemoryItem {
  id: string;
  workspaceId: string;
  projectId?: string;
  collectionId?: string;
  conversationId?: string;
  parentId?: string;
  title: string;
  content: string;
  summary: string;
  type: MemoryType;
  scope: MemoryScope;
  visibility: MemoryVisibility;
  status: MemoryStatus;
  pinned: boolean;
  favorite: boolean;
  importance: number;
  confidence: number;
  quality: number;
  tags: string[];
  keywords: string[];
  entities: MemoryEntity[];
  source: MemorySource;
  notes?: string;
  folderId?: string;
  labels: string[];
  expiresAt?: string | null;
  archivedAt?: string | null;
  createdAt: string;
  updatedAt: string;
  accessedAt: string;
  version: number;
  embedding?: number[] | null;
  checksum: string;
}

export interface MemoryCollection {
  id: string;
  workspaceId: string;
  projectId?: string;
  parentId?: string;
  name: string;
  description?: string;
  color: string;
  icon?: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface MemoryProject {
  id: string;
  workspaceId: string;
  name: string;
  summary: string;
  instructions: string;
  architecture: string;
  codingStandards: string;
  roadmap: string;
  todos: string;
  status: 'active' | 'paused' | 'archived';
  createdAt: string;
  updatedAt: string;
}

export interface MemoryConversationContext {
  conversationId: string;
  workspaceId: string;
  projectId?: string;
  lastActiveAt: string;
  recentMemoryIds: string[];
  selectedMemoryIds: string[];
}

export interface MemorySuggestion {
  id: string;
  kind: 'remember' | 'forget' | 'merge' | 'update' | 'pin';
  title: string;
  reason: string;
  memoryId?: string;
  confidence: number;
  createdAt: string;
}

export interface MemoryStats {
  total: number;
  active: number;
  pinned: number;
  archived: number;
  deleted: number;
  privateCount: number;
  sharedCount: number;
  avgImportance: number;
  avgConfidence: number;
  storageBytes: number;
  updatedToday: number;
}

export interface KnowledgeNote {
  id: string;
  workspaceId: string;
  projectId?: string;
  title: string;
  body: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface MemoryContextBundle {
  workspaceId: string;
  projectId?: string;
  conversationId?: string;
  query: string;
  recent: MemoryItem[];
  relevant: MemoryItem[];
  pinned: MemoryItem[];
  instruction: MemoryItem[];
  preferences: MemoryItem[];
  goals: MemoryItem[];
  projects: MemoryProject[];
  collections: MemoryCollection[];
}

export interface MemoryIntakeDecision {
  action: 'remember' | 'update' | 'ignore' | 'forget' | 'merge' | 'pin';
  reason: string;
  confidence: number;
  memoryType: MemoryType;
  scope: MemoryScope;
  visibility: MemoryVisibility;
  tags: string[];
  keywords: string[];
}

export interface MemoryIntakeResult {
  decision: MemoryIntakeDecision;
  draft?: Partial<MemoryItem>;
  duplicateIds: string[];
  suggestions: MemorySuggestion[];
}

export interface MemoryRetentionReport {
  archived: number;
  deleted: number;
  expired: number;
  retained: number;
}

export interface MemoryAnalyticsSnapshot {
  total: number;
  active: number;
  pinned: number;
  archived: number;
  privateCount: number;
  sharedCount: number;
  updateVelocity: number;
  averageImportance: number;
  averageConfidence: number;
  topTags: string[];
  topEntities: string[];
  timeline: HeatmapCell[];
}
