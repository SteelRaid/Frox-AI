export interface MemoryLimits {
  maxActiveMemories: number;
  maxPinnedMemories: number;
  maxAttachmentsPerMemory: number;
  maxMemoryLength: number;
}

export interface RetentionPolicy {
  shortTermDays: number;
  temporaryHours: number;
  archiveAfterDays: number;
  deleteAfterDays: number;
}

export interface PrivacyControls {
  allowPersonalMemories: boolean;
  allowWorkspaceMemories: boolean;
  allowSharedMemories: boolean;
  allowAutoSuggestions: boolean;
  requireManualApprovalForPrivate: boolean;
}

export interface MemorySettings {
  memoryLimits: MemoryLimits;
  retentionPolicy: RetentionPolicy;
  privacyControls: PrivacyControls;
  autoSave: boolean;
  smartMemory: boolean;
  semanticSearch: boolean;
  offlineMode: boolean;
  encryption: boolean;
}
