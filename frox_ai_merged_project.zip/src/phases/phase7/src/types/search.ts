import type { MemoryItem } from './memory';

export interface MemorySearchFilter {
  query: string;
  types: string[];
  tags: string[];
  projectId?: string;
  workspaceId?: string;
  conversationId?: string;
  collectionId?: string;
  scope?: string[];
  pinnedOnly?: boolean;
  archivedOnly?: boolean;
  favoritesOnly?: boolean;
  recentOnly?: boolean;
  updatedAfter?: string;
  updatedBefore?: string;
}

export interface MemorySearchResult {
  item: MemoryItem;
  score: number;
  highlights: string[];
  reasons: string[];
}

export interface SearchSuggestion {
  id: string;
  label: string;
  value: string;
  category: 'query' | 'tag' | 'project' | 'person' | 'collection';
}

export interface SavedSearch {
  id: string;
  workspaceId: string;
  name: string;
  query: string;
  filters: MemorySearchFilter;
  createdAt: string;
  updatedAt: string;
}
