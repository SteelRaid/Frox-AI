import type { MemoryItem, MemoryVersion } from './memory';

export interface SyncEvent {
  id: string;
  workspaceId: string;
  type: 'create' | 'update' | 'delete' | 'merge' | 'split' | 'archive' | 'restore';
  entityId: string;
  payload: Record<string, unknown>;
  createdAt: string;
}

export interface ConflictRecord {
  id: string;
  entityId: string;
  localVersion: number;
  remoteVersion: number;
  resolution: 'local' | 'remote' | 'merged';
  createdAt: string;
}

export interface SyncState {
  pending: number;
  isOnline: boolean;
  lastSyncAt?: string;
  lastError?: string;
}

export interface MemorySnapshot {
  memories: MemoryItem[];
  versions: MemoryVersion[];
}
