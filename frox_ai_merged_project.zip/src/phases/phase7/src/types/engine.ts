import type { GraphEdge, GraphNode, HeatmapCell } from './dashboard';
import type {
  MemoryAnalyticsSnapshot,
  MemoryAttachment,
  MemoryCollection,
  MemoryContextBundle,
  MemoryEntity,
  MemoryItem,
  MemoryProject,
  MemoryRelation,
  MemoryRetentionReport,
  MemoryStats,
  MemorySuggestion,
} from './memory';
import type { MemorySearchFilter, MemorySearchResult, SavedSearch, SearchSuggestion } from './search';

export interface MemoryDecisionSignal {
  keywordHits: number;
  entityHits: number;
  repeatedPatternHits: number;
  stablePreference: boolean;
  projectIntent: boolean;
  instructionIntent: boolean;
  goalIntent: boolean;
  codingIntent: boolean;
  explicitMemoryRequest: boolean;
  explicitForgetRequest: boolean;
}

export interface MemoryDecisionExplanation {
  action: string;
  reasoning: string[];
  confidence: number;
}

export interface MemoryScoringBreakdown {
  importance: number;
  confidence: number;
  quality: number;
  relevance: number;
  similarity: number;
  recency: number;
}

export interface MemorySimilaritySignal {
  text: number;
  title: number;
  summary: number;
  tags: number;
  keywords: number;
  entities: number;
  projectAffinity: number;
  conversationAffinity: number;
  recency: number;
  importance: number;
}

export interface MemoryRankedItem {
  memory: MemoryItem;
  score: number;
  breakdown: MemoryScoringBreakdown;
  reasons: string[];
}

export interface MemoryContextWindow {
  workspaceId: string;
  projectId?: string;
  conversationId?: string;
  query: string;
  budget: number;
  instructions: MemoryItem[];
  preferences: MemoryItem[];
  goals: MemoryItem[];
  pinned: MemoryItem[];
  recent: MemoryItem[];
  relevant: MemoryItem[];
  supporting: MemoryItem[];
  summary: string;
}

export interface MemoryGraphCluster {
  id: string;
  label: string;
  nodeIds: string[];
  density: number;
}

export interface MemoryGraphSnapshot {
  nodes: GraphNode[];
  edges: GraphEdge[];
  clusters: MemoryGraphCluster[];
  density: number;
  averageDegree: number;
}

export interface MemoryCompressionResult {
  summary: string;
  compressedContent: string;
  highlights: string[];
  keywords: string[];
  entities: MemoryEntity[];
  tokenCount: number;
  compressionRatio: number;
}

export interface MemoryRetentionAction {
  memoryId: string;
  action: 'retain' | 'archive' | 'delete' | 'compress' | 'promote';
  reason: string;
  targetStatus?: MemoryItem['status'];
}

export interface MemoryRetentionPlan {
  actions: MemoryRetentionAction[];
  report: MemoryRetentionReport;
}

export interface ExportBundle {
  workspaceId: string;
  exportedAt: string;
  memories: MemoryItem[];
  projects: MemoryProject[];
  collections: MemoryCollection[];
  attachments: MemoryAttachment[];
  relations: MemoryRelation[];
  savedSearches: SavedSearch[];
  stats?: MemoryStats;
  analytics?: MemoryAnalyticsSnapshot;
  context?: MemoryContextBundle;
  searchResults?: MemorySearchResult[];
  suggestions?: MemorySuggestion[];
}

export interface ExportOptions {
  includeAttachments?: boolean;
  includeProjects?: boolean;
  includeCollections?: boolean;
  includeRelations?: boolean;
  includeSearches?: boolean;
  includeAnalytics?: boolean;
  includeContext?: boolean;
  includeSuggestions?: boolean;
  pretty?: boolean;
}

export interface ImportResult {
  memories: MemoryItem[];
  projects: MemoryProject[];
  collections: MemoryCollection[];
  attachments: MemoryAttachment[];
  relations: MemoryRelation[];
  savedSearches: SavedSearch[];
  warnings: string[];
}

export interface EncryptionResult {
  cipherText: string;
  iv: string;
  salt: string;
}

export interface DecryptionInput {
  cipherText: string;
  iv: string;
  salt: string;
}

export interface SyncConflictResolution {
  winner: MemoryItem;
  loser: MemoryItem;
  reason: string;
  merged?: MemoryItem;
}

export interface MemoryAuditEntry {
  id: string;
  workspaceId: string;
  actorId?: string;
  action: string;
  entityType: 'memory' | 'project' | 'collection' | 'attachment' | 'relation' | 'search' | 'setting';
  entityId: string;
  before?: Record<string, unknown>;
  after?: Record<string, unknown>;
  createdAt: string;
}

export interface MemoryWorkspaceSnapshot {
  workspaceId: string;
  memoryCount: number;
  projectCount: number;
  collectionCount: number;
  attachmentCount: number;
  relationCount: number;
  searchCount: number;
  recentMemoryIds: string[];
  topMemoryIds: string[];
  heatmap: HeatmapCell[];
}


export interface MemoryRankingInsight {
  id: string;
  title: string;
  score: number;
  factors: {
    recency: number;
    importance: number;
    confidence: number;
    quality: number;
    similarity: number;
    entityAffinity: number;
    projectAffinity: number;
  };
  reasons: string[];
}

export interface MemoryPolicyDecision {
  memoryId: string;
  action: 'retain' | 'archive' | 'delete' | 'compress' | 'promote' | 'pin' | 'review';
  reason: string;
  priority: number;
  targetStatus?: MemoryItem['status'];
}

export interface MemoryPolicySummary {
  retained: number;
  archived: number;
  deleted: number;
  compressed: number;
  promoted: number;
  reviewed: number;
}

export interface MemoryContextSlot {
  title: string;
  items: MemoryItem[];
  limit: number;
  rationale: string;
}

export interface MemoryContextPlan {
  workspaceId: string;
  projectId?: string;
  conversationId?: string;
  query: string;
  slots: MemoryContextSlot[];
  condensedSummary: string;
  totalTokens: number;
  injectionOrder: string[];
}

export interface MemoryIntelligenceReport {
  workspaceId: string;
  query: string;
  selectedMemoryIds: string[];
  ranking: MemoryRankingInsight[];
  policy: MemoryPolicyDecision[];
  context: MemoryContextPlan;
  signals: string[];
}

export interface MemorySyncSnapshot {
  pending: number;
  conflicts: number;
  lastPushAt?: string;
  lastPullAt?: string;
  lastError?: string;
}

export interface MemoryWorkspaceInsight {
  workspaceId: string;
  totalMemories: number;
  activeMemories: number;
  pinnedMemories: number;
  projects: number;
  collections: number;
  topTags: string[];
  topEntities: string[];
  activityScore: number;
  storageBytes: number;
  staleMemories: number;
}
