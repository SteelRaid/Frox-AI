import { useState, useEffect, useRef } from "react";

// ── Frox AI Brand Tokens ─────────────────────────────────────────────────────
const C = {
  bg1: "#07070E",
  bg2: "#0F0F1A",
  bg3: "#16162A",
  border: "#1E1E3A",
  borderActive: "#3D3D7A",
  accent: "#5B5BF6",
  accentCyan: "#06C8FF",
  accentGlow: "rgba(91,91,246,0.18)",
  success: "#22C55E",
  warning: "#F59E0B",
  error: "#EF4444",
  textPrimary: "#F0F0FF",
  textSecondary: "#8888BB",
  textMuted: "#44446A",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: ${C.bg1};
    color: ${C.textPrimary};
    font-family: 'Inter', sans-serif;
    font-size: 14px;
    overflow: hidden;
  }

  :root {
    --accent: ${C.accent};
    --accent-cyan: ${C.accentCyan};
    --bg1: ${C.bg1};
    --bg2: ${C.bg2};
    --bg3: ${C.bg3};
    --border: ${C.border};
  }

  /* ── Scrollbar ── */
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: ${C.borderActive}; border-radius: 2px; }

  /* ── Glass card ── */
  .glass {
    background: rgba(255,255,255,0.025);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 12px;
    transition: all 200ms ease-in-out;
  }
  .glass:hover { border-color: rgba(91,91,246,0.3); box-shadow: 0 0 20px rgba(91,91,246,0.08); }

  /* ── Focus ring ── */
  *:focus-visible { outline: 2px solid ${C.accent}; outline-offset: 2px; }

  /* ── Grain texture overlay ── */
  .grain::after {
    content: '';
    position: absolute;
    inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none;
    z-index: 0;
  }

  /* ── Tab button ── */
  .tab-btn {
    display: flex; align-items: center; gap: 7px;
    padding: 7px 14px;
    border-radius: 8px;
    border: 1px solid transparent;
    background: transparent;
    color: ${C.textSecondary};
    font-family: 'Inter', sans-serif;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 200ms ease-in-out;
    white-space: nowrap;
  }
  .tab-btn:hover { color: ${C.textPrimary}; background: rgba(91,91,246,0.08); border-color: rgba(91,91,246,0.2); }
  .tab-btn.active {
    color: ${C.textPrimary};
    background: rgba(91,91,246,0.15);
    border-color: rgba(91,91,246,0.4);
    box-shadow: 0 0 12px rgba(91,91,246,0.2);
  }
  .tab-btn.active .tab-icon { color: ${C.accent}; }

  /* ── Sidebar nav item ── */
  .nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 10px;
    border-radius: 8px;
    border: 1px solid transparent;
    background: transparent;
    color: ${C.textSecondary};
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 200ms ease-in-out;
    width: 100%;
    text-align: left;
  }
  .nav-item:hover { color: ${C.textPrimary}; background: rgba(255,255,255,0.04); }
  .nav-item.active { color: ${C.textPrimary}; background: rgba(91,91,246,0.12); border-color: rgba(91,91,246,0.25); }
  .nav-item.active .nav-icon { color: ${C.accent}; }

  /* ── Sidebar section label ── */
  .sidebar-label {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: ${C.textMuted};
    padding: 0 10px;
    margin-bottom: 4px;
  }

  /* ── Progress bar ── */
  .progress-bar {
    height: 3px;
    border-radius: 2px;
    background: ${C.border};
    overflow: hidden;
  }
  .progress-fill {
    height: 100%;
    border-radius: 2px;
    background: linear-gradient(90deg, ${C.accent}, ${C.accentCyan});
    transition: width 300ms ease;
  }

  /* ── Status bar metric ── */
  .status-metric {
    display: flex; align-items: center; gap: 6px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    color: ${C.textSecondary};
  }

  /* ── Pulse animation ── */
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
  .pulse { animation: pulse 2s ease-in-out infinite; }

  /* ── Fade-up entrance ── */
  @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  .fade-up { animation: fadeUp 300ms ease-out forwards; }
  .fade-up-1 { animation: fadeUp 300ms 60ms ease-out both; }
  .fade-up-2 { animation: fadeUp 300ms 120ms ease-out both; }
  .fade-up-3 { animation: fadeUp 300ms 180ms ease-out both; }

  /* ── Glow ring ── */
  @keyframes glowRing { 0%,100%{box-shadow:0 0 0 0 rgba(91,91,246,0.4)} 50%{box-shadow:0 0 0 4px rgba(91,91,246,0)} }
  .glow-ring { animation: glowRing 2.5s ease-in-out infinite; }

  /* ── Sidebar thumbnail ── */
  .history-thumb {
    width: 36px; height: 36px;
    border-radius: 6px;
    flex-shrink: 0;
    object-fit: cover;
  }

  /* ── Queue ring ── */
  @keyframes spin { to{transform:rotate(360deg)} }
  .spin { animation: spin 1s linear infinite; }

  /* ── Gradient accent border ── */
  .accent-border {
    position: relative;
    border-radius: 12px;
  }
  .accent-border::before {
    content: '';
    position: absolute;
    inset: -1px;
    border-radius: 13px;
    background: linear-gradient(135deg, ${C.accent}, ${C.accentCyan});
    z-index: -1;
    opacity: 0;
    transition: opacity 200ms;
  }
  .accent-border:hover::before { opacity: 1; }

  /* ── Tooltip ── */
  [data-tip] { position: relative; }
  [data-tip]:hover::after {
    content: attr(data-tip);
    position: absolute;
    left: calc(100% + 8px); top: 50%;
    transform: translateY(-50%);
    background: ${C.bg3};
    border: 1px solid ${C.border};
    color: ${C.textPrimary};
    font-size: 11px;
    padding: 4px 8px;
    border-radius: 6px;
    white-space: nowrap;
    z-index: 100;
    pointer-events: none;
  }

  /* ── Content placeholder ── */
  .placeholder-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 12px;
  }
  .placeholder-card {
    aspect-ratio: 1;
    border-radius: 10px;
    background: ${C.bg3};
    border: 1px solid ${C.border};
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    gap: 8px;
    color: ${C.textMuted};
    font-size: 12px;
    transition: all 200ms;
  }
  .placeholder-card:hover { border-color: ${C.borderActive}; color: ${C.textSecondary}; }

  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { animation-duration: 0ms !important; transition-duration: 0ms !important; }
  }
`;

// ── Icons ────────────────────────────────────────────────────────────────────
const Icon = ({ d, size = 16, color = "currentColor", strokeWidth = 1.75, className = "" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
    className={className}>
    <path d={d} />
  </svg>
);

const Icons = {
  image: "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zm7 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm-7 7l4-4 2 2 4-5 5 7H3z",
  video: "M15 10l4.55-2.73A1 1 0 0 1 21 8.13V15.87a1 1 0 0 1-1.45.86L15 14M3 8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8z",
  chat: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
  code: "M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4",
  history: "M12 8v4l3 3m6-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0z",
  gallery: "M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6zM4 10h16M10 4v16",
  models: "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5",
  queue: "M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2M9 5a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2M9 5a2 2 0 0 1 2-2h2a2 2 0 1 1 0 4H9a2 2 0 0 1-2-2z",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm6.32-1.64l1.2 2.08-1.2.69-2.08-1.2a6 6 0 0 1-1.2.69l-.32 2.38H10.28l-.32-2.38a6 6 0 0 1-1.2-.69L6.68 16.13l-1.2-.69 1.2-2.08A6 6 0 0 1 6 12a6 6 0 0 1 .68-2.36L5.48 7.56l1.2-.69 2.08 1.2a6 6 0 0 1 1.2-.69l.32-2.38h3.44l.32 2.38a6 6 0 0 1 1.2.69l2.08-1.2 1.2.69-1.2 2.08A6 6 0 0 1 18 12a6 6 0 0 1-.68 2.36z",
  chevronLeft: "M15 18l-6-6 6-6",
  chevronRight: "M9 18l6-6-6-6",
  cpu: "M9 3H5a2 2 0 0 0-2 2v4m6-6h6m-6 0v18m6-18h4a2 2 0 0 1 2 2v4m-6-6v18m6-18v14a2 2 0 0 1-2 2h-4m6-16v4m0 0h-4m4 0v4m0 0h-4m4 0v4m-16-8H3m0 0v4m0-4h4M3 7v4m0 0h4m-4 4h4m-4 0v4m0 0h4",
  memory: "M6 2h12l4 4v12l-4 4H6l-4-4V6zM12 6v12M6 12h12",
  network: "M8 12l4-4 4 4M12 16V8",
  sparkle: "M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z",
  user: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  plus: "M12 5v14M5 12h14",
  x: "M18 6L6 18M6 6l12 12",
  slash: "M22 2L2 22",
};

// ── Logo ─────────────────────────────────────────────────────────────────────
function FroxLogo({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none">
      <defs>
        <linearGradient id="logoGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#5B5BF6" />
          <stop offset="100%" stopColor="#06C8FF" />
        </linearGradient>
        <filter id="logoGlow">
          <feGaussianBlur stdDeviation="1.5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      {/* Background hexagon */}
      <rect x="1" y="1" width="26" height="26" rx="7" fill="rgba(91,91,246,0.12)" stroke="url(#logoGrad)" strokeWidth="1" />
      {/* F letter */}
      <text x="6" y="20" fontFamily="Space Grotesk, sans-serif" fontSize="16" fontWeight="700" fill="url(#logoGrad)">F</text>
      {/* Spark top-right */}
      <circle cx="22" cy="6" r="1.5" fill="#06C8FF" filter="url(#logoGlow)" />
      <line x1="22" y1="3" x2="22" y2="4" stroke="#06C8FF" strokeWidth="1.2" strokeLinecap="round" />
      <line x1="24.2" y1="3.8" x2="23.4" y2="4.6" stroke="#06C8FF" strokeWidth="1.2" strokeLinecap="round" />
      <line x1="25" y1="6" x2="24" y2="6" stroke="#06C8FF" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

// ── Mock data ─────────────────────────────────────────────────────────────────
const HISTORY_ITEMS = [
  { id: 1, label: "Cyberpunk city at dusk", time: "2m ago", hue: "135deg,#5B5BF6,#06C8FF" },
  { id: 2, label: "Portrait, neon bokeh", time: "18m ago", hue: "135deg,#06C8FF,#22C55E" },
  { id: 3, label: "Abstract fluid art", time: "1h ago", hue: "135deg,#F59E0B,#EF4444" },
  { id: 4, label: "Mountain at sunrise", time: "3h ago", hue: "135deg,#22C55E,#5B5BF6" },
];

const QUEUE_ITEMS = [
  { id: "job-001", label: "Waterfall landscape", progress: 68, status: "generating" },
  { id: "job-002", label: "Anime character", progress: 12, status: "loading model" },
];

// ── Main App ──────────────────────────────────────────────────────────────────
export default function FroxAI() {
  const [activeTab, setActiveTab] = useState("image");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarSection, setSidebarSection] = useState("history");
  const [cpuUsage, setCpuUsage] = useState(42);
  const [ramUsed, setRamUsed] = useState(5.8);
  const ramTotal = 16;
  const [connected, setConnected] = useState(true);
  const [queueCount] = useState(2);

  // Simulate live CPU/RAM fluctuation
  useEffect(() => {
    const id = setInterval(() => {
      setCpuUsage(v => Math.min(95, Math.max(8, v + (Math.random() * 6 - 3))));
      setRamUsed(v => Math.min(14, Math.max(3, v + (Math.random() * 0.4 - 0.2))));
    }, 1800);
    return () => clearInterval(id);
  }, []);

  const tabs = [
    { id: "image",   label: "Create Image",  icon: Icons.image,  sym: "✦" },
    { id: "video",   label: "Create Video",  icon: Icons.video,  sym: "▶" },
    { id: "chat",    label: "Chat",           icon: Icons.chat,   sym: "💬" },
    { id: "code",    label: "Code",           icon: Icons.code,   sym: "⌨" },
  ];

  const sidebarSections = [
    { id: "history",  label: "Recent",      icon: Icons.history  },
    { id: "gallery",  label: "Gallery",     icon: Icons.gallery  },
    { id: "models",   label: "Models",      icon: Icons.models   },
    { id: "queue",    label: "Queue",       icon: Icons.queue, badge: queueCount },
    { id: "settings", label: "Settings",    icon: Icons.settings },
  ];

  return (
    <>
      <style>{css}</style>
      <div style={{
        display: "flex", flexDirection: "column",
        height: "100vh", width: "100vw",
        background: C.bg1,
        position: "relative",
        overflow: "hidden",
      }} className="grain">

        {/* ── TOPBAR ── */}
        <Topbar tabs={tabs} activeTab={activeTab} setActiveTab={setActiveTab} connected={connected} />

        {/* ── BODY ── */}
        <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

          {/* ── SIDEBAR ── */}
          <Sidebar
            open={sidebarOpen}
            setOpen={setSidebarOpen}
            sections={sidebarSections}
            active={sidebarSection}
            setActive={setSidebarSection}
          />

          {/* ── MAIN CONTENT ── */}
          <MainContent activeTab={activeTab} />
        </div>

        {/* ── STATUS BAR ── */}
        <StatusBar
          cpuUsage={cpuUsage}
          ramUsed={ramUsed}
          ramTotal={ramTotal}
          queueCount={queueCount}
          connected={connected}
        />
      </div>
    </>
  );
}

// ── Topbar ────────────────────────────────────────────────────────────────────
function Topbar({ tabs, activeTab, setActiveTab, connected }) {
  return (
    <header style={{
      height: 52,
      background: C.bg2,
      borderBottom: `1px solid ${C.border}`,
      display: "flex", alignItems: "center",
      padding: "0 16px",
      gap: 0,
      flexShrink: 0,
      position: "relative",
      zIndex: 10,
    }}>
      {/* Logo */}
      <div style={{ display: "flex", alignItems: "center", gap: 9, marginRight: 24, flexShrink: 0 }}>
        <FroxLogo size={26} />
        <span style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontWeight: 700, fontSize: 17,
          background: `linear-gradient(135deg, ${C.textPrimary}, ${C.accentCyan})`,
          WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          letterSpacing: "-0.02em",
        }}>Frox AI</span>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 24, background: C.border, marginRight: 20 }} />

      {/* Tabs */}
      <nav style={{ display: "flex", gap: 4, flex: 1 }}>
        {tabs.map(t => (
          <button key={t.id} className={`tab-btn ${activeTab === t.id ? "active" : ""}`}
            onClick={() => setActiveTab(t.id)}
            aria-current={activeTab === t.id ? "page" : undefined}>
            <span className="tab-icon" style={{ fontSize: 13 }}>{t.sym}</span>
            {t.label}
          </button>
        ))}
      </nav>

      {/* Right — system health + avatar */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div className={connected ? "glow-ring" : "pulse"} style={{
            width: 8, height: 8, borderRadius: "50%",
            background: connected ? C.success : C.error,
          }} />
          <span style={{ fontSize: 11, color: C.textMuted, fontFamily: "'JetBrains Mono', monospace" }}>
            {connected ? "Online" : "Offline"}
          </span>
        </div>
        <button aria-label="User account" style={{
          width: 30, height: 30, borderRadius: "50%",
          background: `linear-gradient(135deg, ${C.accent}, ${C.accentCyan})`,
          border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
          transition: "all 200ms",
        }}>
          <Icon d={Icons.user} size={14} color="#fff" />
        </button>
      </div>
    </header>
  );
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function Sidebar({ open, setOpen, sections, active, setActive }) {
  const W = open ? 220 : 52;

  return (
    <aside style={{
      width: W,
      minWidth: W,
      background: C.bg2,
      borderRight: `1px solid ${C.border}`,
      display: "flex", flexDirection: "column",
      transition: "width 200ms ease-in-out, min-width 200ms ease-in-out",
      overflow: "hidden",
      flexShrink: 0,
    }}>
      {/* Nav */}
      <div style={{ flex: 1, padding: "12px 8px", overflowY: "auto", overflowX: "hidden" }}>

        {open && <div className="sidebar-label" style={{ marginBottom: 8 }}>Navigation</div>}

        {sections.map(s => (
          <button key={s.id}
            className={`nav-item ${active === s.id ? "active" : ""}`}
            onClick={() => setActive(s.id)}
            data-tip={!open ? s.label : undefined}
            aria-label={s.label}
            style={{ marginBottom: 2 }}>
            <span className="nav-icon" style={{ flexShrink: 0 }}>
              <Icon d={s.icon} size={16} />
            </span>
            {open && (
              <>
                <span style={{ flex: 1, transition: "opacity 150ms" }}>{s.label}</span>
                {s.badge ? (
                  <span style={{
                    background: C.accent, color: "#fff",
                    fontSize: 10, fontWeight: 600,
                    padding: "1px 6px", borderRadius: 10,
                  }}>{s.badge}</span>
                ) : null}
              </>
            )}
          </button>
        ))}

        {/* ── Section content ── */}
        {open && (
          <div style={{ marginTop: 16 }}>
            <SidebarContent active={active} />
          </div>
        )}
      </div>

      {/* Collapse toggle */}
      <button
        onClick={() => setOpen(o => !o)}
        aria-label={open ? "Collapse sidebar" : "Expand sidebar"}
        style={{
          display: "flex", alignItems: "center", justifyContent: open ? "flex-end" : "center",
          padding: "10px 12px",
          borderTop: `1px solid ${C.border}`,
          background: "transparent", border: "none",
          color: C.textMuted, cursor: "pointer",
          transition: "all 200ms",
        }}>
        <Icon d={open ? Icons.chevronLeft : Icons.chevronRight} size={14} />
      </button>
    </aside>
  );
}

// ── Sidebar Content (per section) ─────────────────────────────────────────────
function SidebarContent({ active }) {
  if (active === "history") return (
    <div>
      <div className="sidebar-label" style={{ marginBottom: 8 }}>Recent</div>
      {HISTORY_ITEMS.map((item, i) => (
        <div key={item.id} className="fade-up" style={{
          display: "flex", alignItems: "center", gap: 9,
          padding: "6px 4px", borderRadius: 8, cursor: "pointer",
          transition: "background 200ms",
          animationDelay: `${i * 50}ms`,
        }}
          onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.04)"}
          onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
          <div style={{
            width: 36, height: 36, borderRadius: 6, flexShrink: 0,
            background: `linear-gradient(${item.hue})`,
            opacity: 0.85,
          }} />
          <div style={{ overflow: "hidden" }}>
            <div style={{ fontSize: 12, color: C.textPrimary, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 130 }}>
              {item.label}
            </div>
            <div style={{ fontSize: 10, color: C.textMuted, marginTop: 1 }}>{item.time}</div>
          </div>
        </div>
      ))}
    </div>
  );

  if (active === "queue") return (
    <div>
      <div className="sidebar-label" style={{ marginBottom: 8 }}>Active Jobs</div>
      {QUEUE_ITEMS.map((job, i) => (
        <div key={job.id} className="glass fade-up" style={{
          padding: "10px 10px", marginBottom: 8,
          animationDelay: `${i * 60}ms`,
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
            <span style={{ fontSize: 11, color: C.textPrimary, fontWeight: 500 }}>{job.label}</span>
            <button aria-label="Cancel job" style={{
              background: "none", border: "none", cursor: "pointer",
              color: C.textMuted, padding: 2, borderRadius: 4,
              transition: "color 150ms",
            }}
              onMouseEnter={e => e.currentTarget.style.color = C.error}
              onMouseLeave={e => e.currentTarget.style.color = C.textMuted}>
              <Icon d={Icons.x} size={12} />
            </button>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${job.progress}%` }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
            <span style={{ fontSize: 10, color: C.textMuted, textTransform: "capitalize" }}>{job.status}</span>
            <span style={{ fontSize: 10, color: C.accentCyan, fontFamily: "'JetBrains Mono',monospace" }}>{job.progress}%</span>
          </div>
        </div>
      ))}
    </div>
  );

  const labels = { gallery: "Your saved creations will appear here.", models: "Downloaded models will appear here.", settings: "Configure Frox AI here." };
  return (
    <div style={{ padding: "8px 4px", color: C.textMuted, fontSize: 12 }}>
      {labels[active] || ""}
    </div>
  );
}

// ── Main Content ──────────────────────────────────────────────────────────────
function MainContent({ activeTab }) {
  const content = {
    image: <ImagePlaceholder />,
    video: <ComingSoon label="Create Video" icon="▶" desc="Generate cinematic videos from text or images." accent={C.accentCyan} />,
    chat:  <ComingSoon label="Chat" icon="💬" desc="Talk with local AI models or cloud assistants." accent={C.accent} />,
    code:  <ComingSoon label="Frox Code" icon="⌨" desc="AI-powered coding agent with full workspace." accent="#22C55E" />,
  };

  return (
    <main style={{
      flex: 1, overflow: "auto",
      background: C.bg1,
      padding: 20,
    }}>
      {content[activeTab]}
    </main>
  );
}

// ── Image Placeholder (Phase 1 mock) ─────────────────────────────────────────
function ImagePlaceholder() {
  return (
    <div className="fade-up" style={{ height: "100%", display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Header */}
      <div className="fade-up-1" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1 style={{ fontFamily: "'Space Grotesk',sans-serif", fontWeight: 700, fontSize: 20, color: C.textPrimary, letterSpacing: "-0.02em" }}>
            ✦ Create Image
          </h1>
          <p style={{ fontSize: 12, color: C.textMuted, marginTop: 2 }}>Phase 1 shell — controls in Phase 2</p>
        </div>
        <button style={{
          padding: "8px 18px", borderRadius: 8, border: "none", cursor: "pointer",
          background: `linear-gradient(135deg, ${C.accent}, ${C.accentCyan})`,
          color: "#fff", fontFamily: "'Inter',sans-serif", fontWeight: 600, fontSize: 13,
          boxShadow: `0 0 20px rgba(91,91,246,0.35)`,
          transition: "all 200ms",
        }}
          onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-1px)"; e.currentTarget.style.boxShadow = `0 4px 24px rgba(91,91,246,0.5)`; }}
          onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = `0 0 20px rgba(91,91,246,0.35)`; }}>
          ✦ Generate
        </button>
      </div>

      {/* 3-column skeleton */}
      <div className="fade-up-2" style={{ display: "grid", gridTemplateColumns: "300px 1fr 260px", gap: 12, flex: 1, minHeight: 0 }}>

        {/* Left — Controls */}
        <div className="glass" style={{ padding: 16, overflowY: "auto" }}>
          <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 12 }}>Controls</div>
          {["Prompt", "Model", "Resolution", "Steps & Guidance", "Sampler", "Seed"].map((label, i) => (
            <div key={label} style={{
              padding: "10px 12px", borderRadius: 8,
              background: C.bg3, border: `1px solid ${C.border}`,
              marginBottom: 8, color: C.textMuted, fontSize: 12,
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}>
              <span>{label}</span>
              <span style={{ color: C.borderActive, fontSize: 10 }}>Phase 2 →</span>
            </div>
          ))}
        </div>

        {/* Center — Canvas */}
        <div className="glass" style={{
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          gap: 16, minHeight: 300,
        }}>
          <div style={{
            width: 200, height: 200, borderRadius: 12,
            background: `linear-gradient(135deg, rgba(91,91,246,0.15), rgba(6,200,255,0.1))`,
            border: `1px dashed ${C.borderActive}`,
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            gap: 8,
          }}>
            <span style={{ fontSize: 36, opacity: 0.4 }}>✦</span>
            <span style={{ fontSize: 12, color: C.textMuted }}>Canvas</span>
          </div>
          <span style={{ fontSize: 12, color: C.textMuted }}>Your creation will appear here</span>
        </div>

        {/* Right — Details */}
        <div className="glass" style={{ padding: 16, overflowY: "auto" }}>
          <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 12 }}>Details</div>
          {["Generation Info", "Metadata", "Actions", "Variations"].map(label => (
            <div key={label} style={{
              padding: "10px 12px", borderRadius: 8,
              background: C.bg3, border: `1px solid ${C.border}`,
              marginBottom: 8, color: C.textMuted, fontSize: 12,
              display: "flex", justifyContent: "space-between", alignItems: "center",
            }}>
              <span>{label}</span>
              <span style={{ color: C.borderActive, fontSize: 10 }}>Phase 2 →</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Coming Soon placeholder ───────────────────────────────────────────────────
function ComingSoon({ label, icon, desc, accent }) {
  return (
    <div className="fade-up" style={{
      height: "100%", display: "flex",
      flexDirection: "column", alignItems: "center", justifyContent: "center",
      gap: 16, textAlign: "center",
    }}>
      <div style={{
        width: 72, height: 72, borderRadius: 20,
        background: `linear-gradient(135deg, ${accent}22, ${accent}11)`,
        border: `1px solid ${accent}44`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 28,
        boxShadow: `0 0 32px ${accent}22`,
      }}>{icon}</div>
      <div>
        <h2 style={{ fontFamily: "'Space Grotesk',sans-serif", fontWeight: 700, fontSize: 22, color: C.textPrimary, letterSpacing: "-0.02em" }}>{label}</h2>
        <p style={{ color: C.textMuted, fontSize: 13, marginTop: 6, maxWidth: 280 }}>{desc}</p>
      </div>
      <div style={{
        padding: "6px 14px", borderRadius: 20,
        background: `${accent}18`, border: `1px solid ${accent}44`,
        fontSize: 11, color: accent, fontWeight: 600, letterSpacing: "0.06em",
      }}>Coming in later phases</div>
    </div>
  );
}

// ── Status Bar ────────────────────────────────────────────────────────────────
function StatusBar({ cpuUsage, ramUsed, ramTotal, queueCount, connected }) {
  const cpuPct = Math.round(cpuUsage);
  const cpuColor = cpuPct > 80 ? C.error : cpuPct > 60 ? C.warning : C.accentCyan;

  return (
    <footer style={{
      height: 30,
      background: C.bg2,
      borderTop: `1px solid ${C.border}`,
      display: "flex", alignItems: "center",
      padding: "0 16px",
      gap: 20,
      flexShrink: 0,
    }}>
      {/* CPU */}
      <div className="status-metric">
        <Icon d={Icons.cpu} size={11} color={cpuColor} />
        <span style={{ color: C.textMuted }}>CPU</span>
        <div style={{ width: 48, height: 3, borderRadius: 2, background: C.border, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${cpuPct}%`, background: cpuColor, borderRadius: 2, transition: "width 500ms ease, background 300ms" }} />
        </div>
        <span style={{ color: cpuColor }}>{cpuPct}%</span>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 14, background: C.border }} />

      {/* RAM */}
      <div className="status-metric">
        <Icon d={Icons.memory} size={11} color={C.accent} />
        <span style={{ color: C.textMuted }}>RAM</span>
        <span style={{ color: C.textSecondary }}>{ramUsed.toFixed(1)} / {ramTotal} GB</span>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 14, background: C.border }} />

      {/* Queue */}
      <div className="status-metric">
        <Icon d={Icons.queue} size={11} color={C.warning} />
        <span style={{ color: C.textMuted }}>Queue</span>
        <span style={{
          background: `${C.warning}22`, border: `1px solid ${C.warning}55`,
          color: C.warning, fontSize: 10, padding: "0 5px", borderRadius: 10,
        }}>{queueCount}</span>
      </div>

      {/* Spacer */}
      <div style={{ flex: 1 }} />

      {/* Status dot */}
      <div className="status-metric">
        <div className={connected ? "" : "pulse"} style={{
          width: 6, height: 6, borderRadius: "50%",
          background: connected ? C.success : C.error,
        }} />
        <span style={{ color: C.textMuted }}>{connected ? "Connected" : "Offline"}</span>
      </div>

      {/* Divider */}
      <div style={{ width: 1, height: 14, background: C.border }} />

      {/* Version */}
      <span style={{
        fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: C.textMuted
      }}>v1.0.0</span>
    </footer>
  );
}
