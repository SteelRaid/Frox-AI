# Frox AI — Phase 6 Chat Module (Improved)

A more complete and maintainable Phase 6 chat module for the Frox AI dashboard.

## Included
- Conversation sidebar with search, grouping, create, rename, and delete
- Chat window with streaming-style assistant replies
- Message actions: copy, regenerate, delete
- Settings drawer with model, temperature, tokens, context, memory, and system prompt
- Suggestions chips and attachment controls
- Modular file structure for easier integration

## File map
- `src/Phase6Chat.tsx` — main composition
- `src/types.ts` — shared types
- `src/mockData.ts` — starter conversations and model data
- `src/hooks/useChatController.ts` — state controller and actions
- `src/components/*` — UI pieces

## Integration
1. Copy `src` into your React app.
2. Install `lucide-react`.
3. Render `<Phase6Chat />` anywhere in your dashboard.

## Notes
- This version uses mock local state, but the controller is shaped so you can replace the mock `sendMessage()` flow with a real API call later.
- The module is written to fit the dark Frox AI design system.