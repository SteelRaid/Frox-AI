import { useEffect, useMemo, useRef, useState } from "react";
import { MODEL_OPTIONS, STARTER_CONVERSATIONS } from "../mockData";
import type { ChatMessage, ChatSettings, Conversation } from "../types";
import { nowTime, safeClipboardCopy, uid, sortByUpdatedAt } from "../utils/chatHelpers";

const INITIAL_SETTINGS: ChatSettings = {
  systemPrompt: "You are Frox AI, a polished and helpful assistant for building products.",
  temperature: 0.7,
  maxTokens: 4096,
  contextLength: 16,
  streamResponse: true,
  memory: true,
  selectedModel: MODEL_OPTIONS[1].label,
};

function buildStreamingReply(userText: string) {
  const clean = userText.trim();
  return [
    "Here is a clear next step for Frox AI:",
    "",
    "• Keep the shell lightweight and reusable.",
    "• Place the strongest glow only on primary actions.",
    "• Use compact spacing, strong hierarchy, and stable states.",
    "",
    `Based on your message: “${clean}”`,
    "I would now wire the design into a real API and preserve the same UX structure.",
  ].join("\n");
}

function makeAssistantMessage(content: string): ChatMessage {
  return {
    id: uid("assistant"),
    role: "assistant",
    content,
    createdAt: nowTime(),
  };
}

function makeUserMessage(content: string): ChatMessage {
  return {
    id: uid("user"),
    role: "user",
    content,
    createdAt: nowTime(),
  };
}

export function useChatController() {
  const [conversations, setConversations] = useState<Conversation[]>(
    sortByUpdatedAt(STARTER_CONVERSATIONS)
  );
  const [activeId, setActiveId] = useState(STARTER_CONVERSATIONS[0]?.id ?? "");
  const [query, setQuery] = useState("");
  const [composerValue, setComposerValue] = useState("");
  const [composerRows, setComposerRows] = useState(2);
  const [isStreaming, setIsStreaming] = useState(false);
  const [status, setStatus] = useState<"Ready" | "Generating..." | "Stopped" | "Copied">("Ready");
  const [showSettings, setShowSettings] = useState(true);
  const [showTitleEditor, setShowTitleEditor] = useState(false);
  const [copiedSettings, setCopiedSettings] = useState(false);
  const [settings, setSettings] = useState<ChatSettings>(INITIAL_SETTINGS);
  const [messageError, setMessageError] = useState<string | null>(null);
  const stopRef = useRef(false);
  const streamingTimerRef = useRef<number | null>(null);

  const activeConversation = useMemo(
    () => conversations.find((conversation) => conversation.id === activeId) ?? conversations[0],
    [activeId, conversations]
  );

  useEffect(() => {
    const rows = Math.min(8, Math.max(2, composerValue.split("\n").length));
    setComposerRows(rows);
  }, [composerValue]);

  useEffect(() => {
    return () => {
      if (streamingTimerRef.current) window.clearInterval(streamingTimerRef.current);
    };
  }, []);

  const filteredConversations = useMemo(() => {
    const q = query.trim().toLowerCase();
    const sorted = sortByUpdatedAt(conversations);
    if (!q) return sorted;
    return sorted.filter((conversation) => {
      return (
        conversation.title.toLowerCase().includes(q) ||
        conversation.model.toLowerCase().includes(q) ||
        conversation.messages.some((message) => message.content.toLowerCase().includes(q))
      );
    });
  }, [conversations, query]);

  function syncConversation(nextConversation: Conversation) {
    setConversations((prev) =>
      sortByUpdatedAt(prev.map((conversation) => (conversation.id === nextConversation.id ? nextConversation : conversation)))
    );
  }

  function updateCurrentConversation(updater: (current: Conversation) => Conversation) {
    if (!activeConversation) return;
    syncConversation(updater(activeConversation));
  }

  function createConversation() {
    const id = uid("conv");
    const next: Conversation = {
      id,
      title: "New chat",
      model: settings.selectedModel,
      createdAt: "Today",
      updatedAt: "now",
      messages: [
        {
          id: uid("welcome"),
          role: "assistant",
          content: "A new Frox AI chat has been created. Tell me what you want to build.",
          createdAt: nowTime(),
        },
      ],
    };
    setConversations((prev) => sortByUpdatedAt([next, ...prev]));
    setActiveId(id);
    setShowTitleEditor(false);
  }

  function renameConversation(title: string) {
    if (!activeConversation) return;
    updateCurrentConversation((current) => ({ ...current, title }));
  }

  function deleteConversation(id: string) {
    setConversations((prev) => {
      const next = prev.filter((conversation) => conversation.id !== id);
      if (activeId === id) {
        setActiveId(next[0]?.id ?? "");
      }
      return next;
    });
  }

  function updateSettings<K extends keyof ChatSettings>(key: K, value: ChatSettings[K]) {
    setSettings((prev) => ({ ...prev, [key]: value }));
  }

  async function copySettings() {
    const payload = JSON.stringify(settings, null, 2);
    const ok = await safeClipboardCopy(payload);
    if (ok) {
      setCopiedSettings(true);
      setStatus("Copied");
      window.setTimeout(() => {
        setCopiedSettings(false);
        setStatus("Ready");
      }, 1200);
    }
  }

  function applySuggestion(text: string) {
    setComposerValue(text);
  }

  function sendMessage(rawText: string) {
    const content = rawText.trim();
    if (!content || !activeConversation || isStreaming) return;

    setMessageError(null);
    stopRef.current = false;
    setIsStreaming(true);
    setStatus("Generating...");

    const userMessage = makeUserMessage(content);
    const startingMessages = [...activeConversation.messages, userMessage];

    const optimisticConversation: Conversation = {
      ...activeConversation,
      model: settings.selectedModel,
      messages: startingMessages,
      updatedAt: "now",
    };

    syncConversation(optimisticConversation);
    setComposerValue("");

    const target = buildStreamingReply(content);
    const assistantId = uid("assistant");
    let currentText = "";

    if (streamingTimerRef.current) {
      window.clearInterval(streamingTimerRef.current);
    }

    streamingTimerRef.current = window.setInterval(() => {
      if (stopRef.current) {
        window.clearInterval(streamingTimerRef.current!);
        streamingTimerRef.current = null;
        setIsStreaming(false);
        setStatus("Stopped");
        return;
      }

      currentText = target.slice(0, Math.min(target.length, currentText.length + 14));
      const assistant: ChatMessage = {
        id: assistantId,
        role: "assistant",
        content: currentText,
        createdAt: nowTime(),
      };

      updateCurrentConversation((current) => ({
        ...current,
        model: settings.selectedModel,
        messages: [...startingMessages, assistant],
        updatedAt: "now",
      }));

      if (currentText.length >= target.length) {
        window.clearInterval(streamingTimerRef.current!);
        streamingTimerRef.current = null;
        setIsStreaming(false);
        setStatus("Ready");
      }
    }, settings.streamResponse ? 30 : 1);
  }

  function stopStreaming() {
    stopRef.current = true;
  }

  function regenerateLast() {
    if (!activeConversation) return;
    const lastUser = [...activeConversation.messages].reverse().find((message) => message.role === "user");
    if (lastUser) {
      sendMessage(lastUser.content);
    }
  }

  function deleteMessage(messageId: string) {
    updateCurrentConversation((current) => ({
      ...current,
      messages: current.messages.filter((message) => message.id !== messageId),
      updatedAt: "now",
    }));
  }

  function copyText(text: string) {
    void safeClipboardCopy(text);
    setStatus("Copied");
    window.setTimeout(() => setStatus("Ready"), 900);
  }

  return {
    conversations,
    activeConversation,
    activeId,
    setActiveId,
    query,
    setQuery,
    composerValue,
    setComposerValue,
    composerRows,
    isStreaming,
    status,
    showSettings,
    setShowSettings,
    showTitleEditor,
    setShowTitleEditor,
    copiedSettings,
    settings,
    setSettings,
    updateSettings,
    messageError,
    setMessageError,
    filteredConversations,
    createConversation,
    renameConversation,
    deleteConversation,
    applySuggestion,
    sendMessage,
    stopStreaming,
    regenerateLast,
    deleteMessage,
    copyText,
    copySettings,
  };
}