import type { Conversation, ModelOption } from "./types";

export const MODEL_OPTIONS: ModelOption[] = [
  {
    id: "frox-local",
    label: "Frox Local",
    subtitle: "Fast on-device assistant",
    dotClass: "bg-emerald-400",
    badgeClass: "border-emerald-400/20 bg-emerald-500/10 text-emerald-200",
  },
  {
    id: "frox-cloud",
    label: "Frox Cloud",
    subtitle: "Balanced quality and speed",
    dotClass: "bg-cyan-400",
    badgeClass: "border-cyan-400/20 bg-cyan-500/10 text-cyan-200",
  },
  {
    id: "frox-pro",
    label: "Frox Pro",
    subtitle: "Best for long reasoning",
    dotClass: "bg-violet-400",
    badgeClass: "border-violet-400/20 bg-violet-500/10 text-violet-200",
  },
];

export const STARTER_CONVERSATIONS: Conversation[] = [
  {
    id: "conv-1",
    title: "Build the dashboard shell",
    model: "Frox Pro",
    createdAt: "Today",
    updatedAt: "2m ago",
    pinned: true,
    messages: [
      {
        id: "msg-1",
        role: "assistant",
        content:
          "I can help you structure the Frox AI dashboard into clean, production-ready panels. Tell me the first screen you want to finish.",
        createdAt: "10:12",
      },
      {
        id: "msg-2",
        role: "user",
        content: "Make the layout premium and futuristic, but still easy to use.",
        createdAt: "10:13",
      },
      {
        id: "msg-3",
        role: "assistant",
        content:
          "Great direction. I would keep the shell quiet, use glass cards sparingly, and reserve the strongest glow only for active states and primary actions.",
        createdAt: "10:13",
      },
    ],
  },
  {
    id: "conv-2",
    title: "Fix my React bug",
    model: "Frox Local",
    createdAt: "Today",
    updatedAt: "18m ago",
    messages: [
      {
        id: "msg-4",
        role: "assistant",
        content:
          "Send the component and I will trace the state flow, props, and render updates step by step.",
        createdAt: "09:52",
      },
    ],
  },
  {
    id: "conv-3",
    title: "Brainstorm app ideas",
    model: "Frox Cloud",
    createdAt: "Yesterday",
    updatedAt: "1h ago",
    messages: [
      {
        id: "msg-5",
        role: "assistant",
        content:
          "We can shape the idea around user pain, a sharp feature set, and a brand voice that feels premium.",
        createdAt: "09:10",
      },
    ],
  },
  {
    id: "conv-4",
    title: "Explain this API route",
    model: "Frox Pro",
    createdAt: "Older",
    updatedAt: "Yesterday",
    messages: [
      {
        id: "msg-6",
        role: "assistant",
        content:
          "Paste the route and I will explain the request flow, expected payload, and likely edge cases.",
        createdAt: "08:44",
      },
    ],
  },
];