import React from "react";
import { ChatHeader } from "./components/ChatHeader";
import { Composer } from "./components/Composer";
import { ConversationSidebar } from "./components/ConversationSidebar";
import { MessageBubble } from "./components/MessageBubble";
import { SettingsPanel } from "./components/SettingsPanel";
import { MODEL_OPTIONS } from "./mockData";
import { useChatController } from "./hooks/useChatController";

export default function Phase6Chat() {
  const controller = useChatController();
  const {
    conversations,
    activeConversation,
    activeId,
    setActiveId,
    query,
    setQuery,
    composerValue,
    setComposerValue,
    composerRows,
    isStreaming,
    status,
    showSettings,
    setShowSettings,
    showTitleEditor,
    setShowTitleEditor,
    copiedSettings,
    settings,
    updateSettings,
    filteredConversations,
    createConversation,
    renameConversation,
    deleteConversation,
    applySuggestion,
    sendMessage,
    stopStreaming,
    regenerateLast,
    deleteMessage,
    copyText,
    copySettings,
  } = controller;

  const activeModelOption = MODEL_OPTIONS.find((model) => model.label === settings.selectedModel) ?? MODEL_OPTIONS[1];

  return (
    <div className="min-h-screen bg-[#07070E] text-slate-100">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(91,91,246,0.16),_transparent_34%),radial-gradient(circle_at_bottom,_rgba(6,200,255,0.08),_transparent_30%)]" />

      <div className="relative mx-auto flex min-h-screen max-w-[1600px] flex-col p-4 md:p-6">
        <header className="mb-4 flex items-center justify-between rounded-3xl border border-white/10 bg-white/[0.03] px-4 py-3 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-2xl border border-indigo-400/30 bg-indigo-500/15 text-indigo-100 shadow-[0_0_24px_rgba(91,91,246,0.2)]">
              <span className="text-lg font-bold">F</span>
            </div>
            <div>
              <div className="text-sm font-semibold tracking-wide">Frox AI</div>
              <div className="text-xs text-slate-400">Phase 6 · Chat Module</div>
            </div>
          </div>

          <div className="hidden items-center gap-2 md:flex">
            <button className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-200">Chat</button>
            <button className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-500">Image</button>
            <button className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-500">Code</button>
          </div>

          <div className="flex items-center gap-2">
            <span className="rounded-full border border-emerald-400/20 bg-emerald-500/10 px-2 py-1 text-[11px] text-emerald-300">
              {status}
            </span>
            <button
              onClick={() => setShowSettings((value) => !value)}
              className="rounded-2xl border border-white/10 bg-white/5 p-2 text-slate-300 transition hover:border-indigo-400/40 hover:bg-white/10"
              aria-label="Toggle settings"
            >
              {showSettings ? "◧" : "◨"}
            </button>
          </div>
        </header>

        <main className="grid flex-1 gap-4 lg:grid-cols-[300px_1fr]">
          <ConversationSidebar
            conversations={filteredConversations}
            activeId={activeId}
            query={query}
            onQueryChange={setQuery}
            onCreate={createConversation}
            onSelect={setActiveId}
            onDelete={deleteConversation}
          />

          <section className="grid min-h-[74vh] gap-4 xl:grid-cols-[1fr_340px]">
            <div className="flex min-h-[74vh] flex-col rounded-3xl border border-white/10 bg-white/[0.03] backdrop-blur-xl">
              <ChatHeader
                title={activeConversation?.title ?? "Conversation"}
                model={settings.selectedModel}
                showSettings={showSettings}
                onToggleSettings={() => setShowSettings((value) => !value)}
                onToggleTitleEditor={() => setShowTitleEditor((value) => !value)}
                onModelChange={(value) => updateSettings("selectedModel", value)}
                modelOptions={MODEL_OPTIONS}
              />

              <div className="flex items-center justify-between border-b border-white/10 px-4 py-2 text-xs text-slate-500">
                <div className="flex items-center gap-2">
                  <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1">
                    {activeModelOption.subtitle}
                  </span>
                  <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1">
                    Context {settings.contextLength}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1">
                    {settings.streamResponse ? "Streaming ON" : "Streaming OFF"}
                  </span>
                  <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1">
                    Memory {settings.memory ? "ON" : "OFF"}
                  </span>
                </div>
              </div>

              {showTitleEditor && activeConversation ? (
                <div className="border-b border-white/10 px-4 py-3">
                  <label className="mb-2 block text-xs uppercase tracking-[0.18em] text-slate-500">
                    Rename conversation
                  </label>
                  <input
                    value={activeConversation.title}
                    onChange={(e) => renameConversation(e.target.value)}
                    className="w-full rounded-2xl border border-white/10 bg-black/25 px-3 py-2 text-sm outline-none"
                  />
                </div>
              ) : null}

              <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
                {(activeConversation?.messages ?? []).map((message) => (
                  <MessageBubble
                    key={message.id}
                    message={message}
                    onCopy={copyText}
                    onDelete={deleteMessage}
                    onRegenerate={message.role === "assistant" ? regenerateLast : undefined}
                  />
                ))}

                {isStreaming ? (
                  <div className="flex justify-start">
                    <div className="rounded-3xl border border-white/10 bg-[#101020]/90 px-4 py-3 text-sm text-slate-300">
                      Frox AI is typing<span className="ml-1 inline-block animate-pulse">...</span>
                    </div>
                  </div>
                ) : null}
              </div>

              <Composer
                value={composerValue}
                rows={composerRows}
                isStreaming={isStreaming}
                onChange={setComposerValue}
                onSend={() => sendMessage(composerValue)}
                onStop={stopStreaming}
                onSuggestion={applySuggestion}
              />
            </div>

            {showSettings ? (
              <SettingsPanel settings={settings} copied={copiedSettings} onChange={updateSettings} onCopy={copySettings} />
            ) : null}
          </section>
        </main>
      </div>
    </div>
  );
}