export type ChatRole = "user" | "assistant" | "system";

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  createdAt: string;
  pending?: boolean;
  error?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  model: string;
  updatedAt: string;
  createdAt: string;
  pinned?: boolean;
  messages: ChatMessage[];
}

export interface ModelOption {
  id: string;
  label: string;
  subtitle: string;
  dotClass: string;
  badgeClass: string;
}

export interface ChatSettings {
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  contextLength: number;
  streamResponse: boolean;
  memory: boolean;
  selectedModel: string;
}