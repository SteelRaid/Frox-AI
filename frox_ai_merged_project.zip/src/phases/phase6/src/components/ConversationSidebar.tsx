import React from "react";
import { MoreHorizontal, Plus, Search, Trash2 } from "lucide-react";
import type { Conversation } from "../types";
import { groupConversations } from "../utils/chatHelpers";

interface Props {
  conversations: Conversation[];
  activeId: string;
  query: string;
  onQueryChange: (value: string) => void;
  onCreate: () => void;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

function Section({ label, items, onSelect, activeId, onDelete }: {
  label: string;
  items: Conversation[];
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  activeId: string;
}) {
  if (!items.length) return null;

  return (
    <div className="space-y-2">
      <div className="px-1 text-[11px] uppercase tracking-[0.22em] text-slate-500">{label}</div>
      <div className="space-y-2">
        {items.map((conversation) => (
          <div
            key={conversation.id}
            className={[
              "group rounded-2xl border p-3 transition",
              conversation.id === activeId
                ? "border-indigo-400/40 bg-indigo-500/10"
                : "border-white/10 bg-black/15 hover:border-white/20 hover:bg-white/[0.04]",
            ].join(" ")}
          >
            <button onClick={() => onSelect(conversation.id)} className="block w-full text-left">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-slate-100">{conversation.title}</div>
                  <div className="truncate text-xs text-slate-500">
                    {conversation.messages[conversation.messages.length - 1]?.content ?? "No messages"}
                  </div>
                </div>
                <span className="rounded-full border border-cyan-400/20 bg-cyan-500/10 px-2 py-0.5 text-[10px] text-cyan-300">
                  {conversation.model}
                </span>
              </div>
              <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
                <span>{conversation.updatedAt}</span>
                {conversation.pinned ? <span className="text-amber-300">Pinned</span> : <span>•</span>}
              </div>
            </button>

            <div className="mt-2 flex items-center justify-end gap-1 opacity-80">
              <button className="rounded-lg p-1.5 text-slate-500 transition hover:bg-white/10 hover:text-slate-200" aria-label="More actions">
                <MoreHorizontal className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => onDelete(conversation.id)}
                className="rounded-lg p-1.5 text-slate-500 transition hover:bg-white/10 hover:text-rose-200"
                aria-label="Delete conversation"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ConversationSidebar({
  conversations,
  activeId,
  query,
  onQueryChange,
  onCreate,
  onSelect,
  onDelete,
}: Props) {
  const grouped = groupConversations(conversations);

  return (
    <aside className="rounded-2xl border border-white/10 bg-white/[0.03] p-3 backdrop-blur-xl">
      <button
        onClick={onCreate}
        className="mb-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-indigo-400/30 bg-indigo-500/15 px-3 py-2.5 text-sm font-medium text-indigo-100 transition hover:bg-indigo-500/25"
      >
        <Plus className="h-4 w-4" />
        New Chat
      </button>

      <label className="mb-4 flex items-center gap-2 rounded-2xl border border-white/10 bg-black/20 px-3 py-2.5 text-sm text-slate-400">
        <Search className="h-4 w-4 text-slate-500" />
        <input
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search conversations..."
          className="w-full bg-transparent text-slate-100 outline-none placeholder:text-slate-600"
        />
      </label>

      <div className="space-y-4">
        <Section label="Today" items={grouped.Today} activeId={activeId} onSelect={onSelect} onDelete={onDelete} />
        <Section label="Yesterday" items={grouped.Yesterday} activeId={activeId} onSelect={onSelect} onDelete={onDelete} />
        <Section label="Older" items={grouped.Older} activeId={activeId} onSelect={onSelect} onDelete={onDelete} />
      </div>
    </aside>
  );
}