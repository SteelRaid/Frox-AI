import React from "react";
import { FileImage, Mic, Paperclip, Send, Square, Sparkles } from "lucide-react";

interface Props {
  value: string;
  rows: number;
  isStreaming: boolean;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  onSuggestion: (value: string) => void;
}

const suggestions = [
  "Explain it in simpler terms",
  "Turn this into a plan",
  "Give me the best next move",
];

export function Composer({ value, rows, isStreaming, onChange, onSend, onStop, onSuggestion }: Props) {
  return (
    <div className="border-t border-white/10 p-4">
      <div className="mb-3 flex flex-wrap gap-2">
        {suggestions.map((item) => (
          <button
            key={item}
            onClick={() => onSuggestion(item)}
            className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:border-cyan-400/30 hover:bg-cyan-500/10"
          >
            <Sparkles className="mr-1 inline h-3.5 w-3.5 text-cyan-300" />
            {item}
          </button>
        ))}
      </div>

      <div className="rounded-3xl border border-white/10 bg-black/25 p-3">
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={rows}
          placeholder="Message Frox AI..."
          className="w-full resize-none bg-transparent text-sm outline-none placeholder:text-slate-600"
          onKeyDown={(e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
              e.preventDefault();
              onSend();
            }
          }}
        />

        <div className="mt-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-400">
            <button className="rounded-xl p-2 transition hover:bg-white/10" aria-label="Attach file">
              <Paperclip className="h-4 w-4" />
            </button>
            <button className="rounded-xl p-2 transition hover:bg-white/10" aria-label="Attach image">
              <FileImage className="h-4 w-4" />
            </button>
            <button className="rounded-xl p-2 transition hover:bg-white/10" aria-label="Voice input">
              <Mic className="h-4 w-4" />
            </button>
            <span className="text-xs text-slate-500">Ctrl + Enter</span>
          </div>

          <div className="flex items-center gap-2">
            {isStreaming ? (
              <button
                onClick={onStop}
                className="flex items-center gap-2 rounded-2xl border border-rose-400/25 bg-rose-500/10 px-4 py-2 text-sm text-rose-200 transition hover:bg-rose-500/20"
              >
                <Square className="h-4 w-4" />
                Stop
              </button>
            ) : null}
            <button
              onClick={onSend}
              className="flex items-center gap-2 rounded-2xl border border-indigo-400/30 bg-gradient-to-br from-indigo-500 to-indigo-700 px-4 py-2 text-sm font-medium text-white transition hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-50"
              disabled={!value.trim()}
            >
              <Send className="h-4 w-4" />
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}