import React from "react";
import { Check, Copy, Settings2 } from "lucide-react";
import type { ChatSettings } from "../types";

interface Props {
  settings: ChatSettings;
  copied: boolean;
  onChange: <K extends keyof ChatSettings>(key: K, value: ChatSettings[K]) => void;
  onCopy: () => void;
}

export function SettingsPanel({ settings, copied, onChange, onCopy }: Props) {
  return (
    <aside className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 backdrop-blur-xl">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Settings2 className="h-4 w-4 text-cyan-300" />
          <div className="text-sm font-semibold">Settings</div>
        </div>
        <button
          onClick={onCopy}
          className="rounded-2xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:bg-white/10"
        >
          {copied ? <Check className="mr-1 inline h-3.5 w-3.5" /> : <Copy className="mr-1 inline h-3.5 w-3.5" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>

      <div className="space-y-4">
        <div>
          <label className="mb-2 block text-xs uppercase tracking-[0.18em] text-slate-500">System Prompt</label>
          <textarea
            value={settings.systemPrompt}
            onChange={(e) => onChange("systemPrompt", e.target.value)}
            rows={6}
            className="w-full rounded-3xl border border-white/10 bg-black/25 px-3 py-2 text-sm outline-none"
          />
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-[0.18em] text-slate-500">
            <span>Temperature</span>
            <span>{settings.temperature.toFixed(1)}</span>
          </div>
          <input
            type="range"
            min="0"
            max="2"
            step="0.1"
            value={settings.temperature}
            onChange={(e) => onChange("temperature", parseFloat(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-[0.18em] text-slate-500">
            <span>Max Tokens</span>
            <span>{settings.maxTokens}</span>
          </div>
          <input
            type="range"
            min="256"
            max="32768"
            step="256"
            value={settings.maxTokens}
            onChange={(e) => onChange("maxTokens", parseInt(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between text-xs uppercase tracking-[0.18em] text-slate-500">
            <span>Context Length</span>
            <span>{settings.contextLength}</span>
          </div>
          <input
            type="range"
            min="1"
            max="50"
            step="1"
            value={settings.contextLength}
            onChange={(e) => onChange("contextLength", parseInt(e.target.value))}
            className="w-full"
          />
        </div>

        <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/20 px-3 py-3 text-sm">
          <span>Stream Response</span>
          <input
            type="checkbox"
            checked={settings.streamResponse}
            onChange={(e) => onChange("streamResponse", e.target.checked)}
          />
        </label>

        <label className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/20 px-3 py-3 text-sm">
          <span>Memory</span>
          <input
            type="checkbox"
            checked={settings.memory}
            onChange={(e) => onChange("memory", e.target.checked)}
          />
        </label>

        <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-3 text-xs text-cyan-100">
          This panel is ready to connect to your real API, model switcher, and persistence layer.
        </div>
      </div>
    </aside>
  );
}