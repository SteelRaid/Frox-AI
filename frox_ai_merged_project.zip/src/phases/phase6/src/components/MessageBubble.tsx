import React from "react";
import { Copy, RefreshCcw, Trash2 } from "lucide-react";
import type { ChatMessage } from "../types";

interface Props {
  message: ChatMessage;
  onCopy: (text: string) => void;
  onDelete: (id: string) => void;
  onRegenerate?: () => void;
}

export function MessageBubble({ message, onCopy, onDelete, onRegenerate }: Props) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={[
          "group max-w-[86%] rounded-3xl border px-4 py-3 shadow-lg backdrop-blur-md transition",
          isUser
            ? "border-white/10 bg-white/[0.07] text-slate-100"
            : "border-white/10 bg-[#101020]/90 text-slate-100",
        ].join(" ")}
      >
        <div className="mb-2 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div
              className={[
                "grid h-7 w-7 place-items-center rounded-full border text-[11px] font-semibold",
                isUser
                  ? "border-indigo-400/40 bg-indigo-500/20 text-indigo-100"
                  : "border-cyan-400/40 bg-cyan-500/15 text-cyan-100",
              ].join(" ")}
            >
              {isUser ? "U" : "F"}
            </div>
            <div className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              {isUser ? "You" : "Frox AI"}
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-500">
            <span>{message.createdAt}</span>
            {message.pending ? <span className="text-cyan-300">typing</span> : null}
          </div>
        </div>

        <div className="whitespace-pre-wrap leading-6 text-slate-100">{message.content}</div>

        <div className="mt-3 flex items-center justify-end gap-1 opacity-0 transition group-hover:opacity-100">
          <button
            onClick={() => onCopy(message.content)}
            className="rounded-lg p-1.5 text-slate-500 transition hover:bg-white/10 hover:text-slate-100"
            aria-label="Copy message"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          {!isUser && onRegenerate ? (
            <button
              onClick={onRegenerate}
              className="rounded-lg p-1.5 text-slate-500 transition hover:bg-white/10 hover:text-slate-100"
              aria-label="Regenerate answer"
            >
              <RefreshCcw className="h-3.5 w-3.5" />
            </button>
          ) : null}
          <button
            onClick={() => onDelete(message.id)}
            className="rounded-lg p-1.5 text-slate-500 transition hover:bg-white/10 hover:text-rose-200"
            aria-label="Delete message"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}