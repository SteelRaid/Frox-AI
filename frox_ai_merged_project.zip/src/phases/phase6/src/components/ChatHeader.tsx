import React from "react";
import { Bot, ChevronDown, PanelRightClose, PanelRightOpen, Sparkles } from "lucide-react";

interface ChatHeaderProps {
  title: string;
  model: string;
  showSettings: boolean;
  onToggleSettings: () => void;
  onToggleTitleEditor: () => void;
  onModelChange: (value: string) => void;
  modelOptions: { label: string; subtitle: string; dotClass: string }[];
}

export function ChatHeader({
  title,
  model,
  showSettings,
  onToggleSettings,
  onToggleTitleEditor,
  onModelChange,
  modelOptions,
}: ChatHeaderProps) {
  return (
    <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-2xl border border-indigo-400/30 bg-indigo-500/15 text-indigo-100 shadow-[0_0_24px_rgba(91,91,246,0.2)]">
          <Bot className="h-5 w-5" />
        </div>
        <div>
          <button
            onClick={onToggleTitleEditor}
            className="text-left text-sm font-semibold tracking-wide transition hover:text-cyan-200"
          >
            {title}
          </button>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Sparkles className="h-3.5 w-3.5 text-cyan-300" />
            Frox AI Chat · Phase 6
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <label className="flex items-center gap-2 rounded-2xl border border-white/10 bg-black/20 px-3 py-2 text-sm">
          <span className="h-2 w-2 rounded-full bg-emerald-400" />
          <select
            value={model}
            onChange={(e) => onModelChange(e.target.value)}
            className="bg-transparent text-sm text-slate-100 outline-none"
          >
            {modelOptions.map((option) => (
              <option key={option.label} value={option.label} className="bg-slate-950">
                {option.label}
              </option>
            ))}
          </select>
          <ChevronDown className="h-4 w-4 text-slate-400" />
        </label>

        <button
          onClick={onToggleSettings}
          className="rounded-xl border border-white/10 bg-white/5 p-2 text-slate-300 transition hover:border-indigo-400/40 hover:bg-white/10"
          aria-label="Toggle settings panel"
        >
          {showSettings ? <PanelRightClose className="h-4 w-4" /> : <PanelRightOpen className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
}