import type { Conversation } from "../types";

export function uid(prefix = "id"): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

export function nowTime(): string {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function toReadableGroup(label: string): "Today" | "Yesterday" | "Older" {
  const value = label.toLowerCase();
  if (value.includes("today")) return "Today";
  if (value.includes("yesterday")) return "Yesterday";
  return "Older";
}

export function groupConversations(conversations: Conversation[]) {
  const groups: Record<"Today" | "Yesterday" | "Older", Conversation[]> = {
    Today: [],
    Yesterday: [],
    Older: [],
  };

  for (const conversation of conversations) {
    groups[toReadableGroup(conversation.createdAt)].push(conversation);
  }

  return groups;
}

export function sortByUpdatedAt(conversations: Conversation[]) {
  const rank = (value: string) => {
    const v = value.toLowerCase();
    if (v.includes("now")) return 0;
    if (v.includes("m")) return 1;
    if (v.includes("h")) return 2;
    if (v.includes("today")) return 3;
    if (v.includes("yesterday")) return 4;
    return 5;
  };

  return [...conversations].sort((a, b) => rank(a.updatedAt) - rank(b.updatedAt));
}

export function safeClipboardCopy(text: string): Promise<boolean> {
  if (!navigator.clipboard?.writeText) return Promise.resolve(false);
  return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
}