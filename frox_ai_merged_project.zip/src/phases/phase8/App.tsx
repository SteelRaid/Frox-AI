import { Navigate, Route, Routes } from 'react-router-dom';
import { voiceMultimodalRoutes } from './features/voice-multimodal/routes';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/voice/dashboard/voice" replace />} />
      {voiceMultimodalRoutes}
    </Routes>
  );
}
