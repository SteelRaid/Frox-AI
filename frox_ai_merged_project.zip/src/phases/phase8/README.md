# Frox AI Phase 8 — Voice AI + Multimodal Intelligence Engine

This ZIP contains a standalone React + TypeScript + Vite implementation inspired by the Phase 8 specification.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Included
- Voice assistant UI and audio state
- Multimodal chat UI
- Camera capture shell
- Upload / attachment handling
- Zustand stores
- Route scaffolding
- Tailwind styling
- Framer Motion animations
