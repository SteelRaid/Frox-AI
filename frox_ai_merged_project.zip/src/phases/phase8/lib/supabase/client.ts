type TableLike = {
  insert: (row: Record<string, unknown> | Record<string, unknown>[]) => Promise<{ data: null; error: null }>;
  upsert: (row: Record<string, unknown> | Record<string, unknown>[]) => Promise<{ data: null; error: null }>;
  select: () => TableLike;
  eq: () => TableLike;
  order: () => TableLike;
  limit: () => TableLike;
  single: () => Promise<{ data: null; error: null }>;
};

const table = (): TableLike => ({
  insert: async () => ({ data: null, error: null }),
  upsert: async () => ({ data: null, error: null }),
  select: () => table(),
  eq: () => table(),
  order: () => table(),
  limit: () => table(),
  single: async () => ({ data: null, error: null }),
});

export const supabase = {
  from: (_name: string) => table(),
  storage: {
    from: (_bucket: string) => ({
      upload: async (_path: string, _file: File | Blob) => ({ data: null, error: null }),
      getPublicUrl: (path: string) => ({ data: { publicUrl: `local://${path}` } }),
      remove: async (_paths: string[]) => ({ data: null, error: null }),
    }),
  },
  channel: (_name: string) => ({
    on: () => ({ subscribe: () => undefined }),
    subscribe: () => undefined,
    send: async () => ({ data: null, error: null }),
  }),
};
