interface Props {
  src: string;
}

export function ImageEditor({ src }: Props) {
  return <img src={src} alt="Captured" className="max-h-[480px] w-full rounded-3xl object-contain" />;
}
