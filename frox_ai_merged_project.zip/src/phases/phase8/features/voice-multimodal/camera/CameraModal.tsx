import { Camera, X } from 'lucide-react';
import { useCameraStore } from '../stores/useCameraStore';

export function CameraModal() {
  const { isOpen, setOpen, settings } = useCameraStore();
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
      <div className="w-full max-w-4xl overflow-hidden rounded-3xl border border-white/10 bg-slate-950 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 p-4">
          <div className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            <h2 className="font-semibold">Camera</h2>
          </div>
          <button onClick={() => setOpen(false)} className="rounded-full p-2 hover:bg-white/10" type="button"><X className="h-4 w-4" /></button>
        </div>
        <div className="grid gap-4 p-4 md:grid-cols-[1.5fr_0.7fr]">
          <div className="rounded-3xl bg-black/40 p-3">
            <video className="aspect-video w-full rounded-2xl bg-black" autoPlay muted playsInline />
          </div>
          <div className="grid gap-3">
            <button className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left" type="button">Take photo</button>
            <button className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left" type="button">Switch camera</button>
            <button className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left" type="button">Flash: {settings.flash}</button>
            <button className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left" type="button">Rotate</button>
          </div>
        </div>
      </div>
    </div>
  );
}
