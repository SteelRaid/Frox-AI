import { useState } from 'react';
import { VoiceLayout } from '../layouts/VoiceLayout';
import { VoiceWaveform } from '../voice/VoiceWaveform';
import { MicrophoneButton } from '../voice/MicrophoneButton';
import { VoiceStatusPanel } from '../voice/VoiceStatusPanel';
import { SpeakingIndicator } from '../voice/SpeakingIndicator';
import { VoiceProfileSelector } from '../voice/VoiceProfileSelector';
import { useVoiceStore } from '../stores/useVoiceStore';
import { voiceEngine } from '../services/voiceEngine';

export function VoiceChatPage() {
  const [level, setLevel] = useState(0);
  const isListening = useVoiceStore((s) => s.isListening);
  const isSpeaking = useVoiceStore((s) => s.isSpeaking);

  return (
    <VoiceLayout>
      <div className="grid gap-6">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
          <div className="flex flex-wrap items-center gap-3">
            <VoiceProfileSelector />
            <MicrophoneButton
              active={isListening}
              onClick={async () => {
                if (isListening) voiceEngine.stopListening();
                else await voiceEngine.startListening();
                setLevel((x) => (x + 0.3) % 1);
              }}
            />
            {isSpeaking && <SpeakingIndicator />}
          </div>
          <div className="mt-6">
            <VoiceWaveform level={level} />
          </div>
        </div>
        <VoiceStatusPanel />
      </div>
    </VoiceLayout>
  );
}
