import { useEffect } from 'react';
import { VoiceLayout } from '../layouts/VoiceLayout';
import { MultimodalInput } from '../multimodal/MultimodalInput';
import { MultimodalMessage } from '../multimodal/MultimodalMessage';
import { useMultimodalStore } from '../stores/useMultimodalStore';
import { createId } from '../../../lib/utils';

export function MultimodalChatPage() {
  const createConversation = useMultimodalStore((s) => s.createConversation);
  const activeConversationId = useMultimodalStore((s) => s.activeConversationId);
  const conversation = useMultimodalStore((s) => s.getActiveConversation());
  const addMessage = useMultimodalStore((s) => s.addMessage);
  const updateUploadProgress = useMultimodalStore((s) => s.updateUploadProgress);

  useEffect(() => {
    if (!activeConversationId) createConversation('multimodal');
  }, [activeConversationId, createConversation]);

  const messages = conversation?.messages ?? [];

  return (
    <VoiceLayout>
      <div className="grid gap-6">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-xs uppercase tracking-[0.2em] text-slate-500">Multimodal chat</div>
              <div className="text-xl font-semibold">{conversation?.title ?? 'New Conversation'}</div>
            </div>
            <div className="text-sm text-slate-400">{messages.length} messages</div>
          </div>
          <div className="grid gap-3">
            {messages.map((message) => (
              <MultimodalMessage key={message.id} message={message} />
            ))}
          </div>
        </div>
        <MultimodalInput
          conversationId={conversation?.id}
          onSend={(content, files) => {
            if (!conversation) return;
            const message = {
              id: createId('msg'),
              conversationId: conversation.id,
              type: 'text' as const,
              role: 'user' as const,
              content,
              attachments: [],
              metadata: {},
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            };
            addMessage(conversation.id, message);
            files.forEach((file) => updateUploadProgress(file.name, 100));
          }}
        />
      </div>
    </VoiceLayout>
  );
}
