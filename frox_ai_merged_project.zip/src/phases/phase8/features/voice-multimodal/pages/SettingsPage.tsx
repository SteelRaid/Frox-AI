import { VoiceLayout } from '../layouts/VoiceLayout';
import { useSettingsStore } from '../stores/useSettingsStore';

export function SettingsPage() {
  const { settings, updateVoiceSettings, updateCameraSettings, updateAccessibilitySettings, updatePerformanceSettings } = useSettingsStore();

  return (
    <VoiceLayout>
      <div className="grid gap-6">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
          <h2 className="text-xl font-semibold">Voice settings</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm"><span>Language</span><input className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3" value={settings.voice.language} onChange={(e) => updateVoiceSettings({ language: e.target.value })} /></label>
            <label className="grid gap-2 text-sm"><span>Speed</span><input type="range" min="0.5" max="2" step="0.1" value={settings.voice.speed} onChange={(e) => updateVoiceSettings({ speed: Number(e.target.value) })} /></label>
            <label className="grid gap-2 text-sm"><span>Pitch</span><input type="range" min="0.5" max="2" step="0.1" value={settings.voice.pitch} onChange={(e) => updateVoiceSettings({ pitch: Number(e.target.value) })} /></label>
            <label className="grid gap-2 text-sm"><span>Volume</span><input type="range" min="0" max="1" step="0.05" value={settings.voice.volume} onChange={(e) => updateVoiceSettings({ volume: Number(e.target.value) })} /></label>
          </div>
        </div>
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
          <h2 className="text-xl font-semibold">Camera & accessibility</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm"><span>Frame rate</span><input type="number" className="rounded-2xl border border-white/10 bg-slate-950/70 px-4 py-3" value={settings.camera.frameRate} onChange={(e) => updateCameraSettings({ frameRate: Number(e.target.value) })} /></label>
            <label className="grid gap-2 text-sm"><span>Mirror</span><input type="checkbox" checked={settings.camera.mirror} onChange={(e) => updateCameraSettings({ mirror: e.target.checked })} /></label>
            <label className="grid gap-2 text-sm"><span>Reduced motion</span><input type="checkbox" checked={settings.accessibility.reducedMotion} onChange={(e) => updateAccessibilitySettings({ reducedMotion: e.target.checked })} /></label>
            <label className="grid gap-2 text-sm"><span>High contrast</span><input type="checkbox" checked={settings.accessibility.highContrast} onChange={(e) => updateAccessibilitySettings({ highContrast: e.target.checked })} /></label>
          </div>
        </div>
      </div>
    </VoiceLayout>
  );
}
