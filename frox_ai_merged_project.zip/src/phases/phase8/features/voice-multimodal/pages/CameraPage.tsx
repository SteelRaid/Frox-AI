import { useEffect, useRef } from 'react';
import { Camera } from 'lucide-react';
import { VoiceLayout } from '../layouts/VoiceLayout';
import { cameraEngine } from '../services/cameraEngine';
import { useCameraStore } from '../stores/useCameraStore';
import { ImageEditor } from '../camera/ImageEditor';

export function CameraPage() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const { capturedImages } = useCameraStore();

  useEffect(() => {
    return () => cameraEngine.destroy();
  }, []);

  return (
    <VoiceLayout>
      <div className="grid gap-6">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow">
          <div className="mb-4 flex items-center gap-2">
            <Camera className="h-5 w-5 text-violet-300" />
            <h2 className="text-xl font-semibold">Camera</h2>
          </div>
          <div className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
            <div className="overflow-hidden rounded-3xl bg-black/50">
              <video ref={videoRef} className="aspect-video w-full object-cover" autoPlay muted playsInline />
            </div>
            <div className="grid gap-3">
              <button className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-left" type="button">Capture photo</button>
              <button className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-left" type="button">Switch camera</button>
              <button className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-left" type="button">Toggle flash</button>
              <button className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-left" type="button">Mirror preview</button>
            </div>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {capturedImages.map((img) => (
            <ImageEditor key={img.id} src={img.dataUrl} />
          ))}
        </div>
      </div>
    </VoiceLayout>
  );
}
