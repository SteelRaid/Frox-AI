import { useEffect } from 'react';

export function useKeyboardShortcuts(shortcuts: Record<string, () => void>) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const normalized = [
        event.ctrlKey ? 'Ctrl' : '',
        event.metaKey ? 'Meta' : '',
        event.shiftKey ? 'Shift' : '',
        event.altKey ? 'Alt' : '',
        event.key.length === 1 ? event.key.toUpperCase() : event.key,
      ].filter(Boolean).join('+');
      shortcuts[normalized]?.();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [shortcuts]);
}
