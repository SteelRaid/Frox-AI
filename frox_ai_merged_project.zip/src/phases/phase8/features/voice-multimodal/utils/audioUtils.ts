export function calculateRMS(buffer: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < buffer.length; i += 1) {
    sum += buffer[i] * buffer[i];
  }
  return Math.sqrt(sum / Math.max(1, buffer.length));
}

export function detectSilence(buffer: Float32Array, threshold = 0.01): boolean {
  return calculateRMS(buffer) < threshold;
}

export function applyGain(buffer: Float32Array, gain: number): Float32Array {
  const result = new Float32Array(buffer.length);
  for (let i = 0; i < buffer.length; i += 1) {
    result[i] = Math.max(-1, Math.min(1, buffer[i] * gain));
  }
  return result;
}

export function resampleAudio(inputBuffer: Float32Array, inputSampleRate: number, outputSampleRate: number): Float32Array {
  if (inputSampleRate === outputSampleRate) return inputBuffer;
  const ratio = inputSampleRate / outputSampleRate;
  const outputLength = Math.round(inputBuffer.length / ratio);
  const outputBuffer = new Float32Array(outputLength);
  for (let i = 0; i < outputLength; i += 1) {
    const inputIndex = i * ratio;
    const indexFloor = Math.floor(inputIndex);
    const indexCeil = Math.min(indexFloor + 1, inputBuffer.length - 1);
    const fraction = inputIndex - indexFloor;
    outputBuffer[i] = inputBuffer[indexFloor] * (1 - fraction) + inputBuffer[indexCeil] * fraction;
  }
  return outputBuffer;
}
