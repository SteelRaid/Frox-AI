import { useEffect } from 'react';
import { Pause, Play, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import { useAudioPlayerStore } from '../stores/useAudioPlayerStore';

export function AudioPlayer() {
  const store = useAudioPlayerStore();

  useEffect(() => {
    if (!store.audioElement && typeof window !== 'undefined') {
      const el = new Audio();
      el.onplay = () => store.setPlayerState('playing');
      el.onpause = () => store.setPlayerState('paused');
      el.onended = () => store.setPlayerState('ended');
      el.ontimeupdate = () => store.updateTime(el.currentTime);
      el.ondurationchange = () => store.updateDuration(el.duration || 0);
      store.setAudioElement(el);
    }
  }, [store]);

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-slate-500">Audio player</div>
          <div className="text-sm text-slate-300">{store.currentTrack?.audioFile.name ?? 'No track loaded'}</div>
        </div>
        <div className="text-xs text-slate-400">{store.playerState}</div>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={store.skipPrevious} className="rounded-2xl border border-white/10 bg-black/20 p-3" type="button"><SkipBack className="h-4 w-4" /></button>
        <button onClick={store.toggle} className="rounded-2xl border border-white/10 bg-violet-600/80 p-3 text-white" type="button">
          {store.playerState === 'playing' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </button>
        <button onClick={store.stop} className="rounded-2xl border border-white/10 bg-black/20 p-3" type="button"><Play className="h-4 w-4" /></button>
        <button onClick={store.skipNext} className="rounded-2xl border border-white/10 bg-black/20 p-3" type="button"><SkipForward className="h-4 w-4" /></button>
        <div className="ml-auto flex items-center gap-2 text-sm text-slate-300">
          <Volume2 className="h-4 w-4" />
          <input type="range" min="0" max="1" step="0.01" value={store.volume} onChange={(e) => store.setVolume(Number(e.target.value))} className="audio-range w-28" />
        </div>
      </div>
    </div>
  );
}
