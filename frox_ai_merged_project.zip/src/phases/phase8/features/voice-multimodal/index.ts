export * from './types/voice';
export * from './types/multimodal';
export * from './types/camera';
export * from './types/audio';
export * from './types/attachment';
export * from './types/conversation';
export * from './types/settings';
export * from './types/dashboard';

export { useVoiceStore } from './stores/useVoiceStore';
export { useMultimodalStore } from './stores/useMultimodalStore';
export { useCameraStore } from './stores/useCameraStore';
export { useAudioPlayerStore } from './stores/useAudioPlayerStore';
export { useSettingsStore } from './stores/useSettingsStore';

export { useVoiceEngine } from './hooks/useVoiceEngine';
export { useCamera } from './hooks/useCamera';
export { useAudioPlayer } from './hooks/useAudioPlayer';
export { useLiveConversation } from './hooks/useLiveConversation';
export { useDragAndDrop } from './hooks/useDragAndDrop';
export { useWaveform } from './hooks/useWaveform';
export { useIndexedDB } from './hooks/useIndexedDB';
export { useKeyboardShortcuts } from './utils/keyboardShortcuts';

export { voiceEngine } from './services/voiceEngine';
export { cameraEngine } from './services/cameraEngine';
export { uploadService } from './services/uploadService';
export { audioService } from './services/audioService';
export { liveConversationService } from './services/liveConversationService';

export { VoiceWaveform } from './voice/VoiceWaveform';
export { MicrophoneButton } from './voice/MicrophoneButton';
export { SpeakingIndicator } from './voice/SpeakingIndicator';
export { ListeningRing } from './voice/ListeningRing';
export { VoiceStatusPanel } from './voice/VoiceStatusPanel';
export { VoiceProfileSelector } from './voice/VoiceProfileSelector';

export { MultimodalInput } from './multimodal/MultimodalInput';
export { MultimodalMessage } from './multimodal/MultimodalMessage';

export { CameraModal } from './camera/CameraModal';
export { ImageEditor } from './camera/ImageEditor';

export { AttachmentPreview } from './attachments/AttachmentPreview';

export { AudioPlayer } from './audio/AudioPlayer';

export { WaveformVisualizer } from './waveforms/WaveformVisualizer';

export { VoiceDashboard } from './dashboard/VoiceDashboard';

export { VoiceChatPage } from './pages/VoiceChatPage';
export { MultimodalChatPage } from './pages/MultimodalChatPage';
export { CameraPage } from './pages/CameraPage';
export { SettingsPage } from './pages/SettingsPage';

export { VoiceProvider, useVoiceContext } from './providers/VoiceProvider';
export { MultimodalProvider, useMultimodalContext } from './providers/MultimodalProvider';

export { voiceMultimodalRoutes } from './routes';
export { VoiceLayout } from './layouts/VoiceLayout';

export * from './utils/audioUtils';
export * from './utils/imageUtils';
export * from './animations/voiceAnimations';
