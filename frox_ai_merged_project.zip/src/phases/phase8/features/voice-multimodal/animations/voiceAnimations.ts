import type { Variants } from 'framer-motion';

export const listeningPulse: Variants = {
  initial: { scale: 1, opacity: 0.5 },
  animate: {
    scale: [1, 1.2, 1],
    opacity: [0.5, 1, 0.5],
    transition: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
  },
};

export const speakingGlow: Variants = {
  initial: { boxShadow: '0 0 0 0 rgba(139, 92, 246, 0)' },
  animate: {
    boxShadow: ['0 0 0 0 rgba(139, 92, 246, 0.4)', '0 0 0 20px rgba(139, 92, 246, 0)'],
    transition: { duration: 1.5, repeat: Infinity, ease: 'easeOut' },
  },
};

export const waveformBar: Variants = {
  initial: { height: 4 },
  animate: (i: number) => ({
    height: [4, 24 + Math.random() * 40, 4],
    transition: { duration: 0.5 + Math.random() * 0.5, repeat: Infinity, delay: i * 0.02, ease: 'easeInOut' },
  }),
};

export const messageSlideIn: Variants = {
  initial: (isUser: boolean) => ({ opacity: 0, x: isUser ? 20 : -20, y: 10 }),
  animate: { opacity: 1, x: 0, y: 0, transition: { type: 'spring', stiffness: 300, damping: 30 } },
  exit: { opacity: 0, scale: 0.95, transition: { duration: 0.2 } },
};

export const attachmentUpload: Variants = {
  initial: { opacity: 0, scale: 0.8, y: 20 },
  animate: { opacity: 1, scale: 1, y: 0, transition: { type: 'spring', stiffness: 400, damping: 25 } },
  exit: { opacity: 0, scale: 0.8, x: -20, transition: { duration: 0.2 } },
};

export const cameraShutter: Variants = {
  initial: { scale: 1 },
  capture: { scale: [1, 0.95, 1], opacity: [1, 0.8, 1], transition: { duration: 0.3 } },
};

export const glassmorphismPanel = {
  background: 'rgba(255, 255, 255, 0.03)',
  backdropFilter: 'blur(20px)',
  border: '1px solid rgba(255, 255, 255, 0.08)',
  borderRadius: '16px',
};

export const premiumGradient = {
  background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%)',
};
