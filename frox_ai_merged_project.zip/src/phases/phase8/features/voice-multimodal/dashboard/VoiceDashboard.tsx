import { BarChart3, Mic, Image, UploadCloud, MessageSquare } from 'lucide-react';
import { useVoiceStore } from '../stores/useVoiceStore';
import { useMultimodalStore } from '../stores/useMultimodalStore';

export function VoiceDashboard() {
  const voice = useVoiceStore();
  const multimodal = useMultimodalStore();

  const tiles = [
    { label: 'Conversations', value: multimodal.conversations.length, icon: MessageSquare },
    { label: 'Messages', value: multimodal.conversations.reduce((sum, c) => sum + c.messages.length, 0), icon: Mic },
    { label: 'Uploads', value: multimodal.attachments.length, icon: UploadCloud },
    { label: 'Voice profiles', value: voice.profiles.length, icon: Image },
  ];

  return (
    <div className="grid gap-6">
      <div className="grid gap-4 md:grid-cols-4">
        {tiles.map((tile) => (
          <div key={tile.label} className="rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glow">
            <tile.icon className="mb-3 h-5 w-5 text-violet-300" />
            <div className="text-sm text-slate-400">{tile.label}</div>
            <div className="text-2xl font-semibold">{tile.value}</div>
          </div>
        ))}
      </div>
      <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
        <div className="mb-4 flex items-center gap-2 text-sm text-slate-300"><BarChart3 className="h-4 w-4" /> Activity overview</div>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-2xl bg-black/20 p-4">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-500">Voice queue</div>
            <div className="mt-2 text-sm text-slate-300">{voice.queue.length} queued item(s)</div>
          </div>
          <div className="rounded-2xl bg-black/20 p-4">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-500">Upload progress</div>
            <div className="mt-2 text-sm text-slate-300">{Object.keys(multimodal.uploadProgress).length} file(s) tracked</div>
          </div>
        </div>
      </div>
    </div>
  );
}
