import { createId } from '../../../lib/utils';
import type { LiveConversation, Participant, StreamMessage } from '../types/conversation';

type Listener = (conversation: LiveConversation) => void;

export class LiveConversationService {
  private static instance: LiveConversationService;
  private conversations = new Map<string, LiveConversation>();
  private listeners = new Set<Listener>();

  static getInstance(): LiveConversationService {
    if (!LiveConversationService.instance) LiveConversationService.instance = new LiveConversationService();
    return LiveConversationService.instance;
  }

  createConversation(mode: LiveConversation['mode'] = 'multimodal'): LiveConversation {
    const conversation: LiveConversation = {
      id: createId('live'),
      mode,
      state: 'idle',
      participants: [],
      messages: [],
      startedAt: new Date().toISOString(),
      duration: 0,
      metrics: {
        totalLatency: 0,
        messageCount: 0,
        audioDuration: 0,
        videoDuration: 0,
        tokenCount: 0,
        interruptCount: 0,
        errorCount: 0,
        avgResponseTime: 0,
      },
      recording: { isRecording: false, startedAt: new Date().toISOString(), duration: 0, size: 0 },
    };
    this.conversations.set(conversation.id, conversation);
    this.emit(conversation);
    return conversation;
  }

  joinConversation(conversationId: string, participant: Participant): void {
    const conversation = this.conversations.get(conversationId);
    if (!conversation) return;
    conversation.participants = [...conversation.participants, participant];
    conversation.state = 'connecting';
    this.emit(conversation);
  }

  addMessage(conversationId: string, message: StreamMessage): void {
    const conversation = this.conversations.get(conversationId);
    if (!conversation) return;
    conversation.messages = [...conversation.messages, message];
    conversation.metrics.messageCount += 1;
    conversation.metrics.totalLatency += message.latency;
    conversation.metrics.avgResponseTime = conversation.metrics.totalLatency / conversation.metrics.messageCount;
    this.emit(conversation);
  }

  updateState(conversationId: string, state: LiveConversation['state']): void {
    const conversation = this.conversations.get(conversationId);
    if (!conversation) return;
    conversation.state = state;
    this.emit(conversation);
  }

  endConversation(conversationId: string): void {
    const conversation = this.conversations.get(conversationId);
    if (!conversation) return;
    conversation.state = 'completed';
    conversation.endedAt = new Date().toISOString();
    conversation.duration = Date.now() - Date.parse(conversation.startedAt);
    this.emit(conversation);
  }

  getConversation(id: string): LiveConversation | null {
    return this.conversations.get(id) || null;
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(conversation: LiveConversation): void {
    this.listeners.forEach((listener) => listener(conversation));
  }
}

export const liveConversationService = LiveConversationService.getInstance();
