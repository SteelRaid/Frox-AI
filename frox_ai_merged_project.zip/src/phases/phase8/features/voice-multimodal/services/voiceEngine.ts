import { useVoiceStore } from '../stores/useVoiceStore';
import { useSettingsStore } from '../stores/useSettingsStore';
import { createId } from '../../../lib/utils';
import type { VoiceProfile, VoiceQueueItem, VoiceTranscript } from '../types/voice';

type SpeechRecognitionCtor = new () => SpeechRecognition;

export class VoiceEngine {
  private static instance: VoiceEngine;
  private recognition: SpeechRecognition | null = null;
  private synthesis: SpeechSynthesis | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private stream: MediaStream | null = null;
  private isInitialized = false;
  private abortController: AbortController | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  private constructor() {}

  static getInstance(): VoiceEngine {
    if (!VoiceEngine.instance) {
      VoiceEngine.instance = new VoiceEngine();
    }
    return VoiceEngine.instance;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;
    if (typeof window === 'undefined') return;

    const store = useVoiceStore.getState();
    const settings = useSettingsStore.getState().settings.voice;
    try {
      const audioContext = new AudioContext({ sampleRate: 48000 });
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 2048;
      analyser.smoothingTimeConstant = 0.8;
      store.setAudioContext(audioContext);
      store.setAnalyserNode(analyser);
      await this.enumerateDevices();

      const SpeechRecognitionAPI =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognitionAPI) {
        this.recognition = new SpeechRecognitionAPI() as SpeechRecognition;
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = settings.language;
        this.recognition.onstart = () => {
          store.setActivity('listening', 1);
          store.setListening(true);
        };
        this.recognition.onresult = (event) => {
          let finalTranscript = '';
          let interimTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i += 1) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) finalTranscript += transcript;
            else interimTranscript += transcript;
          }
          if (finalTranscript) {
            store.addHistory({
              id: createId('trans'),
              type: 'transcript',
              content: finalTranscript,
              duration: 0,
              timestamp: Date.now(),
            });
          }
          const transcript: VoiceTranscript = {
            id: createId('live'),
            text: finalTranscript || interimTranscript,
            isFinal: Boolean(finalTranscript),
            confidence: event.results[event.resultIndex]?.[0]?.confidence || 0,
            timestamp: Date.now(),
            speaker: 'user',
          };
          window.dispatchEvent(new CustomEvent('voice:transcript', { detail: transcript }));
        };
        this.recognition.onerror = (event) => {
          console.error('Speech recognition error:', event.error);
          store.setActivity('error', 0);
          store.setListening(false);
        };
        this.recognition.onend = () => {
          if (store.isAlwaysListening && !store.isPushToTalkActive) {
            this.recognition?.start();
          } else {
            store.setActivity('idle', 0);
            store.setListening(false);
          }
        };
      }

      this.synthesis = window.speechSynthesis;
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize voice engine:', error);
      throw error;
    }
  }

  private async enumerateDevices(): Promise<void> {
    try {
      if (!navigator.mediaDevices?.enumerateDevices) return;
      const devices = await navigator.mediaDevices.enumerateDevices();
      const inputs = devices
        .filter((d) => d.kind === 'audioinput')
        .map((d) => ({
          id: d.deviceId,
          label: d.label || `Microphone ${d.deviceId.slice(0, 8)}`,
          kind: 'audioinput' as const,
          groupId: d.groupId,
          isDefault: d.deviceId === 'default',
        }));
      const outputs = devices
        .filter((d) => d.kind === 'audiooutput')
        .map((d) => ({
          id: d.deviceId,
          label: d.label || `Speaker ${d.deviceId.slice(0, 8)}`,
          kind: 'audiooutput' as const,
          groupId: d.groupId,
          isDefault: d.deviceId === 'default',
        }));
      useVoiceStore.getState().setDevices(inputs, outputs);
    } catch (error) {
      console.error('Failed to enumerate audio devices:', error);
    }
  }

  async startListening(options?: { pushToTalk?: boolean }): Promise<void> {
    const store = useVoiceStore.getState();
    const settings = useSettingsStore.getState().settings.voice;
    if (!this.isInitialized) await this.initialize();
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone access is not supported in this browser.');

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: settings.inputDeviceId ? { exact: settings.inputDeviceId } : undefined,
        echoCancellation: settings.noiseSuppression.enabled,
        noiseSuppression: settings.noiseSuppression.enabled,
        sampleRate: 48000,
        channelCount: 1,
      },
    });

    const audioContext = store.audioContext;
    const analyser = store.analyserNode;
    if (audioContext && analyser) {
      const source = audioContext.createMediaStreamSource(this.stream);
      source.connect(analyser);
    }

    this.mediaRecorder = new MediaRecorder(
      this.stream,
      MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? { mimeType: 'audio/webm;codecs=opus' } : undefined
    );

    this.audioChunks = [];
    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) this.audioChunks.push(event.data);
    };
    this.mediaRecorder.start(100);

    if (this.recognition && !store.isListening) this.recognition.start();
    if (options?.pushToTalk) store.setPushToTalk(true);
    this.startVADMonitoring();
  }

  stopListening(): void {
    const store = useVoiceStore.getState();
    this.recognition?.stop();
    this.mediaRecorder?.stop();
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
    store.setListening(false);
    store.setPushToTalk(false);
    store.setActivity('idle', 0);
  }

  private startVADMonitoring(): void {
    const store = useVoiceStore.getState();
    const analyser = store.analyserNode;
    if (!analyser) return;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    let silenceFrames = 0;
    const SILENCE_FRAMES_THRESHOLD = 30;

    const monitor = () => {
      if (!store.isListening) return;
      analyser.getByteFrequencyData(dataArray);
      const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
      const normalized = average / 255;
      store.setMetrics({ inputLevel: normalized });

      if (normalized < 0.02) {
        silenceFrames += 1;
        if (silenceFrames > SILENCE_FRAMES_THRESHOLD && !store.isPushToTalkActive && !store.isAlwaysListening) {
          this.stopListening();
          return;
        }
      } else {
        silenceFrames = 0;
      }
      requestAnimationFrame(monitor);
    };
    requestAnimationFrame(monitor);
  }

  async speak(text: string, profile?: VoiceProfile): Promise<void> {
    const store = useVoiceStore.getState();
    const activeProfile = profile || store.activeProfile;
    if (!activeProfile) throw new Error('No voice profile selected');
    if (!this.synthesis) {
      if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('voice:spoken', { detail: text }));
      return;
    }

    if (store.interruptEnabled && this.synthesis.speaking) {
      this.synthesis.cancel();
      this.abortController?.abort();
    }

    this.abortController = new AbortController();
    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.voice = this.findBestVoice(activeProfile);
      utterance.pitch = activeProfile.pitch;
      utterance.rate = activeProfile.speed;
      utterance.volume = activeProfile.volume;
      utterance.lang = activeProfile.locale;
      utterance.onstart = () => {
        store.setActivity('speaking', 1);
        store.setSpeaking(true);
        this.currentUtterance = utterance;
      };
      utterance.onend = () => {
        store.setActivity('idle', 0);
        store.setSpeaking(false);
        this.currentUtterance = null;
        resolve();
      };
      utterance.onerror = (event) => {
        store.setActivity('error', 0);
        store.setSpeaking(false);
        this.currentUtterance = null;
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };
      this.synthesis!.speak(utterance);
    });
  }

  private findBestVoice(profile: VoiceProfile): SpeechSynthesisVoice | null {
    const voices = this.synthesis?.getVoices() || [];
    if (voices.length === 0) return null;
    return voices.find((v) => v.lang === profile.locale) || voices.find((v) => v.lang.startsWith(profile.language)) || voices[0] || null;
  }

  interrupt(): void {
    const store = useVoiceStore.getState();
    if (this.synthesis?.speaking) {
      this.synthesis.cancel();
      this.abortController?.abort();
      store.setActivity('interrupted', 0);
      store.setSpeaking(false);
    }
  }

  getRecordedAudio(): Blob | null {
    if (this.audioChunks.length === 0) return null;
    return new Blob(this.audioChunks, { type: 'audio/webm' });
  }

  clearRecording(): void {
    this.audioChunks = [];
  }

  async queueSpeech(item: VoiceQueueItem): Promise<void> {
    const store = useVoiceStore.getState();
    store.enqueue(item);
    await this.processQueue();
  }

  private async processQueue(): Promise<void> {
    const store = useVoiceStore.getState();
    if (store.isSpeaking || store.queue.length === 0) return;
    const item = store.dequeue();
    if (!item) return;
    await this.speak(item.text, item.profile);
    await this.processQueue();
  }

  destroy(): void {
    this.stopListening();
    this.synthesis?.cancel();
    this.stream?.getTracks().forEach((t) => t.stop());
    const store = useVoiceStore.getState();
    store.audioContext?.close();
    store.setAudioContext(null);
    store.setAnalyserNode(null);
    this.isInitialized = false;
  }
}

export const voiceEngine = VoiceEngine.getInstance();
