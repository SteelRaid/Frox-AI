import { createId } from '../../../lib/utils';
import type { AudioFile, WaveformData } from '../types/audio';

export class AudioService {
  private static instance: AudioService;
  private audioContext: AudioContext | null = null;

  static getInstance(): AudioService {
    if (!AudioService.instance) AudioService.instance = new AudioService();
    return AudioService.instance;
  }

  getContext(): AudioContext {
    if (this.audioContext) return this.audioContext;
    this.audioContext = new AudioContext();
    return this.audioContext;
  }

  async createAudioFileFromBlob(blob: Blob, name = 'audio.webm'): Promise<AudioFile> {
    const url = URL.createObjectURL(blob);
    const duration = await this.getDuration(url);
    return {
      id: createId('audio'),
      name,
      url,
      blob,
      duration,
      sampleRate: 48000,
      channels: 1,
      bitrate: 128000,
      format: blob.type || 'audio/webm',
      size: blob.size,
      metadata: {},
      createdAt: new Date().toISOString(),
    };
  }

  private async getDuration(url: string): Promise<number> {
    return new Promise((resolve) => {
      const audio = new Audio();
      audio.preload = 'metadata';
      audio.onloadedmetadata = () => resolve(Number.isFinite(audio.duration) ? audio.duration : 0);
      audio.onerror = () => resolve(0);
      audio.src = url;
    });
  }

  async generateWaveform(blobOrUrl: Blob | string): Promise<WaveformData> {
    const url = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
    const duration = await this.getDuration(url);
    const ctx = this.getContext();
    const response = await fetch(url);
    const arrayBuffer = await response.arrayBuffer();
    const audioBuffer = await ctx.decodeAudioData(arrayBuffer.slice(0));
    const data = audioBuffer.getChannelData(0);
    return {
      id: createId('wave'),
      audioId: createId('audio-ref'),
      data: new Float32Array(data),
      duration,
      sampleRate: audioBuffer.sampleRate,
      peaksPerSecond: 10,
      generatedAt: new Date().toISOString(),
    };
  }

  async play(blobOrUrl: Blob | string): Promise<HTMLAudioElement> {
    const url = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
    const audio = new Audio(url);
    await audio.play();
    return audio;
  }
}

export const audioService = AudioService.getInstance();
