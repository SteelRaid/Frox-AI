import { supabase } from '../../../lib/supabase/client';
import { createId, formatBytes } from '../../../lib/utils';
import { useMultimodalStore } from '../stores/useMultimodalStore';
import { useSettingsStore } from '../stores/useSettingsStore';
import type { Attachment, AttachmentMetadata, AttachmentStatus, FileValidationResult, UploadProgress } from '../types/attachment';

const CHUNK_SIZE = 5 * 1024 * 1024;
const MAX_RETRIES = 3;

export class UploadService {
  private static instance: UploadService;
  private activeUploads = new Map<string, AbortController>();

  static getInstance(): UploadService {
    if (!UploadService.instance) UploadService.instance = new UploadService();
    return UploadService.instance;
  }

  validateFile(file: File): FileValidationResult {
    const settings = useSettingsStore.getState().settings;
    const errors: string[] = [];
    const warnings: string[] = [];

    if (file.size > settings.maxAttachmentSize) {
      errors.push(`File exceeds maximum size of ${formatBytes(settings.maxAttachmentSize)}`);
    }
    if (!settings.allowedAttachmentTypes.includes(file.type)) {
      errors.push(`File type ${file.type || 'unknown'} is not allowed`);
    }

    return { valid: errors.length === 0, file, errors, warnings };
  }

  async uploadFile(file: File, messageId: string): Promise<Attachment> {
    const validation = this.validateFile(file);
    if (!validation.valid) throw new Error(validation.errors.join(', '));

    const fileId = createId('file');
    const store = useMultimodalStore.getState();
    store.updateUploadProgress(fileId, 0);

    const attachment: Attachment = {
      id: fileId,
      messageId,
      type: this.inferFileType(file.type),
      name: file.name,
      size: file.size,
      mimeType: file.type,
      url: URL.createObjectURL(file),
      status: 'ready',
      progress: 100,
      metadata: {
        checksum: `${file.name}-${file.size}`,
      },
      createdAt: new Date().toISOString(),
    };

    useMultimodalStore.getState().addAttachment(attachment);
    store.updateUploadProgress(fileId, 100);
    return attachment;
  }

  async uploadFiles(files: File[], messageId: string): Promise<Attachment[]> {
    const results: Attachment[] = [];
    for (const file of files) {
      results.push(await this.uploadFile(file, messageId));
    }
    return results;
  }

  cancelUpload(fileId: string): void {
    this.activeUploads.get(fileId)?.abort();
    this.activeUploads.delete(fileId);
  }

  private inferFileType(mimeType: string): Attachment['type'] {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (mimeType.includes('pdf') || mimeType.startsWith('text/') || mimeType.includes('document')) return 'document';
    if (mimeType.includes('zip') || mimeType.includes('archive')) return 'archive';
    if (mimeType.includes('javascript') || mimeType.includes('typescript') || mimeType.includes('json') || mimeType.includes('html') || mimeType.includes('css')) return 'code';
    return 'unknown';
  }
}

export const uploadService = UploadService.getInstance();
