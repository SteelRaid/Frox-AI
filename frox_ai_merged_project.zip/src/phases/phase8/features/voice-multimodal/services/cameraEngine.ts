import { createId } from '../../../lib/utils';
import { useCameraStore } from '../stores/useCameraStore';
import type { CameraDevice, CameraSettings, CameraResolution, CapturedImage } from '../types/camera';

export class CameraEngine {
  private static instance: CameraEngine;
  private stream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null = null;

  private constructor() {}

  static getInstance(): CameraEngine {
    if (!CameraEngine.instance) CameraEngine.instance = new CameraEngine();
    return CameraEngine.instance;
  }

  async enumerateDevices(): Promise<CameraDevice[]> {
    try {
      if (!navigator.mediaDevices?.getUserMedia) return [];
      await navigator.mediaDevices.getUserMedia({ video: true });
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices
        .filter((d) => d.kind === 'videoinput')
        .map((d, index) => ({
          id: d.deviceId,
          label: d.label || `Camera ${index + 1}`,
          facing: this.inferFacingMode(d.label),
          capabilities: {} as MediaTrackCapabilities,
          isDefault: index === 0,
        }));
      useCameraStore.getState().setDevices(videoDevices);
      return videoDevices;
    } catch (error) {
      console.error('Failed to enumerate camera devices:', error);
      return [];
    }
  }

  private inferFacingMode(label: string): 'user' | 'environment' {
    const lower = label.toLowerCase();
    return lower.includes('front') || lower.includes('user') || lower.includes('selfie') ? 'user' : 'environment';
  }

  async startPreview(videoElement: HTMLVideoElement, settings?: Partial<CameraSettings>): Promise<void> {
    const store = useCameraStore.getState();
    const currentSettings = { ...store.settings, ...settings };
    this.stop();
    const constraints: MediaStreamConstraints = {
      video: {
        deviceId: currentSettings.deviceId ? { exact: currentSettings.deviceId } : undefined,
        width: { ideal: currentSettings.resolution.width },
        height: { ideal: currentSettings.resolution.height },
        frameRate: { ideal: currentSettings.frameRate },
        facingMode: currentSettings.facing,
      },
      audio: false,
    };

    this.stream = await navigator.mediaDevices.getUserMedia(constraints);
    this.videoElement = videoElement;
    videoElement.srcObject = this.stream;
    videoElement.muted = true;
    videoElement.playsInline = true;
    await videoElement.play();

    const track = this.stream.getVideoTracks()[0];
    if (track) {
      const device = store.devices.find((d) => d.id === currentSettings.deviceId);
      if (device) device.capabilities = track.getCapabilities();
    }
    store.setStream(this.stream);
    store.setReady(true);
    store.setOpen(true);
  }

  async capturePhoto(): Promise<CapturedImage> {
    const store = useCameraStore.getState();
    if (!this.videoElement || !this.stream) throw new Error('Camera not initialized');
    store.setCapturing(true);
    try {
      const video = this.videoElement;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');
      const settings = store.settings;
      if (settings.mirror && settings.facing === 'user') {
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
      }
      ctx.drawImage(video, 0, 0);
      ctx.setTransform(1, 0, 0, 1, 0, 0);

      const blob = await new Promise<Blob>((resolve, reject) => {
        canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('Canvas toBlob failed'))), 'image/jpeg', 0.92);
      });
      const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      const image: CapturedImage = {
        id: createId('img'),
        dataUrl,
        blob,
        width: canvas.width,
        height: canvas.height,
        timestamp: Date.now(),
        deviceId: store.selectedDeviceId || '',
        settings: { ...settings },
        metadata: { orientation: settings.mirror && settings.facing === 'user' ? 2 : 1 },
      };
      store.addCapturedImage(image);
      return image;
    } finally {
      store.setCapturing(false);
    }
  }

  async switchCamera(): Promise<void> {
    const store = useCameraStore.getState();
    const devices = store.devices;
    if (devices.length === 0 || !this.videoElement) return;
    const currentIndex = Math.max(0, devices.findIndex((d) => d.id === store.selectedDeviceId));
    const nextIndex = (currentIndex + 1) % devices.length;
    const nextDevice = devices[nextIndex];
    if (nextDevice) {
      store.selectDevice(nextDevice.id);
      store.setSettings({ facing: nextDevice.facing, deviceId: nextDevice.id });
      await this.startPreview(this.videoElement, { deviceId: nextDevice.id, facing: nextDevice.facing });
    }
  }

  stop(): void {
    const store = useCameraStore.getState();
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
    if (this.videoElement) {
      this.videoElement.srcObject = null;
      this.videoElement = null;
    }
    store.setStream(null);
    store.setReady(false);
    store.setOpen(false);
  }

  getResolutions(): CameraResolution[] {
    return [
      { width: 640, height: 480, label: '480p' },
      { width: 1280, height: 720, label: '720p' },
      { width: 1920, height: 1080, label: '1080p' },
      { width: 2560, height: 1440, label: '1440p' },
      { width: 3840, height: 2160, label: '4K' },
    ];
  }

  destroy(): void {
    this.stop();
  }
}

export const cameraEngine = CameraEngine.getInstance();
