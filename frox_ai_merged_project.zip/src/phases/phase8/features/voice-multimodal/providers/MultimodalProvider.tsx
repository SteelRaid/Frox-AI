import { createContext, useContext, type ReactNode } from 'react';

const MultimodalContext = createContext<{ ready: boolean }>({ ready: true });

export function MultimodalProvider({ children }: { children: ReactNode }) {
  return <MultimodalContext.Provider value={{ ready: true }}>{children}</MultimodalContext.Provider>;
}

export function useMultimodalContext() {
  return useContext(MultimodalContext);
}
