import { createContext, useContext, type ReactNode } from 'react';
import { useVoiceEngine } from '../hooks/useVoiceEngine';

const VoiceContext = createContext<{ ready: boolean }>({ ready: true });

export function VoiceProvider({ children }: { children: ReactNode }) {
  useVoiceEngine();
  return <VoiceContext.Provider value={{ ready: true }}>{children}</VoiceContext.Provider>;
}

export function useVoiceContext() {
  return useContext(VoiceContext);
}
