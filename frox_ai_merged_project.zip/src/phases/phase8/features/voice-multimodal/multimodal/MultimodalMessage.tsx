import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';
import type { MultimodalMessage as MessageType } from '../types/multimodal';

interface Props {
  message: MessageType;
}

export function MultimodalMessage({ message }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8, x: message.role === 'user' ? 12 : -12 }}
      animate={{ opacity: 1, y: 0, x: 0 }}
      className={message.role === 'user' ? 'ml-auto max-w-[85%]' : 'mr-auto max-w-[85%]'}
    >
      <div className={`rounded-3xl border p-4 shadow-glow ${message.role === 'user' ? 'border-violet-500/20 bg-violet-500/10' : 'border-white/10 bg-white/5'}`}>
        <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-slate-400">{message.role}</div>
        <div className="prose prose-invert max-w-none prose-p:my-2 prose-headings:mb-2 prose-headings:mt-0 prose-a:text-violet-300">
          <ReactMarkdown>{message.content || ' '}</ReactMarkdown>
        </div>
      </div>
    </motion.div>
  );
}
