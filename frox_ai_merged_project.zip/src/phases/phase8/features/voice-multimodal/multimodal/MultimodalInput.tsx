import { useMemo, useState } from 'react';
import { Image, Send, Mic, Paperclip } from 'lucide-react';
import { uploadService } from '../services/uploadService';

interface Props {
  conversationId?: string;
  onSend: (content: string, files: File[]) => void;
}

export function MultimodalInput({ onSend }: Props) {
  const [text, setText] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const canSend = useMemo(() => text.trim().length > 0 || files.length > 0, [text, files]);

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-3 shadow-glow">
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={3}
        placeholder="Ask anything, attach an image, or paste a document..."
        className="w-full resize-none rounded-2xl border border-white/10 bg-slate-950/70 p-4 text-sm outline-none placeholder:text-slate-500"
      />
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl border border-white/10 bg-black/20 px-3 py-2 text-sm hover:bg-white/10">
          <Paperclip className="h-4 w-4" />
          Attach
          <input
            type="file"
            multiple
            className="hidden"
            onChange={(e) => setFiles(Array.from(e.target.files || []))}
          />
        </label>
        <button type="button" className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/20 px-3 py-2 text-sm">
          <Mic className="h-4 w-4" />
          Voice
        </button>
        <button type="button" className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/20 px-3 py-2 text-sm">
          <Image className="h-4 w-4" />
          Camera
        </button>
        <div className="ml-auto">
          <button
            type="button"
            disabled={!canSend}
            onClick={() => {
              onSend(text, files);
              setText('');
              setFiles([]);
            }}
            className="inline-flex items-center gap-2 rounded-2xl bg-violet-600 px-4 py-3 text-sm font-medium text-white disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
            Send
          </button>
        </div>
      </div>
      {files.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {files.map((file) => (
            <div key={`${file.name}-${file.size}`} className="rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-slate-300">
              {file.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
