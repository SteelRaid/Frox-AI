import { motion } from 'framer-motion';
import { useWaveform } from '../hooks/useWaveform';

interface Props {
  level?: number;
}

export function WaveformVisualizer({ level = 0 }: Props) {
  const bars = useWaveform(level);
  return (
    <div className="flex h-24 items-end gap-1 rounded-3xl border border-white/10 bg-white/5 p-3">
      {bars.map((bar, index) => (
        <motion.span
          key={index}
          initial={{ height: 4, opacity: 0.5 }}
          animate={{ height: bar, opacity: 1 }}
          transition={{ duration: 0.25 }}
          className="w-1 rounded-full bg-violet-400"
        />
      ))}
    </div>
  );
}
