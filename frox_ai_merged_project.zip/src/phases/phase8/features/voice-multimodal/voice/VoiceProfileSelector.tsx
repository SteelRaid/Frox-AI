import { useVoiceStore } from '../stores/useVoiceStore';

export function VoiceProfileSelector() {
  const profiles = useVoiceStore((s) => s.profiles);
  const activeProfile = useVoiceStore((s) => s.activeProfile);
  const setActiveProfile = useVoiceStore((s) => s.setActiveProfile);

  return (
    <label className="grid gap-2 text-sm text-slate-300">
      <span>Voice profile</span>
      <select
        value={activeProfile?.id ?? ''}
        onChange={(e) => setActiveProfile(profiles.find((p) => p.id === e.target.value) ?? null)}
        className="rounded-2xl border border-white/10 bg-slate-900/80 px-4 py-3 text-sm text-slate-100 outline-none"
      >
        {profiles.map((profile) => (
          <option key={profile.id} value={profile.id}>
            {profile.name}
          </option>
        ))}
      </select>
    </label>
  );
}
