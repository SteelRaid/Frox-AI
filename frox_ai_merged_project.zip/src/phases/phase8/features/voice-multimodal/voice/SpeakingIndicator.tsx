import { motion } from 'framer-motion';
import { Volume2 } from 'lucide-react';

export function SpeakingIndicator() {
  return (
    <motion.div
      className="inline-flex items-center gap-2 rounded-full border border-violet-500/20 bg-violet-500/10 px-3 py-1 text-sm text-violet-100"
      animate={{ scale: [1, 1.02, 1] }}
      transition={{ duration: 1.8, repeat: Infinity }}
    >
      <Volume2 className="h-4 w-4" />
      Speaking
    </motion.div>
  );
}
