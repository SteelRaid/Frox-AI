import { motion } from 'framer-motion';
import { useWaveform } from '../hooks/useWaveform';
import { waveformBar } from '../animations/voiceAnimations';

interface Props {
  level?: number;
}

export function VoiceWaveform({ level = 0 }: Props) {
  const bars = useWaveform(level);
  return (
    <div className="flex h-16 items-end gap-1 overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-3">
      {bars.map((bar, index) => (
        <motion.div
          key={`${index}-${bar}`}
          className="w-1.5 rounded-full bg-gradient-to-t from-violet-500 to-fuchsia-400"
          variants={waveformBar}
          initial="initial"
          animate="animate"
          custom={index}
          style={{ height: `${bar}px` }}
        />
      ))}
    </div>
  );
}
