import { useVoiceStore } from '../stores/useVoiceStore';
import { formatBytes } from '../../../lib/utils';

export function VoiceStatusPanel() {
  const { activity, metrics, selectedInputDevice, selectedOutputDevice, isListening, isSpeaking } = useVoiceStore();
  return (
    <div className="grid gap-3 rounded-3xl border border-white/10 bg-white/5 p-4 shadow-glow">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm text-slate-400">Status</div>
          <div className="text-lg font-semibold capitalize">{activity.state}</div>
        </div>
        <div className="rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-slate-300">
          {isListening ? 'Mic On' : 'Mic Off'} · {isSpeaking ? 'TTS On' : 'TTS Off'}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-sm text-slate-300">
        <div className="rounded-2xl bg-black/20 p-3">Input level: {(metrics.inputLevel * 100).toFixed(0)}%</div>
        <div className="rounded-2xl bg-black/20 p-3">Output level: {(metrics.outputLevel * 100).toFixed(0)}%</div>
        <div className="rounded-2xl bg-black/20 p-3">Latency: {metrics.latency.toFixed(0)} ms</div>
        <div className="rounded-2xl bg-black/20 p-3">Noise: {(metrics.noiseLevel * 100).toFixed(0)}%</div>
      </div>
      <div className="text-xs text-slate-400">
        Input: {selectedInputDevice ?? 'default'} · Output: {selectedOutputDevice ?? 'default'}
      </div>
    </div>
  );
}
