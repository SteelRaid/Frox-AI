import { Mic, MicOff } from 'lucide-react';
import { cn } from '../../../lib/utils';

interface Props {
  active?: boolean;
  disabled?: boolean;
  onClick?: () => void;
}

export function MicrophoneButton({ active = false, disabled = false, onClick }: Props) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'inline-flex items-center justify-center rounded-2xl border px-4 py-3 text-sm font-medium transition',
        active
          ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-200'
          : 'border-white/10 bg-white/5 text-white hover:bg-white/10',
        disabled && 'cursor-not-allowed opacity-50'
      )}
      aria-label={active ? 'Stop listening' : 'Start listening'}
    >
      {active ? <MicOff className="mr-2 h-4 w-4" /> : <Mic className="mr-2 h-4 w-4" />}
      {active ? 'Listening' : 'Microphone'}
    </button>
  );
}
