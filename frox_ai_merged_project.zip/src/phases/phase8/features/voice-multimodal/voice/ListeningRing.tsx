import { motion } from 'framer-motion';

export function ListeningRing() {
  return (
    <motion.div
      className="h-20 w-20 rounded-full border border-emerald-400/30"
      animate={{ boxShadow: ['0 0 0 0 rgba(16,185,129,0.15)', '0 0 0 18px rgba(16,185,129,0)'] }}
      transition={{ duration: 2, repeat: Infinity }}
    />
  );
}
