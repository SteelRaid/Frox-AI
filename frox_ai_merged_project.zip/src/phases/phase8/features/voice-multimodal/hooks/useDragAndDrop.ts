import { useCallback, useState, type DragEvent as ReactDragEvent } from 'react';
import type { DragDropState } from '../types/attachment';

export function useDragAndDrop(onFiles: (files: File[]) => void) {
  const [state, setState] = useState<DragDropState>({ isDragging: false, isOver: false, types: [], count: 0, totalSize: 0 });

  const onDragEnter = useCallback((event: ReactDragEvent) => {
    event.preventDefault();
    const items = Array.from(event.dataTransfer.items || []);
    const files = items.filter((item) => item.kind === 'file');
    setState({
      isDragging: true,
      isOver: true,
      types: Array.from(new Set(files.map((f) => f.type || 'unknown'))),
      count: files.length,
      totalSize: 0,
    });
  }, []);

  const onDragLeave = useCallback((event: ReactDragEvent) => {
    event.preventDefault();
    setState((s) => ({ ...s, isOver: false }));
  }, []);

  const onDrop = useCallback((event: ReactDragEvent) => {
    event.preventDefault();
    const files = Array.from(event.dataTransfer.files || []);
    onFiles(files);
    setState({ isDragging: false, isOver: false, types: [], count: 0, totalSize: 0 });
  }, [onFiles]);

  return { state, onDragEnter, onDragLeave, onDrop };
}
