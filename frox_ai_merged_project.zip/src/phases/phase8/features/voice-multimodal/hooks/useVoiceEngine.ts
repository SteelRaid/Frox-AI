import { useEffect } from 'react';
import { voiceEngine } from '../services/voiceEngine';

export function useVoiceEngine() {
  useEffect(() => {
    void voiceEngine.initialize();
    return () => voiceEngine.destroy();
  }, []);
  return voiceEngine;
}
