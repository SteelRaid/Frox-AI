import { useEffect, useMemo, useState } from 'react';

export function useWaveform(level = 0) {
  const [bars, setBars] = useState<number[]>(Array.from({ length: 32 }, () => 8));

  useEffect(() => {
    setBars((prev) => prev.map((bar, index) => {
      const next = 8 + Math.round((Math.sin(Date.now() / 180 + index) + 1) * 0.5 * (12 + level * 30));
      return Math.max(4, Math.min(48, next));
    }));
  }, [level]);

  return useMemo(() => bars, [bars]);
}
