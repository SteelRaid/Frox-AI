import { useEffect, useState } from 'react';
import { liveConversationService } from '../services/liveConversationService';
import type { LiveConversation } from '../types/conversation';

export function useLiveConversation(conversationId?: string) {
  const [conversation, setConversation] = useState<LiveConversation | null>(conversationId ? liveConversationService.getConversation(conversationId) : null);

  useEffect(() => {
    if (!conversationId) return undefined;
    setConversation(liveConversationService.getConversation(conversationId));
    return liveConversationService.subscribe((updated) => {
      if (updated.id === conversationId) setConversation({ ...updated });
    });
  }, [conversationId]);

  return conversation;
}
