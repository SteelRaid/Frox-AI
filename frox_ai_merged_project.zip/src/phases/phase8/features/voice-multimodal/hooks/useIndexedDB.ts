import { useEffect, useState } from 'react';

type DBRecord = Record<string, unknown>;

export function useIndexedDB<T extends DBRecord>(storeName: string) {
  const [items, setItems] = useState<T[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(true);
  }, [storeName]);

  const add = async (item: T) => setItems((prev) => [...prev, item]);
  const clear = async () => setItems([]);

  return { items, ready, add, clear };
}
