import { useEffect } from 'react';
import { cameraEngine } from '../services/cameraEngine';

export function useCamera() {
  useEffect(() => () => cameraEngine.destroy(), []);
  return cameraEngine;
}
