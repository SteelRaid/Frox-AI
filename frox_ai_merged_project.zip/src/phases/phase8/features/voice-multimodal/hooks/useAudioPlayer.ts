import { useEffect } from 'react';
import { useAudioPlayerStore } from '../stores/useAudioPlayerStore';

export function useAudioPlayer() {
  const store = useAudioPlayerStore();
  useEffect(() => {
    if (store.audioElement) {
      const onEnded = () => store.setPlayerState('ended');
      const el = store.audioElement;
      el.addEventListener('ended', onEnded);
      return () => el.removeEventListener('ended', onEnded);
    }
    return undefined;
  }, [store.audioElement, store]);
  return store;
}
