import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { CameraDevice, CameraFacing, CameraSettings, CapturedImage, FlashMode, ImageTransform, ScanResult } from '../types/camera';

interface CameraState {
  devices: CameraDevice[];
  selectedDeviceId: string | null;
  settings: CameraSettings;
  isOpen: boolean;
  isReady: boolean;
  isCapturing: boolean;
  isScanning: boolean;
  stream: MediaStream | null;
  capturedImages: CapturedImage[];
  selectedImageId: string | null;
  scanResults: ScanResult[];
  activeTransform: ImageTransform;
  setDevices: (devices: CameraDevice[]) => void;
  selectDevice: (id: string) => void;
  setSettings: (settings: Partial<CameraSettings>) => void;
  setOpen: (value: boolean) => void;
  setReady: (value: boolean) => void;
  setCapturing: (value: boolean) => void;
  setScanning: (value: boolean) => void;
  setStream: (stream: MediaStream | null) => void;
  addCapturedImage: (image: CapturedImage) => void;
  removeCapturedImage: (id: string) => void;
  selectImage: (id: string | null) => void;
  addScanResult: (result: ScanResult) => void;
  clearScanResults: () => void;
  setTransform: (transform: Partial<ImageTransform>) => void;
  resetTransform: () => void;
  clearCaptured: () => void;
}

const defaultSettings: CameraSettings = {
  deviceId: '',
  facing: 'environment',
  flash: 'auto',
  focus: 'auto',
  zoom: 1,
  resolution: { width: 1920, height: 1080, label: '1080p' },
  frameRate: 30,
  mirror: false,
};

const defaultTransform: ImageTransform = {
  rotation: 0,
  flipX: false,
  flipY: false,
  scale: 1,
};

export const useCameraStore = create<CameraState>()(
  persist(
    (set, get) => ({
      devices: [],
      selectedDeviceId: null,
      settings: defaultSettings,
      isOpen: false,
      isReady: false,
      isCapturing: false,
      isScanning: false,
      stream: null,
      capturedImages: [],
      selectedImageId: null,
      scanResults: [],
      activeTransform: defaultTransform,
      setDevices: (devices) =>
        set({
          devices,
          selectedDeviceId: devices.find((d) => d.isDefault)?.id || devices[0]?.id || null,
        }),
      selectDevice: (id) => set({ selectedDeviceId: id }),
      setSettings: (settings) => set({ settings: { ...get().settings, ...settings } }),
      setOpen: (value) => set({ isOpen: value }),
      setReady: (value) => set({ isReady: value }),
      setCapturing: (value) => set({ isCapturing: value }),
      setScanning: (value) => set({ isScanning: value }),
      setStream: (stream) => set({ stream }),
      addCapturedImage: (image) =>
        set({
          capturedImages: [image, ...get().capturedImages],
          selectedImageId: image.id,
        }),
      removeCapturedImage: (id) =>
        set({
          capturedImages: get().capturedImages.filter((img) => img.id !== id),
          selectedImageId: get().selectedImageId === id ? null : get().selectedImageId,
        }),
      selectImage: (id) => set({ selectedImageId: id }),
      addScanResult: (result) => set({ scanResults: [...get().scanResults, result] }),
      clearScanResults: () => set({ scanResults: [] }),
      setTransform: (transform) => set({ activeTransform: { ...get().activeTransform, ...transform } }),
      resetTransform: () => set({ activeTransform: defaultTransform }),
      clearCaptured: () =>
        set({
          capturedImages: [],
          selectedImageId: null,
          scanResults: [],
          activeTransform: defaultTransform,
        }),
    }),
    {
      name: 'frox-camera-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        settings: state.settings,
        selectedDeviceId: state.selectedDeviceId,
      }),
    }
  )
);
