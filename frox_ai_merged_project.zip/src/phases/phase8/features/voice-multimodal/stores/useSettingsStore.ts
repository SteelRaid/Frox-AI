import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { AccessibilitySettings, CameraSettings, MultimodalSettings, PerformanceSettings, VoiceSettings } from '../types/settings';

interface SettingsState {
  settings: MultimodalSettings;
  isHydrated: boolean;
  updateVoiceSettings: (settings: Partial<VoiceSettings>) => void;
  updateCameraSettings: (settings: Partial<CameraSettings>) => void;
  updateAccessibilitySettings: (settings: Partial<AccessibilitySettings>) => void;
  updatePerformanceSettings: (settings: Partial<PerformanceSettings>) => void;
  updateSettings: (settings: Partial<MultimodalSettings>) => void;
  resetSettings: () => void;
  setHydrated: () => void;
}

const defaultSettings: MultimodalSettings = {
  voice: {
    enabled: true,
    profileId: 'default-en',
    language: 'en',
    speed: 1,
    pitch: 1,
    volume: 1,
    autoPlay: false,
    pushToTalk: false,
    pushToTalkKey: 'Space',
    alwaysListen: false,
    wakeWord: 'Hey Frox',
    wakeWordEnabled: false,
    interruptEnabled: true,
    noiseSuppression: {
      enabled: true,
      strength: 'adaptive',
    },
    echoCancellation: {
      enabled: true,
      algorithm: 'webrtc',
    },
  },
  camera: {
    enabled: true,
    resolution: 'high',
    frameRate: 30,
    flash: 'auto',
    mirror: true,
    autoFocus: true,
    saveToGallery: false,
  },
  accessibility: {
    reducedMotion: false,
    highContrast: false,
    largeText: false,
    screenReaderOptimized: false,
    keyboardShortcuts: true,
    autoDescribeImages: false,
  },
  performance: {
    lazyLoadMedia: true,
    cacheStrategy: 'indexeddb',
    maxCacheSize: 500 * 1024 * 1024,
    streamBufferSize: 4096,
    imageQuality: 'high',
    videoQuality: 'high',
  },
  maxAttachmentSize: 50 * 1024 * 1024,
  allowedAttachmentTypes: [
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
    'video/mp4',
    'video/webm',
    'audio/mp3',
    'audio/wav',
    'audio/ogg',
    'application/pdf',
    'text/plain',
    'text/markdown',
    'application/json',
    'text/javascript',
    'text/typescript',
    'text/html',
    'text/css',
    'application/zip',
  ],
  defaultConversationMode: 'multimodal',
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      settings: defaultSettings,
      isHydrated: false,
      updateVoiceSettings: (voiceSettings) =>
        set({
          settings: {
            ...get().settings,
            voice: { ...get().settings.voice, ...voiceSettings },
          },
        }),
      updateCameraSettings: (cameraSettings) =>
        set({
          settings: {
            ...get().settings,
            camera: { ...get().settings.camera, ...cameraSettings },
          },
        }),
      updateAccessibilitySettings: (accessibilitySettings) =>
        set({
          settings: {
            ...get().settings,
            accessibility: { ...get().settings.accessibility, ...accessibilitySettings },
          },
        }),
      updatePerformanceSettings: (performanceSettings) =>
        set({
          settings: {
            ...get().settings,
            performance: { ...get().settings.performance, ...performanceSettings },
          },
        }),
      updateSettings: (newSettings) => set({ settings: { ...get().settings, ...newSettings } }),
      resetSettings: () => set({ settings: defaultSettings }),
      setHydrated: () => set({ isHydrated: true }),
    }),
    {
      name: 'frox-multimodal-settings',
      storage: createJSONStorage(() => localStorage),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
    }
  )
);
