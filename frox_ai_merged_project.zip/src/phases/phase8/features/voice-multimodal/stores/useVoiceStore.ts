import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { AudioDevice, NoiseSuppressionOptions, EchoCancellationOptions, VoiceActivity, VoiceActivityState, VoiceHistoryEntry, VoiceMetrics, VoiceProfile, VoiceQueueItem } from '../types/voice';
import { createId } from '../../../lib/utils';

interface VoiceState {
  profiles: VoiceProfile[];
  activeProfile: VoiceProfile | null;
  defaultProfileId: string | null;
  activity: VoiceActivity;
  metrics: VoiceMetrics;
  inputDevices: AudioDevice[];
  outputDevices: AudioDevice[];
  selectedInputDevice: string | null;
  selectedOutputDevice: string | null;
  queue: VoiceQueueItem[];
  history: VoiceHistoryEntry[];
  noiseSuppression: NoiseSuppressionOptions;
  echoCancellation: EchoCancellationOptions;
  isListening: boolean;
  isSpeaking: boolean;
  isPushToTalkActive: boolean;
  isAlwaysListening: boolean;
  wakeWordEnabled: boolean;
  wakeWord: string;
  interruptEnabled: boolean;
  audioContext: AudioContext | null;
  analyserNode: AnalyserNode | null;
  setActivity: (state: VoiceActivityState, confidence?: number) => void;
  setMetrics: (metrics: Partial<VoiceMetrics>) => void;
  setActiveProfile: (profile: VoiceProfile | null) => void;
  addProfile: (profile: VoiceProfile) => void;
  updateProfile: (id: string, updates: Partial<VoiceProfile>) => void;
  deleteProfile: (id: string) => void;
  setDevices: (inputs: AudioDevice[], outputs: AudioDevice[]) => void;
  selectInputDevice: (id: string) => void;
  selectOutputDevice: (id: string) => void;
  enqueue: (item: VoiceQueueItem) => void;
  dequeue: () => VoiceQueueItem | undefined;
  clearQueue: () => void;
  addHistory: (entry: VoiceHistoryEntry) => void;
  setListening: (value: boolean) => void;
  setSpeaking: (value: boolean) => void;
  setPushToTalk: (value: boolean) => void;
  setAudioContext: (ctx: AudioContext | null) => void;
  setAnalyserNode: (node: AnalyserNode | null) => void;
  setNoiseSuppression: (opts: Partial<NoiseSuppressionOptions>) => void;
  setEchoCancellation: (opts: Partial<EchoCancellationOptions>) => void;
  reset: () => void;
}

const defaultProfile: VoiceProfile = {
  id: 'default-en',
  name: 'Default English',
  gender: 'neutral',
  age: 'adult',
  emotion: 'neutral',
  language: 'en',
  locale: 'en-US',
  pitch: 1,
  speed: 1,
  volume: 1,
  sampleRate: 24000,
  isDefault: true,
  isCustom: false,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

const initialActivity: VoiceActivity = { state: 'idle', confidence: 0, timestamp: Date.now() };
const initialMetrics: VoiceMetrics = { inputLevel: 0, outputLevel: 0, noiseLevel: 0, clippingDetected: false, latency: 0 };
const initialNoiseSuppression: NoiseSuppressionOptions = { enabled: true, strength: 'adaptive', sampleRate: 48000 };
const initialEchoCancellation: EchoCancellationOptions = { enabled: true, algorithm: 'webrtc', delayMs: 0 };

const createAudioDevice = (id: string, kind: 'audioinput' | 'audiooutput', label: string): AudioDevice => ({
  id,
  label,
  kind,
  groupId: '',
  isDefault: true,
});

export const useVoiceStore = create<VoiceState>()(
  persist(
    (set, get) => ({
      profiles: [defaultProfile],
      activeProfile: defaultProfile,
      defaultProfileId: defaultProfile.id,
      activity: initialActivity,
      metrics: initialMetrics,
      inputDevices: [],
      outputDevices: [],
      selectedInputDevice: null,
      selectedOutputDevice: null,
      queue: [],
      history: [],
      noiseSuppression: initialNoiseSuppression,
      echoCancellation: initialEchoCancellation,
      isListening: false,
      isSpeaking: false,
      isPushToTalkActive: false,
      isAlwaysListening: false,
      wakeWordEnabled: false,
      wakeWord: 'Hey Frox',
      interruptEnabled: true,
      audioContext: null,
      analyserNode: null,
      setActivity: (state, confidence = 0) =>
        set({
          activity: {
            state,
            confidence,
            timestamp: Date.now(),
            duration: state !== 'idle' ? Date.now() - get().activity.timestamp : undefined,
          },
        }),
      setMetrics: (metrics) => set({ metrics: { ...get().metrics, ...metrics } }),
      setActiveProfile: (profile) => set({ activeProfile: profile }),
      addProfile: (profile) => set({ profiles: [...get().profiles, profile] }),
      updateProfile: (id, updates) =>
        set({
          profiles: get().profiles.map((p) =>
            p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
          ),
        }),
      deleteProfile: (id) =>
        set({
          profiles: get().profiles.filter((p) => p.id !== id),
          activeProfile: get().activeProfile?.id === id ? get().profiles[0] || null : get().activeProfile,
        }),
      setDevices: (inputs, outputs) =>
        set({
          inputDevices: inputs,
          outputDevices: outputs,
          selectedInputDevice: inputs.find((d) => d.isDefault)?.id || inputs[0]?.id || null,
          selectedOutputDevice: outputs.find((d) => d.isDefault)?.id || outputs[0]?.id || null,
        }),
      selectInputDevice: (id) => set({ selectedInputDevice: id }),
      selectOutputDevice: (id) => set({ selectedOutputDevice: id }),
      enqueue: (item) => set({ queue: [...get().queue, item].sort((a, b) => b.priority - a.priority) }),
      dequeue: () => {
        const queue = get().queue;
        if (queue.length === 0) return undefined;
        const [first, ...rest] = queue;
        set({ queue: rest });
        return first;
      },
      clearQueue: () => set({ queue: [] }),
      addHistory: (entry) => set({ history: [entry, ...get().history].slice(0, 1000) }),
      setListening: (value) => set({ isListening: value }),
      setSpeaking: (value) => set({ isSpeaking: value }),
      setPushToTalk: (value) => set({ isPushToTalkActive: value }),
      setAudioContext: (ctx) => set({ audioContext: ctx }),
      setAnalyserNode: (node) => set({ analyserNode: node }),
      setNoiseSuppression: (opts) => set({ noiseSuppression: { ...get().noiseSuppression, ...opts } }),
      setEchoCancellation: (opts) => set({ echoCancellation: { ...get().echoCancellation, ...opts } }),
      reset: () =>
        set({
          activity: initialActivity,
          metrics: initialMetrics,
          queue: [],
          isListening: false,
          isSpeaking: false,
          isPushToTalkActive: false,
        }),
    }),
    {
      name: 'frox-voice-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        profiles: state.profiles,
        activeProfile: state.activeProfile,
        defaultProfileId: state.defaultProfileId,
        selectedInputDevice: state.selectedInputDevice,
        selectedOutputDevice: state.selectedOutputDevice,
        noiseSuppression: state.noiseSuppression,
        echoCancellation: state.echoCancellation,
        wakeWordEnabled: state.wakeWordEnabled,
        wakeWord: state.wakeWord,
        interruptEnabled: state.interruptEnabled,
        isAlwaysListening: state.isAlwaysListening,
      }),
    }
  )
);

export const voiceStoreDefaults = {
  defaultProfile,
  initialActivity,
  initialMetrics,
  initialNoiseSuppression,
  initialEchoCancellation,
  createAudioDevice,
};
