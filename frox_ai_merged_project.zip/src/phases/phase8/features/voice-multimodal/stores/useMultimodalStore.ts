import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { createId } from '../../../lib/utils';
import type { Attachment, AttachmentType, ConversationSettings, MultimodalConversation, MultimodalMessage } from '../types/multimodal';

interface MultimodalState {
  conversations: MultimodalConversation[];
  activeConversationId: string | null;
  isStreaming: boolean;
  isUploading: boolean;
  uploadProgress: Record<string, number>;
  attachments: Attachment[];
  draftAttachments: Attachment[];
  messageQueue: MultimodalMessage[];
  setActiveConversation: (id: string | null) => void;
  createConversation: (mode?: 'text' | 'voice' | 'multimodal') => MultimodalConversation;
  deleteConversation: (id: string) => void;
  addMessage: (conversationId: string, message: MultimodalMessage) => void;
  updateMessage: (conversationId: string, messageId: string, updates: Partial<MultimodalMessage>) => void;
  deleteMessage: (conversationId: string, messageId: string) => void;
  setStreaming: (value: boolean) => void;
  addAttachment: (attachment: Attachment) => void;
  removeAttachment: (id: string) => void;
  setDraftAttachments: (attachments: Attachment[]) => void;
  updateUploadProgress: (fileId: string, progress: number) => void;
  updateConversationSettings: (conversationId: string, settings: Partial<ConversationSettings>) => void;
  clearUploadProgress: () => void;
  getActiveConversation: () => MultimodalConversation | null;
  getMessages: (conversationId: string) => MultimodalMessage[];
  getAttachments: (messageId: string) => Attachment[];
}

const defaultSettings: ConversationSettings = {
  voiceEnabled: false,
  autoPlay: false,
  pushToTalk: false,
  alwaysListen: false,
  language: 'en',
  noiseSuppression: true,
  echoCancellation: true,
  interruptEnabled: true,
  maxAttachmentSize: 50 * 1024 * 1024,
  allowedTypes: ['image', 'video', 'audio', 'document', 'code', 'archive'],
};

const createConversationId = () => `conv_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

export const useMultimodalStore = create<MultimodalState>()(
  persist(
    (set, get) => ({
      conversations: [],
      activeConversationId: null,
      isStreaming: false,
      isUploading: false,
      uploadProgress: {},
      attachments: [],
      draftAttachments: [],
      messageQueue: [],
      setActiveConversation: (id) => set({ activeConversationId: id }),
      createConversation: (mode = 'multimodal') => {
        const conversation: MultimodalConversation = {
          id: createConversationId(),
          title: 'New Conversation',
          mode,
          messages: [],
          participants: ['user', 'assistant'],
          settings: { ...defaultSettings },
          tokenCount: 0,
          messageCount: 0,
          lastMessageAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set({
          conversations: [conversation, ...get().conversations],
          activeConversationId: conversation.id,
        });
        return conversation;
      },
      deleteConversation: (id) =>
        set({
          conversations: get().conversations.filter((c) => c.id !== id),
          activeConversationId: get().activeConversationId === id ? null : get().activeConversationId,
        }),
      addMessage: (conversationId, message) =>
        set({
          conversations: get().conversations.map((c) =>
            c.id === conversationId
              ? {
                  ...c,
                  messages: [...c.messages, message],
                  messageCount: c.messageCount + 1,
                  lastMessageAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                }
              : c
          ),
        }),
      updateMessage: (conversationId, messageId, updates) =>
        set({
          conversations: get().conversations.map((c) =>
            c.id === conversationId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === messageId ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m
                  ),
                  updatedAt: new Date().toISOString(),
                }
              : c
          ),
        }),
      deleteMessage: (conversationId, messageId) =>
        set({
          conversations: get().conversations.map((c) =>
            c.id === conversationId
              ? {
                  ...c,
                  messages: c.messages.filter((m) => m.id !== messageId),
                  messageCount: Math.max(0, c.messageCount - 1),
                  updatedAt: new Date().toISOString(),
                }
              : c
          ),
        }),
      setStreaming: (value) => set({ isStreaming: value }),
      addAttachment: (attachment) => set({ attachments: [...get().attachments, attachment] }),
      removeAttachment: (id) =>
        set({
          attachments: get().attachments.filter((a) => a.id !== id),
          draftAttachments: get().draftAttachments.filter((a) => a.id !== id),
        }),
      setDraftAttachments: (attachments) => set({ draftAttachments: attachments }),
      updateUploadProgress: (fileId, progress) => set({ uploadProgress: { ...get().uploadProgress, [fileId]: progress } }),
      updateConversationSettings: (conversationId, settings) =>
        set({
          conversations: get().conversations.map((c) =>
            c.id === conversationId ? { ...c, settings: { ...c.settings, ...settings } } : c
          ),
        }),
      clearUploadProgress: () => set({ uploadProgress: {} }),
      getActiveConversation: () => get().conversations.find((c) => c.id === get().activeConversationId) || null,
      getMessages: (conversationId) => get().conversations.find((c) => c.id === conversationId)?.messages || [],
      getAttachments: (messageId) => get().attachments.filter((a) => a.messageId === messageId),
    }),
    {
      name: 'frox-multimodal-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        conversations: state.conversations,
        activeConversationId: state.activeConversationId,
      }),
    }
  )
);
