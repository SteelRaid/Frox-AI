import { create } from 'zustand';
import type { AudioFile, AudioPlayerState, AudioPlayerTrack } from '../types/audio';

interface AudioPlayerStateStore {
  currentTrack: AudioPlayerTrack | null;
  playerState: AudioPlayerState;
  currentTime: number;
  duration: number;
  volume: number;
  playbackSpeed: number;
  isLooping: boolean;
  queue: AudioFile[];
  queueIndex: number;
  recentlyPlayed: AudioFile[];
  audioElement: HTMLAudioElement | null;
  loadTrack: (file: AudioFile, autoPlay?: boolean) => void;
  play: () => void;
  pause: () => void;
  toggle: () => void;
  stop: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  setPlaybackSpeed: (speed: number) => void;
  setLooping: (value: boolean) => void;
  skipNext: () => void;
  skipPrevious: () => void;
  addToQueue: (file: AudioFile) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
  setAudioElement: (element: HTMLAudioElement | null) => void;
  updateTime: (time: number) => void;
  updateDuration: (duration: number) => void;
  setPlayerState: (state: AudioPlayerState) => void;
  addToHistory: (file: AudioFile) => void;
}

export const useAudioPlayerStore = create<AudioPlayerStateStore>((set, get) => ({
  currentTrack: null,
  playerState: 'idle',
  currentTime: 0,
  duration: 0,
  volume: 1,
  playbackSpeed: 1,
  isLooping: false,
  queue: [],
  queueIndex: 0,
  recentlyPlayed: [],
  audioElement: null,
  loadTrack: (file, autoPlay = true) => {
    const track: AudioPlayerTrack = {
      id: `track_${Date.now()}`,
      audioFile: file,
      startTime: 0,
      endTime: file.duration,
      playbackSpeed: get().playbackSpeed,
      volume: get().volume,
      isLooping: get().isLooping,
    };
    set({
      currentTrack: track,
      duration: file.duration,
      currentTime: 0,
      playerState: autoPlay ? 'loading' : 'idle',
    });
    if (autoPlay) {
      get().audioElement?.play().catch(() => set({ playerState: 'error' }));
    }
  },
  play: () => {
    get().audioElement?.play().then(() => set({ playerState: 'playing' })).catch(() => set({ playerState: 'error' }));
  },
  pause: () => {
    get().audioElement?.pause();
    set({ playerState: 'paused' });
  },
  toggle: () => {
    const state = get().playerState;
    state === 'playing' ? get().pause() : get().play();
  },
  stop: () => {
    get().audioElement?.pause();
    if (get().audioElement) get().audioElement.currentTime = 0;
    set({ playerState: 'idle', currentTime: 0 });
  },
  seek: (time) => {
    if (get().audioElement) {
      get().audioElement.currentTime = Math.max(0, Math.min(time, get().duration));
    }
    set({ currentTime: time });
  },
  setVolume: (volume) => {
    const clamped = Math.max(0, Math.min(1, volume));
    if (get().audioElement) get().audioElement.volume = clamped;
    set({ volume: clamped });
  },
  setPlaybackSpeed: (speed) => {
    const clamped = Math.max(0.25, Math.min(4, speed));
    if (get().audioElement) get().audioElement.playbackRate = clamped;
    set({ playbackSpeed: clamped });
    if (get().currentTrack) set({ currentTrack: { ...get().currentTrack!, playbackSpeed: clamped } });
  },
  setLooping: (value) => {
    if (get().audioElement) get().audioElement.loop = value;
    set({ isLooping: value });
  },
  skipNext: () => {
    const { queue, queueIndex } = get();
    if (queueIndex < queue.length - 1) {
      const nextIndex = queueIndex + 1;
      set({ queueIndex: nextIndex });
      get().loadTrack(queue[nextIndex]);
    }
  },
  skipPrevious: () => {
    const { queue, queueIndex } = get();
    if (queueIndex > 0) {
      const prevIndex = queueIndex - 1;
      set({ queueIndex: prevIndex });
      get().loadTrack(queue[prevIndex]);
    }
  },
  addToQueue: (file) => set({ queue: [...get().queue, file] }),
  removeFromQueue: (index) =>
    set({
      queue: get().queue.filter((_, i) => i !== index),
      queueIndex: get().queueIndex > index ? get().queueIndex - 1 : get().queueIndex,
    }),
  clearQueue: () => set({ queue: [], queueIndex: 0 }),
  setAudioElement: (element) => set({ audioElement: element }),
  updateTime: (time) => set({ currentTime: time }),
  updateDuration: (duration) => set({ duration }),
  setPlayerState: (state) => set({ playerState: state }),
  addToHistory: (file) =>
    set({
      recentlyPlayed: [file, ...get().recentlyPlayed.filter((f) => f.id !== file.id)].slice(0, 50),
    }),
}));
