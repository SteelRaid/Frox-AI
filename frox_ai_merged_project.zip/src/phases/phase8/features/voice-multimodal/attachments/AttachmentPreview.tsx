import { File, Image, Music, Video } from 'lucide-react';
import { formatBytes } from '../../../lib/utils';
import type { Attachment } from '../types/multimodal';

interface Props {
  attachment: Attachment;
}

export function AttachmentPreview({ attachment }: Props) {
  const icon = attachment.type === 'image' ? <Image className="h-4 w-4" /> : attachment.type === 'video' ? <Video className="h-4 w-4" /> : attachment.type === 'audio' ? <Music className="h-4 w-4" /> : <File className="h-4 w-4" />;
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/20 p-3 text-sm">
      <div className="rounded-xl bg-white/5 p-2">{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="truncate font-medium">{attachment.name}</div>
        <div className="text-xs text-slate-400">{formatBytes(attachment.size)} · {attachment.status}</div>
      </div>
    </div>
  );
}
