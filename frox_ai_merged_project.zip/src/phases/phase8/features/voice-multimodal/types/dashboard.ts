export type TimeRange = 'today' | 'week' | 'month' | 'year' | 'all';

export interface TimeSeriesData {
  date: string;
  value: number;
  label?: string;
}

export interface DistributionData {
  label: string;
  value: number;
  percentage: number;
  color: string;
}

export interface ProfileUsage {
  profileId: string;
  profileName: string;
  usageCount: number;
  totalDuration: number;
  percentage: number;
}

export interface ActivityItem {
  id: string;
  type: 'conversation' | 'upload' | 'voice' | 'camera' | 'attachment';
  title: string;
  description: string;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

export interface VoiceDashboardStats {
  totalConversations: number;
  totalMessages: number;
  totalVoiceDuration: number;
  totalAudioFiles: number;
  avgConversationLength: number;
  avgResponseTime: number;
  voiceUsageByDay: TimeSeriesData[];
  messageDistribution: DistributionData[];
  topVoiceProfiles: ProfileUsage[];
  recentActivity: ActivityItem[];
}

export interface StorageUsage {
  total: number;
  used: number;
  available: number;
  byType: Record<string, number>;
  history: TimeSeriesData[];
}

export interface SearchFilters {
  types: string[];
  dateRange?: { from: string; to: string };
  participants?: string[];
  hasAttachments?: boolean;
  query?: string;
}

export interface SearchResult {
  id: string;
  type: 'conversation' | 'message' | 'attachment' | 'voice' | 'image' | 'document';
  title: string;
  snippet: string;
  relevance: number;
  timestamp: string;
  url?: string;
  thumbnailUrl?: string;
}
