export type MessageType = 'text' | 'voice' | 'image' | 'video' | 'audio' | 'document' | 'code' | 'markdown' | 'camera' | 'clipboard';
export type AttachmentStatus = 'pending' | 'uploading' | 'processing' | 'ready' | 'error' | 'removed';

export interface MessageMetadata {
  tokens?: number;
  model?: string;
  latency?: number;
  processingTime?: number;
  confidence?: number;
  language?: string;
  voiceProfileId?: string;
  audioDuration?: number;
  imageDimensions?: { width: number; height: number };
  documentPages?: number;
  isStreaming?: boolean;
  isInterrupted?: boolean;
}

export interface MessageEdit {
  content: string;
  editedAt: string;
  reason?: string;
}

export interface AttachmentMetadata {
  width?: number;
  height?: number;
  duration?: number;
  pages?: number;
  encoding?: string;
  bitrate?: number;
  fps?: number;
  exif?: Record<string, unknown>;
  ocrText?: string;
  extractedText?: string;
  checksum: string;
}

export type AttachmentType = 'image' | 'video' | 'audio' | 'document' | 'code' | 'archive' | 'unknown';

export interface Attachment {
  id: string;
  messageId: string;
  type: AttachmentType;
  name: string;
  size: number;
  mimeType: string;
  url: string;
  thumbnailUrl?: string;
  previewUrl?: string;
  status: AttachmentStatus;
  progress: number;
  metadata: AttachmentMetadata;
  createdAt: string;
}

export interface MultimodalMessage {
  id: string;
  conversationId: string;
  type: MessageType;
  role: 'user' | 'assistant' | 'system';
  content: string;
  attachments: Attachment[];
  metadata: MessageMetadata;
  parentId?: string;
  editHistory?: MessageEdit[];
  createdAt: string;
  updatedAt: string;
}

export interface ConversationSettings {
  voiceEnabled: boolean;
  autoPlay: boolean;
  pushToTalk: boolean;
  alwaysListen: boolean;
  voiceProfileId?: string;
  language: string;
  noiseSuppression: boolean;
  echoCancellation: boolean;
  interruptEnabled: boolean;
  maxAttachmentSize: number;
  allowedTypes: AttachmentType[];
}

export interface MultimodalConversation {
  id: string;
  title: string;
  mode: 'text' | 'voice' | 'multimodal';
  messages: MultimodalMessage[];
  participants: string[];
  settings: ConversationSettings;
  summary?: string;
  tokenCount: number;
  messageCount: number;
  lastMessageAt: string;
  createdAt: string;
  updatedAt: string;
}
