export type CameraFacing = 'user' | 'environment';
export type FlashMode = 'auto' | 'on' | 'off' | 'torch';
export type FocusMode = 'auto' | 'continuous' | 'manual';

export interface CameraResolution {
  width: number;
  height: number;
  label: string;
}

export interface CameraDevice {
  id: string;
  label: string;
  facing: CameraFacing;
  capabilities: MediaTrackCapabilities;
  isDefault: boolean;
}

export interface CameraSettings {
  deviceId: string;
  facing: CameraFacing;
  flash: FlashMode;
  focus: FocusMode;
  zoom: number;
  resolution: CameraResolution;
  frameRate: number;
  mirror: boolean;
}

export interface ImageMetadata {
  iso?: number;
  exposure?: number;
  aperture?: string;
  focalLength?: number;
  gps?: { lat: number; lng: number };
  orientation: number;
}

export interface CapturedImage {
  id: string;
  dataUrl: string;
  blob: Blob;
  width: number;
  height: number;
  timestamp: number;
  deviceId: string;
  settings: CameraSettings;
  metadata: ImageMetadata;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ScanResult {
  id: string;
  type: 'document' | 'barcode' | 'qrcode' | 'ocr';
  imageId: string;
  confidence: number;
  data: string;
  boundingBox?: BoundingBox;
  rawData?: unknown;
}

export interface CropRegion {
  x: number;
  y: number;
  width: number;
  height: number;
  aspectRatio?: number;
}

export interface ImageTransform {
  rotation: number;
  flipX: boolean;
  flipY: boolean;
  scale: number;
  crop?: CropRegion;
}
