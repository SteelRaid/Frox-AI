export type UploadStrategy = 'direct' | 'chunked' | 'resumable' | 'multipart';

export interface CompressionConfig {
  enabled: boolean;
  maxWidth?: number;
  maxHeight?: number;
  quality: number;
  maxDuration?: number;
  targetBitrate?: number;
}

export interface UploadConfig {
  maxFileSize: number;
  maxTotalSize: number;
  maxFiles: number;
  allowedTypes: string[];
  chunkSize: number;
  concurrentUploads: number;
  retryAttempts: number;
  retryDelay: number;
  strategy: UploadStrategy;
  compression: CompressionConfig;
}

export interface UploadProgress {
  fileId: string;
  loaded: number;
  total: number;
  percentage: number;
  speed: number;
  eta: number;
  stage: 'compressing' | 'uploading' | 'processing' | 'verifying' | 'complete';
}

export interface FileValidationResult {
  valid: boolean;
  file: File;
  errors: string[];
  warnings: string[];
  compressed?: File;
}

export interface DragDropState {
  isDragging: boolean;
  isOver: boolean;
  types: string[];
  count: number;
  totalSize: number;
}

export interface ClipboardItem {
  type: string;
  data: Blob | string;
  kind: 'file' | 'string';
}

export interface ClipboardData {
  items: ClipboardItem[];
  types: string[];
  hasImage: boolean;
  hasText: boolean;
  hasFiles: boolean;
}
