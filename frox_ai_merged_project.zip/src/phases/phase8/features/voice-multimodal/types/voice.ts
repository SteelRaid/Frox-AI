export type VoiceGender = 'male' | 'female' | 'neutral';
export type VoiceAge = 'child' | 'young' | 'adult' | 'senior';
export type VoiceEmotion = 'neutral' | 'happy' | 'sad' | 'excited' | 'calm' | 'serious';

export interface VoiceProfile {
  id: string;
  name: string;
  gender: VoiceGender;
  age: VoiceAge;
  emotion: VoiceEmotion;
  language: string;
  locale: string;
  pitch: number;
  speed: number;
  volume: number;
  sampleRate: number;
  previewUrl?: string;
  isDefault: boolean;
  isCustom: boolean;
  createdAt: string;
  updatedAt: string;
}

export type VoiceActivityState = 'idle' | 'listening' | 'processing' | 'speaking' | 'thinking' | 'interrupted' | 'error';

export interface VoiceActivity {
  state: VoiceActivityState;
  confidence: number;
  timestamp: number;
  duration?: number;
}

export interface VoiceCommand {
  id: string;
  trigger: string | RegExp;
  action: string;
  description: string;
  isEnabled: boolean;
  requiresConfirmation: boolean;
}

export interface VoiceTranscript {
  id: string;
  text: string;
  isFinal: boolean;
  confidence: number;
  timestamp: number;
  speaker: 'user' | 'ai';
  words?: TranscriptWord[];
}

export interface TranscriptWord {
  word: string;
  startTime: number;
  endTime: number;
  confidence: number;
}

export interface VoiceMetrics {
  inputLevel: number;
  outputLevel: number;
  noiseLevel: number;
  clippingDetected: boolean;
  latency: number;
}

export interface AudioDevice {
  id: string;
  label: string;
  kind: 'audioinput' | 'audiooutput';
  groupId: string;
  isDefault: boolean;
}

export interface VoiceQueueItem {
  id: string;
  text: string;
  profile: VoiceProfile;
  priority: number;
  metadata?: Record<string, unknown>;
}

export interface VoiceHistoryEntry {
  id: string;
  type: 'transcript' | 'synthesis' | 'command';
  content: string;
  duration: number;
  timestamp: number;
  profileId?: string;
}

export interface NoiseSuppressionOptions {
  enabled: boolean;
  strength: 'low' | 'medium' | 'high' | 'adaptive';
  sampleRate: number;
}

export interface EchoCancellationOptions {
  enabled: boolean;
  algorithm: 'speex' | 'webrtc' | 'adaptive';
  delayMs: number;
}
