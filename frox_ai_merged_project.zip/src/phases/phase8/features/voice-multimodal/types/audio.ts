export type AudioPlayerState = 'idle' | 'loading' | 'playing' | 'paused' | 'ended' | 'error';
export type AudioVisualizationType = 'waveform' | 'spectrum' | 'bars' | 'circle' | 'line';

export interface AudioMetadata {
  title?: string;
  artist?: string;
  album?: string;
  genre?: string;
  year?: number;
  track?: number;
  composer?: string;
  lyrics?: string;
  coverArt?: string;
}

export interface AudioFile {
  id: string;
  name: string;
  url: string;
  blob?: Blob;
  duration: number;
  sampleRate: number;
  channels: number;
  bitrate: number;
  format: string;
  size: number;
  waveformData?: number[];
  metadata: AudioMetadata;
  createdAt: string;
}

export interface AudioPlayerTrack {
  id: string;
  audioFile: AudioFile;
  startTime: number;
  endTime: number;
  playbackSpeed: number;
  volume: number;
  isLooping: boolean;
}

export interface AudioVisualizationConfig {
  type: AudioVisualizationType;
  fftSize: number;
  smoothingTimeConstant: number;
  minDecibels: number;
  maxDecibels: number;
  barCount: number;
  colorStart: string;
  colorEnd: string;
  mirror: boolean;
}

export interface WaveformData {
  id: string;
  audioId: string;
  data: Float32Array;
  duration: number;
  sampleRate: number;
  peaksPerSecond: number;
  generatedAt: string;
}

export interface AudioEffect {
  id: string;
  type: 'reverb' | 'delay' | 'compressor' | 'eq' | 'noise_gate' | 'limiter';
  params: Record<string, number>;
  isEnabled: boolean;
  wetDry: number;
}
