import type { FlashMode } from './camera';
import type { NoiseSuppressionOptions, EchoCancellationOptions } from './voice';

export interface VoiceSettings {
  enabled: boolean;
  profileId: string;
  language: string;
  speed: number;
  pitch: number;
  volume: number;
  autoPlay: boolean;
  pushToTalk: boolean;
  pushToTalkKey: string;
  alwaysListen: boolean;
  wakeWord: string;
  wakeWordEnabled: boolean;
  interruptEnabled: boolean;
  noiseSuppression: NoiseSuppressionSettings;
  echoCancellation: EchoCancellationSettings;
  inputDeviceId?: string;
  outputDeviceId?: string;
}

export interface NoiseSuppressionSettings {
  enabled: boolean;
  strength: 'low' | 'medium' | 'high' | 'adaptive';
}

export interface EchoCancellationSettings {
  enabled: boolean;
  algorithm: 'webrtc' | 'speex';
}

export interface CameraSettings {
  enabled: boolean;
  deviceId?: string;
  resolution: 'low' | 'medium' | 'high' | 'max';
  frameRate: number;
  flash: FlashMode;
  mirror: boolean;
  autoFocus: boolean;
  saveToGallery: boolean;
}

export interface AccessibilitySettings {
  reducedMotion: boolean;
  highContrast: boolean;
  largeText: boolean;
  screenReaderOptimized: boolean;
  keyboardShortcuts: boolean;
  autoDescribeImages: boolean;
}

export interface PerformanceSettings {
  lazyLoadMedia: boolean;
  cacheStrategy: 'memory' | 'indexeddb' | 'none';
  maxCacheSize: number;
  streamBufferSize: number;
  imageQuality: 'low' | 'medium' | 'high' | 'original';
  videoQuality: 'low' | 'medium' | 'high' | 'original';
}

export interface MultimodalSettings {
  voice: VoiceSettings;
  camera: CameraSettings;
  accessibility: AccessibilitySettings;
  performance: PerformanceSettings;
  maxAttachmentSize: number;
  allowedAttachmentTypes: string[];
  defaultConversationMode: 'text' | 'voice' | 'multimodal';
}
