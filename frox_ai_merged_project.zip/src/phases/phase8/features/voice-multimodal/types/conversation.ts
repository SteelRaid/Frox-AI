export type ConversationMode = 'text' | 'voice' | 'multimodal' | 'live';
export type StreamingState = 'idle' | 'connecting' | 'streaming' | 'buffering' | 'completed' | 'interrupted' | 'error';

export interface Participant {
  id: string;
  name: string;
  avatar?: string;
  isAI: boolean;
  isMuted: boolean;
  isSpeaking: boolean;
  isVideoOn: boolean;
  isScreenSharing: boolean;
  joinedAt: string;
  leftAt?: string;
}

export interface StreamMessage {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  type: 'text' | 'audio' | 'image' | 'video' | 'action';
  content: string;
  isPartial: boolean;
  timestamp: number;
  latency: number;
  confidence?: number;
}

export interface ConversationMetrics {
  totalLatency: number;
  messageCount: number;
  audioDuration: number;
  videoDuration: number;
  tokenCount: number;
  interruptCount: number;
  errorCount: number;
  avgResponseTime: number;
}

export interface RecordingInfo {
  isRecording: boolean;
  audioBlob?: Blob;
  videoBlob?: Blob;
  startedAt: string;
  duration: number;
  size: number;
}

export interface LiveConversation {
  id: string;
  mode: ConversationMode;
  state: StreamingState;
  participants: Participant[];
  messages: StreamMessage[];
  audioStream?: MediaStream;
  videoStream?: MediaStream;
  screenStream?: MediaStream;
  startedAt: string;
  endedAt?: string;
  duration: number;
  metrics: ConversationMetrics;
  recording?: RecordingInfo;
}

export interface ConversationExport {
  format: 'json' | 'markdown' | 'txt' | 'pdf' | 'srt';
  includeAudio: boolean;
  includeImages: boolean;
  includeMetadata: boolean;
  anonymize: boolean;
}

export interface ConversationReplay {
  conversationId: string;
  currentTime: number;
  isPlaying: boolean;
  speed: number;
  currentMessageIndex: number;
}
