import { lazy, Suspense, type ReactNode } from 'react';
import { Route } from 'react-router-dom';
import { VoiceProvider } from './providers/VoiceProvider';
import { MultimodalProvider } from './providers/MultimodalProvider';

const VoiceChatPage = lazy(() => import('./pages/VoiceChatPage').then((m) => ({ default: m.VoiceChatPage })));
const MultimodalChatPage = lazy(() => import('./pages/MultimodalChatPage').then((m) => ({ default: m.MultimodalChatPage })));
const CameraPage = lazy(() => import('./pages/CameraPage').then((m) => ({ default: m.CameraPage })));
const SettingsPage = lazy(() => import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })));
const VoiceDashboard = lazy(() => import('./dashboard/VoiceDashboard').then((m) => ({ default: m.VoiceDashboard })));

const PageWrapper = ({ children }: { children: ReactNode }) => (
  <Suspense
    fallback={
      <div className="flex h-screen items-center justify-center bg-slate-950">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-violet-500/20 border-t-violet-500" />
      </div>
    }
  >
    {children}
  </Suspense>
);

export const voiceMultimodalRoutes = [
  <Route
    key="voice-chat"
    path="/voice/voice-chat"
    element={
      <PageWrapper>
        <VoiceProvider>
          <VoiceChatPage />
        </VoiceProvider>
      </PageWrapper>
    }
  />,
  <Route
    key="multimodal-chat"
    path="/voice/multimodal-chat"
    element={
      <PageWrapper>
        <MultimodalProvider>
          <MultimodalChatPage />
        </MultimodalProvider>
      </PageWrapper>
    }
  />,
  <Route
    key="camera"
    path="/voice/camera"
    element={
      <PageWrapper>
        <CameraPage />
      </PageWrapper>
    }
  />,
  <Route
    key="settings-voice"
    path="/voice/settings/voice"
    element={
      <PageWrapper>
        <SettingsPage />
      </PageWrapper>
    }
  />,
  <Route
    key="voice-dashboard"
    path="/voice/dashboard/voice"
    element={
      <PageWrapper>
        <VoiceDashboard />
      </PageWrapper>
    }
  />,
];
