import type { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { AudioPlayer } from '../audio/AudioPlayer';

interface VoiceLayoutProps {
  children: ReactNode;
}

const navItem = 'rounded-2xl bg-black/20 px-4 py-3 hover:bg-white/10 transition';

export function VoiceLayout({ children }: VoiceLayoutProps) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen bg-slate-950 text-slate-200">
      <div className="mx-auto grid min-h-screen w-full max-w-7xl gap-6 p-4 lg:grid-cols-[280px_1fr] lg:p-6">
        <aside className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glow">
          <div className="text-xs uppercase tracking-[0.25em] text-slate-500">Frox AI</div>
          <h1 className="mt-2 text-2xl font-semibold">Phase 8</h1>
          <p className="mt-2 text-sm text-slate-400">Voice AI + Multimodal Intelligence Engine</p>
          <div className="mt-6 grid gap-2 text-sm text-slate-300">
            <Link className={navItem} to="/voice/voice-chat">Voice chat</Link>
            <Link className={navItem} to="/voice/multimodal-chat">Multimodal chat</Link>
            <Link className={navItem} to="/voice/camera">Camera</Link>
            <Link className={navItem} to="/voice/settings/voice">Settings</Link>
            <Link className={navItem} to="/voice/dashboard/voice">Dashboard</Link>
          </div>
        </aside>
        <main className="grid gap-6">
          {children}
          <AudioPlayer />
        </main>
      </div>
    </motion.div>
  );
}
