import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      boxShadow: {
        glow: '0 0 0 1px rgba(148,163,184,0.08), 0 10px 40px rgba(0,0,0,0.35)',
      },
      backgroundImage: {
        'radial-soft':
          'radial-gradient(circle at top, rgba(99,102,241,0.18), transparent 34%), radial-gradient(circle at bottom right, rgba(168,85,247,0.12), transparent 28%)',
      },
    },
  },
  plugins: [],
} satisfies Config;
