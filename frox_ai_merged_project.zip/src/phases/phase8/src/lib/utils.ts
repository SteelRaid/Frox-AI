import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { v4 as uuidv4 } from 'uuid'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function createId(prefix = 'id') {
  return `${prefix}_${uuidv4().replace(/-/g, '').slice(0, 12)}`
}

export function formatBytes(bytes: number, decimals = 1) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B'
  const k = 1024
  const dm = Math.max(0, decimals)
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(k)), sizes.length - 1)
  const value = bytes / Math.pow(k, i)
  return `${value.toFixed(dm)} ${sizes[i]}`
}

export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function validatePassword(password: string): {
  isValid: boolean
  strength: number
  errors: string[]
} {
  const errors: string[] = []
  let strength = 0
  if (password.length >= 8) strength += 1
  else errors.push('At least 8 characters')
  if (/[A-Z]/.test(password)) strength += 1
  else errors.push('At least one uppercase letter')
  if (/[a-z]/.test(password)) strength += 1
  else errors.push('At least one lowercase letter')
  if (/[0-9]/.test(password)) strength += 1
  else errors.push('At least one number')
  if (/[^A-Za-z0-9]/.test(password)) strength += 1
  else errors.push('At least one special character')
  return { isValid: errors.length === 0, strength, errors }
}
