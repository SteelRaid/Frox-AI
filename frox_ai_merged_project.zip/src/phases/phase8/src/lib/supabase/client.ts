import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

function createFallbackClient() {
  const table = () => ({
    select: () => table(),
    insert: async () => ({ data: null, error: null }),
    upsert: async () => ({ data: null, error: null }),
    update: () => table(),
    delete: () => table(),
    eq: () => table(),
    in: () => table(),
    order: () => table(),
    limit: () => table(),
    single: async () => ({ data: null, error: null }),
  })
  return {
    from: (_name: string) => table(),
    storage: {
      from: (_bucket: string) => ({
        upload: async () => ({ data: null, error: null }),
        remove: async () => ({ data: null, error: null }),
        getPublicUrl: (path: string) => ({ data: { publicUrl: `local://${path}` } }),
      }),
    },
    channel: () => ({ on: () => createFallbackClient().channel(), subscribe: () => ({ unsubscribe: () => void 0 }) }),
  } as any
}

export const supabase = url && anonKey ? createClient(url, anonKey) : createFallbackClient()
