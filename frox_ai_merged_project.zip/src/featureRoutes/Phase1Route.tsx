import Phase1 from '../phases/phase1/FroxAI_Phase1'

export default function Phase1Route() {
  return <Phase1 />
}
