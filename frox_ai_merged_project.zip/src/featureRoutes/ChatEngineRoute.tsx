import { AppProvider } from '../phases/phase4/src/providers/index'
import { App as ChatEngineApp } from '../phases/phase4/src/App'
import '../phases/phase4/src/styles/index.css'

export default function ChatEngineRoute() {
  return (
    <AppProvider>
      <ChatEngineApp />
    </AppProvider>
  )
}
