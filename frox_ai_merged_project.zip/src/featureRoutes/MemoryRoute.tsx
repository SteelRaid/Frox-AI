import { AppProvider } from '../phases/phase7/src/providers/index'
import MemoryApp from '../phases/phase7/src/App'
import '../phases/phase7/src/styles/index.css'

export default function MemoryRoute() {
  return (
    <AppProvider>
      <MemoryApp />
    </AppProvider>
  )
}
