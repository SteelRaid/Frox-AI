import Phase6Chat from '../phases/phase6/src/Phase6Chat'

export default function ChatModuleRoute() {
  return <Phase6Chat />
}
