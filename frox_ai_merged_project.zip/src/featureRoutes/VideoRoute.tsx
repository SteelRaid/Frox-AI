import { CreateVideoTab } from '../phases/phase5/src/features/video'

export default function VideoRoute() {
  return (
    <div className="min-h-screen bg-slate-950 p-4 md:p-6">
      <CreateVideoTab />
    </div>
  )
}
