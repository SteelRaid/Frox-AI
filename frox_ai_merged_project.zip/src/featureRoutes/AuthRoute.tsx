import { AuthProvider } from '../phases/phase2/src/contexts/AuthContext'
import AuthApp from '../phases/phase2/src/App'
import '../phases/phase2/src/styles/globals.css'

export default function AuthRoute() {
  return (
    <AuthProvider>
      <AuthApp />
    </AuthProvider>
  )
}
