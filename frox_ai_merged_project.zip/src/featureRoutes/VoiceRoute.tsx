import VoiceApp from '../phases/phase8/App'
import './voice-route.css'
import '../phases/phase8/index.css'

export default function VoiceRoute() {
  return <VoiceApp />
}
