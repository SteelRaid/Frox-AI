import { lazy, Suspense } from 'react'
import { Link, Navigate, Route, Routes } from 'react-router-dom'
import { Camera, MessageSquare, Mic, Sparkles, Video, Brain, ShieldCheck } from 'lucide-react'

const Phase1Route = lazy(() => import('./featureRoutes/Phase1Route'))
const AuthRoute = lazy(() => import('./featureRoutes/AuthRoute'))
const ChatEngineRoute = lazy(() => import('./featureRoutes/ChatEngineRoute'))
const ChatModuleRoute = lazy(() => import('./featureRoutes/ChatModuleRoute'))
const MemoryRoute = lazy(() => import('./featureRoutes/MemoryRoute'))
const VoiceRoute = lazy(() => import('./featureRoutes/VoiceRoute'))
const VideoRoute = lazy(() => import('./featureRoutes/VideoRoute'))

function Loader() {
  return (
    <div className="grid min-h-screen place-items-center">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-violet-400/25 border-t-violet-400" />
    </div>
  )
}

function Home() {
  const cards = [
    { to: '/phase-1', title: 'Phase 1', text: 'Legacy Frox AI UI concept', icon: Sparkles },
    { to: '/auth/welcome', title: 'Phase 2', text: 'Supabase auth flow', icon: ShieldCheck },
    { to: '/chat-engine', title: 'Phase 4', text: 'Streaming chat engine', icon: MessageSquare },
    { to: '/chat-module', title: 'Phase 6', text: 'Conversation module', icon: Camera },
    { to: '/memory', title: 'Phase 7', text: 'Memory engine', icon: Brain },
    { to: '/voice', title: 'Phase 8', text: 'Voice + multimodal', icon: Mic },
    { to: '/video', title: 'Phase 5', text: 'Video creation tab', icon: Video },
  ]

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6 rounded-3xl border border-white/10 bg-white/5 p-6 shadow-glow backdrop-blur-xl">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-violet-400/20 bg-violet-500/10 px-3 py-1 text-xs text-violet-100">
            Frox AI Unified
          </div>
          <h1 className="text-3xl font-semibold tracking-tight md:text-5xl">One project for all 8 phases</h1>
          <p className="mt-3 max-w-2xl text-sm text-slate-300 md:text-base">
            Open the phase you need from the launcher below. Each phase keeps its own code and runs as one app shell.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {cards.map((card) => {
            const Icon = card.icon
            return (
              <Link
                key={card.to}
                to={card.to}
                className="group rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glow transition hover:-translate-y-0.5 hover:border-violet-400/30 hover:bg-white/8"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-violet-400/20 bg-violet-500/10 text-violet-100">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="text-lg font-semibold">{card.title}</div>
                <div className="mt-1 text-sm text-slate-300">{card.text}</div>
              </Link>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/phase-1" element={<Phase1Route />} />
        <Route path="/auth/*" element={<AuthRoute />} />
        <Route path="/chat-engine/*" element={<ChatEngineRoute />} />
        <Route path="/chat-module" element={<ChatModuleRoute />} />
        <Route path="/memory/*" element={<MemoryRoute />} />
        <Route path="/voice" element={<Navigate to="/voice/dashboard/voice" replace />} />
        <Route path="/voice/*" element={<VoiceRoute />} />
        <Route path="/video" element={<VideoRoute />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  )
}
