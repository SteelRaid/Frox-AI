/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx,js,jsx}'],
  theme: {
    extend: {
      boxShadow: {
        glow: '0 0 30px rgba(91, 91, 246, 0.18)',
      },
    },
  },
  plugins: [],
}
